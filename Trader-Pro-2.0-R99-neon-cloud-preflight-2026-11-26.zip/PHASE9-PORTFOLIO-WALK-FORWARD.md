# Phase 9 — portefeuille multi-actifs : scoreboard walk-forward OOS

Date : 23 novembre 2026  
Statut : brique logicielle ajoutée et testée localement ; validation financière réelle toujours ouverte.

## Périmètre livré

Le module `research_v1/backtesting/portfolio_scoreboard.py` évalue les sept stratégies de portefeuille de V1 sur un univers synchronisé. Route authentifiée :

`POST /api/research/portfolio-strategies/scoreboard`

Exemple de corps :

```json
{
  "symbols": ["AAPL", "MSFT", "NVDA"],
  "benchmark_symbol": "SPY",
  "limit": 2000,
  "warmup": 60,
  "test_window": 126,
  "min_oos_bars": 756,
  "min_folds": 6,
  "fee": 0.0005,
  "slippage": 0.0005,
  "fundamentals_by_symbol": {
    "AAPL": [{"available_at": "2025-02-05T21:10:00Z", "as_of": "2024-Q4", "eps": 2.40, "growth_pct": 8.5, "margin_pct": 25.0}],
    "MSFT": [{"available_at": "2025-01-30T21:10:00Z", "as_of": "2024-Q4", "eps": 3.20, "growth_pct": 12.0, "margin_pct": 35.0}],
    "NVDA": [{"available_at": "2025-02-26T21:10:00Z", "as_of": "2024-Q4", "eps": 0.90, "growth_pct": 45.0, "margin_pct": 55.0}]
  }
}
```

*Les valeurs et horodatages de cet exemple sont illustratifs : chaque `available_at` doit être remplacé par la date/heure de publication réellement documentée par la source fondamentale choisie.*

Le moteur parcourt les 7 stratégies avec des paramètres figés ; Multi-Factor ne peut être effectivement évaluée que si des snapshots fondamentaux point-in-time sont fournis pour tous les titres de l'univers. Le portefeuille simulé est continu d'une fenêtre OOS à la suivante : les fenêtres sont des segments chronologiques de reporting, pas des redémarrages avec capital neuf. Les décisions sont prises à la clôture et exécutées à l'ouverture suivante. Les frais et le glissement sont imputés aux transactions. Le rapport compare à un benchmark passif équipondéré et au symbole de marché demandé (SPY par défaut).

Les garde-fous statistiques et de robustesse sont :

- warmup minimal déterminé par la stratégie et ses paramètres (Momentum 12–1 : 253 barres ; Dual Momentum : lookback ; Low Volatility : au moins 200 barres et sa fenêtre de volatilité ; RS Rotation : au moins 200 barres et sa fenêtre RS ; Multi-Factor : 130 barres) ;
- seuil Bonferroni bilatéral sur l'ensemble du catalogue de 50 stratégies (43 par titre + 7 portefeuille), même si le tableau courant n'en affiche que sept ;
- t-stat de surperformance quotidienne avec variance Newey-West et cinq retards maximum ;
- minimum par défaut de 756 séances OOS et six fenêtres de 126 séances ;
- cohérence de la surperformance d'une fenêtre à l'autre ;
- second backtest en doublant frais et glissement ;
- verdicts limités à `prometteuse`, `à surveiller`, `non démontrée` ou `rejetée` ; aucun verdict `fiable`.

La stratégie de rééquilibrage reçoit par défaut des poids équipondérés si aucun objectif n'est fourni. Multi-Factor est traitée séparément : un backtest historique doit recevoir pour chacun des titres une liste de snapshots fondamentaux triés par `available_at` (timestamp ISO 8601 avec fuseau horaire), avec `eps`, `growth_pct` et/ou `margin_pct`. `available_at` doit être l'instant où l'information était réellement accessible au public ; `as_of` identifie la période financière à laquelle elle se rapporte et ne remplace jamais `available_at`. À chaque séance, seul le dernier snapshot publié à cette date ou avant est utilisé. Les valeurs statiques actuelles sont refusées pour éviter le biais de regard vers le futur. Le scoreboard marque Multi-Factor `evaluated=false` et `blocked_by=point_in_time_fundamentals_missing` si ces snapshots sont absents ; le `evaluated_count` et la correction de tests multiples restent explicites. Des paramètres inconnus ou mal formés sont refusés. Les historiques d'actifs et le benchmark doivent partager exactement les mêmes horodatages. Les horodatages doivent être timezone-aware et strictement croissants ; volumes négatifs, symboles dupliqués après normalisation et données OHLC incohérentes sont rejetés.

Le rapport inclut l'exposition OOS, le nombre de transactions clôturées, le drawdown, la volatilité, le Sharpe, les rendements annualisés, la surperformance par fenêtre, la comparaison benchmark, le scénario de coûts doublés et la statistique HAC. Le backtest enregistre aussi les poids de chaque actif et des liquidités à chaque clôture ; le scoreboard en déduit, pour l'OOS, les poids moyens et maximaux par titre, le pourcentage de séances exposées, le HHI de concentration des positions et le nombre maximal de positions simultanées. Ces mesures constituent une mesure d'exposition par actif, pas encore une validation sectorielle, factorielle ou de liquidité. Il fournit également une matrice de corrélation des rendements quotidiens nets des stratégies évaluées, sur leur période OOS commune, ainsi qu'un indicateur de paires fortement corrélées parmi les candidates. Cette matrice ne constitue pas un contrôle des secteurs, des facteurs ou des risques de liquidité. Le moteur de recherche ne dispose d'aucun import de courtier et renvoie explicitement `broker_access=false`, `orders_created=0`, `strategies_activated=0`. Une prévisualisation de sélection n'autorise jamais le capital : elle indique toujours 100 % de liquidités. Sans candidat, elle reste en attente ; avec candidat, le statut est `REVIEW_REQUIRED` et une revue de corrélation stratégique, d'exposition réelle par actif/secteur, de liquidité, de drawdown et de risque est nécessaire avant tout test Paper.


## Renforcement du scoreboard des 43 règles individuelles

Le module `research_v1/backtesting/scoreboard.py`, utilisé par `POST /api/research/strategies/scoreboard`, ne traite plus les transactions comme des observations indépendantes pour conclure à une surperformance. Chaque titre est simulé avec son capital initial identique, puis les lignes sont agrégées dans un portefeuille à capital initial équipondéré. Le verdict utilise le t-stat Newey-West HAC des rendements journaliers de ce portefeuille moins ceux de l'achat-conservation agrégé (cinq retards maximum). Le t-stat calculé sur les trades est conservé uniquement à titre descriptif.

Une transaction n'est comptée dans l'espérance et le nombre de trades OOS que si ses indices d'entrée ET de sortie se situent dans la période OOS. Une position ouverte pendant l'apprentissage et clôturée après le split continue de contribuer aux rendements journaliers OOS marqués au marché, mais elle n'est pas comptée comme un trade OOS intégral. Tous les titres de l'univers et tous les benchmarks doivent avoir exactement les mêmes horodatages, timezone-aware et strictement croissants. Les paramètres statistiques et de coûts sont validés ; les benchmarks incomplets, désynchronisés ou mal horodatés sont rejetés.

La correction Bonferroni reste appliquée à la famille de 50 stratégies, même si le tableau individuel ne montre que 43 règles. Cette correction ne neutralise pas à elle seule toutes les dépendances entre actifs, stratégies et régimes de marché : une validation multi-univers, par secteur et sur plusieurs régimes reste nécessaire.

## Corrections de qualité réalisées pendant cette passe

- Correction de l'horodatage de preuve de la stratégie Multi-Factor : l'évidence utilise maintenant la barre au curseur courant, et non la dernière barre de l'historique complet.
- Contrat de fondamentaux point-in-time : validation des timestamps timezone-aware et strictement croissants, valeurs numériques finies, snapshots disponibles uniquement à partir de `available_at`. Sans historique publié et daté pour chaque titre, Multi-Factor n'est pas évaluée ; les valeurs statiques sont refusées.
- Test HTTP ajouté : le backtest Multi-Factor sans snapshots point-in-time est rejeté (422).
- Correction du calcul du rendement d'une transaction clôturée : le coût d'achat était déjà inclus dans le prix de revient moyen ; la commission acheteuse n'est plus appliquée une deuxième fois dans le rendement affiché.
- Ajout d'une courbe quotidienne des poids par actif et en liquidités ; le scoreboard expose le poids moyen/maximal, les jours investis, le HHI moyen de concentration et le nombre maximal de lignes détenues. Les revues secteur et liquidité restent non validées.
- Validation des timestamps croissants, des fuseaux horaires et des volumes non négatifs.
- Rejet des symboles qui deviennent doublons après conversion en majuscules.
- Le warmup des routes de backtest est automatiquement relevé pour couvrir les périodes réellement requises par la stratégie.

## Validation locale

- Suite complète : **702 passed, 11 skipped, 202 subtests passed**, 2 avertissements de dépréciation FastAPI, aucun échec.
- 31 tests ciblés sur les deux scoreboards, le backtest multi-actifs et les contrats HTTP : passés.
- Compilation Python : passée.
- Test fonctionnel long sur 1 100 barres pseudo-aléatoires synthétiques : sept lignes de stratégie sont retournées ; six sont évaluées et Multi-Factor est bloquée sans fondamentaux point-in-time. Une candidate a franchi les seuils sur ce jeu artificiel, mais la prévisualisation reste à 100 % cash avec revue obligatoire et zéro capital autorisé ; aucun ordre/activation. Résultats synthétiques exclus de toute conclusion de rentabilité.

## Limites non levées

Cette livraison ne prouve pas la rentabilité. Aucune performance sur un historique réel authentifié n'est rapportée dans cette passe. Les résultats dépendront de la source de données, de l'univers, de la période, des corporate actions, des spreads, de la liquidité, du slippage réel et de la fiscalité. Le scénario de coûts doublés n'est pas un modèle d'impact de marché.

PostgreSQL/Neon réel, intégrations Alpaca Paper, build React/PWA, tests navigateur et déploiement worker ne sont pas validés ici. Aucune commande Paper ou Live n'a été envoyée. Live reste verrouillé. Le scoreboard ne modifie ni le registre stratégique actif ni le pipeline d'exécution.

## Étape suivante

1. Alimenter ce scoreboard avec des données OHLCV réelles, ajustées des opérations sur titres, sur plusieurs univers et périodes.
2. Ajouter une validation multi-univers et des tests de biais (survivorship, look-ahead, sélection de paramètres, concentration sectorielle, liquidité et spread).
3. Faire la parité V1/V2 sur mêmes données, puis publier un rapport par actif et par régime de marché.
4. Compléter la revue des expositions par actif/secteur, spreads, liquidité et stress du portefeuille combiné ; le preview reste à 100 % cash et aucun résultat de recherche ne peut rejoindre l'exécution avant les validations PostgreSQL et Alpaca Paper.
