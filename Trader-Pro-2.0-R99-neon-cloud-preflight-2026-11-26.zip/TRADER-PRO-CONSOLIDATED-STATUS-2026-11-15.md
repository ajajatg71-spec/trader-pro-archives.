# Trader Pro 2.0 — consolidated status (2026-11-15, update 2)

This report supersedes older test counts and phase summaries in historical changelogs. It reflects the project archive reviewed on 2026-11-15 and the OOS-boundary correction, block-bootstrap hardening, bootstrap overflow protection, OHLC intrabar engine, and environment setup work performed on the same date.

## Phase position

| Phase | Scope | Status | Evidence / gate |
|---|---|---|---|
| 1 | Audit, backup, security, regression | Base present; original V1 full audit not repeatable from this archive alone | V1 parity and prior audit reports; original V1 ZIP not present in this snapshot |
| 2 | Modular FastAPI backend | Closed for stated software scope | Modular routers/services and Phase 2 closure report |
| 3 | PostgreSQL / SQLAlchemy / Alembic | **Open** | Migrations and integration harness exist; real PostgreSQL migration, concurrency, backup/restore and recovery not run here |
| 4 | Market Data Engine | Implemented locally; operational validation open | Provider adapters and data-quality/freshness tests; no production provider/failover certification |
| 5 | Quantitative Engine | Implemented locally; research validation open | Quantitative services and regression tests; timestamp/data quality remain upstream dependencies |
| 6 | Multi-strategy Strategy Engine | Advanced locally; integration gates open | Strategy registry/pipeline/persistence and tests; no end-to-end PostgreSQL + Alpaca Paper certification |
| 7 | Institutional Risk Management | Implemented locally; DB concurrency gate open | Risk controls, durable pause, atomic claims, partial-fill and liquidity checks; PostgreSQL locking not certified on a real server |
| 8 | Execution + broker reconciliation | **Open** | Durable order/fill records, reconciliation, event inbox/listener and workers exist; no authenticated Alpaca Paper lifecycle test, live stream, deployed worker or real PostgreSQL validation |
| 9 | Backtesting + OOS validation | **Partial / in preparation** | Input checks, aggregate reporting, OOS boundary cost accounting, block bootstrap and first OHLC intrabar execution model implemented; execution/data/research limitations remain; no untouched multi-regime holdout study |
| 10 | React/TypeScript web-mobile PWA | Not delivered | Existing HTML dashboard is not the requested React/TypeScript PWA |
| 11 | Docker, workers, monitoring, backups | Files present; deployment/restore gate open | Docker/Compose/scripts/workflows exist; no deployed environment or evidenced restore drill |
| 12 | Final validation, Paper trading, Live authorization | Not reached | No authenticated Alpaca Paper validation; Live stays disabled |

## Reproduced local verification — 2026-11-15

- Backtest tests: **56 passed, 93 subtests passed**.
- Full pytest: **551 passed, 10 skipped, 177 subtests passed**.
- Unittest discovery: **547 passed**.
- Python `compileall`: passed.
- Environment probe: SQLAlchemy and Alembic are importable; `psycopg` and `psycopg2` are absent; `TRADER_PRO_TEST_DATABASE_URL`, `APCA_API_KEY_ID` and `APCA_API_SECRET_KEY` are absent; Docker, Podman, psql and pg_dump were not found on PATH. A Windows PowerShell PostgreSQL validation script and an environment runbook were added, but neither could be executed in this Linux session because PowerShell and PostgreSQL client/server tools are unavailable.

The ten skipped tests are not PostgreSQL passes. No authenticated Alpaca request, order submission or cancellation was performed.

## Phase 9 correction

The OOS metric window previously began at the first test close. If the signal generated at the last training close entered at the first test close, the entry fee/slippage was included in equity but excluded from measured OOS return. `optimize()` and `walk_forward()` now include the final training close as the return anchor, and walk-forward stitching includes each fold's first test-bar return. Exposure is recomputed over actual OOS bars. Regression tests verify a flat-price, 1%-fee case produces the expected -1% initial OOS cost.

## Critical blockers

1. Configure a disposable PostgreSQL 16 environment and run migrations, integration/concurrency tests, backup/restore and restart recovery.
2. Configure Alpaca Paper credentials only as protected environment secrets; run the read-only verification first. Do not paste keys into chat.
3. After read-only success, obtain separate explicit authorization before running the one-order Paper smoke test. No order submission/cancellation was performed in this work.
4. Validate the Alpaca trade-updates listener, missed-event recovery and independent periodic reconciliation against the real Paper API and PostgreSQL.
5. Continue research-grade Phase 9 validation: intrabar OHLC execution, gaps, partial fills, spread/impact/latency, corporate actions, point-in-time universe integrity, sensitivity to block size and untouched final holdout.

## Environment unblockers added

- `scripts/verify_postgres.ps1` provides a Windows PowerShell path for migrations, PostgreSQL integration tests, dump, restore and schema verification. It refuses unsafe database names and a non-empty restore target.
- `PHASE8-REAL-ENVIRONMENT-BLOCKER-SOLUTIONS-2026-11-15.md` documents Docker Desktop/WSL2, native PostgreSQL and managed disposable PostgreSQL alternatives, plus the read-only Alpaca Paper procedure.
- The existing Alpaca read-only script remains the first external broker gate. The separate Paper order smoke test remains opt-in and was not run.

## Safety decisions

- Keep Phases 3 and 8 open until external gates pass.
- Phase 9 may be audited and hardened in parallel, but is not formally closed or release-certified.
- Keep autonomous order flow gated; keep Live mode disabled.
- Preserve original V1 calculation parity unless a deliberate, measured change is approved.


## Additional bootstrap overflow correction

An adversarial finite-input case reproduced infinite bootstrap percentiles from multiplication overflow. The implementation now compounds in log space and fails explicitly if the resulting percentage is outside finite floating-point range. Regression coverage added. Current counts: **540 pytest passed, 10 skipped, 127 subtests; 536 unittest passed; compileall passed**.

## Latest follow-up — backtest contract validation (2026-11-15)

`evaluate()` now validates the full result contract (equity, 0/1 positions, and finite in-range trade records) rather than accepting malformed exposure/trade data. Built-in strategy parameter sets are validated before execution. All shipped built-in parameter grids were exercised in regression tests.

Latest reproduced verification: **544 pytest passed, 10 skipped, 177 subtests passed; 540 unittest passed; compileall passed**. Backtest-specific suite: **49 passed, 93 subtests passed**. The ten skipped tests remain PostgreSQL tests. No real PostgreSQL connection or Alpaca Paper API request was possible, and no orders were submitted.


## Latest follow-up — OHLC execution model (2026-11-15)

A distinct `run_ohlc()` path now models next-open strategy execution, opening gaps, intrabar stop/target touches, conservative stop-first ambiguity handling and stop cooldown. The legacy close-only `run()` path is unchanged. This is a bounded first model, not an institutional execution simulator: volume, spread, impact, latency, partial fills, corporate actions and portfolio-level OHLC execution remain outside scope.

Latest reproduced verification: **551 pytest passed, 10 skipped, 177 subtests passed; 547 unittest passed; compileall passed**. Backtest suite: **56 passed, 93 subtests passed**. PostgreSQL tests remain skipped; no external broker calls or orders were made.

## Latest follow-up — OHLC sizing parity (2026-11-15)

`run_ohlc()` now supports the established optional volatility sizing contract (`risk`, `k`, `max_frac`) and leaves the unused cash uninvested. The sizing volatility estimate uses only closes strictly before the entry bar; when history is insufficient, the documented `max_frac` fallback is used. The original close-only engine remains unchanged. Tests cover fallback, volatility-derived sizing and invalid configuration.

Latest reproduced verification: **554 pytest passed, 10 skipped, 177 subtests passed; 550 unittest passed; compileall passed**. Backtest-specific suite: **59 passed, 93 subtests passed**. The 10 skipped tests remain PostgreSQL integration tests. No real PostgreSQL validation, authenticated Alpaca call, or order submission/cancellation occurred.

## Latest follow-up — OHLC numeric overflow guards (2026-11-15)

Adversarial finite-input testing reproduced two OHLC failure modes: overflow in share quantity during entry sizing, and overflow in mark-to-market portfolio equity. `run_ohlc()` now fails closed with explicit `OverflowError` for non-representable entry sizing, cash balances, exit proceeds, trade returns and marked equity. The close-only legacy engine was not changed. Two regression tests reproduce the quantity and valuation cases.

Latest reproduced verification: **556 pytest passed, 10 skipped, 177 subtests passed; 552 unittest passed; compileall passed**. Backtest-specific suite: **61 passed, 93 subtests passed**. The ten skipped tests remain PostgreSQL integration tests. No real PostgreSQL connection, authenticated Alpaca request, or Paper order submission/cancellation was performed.


## Latest follow-up — open-order reservation hardening (2026-11-15)

An execution-path audit found that institutional pre-trade reservation totals were fetched from only the first 50 open broker orders. This could understate reserved buying power when an account had more than 50 open orders. The approval path now requests up to 10,000 records using the broker adapter's paginated interface, blocks if the result reaches the safety ceiling (potential truncation), rejects malformed snapshots and missing/invalid buy-order notionals, and sums reservations with `math.fsum`. Failure blocks approval before broker submission. Regression tests cover 75 open orders, a potentially truncated 10,000-order snapshot, and a buy order with missing notional.

Latest reproduced verification: **559 pytest passed, 10 skipped, 177 subtests passed; 555 unittest passed; compileall passed**. Focused order/risk suites: **71 passed**. The 10 skipped tests remain PostgreSQL integration tests. No real PostgreSQL validation, authenticated Alpaca call, order submission or cancellation was performed. Phase 8 remains open.

## Follow-up — atomic aggregate buy reservations (2026-11-15)

- Added a final transactional reservation gate to the durable order claim.
- PostgreSQL serializes Trader Pro claims on the singleton durable pause row; within that transaction, the repository merges local non-terminal buy intents with the complete broker open-buy snapshot and checks both aggregate cash/gross headroom and per-symbol `max_pos` headroom.
- Broker/local duplicates are counted once only if broker ID, symbol, and notional agree. Unknown or inconsistent local reservations block the claim.
- Added a real PostgreSQL concurrency integration test: two concurrent 100 USD claims against a 150 USD ceiling must yield one accepted claim and one blocked/audited claim.
- Added disposable PostgreSQL 16 Docker Compose environments and Windows/Unix runners: `compose.test.yaml`, `scripts/run_postgres_container_tests.sh`, and `.ps1`.
- Latest local verification: **563 pytest passed, 11 skipped, 177 subtests passed**; **559 unittest passed**; compileall passed.
- The 11 skipped tests are opt-in PostgreSQL integration tests. Docker/Podman and PostgreSQL binaries are absent from this current runtime, so the PostgreSQL concurrency test is prepared but not executed here. Run the disposable Docker script or `.github/workflows/postgres-integration.yml` to obtain real PostgreSQL evidence.
- No Alpaca Paper order was submitted or cancelled; Live remains disabled.

## Phase 8 follow-up — broker event lease fencing (2026-11-15)

The durable broker-event inbox now uses a per-claim UUID fencing token. A worker can finalize an event only while it still owns the exact `processing_token`; a worker whose lease was reclaimed cannot overwrite the new owner's success or failure state. Added migration `b8d2f4a6c901` (single Alembic head).

Verification on this archive: `pytest -q` = 568 passed, 11 skipped, 187 subtests passed; `python -m unittest discover -q` = 564 passed; `compileall` passed; Alembic `upgrade head` and `current` passed on a temporary SQLite database. This does not certify PostgreSQL concurrency: the 11 PostgreSQL-dependent tests remain skipped, and Alpaca Paper has not been accessed.

## Latest follow-up — strict rejection of malformed broker snapshots (2026-11-15)

A reconciliation audit found that non-dictionary elements in broker order/fill/position lists were silently skipped. This could allow an incomplete response to be treated as a complete snapshot. Reconciliation now rejects malformed list elements immediately after broker reads and before stale-submission recovery or any database write. Added three tests proving malformed order, fill, and position entries abort without snapshots, order changes, fills, or reconciliation evidence.

Fresh verification after this change: `pytest -q` = **571 passed, 11 skipped, 187 subtests passed**; `python -m unittest discover -q` = **567 passed**; `compileall` passed. Targeted reconciliation suite: **27 passed**. SQLite Alembic upgrade to head had passed immediately before this code-only change; migrations were not modified.

Environment audit: latest archive was retrieved from the Library and ZIP integrity passed. Existing Docker Compose PostgreSQL 16 test setup, GitHub Actions PostgreSQL integration workflow, Windows test workflow, Alpaca Paper read-only workflow, and separately gated Paper order/cancel smoke workflow are already present. This execution runtime has no Docker/Podman, PostgreSQL server/client binaries, or `psycopg` driver, and no Alpaca Paper secrets are configured. Therefore PostgreSQL integration/backup-restore and authenticated Alpaca Paper checks remain unexecuted. The 11 skipped tests are PostgreSQL integration tests. No broker orders were submitted or cancelled; Live remains disabled.

## Phase 8 follow-up — strict Alpaca FILL snapshot validation (2026-11-15)

- `broker.fills()` now rejects malformed or incomplete FILL activity rows instead of silently filtering them, validates page bounds and side values, and detects repeated execution IDs/non-progressing pagination.
- Six focused tests cover malformed payloads, incomplete activities, invalid side, successful normalization, duplicate IDs, and page-count validation.
- This is a read-only connector hardening change; no broker write operation was added.
- PostgreSQL and authenticated Alpaca Paper remain unvalidated in a real external environment.

## Phase 8 follow-up — validation des champs d'ordres et positions (2026-11-15)

L'audit du snapshot a montré que le rejet des éléments non-dictionnaires ne suffisait pas : un dictionnaire d'ordre sans statut ou une position avec quantité absente/non finie pouvait encore traverser le contrôle initial. `ReconciliationService` exige maintenant les champs d'identité/statut minimaux pour chaque ordre, un sens `buy`/`sell`, et pour chaque position un symbole unique ainsi qu'une quantité Decimal finie et non nulle. Tous ces contrôles interviennent avant toute écriture en base. Tests ajoutés pour les ordres incomplets, `NaN`, quantités nulles et symboles dupliqués.

Vérification fraîche : **579 pytest passed, 11 skipped, 194 subtests passed** ; **575 unittest passed** ; compileall réussi ; migration SQLite temporaire complète jusqu'à `b8d2f4a6c901` réussie. Les 11 tests PostgreSQL restent ignorés ; aucun Docker/Podman/psql n'est présent dans ce runtime. Aucun appel authentifié Alpaca Paper ni ordre Paper n'a été effectué. Phase 8 reste ouverte ; Live désactivé.

## Phase 8 follow-up — fill snapshot pre-write validation (2026-11-15)

An audit of the alternate-adapter path found that a dictionary-shaped fill with duplicate IDs or invalid numeric fields could reach the write phase even though the native Alpaca connector rejects malformed activities. `ReconciliationService` now validates fill identity, duplicate IDs, optional side, positive finite quantity/price, non-negative finite fee, and timestamp syntax (when supplied) before stale-submission recovery or any database mutation. Missing timestamps retain the existing invalid-fill diagnostic and are never fabricated. Added regressions proving duplicate IDs and invalid numeric values abort before snapshots or ledger writes.

Fresh verification: **581 pytest passed, 11 skipped, 194 subtests passed**; **577 unittest passed**; `compileall` passed; Alembic has one head (`b8d2f4a6c901`). The 11 skipped tests are still PostgreSQL integration tests. Docker/Podman/psql and authenticated Alpaca Paper credentials remain unavailable in this runtime. No broker order was submitted/cancelled; Live remains disabled. Phase 8 remains open.

## Phase 8 follow-up — mandatory fill-side validation (2026-11-15)

The central reconciliation boundary previously allowed a dictionary-shaped fill without `side`, even though the Alpaca adapter itself requires it. `ReconciliationService` now requires every fill to carry a valid `buy` or `sell` side and rejects missing/blank/unsupported values before any stale-submission recovery or database write. Updated valid fixtures and added a regression test proving no account snapshot, fill, or reconciliation evidence is written for a side-less fill.

Fresh verification: **582 pytest passed, 11 skipped, 194 subtests passed** (complete run output); **578 unittest passed**; compileall passed; Alembic has one head (`b8d2f4a6c901`); complete migration upgrade/current succeeded on temporary SQLite. The 11 PostgreSQL integration tests remain skipped; no real PostgreSQL or authenticated Alpaca Paper validation occurred. No broker order was submitted or cancelled; Live remains disabled. Phase 8 remains open.

## Phase 8 follow-up — signed short-position snapshots and numeric preflight (2026-11-16)

A cross-layer mismatch was found: the reconciliation service accepted negative position quantities (valid for short positions), but the SQL repository rejected them. Snapshot persistence now supports signed quantity and market value while enforcing finite numeric fields. It validates optional average entry price and unrealized P/L, preserves Decimal values for SQL, and serializes audit JSON decimals as strings. Account and position numeric fields are now preflighted before stale-submission recovery or any database mutation.

Regression tests prove a short position is persisted and malformed `NaN` market value / infinite equity are rejected before local order recovery or snapshots.

Fresh verification: **585 pytest passed, 11 skipped, 194 subtests passed**; **581 unittest passed**; compileall passed; Alembic single head `b8d2f4a6c901`; complete SQLite migration upgrade/current passed. The 11 skipped PostgreSQL tests remain unexecuted because this runtime has no Docker/Podman or PostgreSQL service. Authenticated Alpaca Paper remains untested. No broker order was submitted or cancelled; Live remains disabled. Phase 8 remains open.
