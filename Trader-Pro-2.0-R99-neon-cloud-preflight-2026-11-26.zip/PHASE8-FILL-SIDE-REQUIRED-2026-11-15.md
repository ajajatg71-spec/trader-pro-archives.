# Phase 8 — mandatory execution side validation (2026-11-15)

An audit of the alternate broker-adapter path found that reconciliation accepted a fill record with no `side`, although the Alpaca adapter already requires `buy` or `sell`. This left a contract mismatch between the provider adapter and the central reconciliation boundary.

`ReconciliationService` now rejects missing, blank, or unsupported fill sides before stale-submission recovery, account/position snapshots, fill ingestion, or reconciliation evidence writes. Existing fixtures that represent valid fills now include their side. A regression test proves a side-less fill aborts with no account snapshot, fill row, or reconciliation-run row.

Verification on this archive:
- `pytest -vv`: **582 passed, 11 skipped, 194 subtests passed** (the complete run output ended successfully; 30.34 seconds).
- `python -m unittest discover -q`: **578 passed**.
- `python -m compileall -q .`: passed.
- `alembic heads`: one head, `b8d2f4a6c901`.
- Full Alembic upgrade to head and `current` succeeded on a disposable SQLite database.
- The 11 skipped tests remain opt-in PostgreSQL integration tests. No real PostgreSQL service or authenticated Alpaca Paper credentials were available, so neither real PostgreSQL nor Alpaca Paper was validated.
- No broker order was submitted or cancelled. Live remains disabled.

Phase 8 remains open. The next meaningful external gate is running the already-prepared PostgreSQL 16 integration workflow and the read-only Alpaca Paper verification workflow in an environment with the required services/secrets.
