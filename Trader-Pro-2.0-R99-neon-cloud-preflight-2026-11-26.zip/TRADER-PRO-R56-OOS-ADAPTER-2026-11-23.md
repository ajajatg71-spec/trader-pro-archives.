# Trader Pro 2.0 — R56 : raccordement du sélecteur aux résultats OOS

Date : 23 novembre 2026
Base : R55
Statut : adaptateur de recherche livré ; aucune allocation réelle ni activation.

## Objectif
Relier le premier allocateur hybride R55 au format réel de sortie du scoreboard portefeuille walk-forward OOS, sans contourner les contrôles existants.

## Changements
Ajout de `build_hybrid_allocation_from_scoreboard` dans `research_v1/backtesting/hybrid_allocator.py`.

L'adaptateur :
- n'accepte que les lignes `evaluated=True` et `verdict="prometteuse"` ;
- utilise le CAGR OOS, la volatilité OOS et le drawdown maximal OOS ;
- transforme le t-stat HAC en score de confiance borné entre 0 et 1 ;
- utilise le ratio de fenêtres OOS positives comme score de stabilité ;
- réutilise la matrice de corrélation Pearson des rendements journaliers nets sur dates OOS communes ;
- exige un score de liquidité fourni séparément et validé ; il ne l'invente pas à partir des seuls rendements OHLCV ;
- transmet ces facteurs à l'allocateur R55, qui applique les plafonds d'exposition et les règles de diversification.

Si une candidate n'a pas de score de liquidité fourni, elle est rejetée avec `validated_liquidity_score_missing`. Les corrélations manquantes restent traitées de manière conservatrice par le noyau R55.

## Sécurité
- Adaptateur et allocateur restent dans `research_v1/backtesting`.
- Aucun import broker, route API d'ordre, accès compte ou activation de stratégie.
- `capital_authorized=False`, `orders_created=0`, `broker_access=False`.
- Aucun changement de la logique de scoreboard, du moteur d'exécution ou des validations PostgreSQL/Alpaca Paper.
- Les propositions sont des diagnostics de recherche, pas des recommandations d'investissement ni une preuve de rentabilité.

## Tests exécutés
- Tests ciblés allocateur/adaptateur : 14 réussis.
- Suite complète : **823 passed, 11 skipped, 202 subtests passed**.
- Les 11 ignorés sont les tests d'intégration PostgreSQL qui nécessitent une base jetable externe.
- `python -m compileall -q .` : réussi.

## Limites restantes
- Les scores de liquidité ne sont pas encore produits automatiquement par un module de microstructure validé.
- La matrice de corrélation provient des courbes OOS du scoreboard ; il reste à contrôler les régimes, l'instabilité temporelle et les changements de corrélation.
- L'allocateur n'est pas encore relié au simulateur de portefeuille continu ni à un rééquilibrage tenant compte des coûts/turnover.
- Le contrôle institutionnel final doit être appliqué au portefeuille combiné, pas seulement à chaque stratégie isolée.
- PostgreSQL/Neon réel, build React et Alpaca Paper réel restent à valider.
- Rentabilité réelle non démontrée.

## Prochaine étape
R57 : construire un modèle de portefeuille multi-stratégies continu avec des poids cibles datés, rééquilibrage sous contraintes, coûts/turnover et contrôle du risque global. Conserver l'exécution broker séparée et verrouillée.
