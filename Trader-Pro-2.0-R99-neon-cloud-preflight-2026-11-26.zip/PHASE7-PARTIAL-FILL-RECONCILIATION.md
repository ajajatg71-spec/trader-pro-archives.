# Phase 7 — partial-fill and late-fill reconciliation

Date: 2026-11-12

## Changes

- Reconciliation now validates broker `qty` and cumulative `filled_qty` when both are supplied. Values must be finite, non-negative, and within the requested quantity. A broker status of `filled` must agree with a fully filled quantity; `partially_filled` must agree with a strict partial quantity.
- Fill activities are checked against the parent order side before ingestion. A side mismatch is reported as invalid and is not persisted.
- Fill ingestion remains idempotent by broker activity/fill ID. The reconciliation report now includes per-order `fill_quantity_checks` comparing broker cumulative `filled_qty` with the durable fill ledger.
- A mismatch is explicitly warned and makes optional financial reconciliation inconclusive; it is never silently treated as a complete ledger.
- Recently terminal orders (`filled`, `canceled`, `cancelled`, `expired`, `rejected`, `done_for_day`, `replaced`) remain in the local reconciliation window for seven days, allowing late fill activities after cancellation to be ingested and checked.
- No automatic resubmission is introduced. A canceled order with a non-zero `filled_qty` remains canceled at broker status level while its executed quantity is retained in the fill ledger.

## Regression coverage

- Multiple partial fills during cancellation sum to broker cumulative `filled_qty`.
- A missing partial-fill activity produces an explicit quantity mismatch.
- A late fill arriving in a later reconciliation run is ingested for a recently terminal order and resolves the mismatch.
- A fill side inconsistent with the broker order is rejected.
- A broker `filled` status inconsistent with `filled_qty` aborts before account/position snapshot persistence.
- Quantity mismatch prevents financial reconciliation from claiming a complete ledger.

## Local validation

- `python -m pytest -q`: **439 passed, 6 skipped, 88 subtests passed**.
- `python -m unittest discover -q`: **435 tests passed**.
- `python -m compileall -q .`: passed.
- SQLite Alembic migration: reached `f3b8c2d91a64` (`head`).
- FastAPI import: simulation and non-simulation configuration each exposed 35 routes.

## Limitations

- Six PostgreSQL-only tests remain skipped because no real PostgreSQL test URL/server is configured.
- No authenticated Alpaca Paper API request or Paper order was performed in this validation.
- The seven-day local terminal-order window is a bounded late-activity recovery window, not proof of complete broker history. Truncated broker activity snapshots remain inconclusive.
- This does not enable Live trading or authorize automatic retry of ambiguous orders.
