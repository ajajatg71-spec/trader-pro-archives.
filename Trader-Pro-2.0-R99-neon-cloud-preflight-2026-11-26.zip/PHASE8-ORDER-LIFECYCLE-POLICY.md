# Phase 8 — Order lifecycle transition policy

**Status: implemented locally; Phase 8 remains in progress.**

## Problem addressed

Broker snapshots can arrive late or out of order. Blindly copying every broker status into the local ledger can regress a terminal local order (for example, `filled` back to `new`) and can incorrectly propagate that regression to strategy state.

## Implementation

- `services/order_lifecycle.py` defines the known broker/local statuses and an explicit allow-list of status transitions.
- Unknown statuses fail closed and are reported for review.
- Reconciliation evaluates each incoming broker status against the current durable local status before changing the order or synchronizing strategy state.
- A stale/invalid transition is not applied and adds a warning to the reconciliation report.
- Legitimate race outcomes remain supported: `pending_cancel` → `filled` and `canceled` → `filled` when the broker's authoritative snapshot confirms a fill that won the cancellation race.
- Reconciliation still does not automatically resubmit missing or uncertain orders.

## Tests added

- Submission acknowledgement.
- Partial fill to canceled.
- Cancellation/fill race.
- Terminal status cannot regress to active.
- Unknown status fails closed.
- Canceled-to-filled race.
- Rejected status remains terminal.
- Reconciliation-level stale snapshot regression test.
- Reconciliation-level canceled-to-filled race test.

## Verification

- `python -m pytest -q`: 459 passed, 7 skipped, 88 subtests passed.
- `python -m unittest discover -q`: 455 tests passed.
- `python -m compileall -q .`: passed.
- YAML parsing for Compose and all current GitHub workflows: passed.
- 7 PostgreSQL integration tests remain skipped without a real PostgreSQL service.
- No authenticated Alpaca Paper request was made in this environment.

## Remaining work

1. Validate the lifecycle policy against actual Alpaca Paper status sequences and documented edge cases.
2. Add full submit/ack/fill/cancel/restart/reconcile integration scenarios with durable PostgreSQL.
3. Add a structured unresolved-order and discrepancy report with operator actions.
4. Complete real PostgreSQL and Alpaca Paper validation before Phase 8 closure.

Live trading remains disabled.
