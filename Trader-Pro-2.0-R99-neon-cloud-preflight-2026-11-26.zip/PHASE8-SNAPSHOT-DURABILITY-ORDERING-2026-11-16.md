# Phase 8 — snapshot durability before stale-submission recovery (2026-11-16)

A failure-ordering audit found that stale `submitting` orders were reclassified as `submission_unknown` before the validated account/positions snapshot had been durably persisted. If snapshot persistence failed, local order state had already changed despite there being no durable broker snapshot to support the recovery decision.

The reconciliation flow now persists the fully validated account and positions snapshot first. Only after that repository transaction succeeds does it recover stale submissions as `submission_unknown`; this remains a non-retrying action. A snapshot persistence failure therefore leaves stale order lifecycle state unchanged.

Regression coverage added:
- Injected snapshot persistence failure leaves a stale order in `submitting` and creates no account snapshot.
- Injected ORM flush failure while adding a position rolls back the account snapshot, position snapshot, and audit event together.

Verification:
- `python -m pytest -q`: 593 passed, 11 skipped, 194 subtests.
- `python -m unittest discover -q`: 589 passed.
- `python -m compileall -q .`: passed.
- `alembic heads`: one head, `b8d2f4a6c901`.
- Full Alembic upgrade and current revision on a disposable SQLite database: succeeded.

Limits: this is local SQLite/test validation, not PostgreSQL validation. This runtime has no Docker/Podman, PostgreSQL server/client, or psycopg driver. No authenticated Alpaca Paper read was performed and no broker order was submitted or cancelled. Live remains disabled. Phase 8 remains open.
