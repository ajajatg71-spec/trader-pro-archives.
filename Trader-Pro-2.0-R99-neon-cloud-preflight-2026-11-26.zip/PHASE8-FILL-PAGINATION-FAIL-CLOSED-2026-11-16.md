# Phase 8 — garde de pagination des exécutions Alpaca

Date : 2026-11-16

## Constat

`broker.fills(pages=N)` bornait correctement le nombre de pages et détectait les identifiants dupliqués, mais retournait la liste accumulée après la dernière page sans signaler que cette page était pleine. Une page de 100 activités à la limite du budget de pagination ne prouve pas que l'historique est complet : des exécutions plus anciennes peuvent rester derrière le curseur.

## Correction

- Le compteur de page est maintenant explicite.
- Si la dernière page autorisée contient 100 activités, `BrokerError` est levée au lieu de retourner un snapshot potentiellement tronqué.
- Une dernière page partielle reste considérée comme complète.
- La réconciliation reçoit donc une erreur bloquante plutôt qu'un historique d'exécutions incomplet présenté comme normal.

## Tests ajoutés

- Dernière page pleine au plafond : refus avec `BrokerError`.
- Dernière page partielle au plafond : acceptée.

## Vérifications

- `python -m pytest -q tests/test_broker.py tests/test_reconciliation.py` : 57 passed.
- `python -m pytest -q` : 591 passed, 11 skipped, 194 subtests passed.
- `python -m unittest discover -q` : 587 tests OK.

Les tests PostgreSQL restent conditionnels et ne sont pas déclarés validés tant qu'un serveur PostgreSQL réel n'est pas disponible. Aucun ordre Alpaca n'a été soumis ou annulé.
