# Décision d'architecture — univers de marché initial (R61)

Le périmètre initial demandé est limité aux actions et ETF.

Alpaca expose la classe `us_equity` pour les titres actions cotés US et ne garantit pas une sous-classe `us_etf` distincte dans le champ `class`. Trader Pro utilise donc `us_equity` comme famille fournisseur pour les actions et ETF, sans inventer une classification plus fine.

Avant toute approbation d'ordre, le service lit les métadonnées broker (`/v2/assets/{symbol}`), vérifie la correspondance du symbole, la classe `us_equity`, le statut `active` et `tradable=true`. Toute absence, incohérence, inactivité ou classe inconnue bloque l'ordre avant les contrôles de risque et la soumission.

Le mandat global reste : autonomie complète dans les limites du Risk Governor, liquidités disponibles uniquement, sans marge ni fonds empruntés.

La simulation injecte une métadonnée synthétique ; elle ne prouve pas l'éligibilité réelle. La connexion authentifiée Alpaca Paper et la vérification réelle de la classification ETF restent à effectuer. Live reste verrouillé.
