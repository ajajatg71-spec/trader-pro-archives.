"""Test réel sur le compte PAPER : compte, positions, ordres, exécution, statut, annulation, doublon.
Lance : python smoke_test.py   (clés Alpaca paper dans les variables d'environnement)"""
import sys, time, uuid

def main():
    import broker

    def step(name, fn):
        try:
            r = fn(); print("OK     ", name); return r
        except Exception as e:
            print("ÉCHEC  ", name, "->", e); return None

    a = step("Compte", broker.account)
    if not a: sys.exit("Vérifie les clés (APCA_API_KEY_ID / APCA_API_SECRET_KEY) et l'URL paper.")
    print("   équité", a["equity"], "| cash", a["cash"], "| statut", a["status"])
    c = step("Horloge", broker.clock); print("   bourse ouverte :", c and c["is_open"])
    p = step("Positions", broker.positions); print("   ", len(p or []), "position(s)")
    step("Liste des ordres", lambda: broker.orders("all", 5))
    step("Bougies AAPL (données de marché)", lambda: print("   ", len(broker.bars("AAPL")), "bougies"))
    step("Actualités AAPL", lambda: print("   ", len(broker.news("AAPL")), "titres"))
    step("Historique des exécutions", lambda: print("   ", len(broker.fills()), "exécution(s)"))
    cid = "smoke-" + uuid.uuid4().hex[:8]
    o = step("Ordre test 1 $ AAPL", lambda: broker.order("AAPL", "buy", 1.0, cid))
    if o:
        time.sleep(2)
        g = step("Statut de l'ordre", lambda: broker.order_get(o["id"])); print("   statut :", g and g["status"])
        d = step("Doublon (même client_order_id)", lambda: broker.order("AAPL", "buy", 1.0, cid))
        print("   doublon renvoie le même ordre :", bool(d) and d["id"] == o["id"])
        if g and g["status"] not in ("filled", "canceled"):
            step("Annulation", lambda: broker.cancel(o["id"]))
        else:
            print("   déjà exécuté ou annulé : annulation impossible (normal)")

if __name__ == "__main__":
    main()
