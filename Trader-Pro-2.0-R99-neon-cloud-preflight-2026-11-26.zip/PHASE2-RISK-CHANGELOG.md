# Trader Pro 2.0 — Phase 2 risk router

## Scope
- Extracted the read-only `GET /api/risk` endpoint into `routers/risk.py`.
- Added a router factory with injected authentication guard and risk snapshot reader.
- Kept the existing risk snapshot composition and all financial calculations in the application/service layer; no formulas or thresholds were changed.
- Existing order pause/approval controls remain in the orders router and legacy domain handlers.

## Validation
- Re-run compileall, unittest, pytest, application import, and route registration checks before release.
- No broker credentials, paper orders, or live orders are used in validation.
