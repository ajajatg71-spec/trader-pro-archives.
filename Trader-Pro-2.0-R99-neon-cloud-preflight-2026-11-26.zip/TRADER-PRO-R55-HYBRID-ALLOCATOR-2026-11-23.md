# Trader Pro 2.0 — R55 : premier allocateur hybride multi-facteurs

Date : 23 novembre 2026
Base : archive R54 reçue dans la conversation
Statut : incrément de recherche uniquement ; aucune intégration à l'exécution broker.

## Objectif
Commencer la concrétisation du modèle C : sélectionner et pondérer plusieurs stratégies en combinant plusieurs dimensions plutôt qu'un seul classement de performance.

## Ajout
Nouveau module `research_v1/backtesting/hybrid_allocator.py`.

L'allocateur prend des métriques candidates issues d'une recherche hors échantillon :
- rendement attendu estimé (entrée statistique, pas une promesse) ;
- volatilité ;
- drawdown maximal ;
- confiance ;
- stabilité ;
- score de liquidité ;
- corrélations entre stratégies sur une fenêtre OOS commune.

Il rejette les espérances non positives et les drawdowns au-delà de la limite fournie, construit un classement ajusté de la qualité et de la diversification, puis produit des poids long-only bornés par les plafonds d'exposition et de poids individuel.

Les corrélations manquantes sont traitées de façon conservatrice comme une corrélation positive de 1.0. Les poids sont des propositions de recherche uniquement.

## Sécurité / frontières
- Module sans accès broker, compte, ordre ou service de risque de production.
- `capital_authorized=False`, `orders_created=0`, `broker_access=False`.
- Aucun transfert vers les stratégies actives.
- Aucune allocation réelle, aucun ordre Paper ou Live.
- L'approbation humaine et le chemin V2 de contrôle des risques restent obligatoires.

## Tests
- Tests ciblés R55 : 10 réussis.
- Suite complète : 819 passed, 11 skipped, 202 subtests passed.
- Les 11 tests ignorés nécessitent une base PostgreSQL jetable externe.
- Compilation Python complète : réussie.

## Limites et suite
- Les métriques candidates ne sont pas encore automatiquement produites ni transmises par le moteur walk-forward.
- Le calcul de corrélation doit être relié à des séries OOS synchronisées et persistées.
- L'allocateur n'est pas encore intégré au simulateur de portefeuille continu.
- Les coûts, contraintes de liquidité, turnover et limites du Risk Governor devront être intégrés au rééquilibrage.
- PostgreSQL/Neon réel, build React et Alpaca Paper réel restent non validés.
- Rentabilité réelle non démontrée ; aucune performance future n'est garantie.

## Décision
R55 établit un premier contrat de pondération multi-facteurs, isolé en recherche. Prochaine étape : connecter les résultats OOS vérifiables et les corrélations au calcul d'allocation, puis tester la stabilité des poids, le turnover et les coûts avant toute intégration au portefeuille.
