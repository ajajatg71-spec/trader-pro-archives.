# Trader Pro 2.0 — R92 : vérification réelle de la persistance PostgreSQL

Base : R91.

## Objectif
Éviter qu'un booléen fourni par l'appelant puisse déclarer le registre des opérations sur titres persistant alors que le schéma PostgreSQL ou son mécanisme append-only manque.

## Modifications
- Ajout de `CorporateActionRepository.storage_readiness()`.
- Inspection du schéma réel : table, colonnes, contrainte unique `(source, event_id, revision)` et contraintes CHECK.
- Sur PostgreSQL, vérification du trigger `trg_corporate_action_revisions_append_only` et de son activation.
- Sur SQLite ou tout autre dialecte, la preuve est explicitement refusée : le stockage peut servir aux tests, mais ne certifie pas l'immutabilité PostgreSQL.
- Ajout de `assess_corporate_action_readiness_with_repository`, qui remplace la preuve de persistance fournie par l'appelant par le résultat réel de l'inspection DB.
- Le readiness gate reste fail-closed ; aucune autorisation Live ni création d'ordre.

## Tests
- Tests ciblés R92 + repository R91 : 16 réussis.
- Suite complète : **996 passed, 11 skipped, 205 subtests passed** (36,76 s). Rapport JUnit : 0 erreur, 0 échec, 11 ignorés.
- `compileall` : réussi.
- Aucun changement de schéma requis dans cette version ; head Alembic R91 inchangé (`f19a6c3d8b42`).
- `history.jsonl` restauré octet pour octet après les tests.

## Validation Neon réelle (lecture seule)
Projet `Trader pro`, branche `production`, base `trader_pro_test`, PostgreSQL 18.7 :
- `user_tables = 0`.
- `corporate_action_revisions` absente.
- Trigger append-only absent.
- R92 conclut donc correctement `BLOCKED` pour la preuve de persistance.
- Aucune écriture, migration ou modification de production effectuée.

## Limites
- La migration R91 a été appliquée localement sur SQLite pour valider le graphe Alembic ; le DDL PostgreSQL et le trigger doivent encore être exécutés sur une branche Neon de validation.
- Aucune session Alpaca authentifiée ni donnée réelle de corporate actions n'a été utilisée.
- Live désactivé ; aucun ordre créé.
