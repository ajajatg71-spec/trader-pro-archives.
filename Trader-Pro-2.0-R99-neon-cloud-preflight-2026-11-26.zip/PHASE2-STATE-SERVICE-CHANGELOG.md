# Trader Pro 2.0 — Phase 2 state service extraction

## Scope
- Added `services/state.py` with a `StateService` responsible for loading and merging persisted JSON state, atomic saves through the existing `store` module, append-only history, secret redaction, history tail reads, and backups.
- Wired `app.py` to use the service through compatibility wrappers (`save`, `hist`, `tail`) so existing route and domain behavior remains unchanged.
- Preserved the V1 working-directory-relative paths and existing JSON schema/default merging.
- No financial calculations, broker calls, strategy logic, or order behavior were changed.

## Validation
- Dedicated tests cover default merging, persistence round-trip, append-only history ordering, secret redaction, and missing history files.
- Full test suite, compilation, and FastAPI route registration checked after integration.
- No broker orders are submitted by this change.
