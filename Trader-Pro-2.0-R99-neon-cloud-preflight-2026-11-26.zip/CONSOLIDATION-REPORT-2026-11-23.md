# Trader Pro 2.0 — rapport de consolidation et validation

Date : 23 novembre 2026  
Base de travail : Trade Pro 7 (dérivé de R5)  
Statut : candidat consolidé de recherche et d'intégration ; non certifié pour le trading réel.

## 1. Sources comparées

Les archives originales sont conservées sans modification. Les sources principales inspectées dans cette passe :

- V1 gelée et branche Git `refactor-v2` de `trader-pro-1.zip` ; commit `a804ee2`.
- `trader-pro-2.0-source-candidate-2026-11-18.zip` et sa variante R2.
- R2, R3, R4, R5 et Trade Pro 7.
- `trader-pro-2.0-pack-complet-colab.zip` et son notebook `Trader_Pro_2_Validation_Mobile.ipynb`.
- Import Replit, archive de validation Windows et App-Creator.

Empreintes des archives majeures vérifiées :

| Source | SHA-256 |
|---|---|
| V1 gelée `trader-pro.zip` | `1a89ac91c5a27e6c79ae12b6e338a30f8de38262493b6fdeede1378070fa0019` |
| V1/refactor bundle `trader-pro-1.zip` | `c160b514da9ea2440126ff5b7c9879946091d3bd6b91245e137840607ac127d4` |
| ZIP Git imbriqué (branche `refactor-v2`) | `a3750359bc6910685220066e9d6fca1f7e226ccfcc95f9669e309ad691dd24d9` |
| Source candidate 18/11 | `604eb15ba4f4e4e41870db9939baace1dfcc3a450b4d8f781ac08920de4b5c4a` |
| R2 | `3cdc0de7734b11f6dda1cc3798a1c927bfd896e4b131f86eca4aa60159cf48ca` |
| R3 | `f800a9e522cc3682b3547ae54d7a976830152e27e632fe2ef0e0020fd47fb0db` |
| R4 | `b99fc8434213a84483aa7c62657379225dd89c53ba3c0e0387c07263d3eb60bf` |
| R5 | `013440d0d2c06439a674416bd206ccf101c0ef6261ab201ddada13a74d3125c7` |
| Trade Pro 7 | `ddfadeff320727958d115a5041c978ea6eeb82c02fb16d4e559e79b93fe2b1a8` |
| Colab pack complet | `94cc07a1d3a8db43276912d811fd6003de1ceec80738fe4f486ceed25ee8a728` |
| App-Creator | `56a1b5e99ecfea4eb3db8432be772c419b60a078f4b3e66a58484660a4bf4167` |
| Import Replit | `aa9c4715274d8d246ca85738e3e272536c40bc8afdd9c457abaaa05a30df44c2` |
| Validation Windows | `c1871fba71f9bfa456aecea9201dde89f1fcd553bb56e93ddeb086b2bca6459d` |

Les archives ZIP principales ouvertes dans cette passe ont passé `ZipFile.testzip()` sans entrée corrompue. Le paquet V1 contenait lui-même un ZIP imbriqué ; celui-ci a également été ouvert sans corruption.

## 2. Décisions d'architecture

### Base conservée : Trade Pro 7 / R5

La comparaison exacte R5 → Trade Pro 7 donne : aucun fichier supprimé, deux fichiers ajoutés et cinq fichiers modifiés (`README.md`, `app.py`, `broker.py`, `routers/analytics.py`, `tests/test_broker.py`). Trade Pro 7 conserve donc le contrat OHLCV/candle de R5 et apporte le durcissement Paper/broker.

### Colab : ne pas remplacer R5/Trade Pro 7

Le pack Colab retire huit fichiers OHLCV/candle/tests présents dans R5 et modifie 14 fichiers communs. Le notebook Colab est un script de validation mobile (installation, build frontend, tests, migrations SQLite, contrôles optionnels Neon/Alpaca Paper), pas un moteur stratégique alternatif autonome. Le code Colab ne doit donc pas remplacer la base R5/Trade Pro 7.

### App-Creator : sélection ciblée uniquement

App-Creator contient des éléments Replit/frontend et une normalisation utile des URL PostgreSQL vers psycopg 3. Cette normalisation a été reprise dans `db/session.py` et `alembic/env.py`, avec tests.

Deux régressions ont été écartées :

1. Sa configuration peut sélectionner le simulateur si `BROKER=alpaca` mais que les identifiants sont absents. Cela masque une sélection explicite d'Alpaca et contredit le comportement fail-closed de Trade Pro 7.
2. Son backend retire `OHLCVDailyBars`, le cache `daily_ohlcv()`, le mode OHLCV de Twelve Data et les tests correspondants.

## 3. Moteur V1 : portage isolé

La branche V1 `refactor-v2` (`a804ee2`) comprend 50 types : 43 règles individuelles et 7 stratégies d'univers. Son contrat utilise des barres OHLCV, des `Intent`, des cycles de stratégie, un ledger FIFO, un arbitre et un scoreboard hors échantillon. Il n'est pas interchangeable avec le moteur V2, qui expose quatre adaptateurs recevant uniquement les clôtures.

Le paquet `research_v1/` reprend les modules quantitatifs, les règles, le catalogue, l'arbitrage, le ledger et le backtest/scoreboard sous un namespace isolé. Les imports ont été renommés pour ne pas créer de collision avec un futur package `backend`.

Routes ajoutées :

- `GET /api/research/strategies/catalog` ;
- `POST /api/research/strategies/{kind}/dry-run` pour les 43 règles par titre ;
- `POST /api/research/portfolio-strategies/{kind}/dry-run` pour les 7 stratégies de portefeuille, avec synchronisation stricte des dates ;
- `POST /api/research/portfolio-strategies/{kind}/backtest` pour simuler les 7 stratégies d'univers sur plusieurs actifs, avec signal à la clôture, exécution à l'ouverture suivante, frais, glissement, liquidités plafonnées et comparaison à un portefeuille passif équipondéré ;
- `POST /api/research/portfolio-strategies/scoreboard` pour le scoreboard OOS walk-forward des 7 stratégies de portefeuille ;
- `POST /api/research/strategies/scoreboard` pour la validation OOS des 43 règles individuelles, avec frais, glissement, comparaison achat-conservation et seuil Bonferroni.
- Le scoreboard des 43 règles individuelles agrège les symboles en portefeuille de lignes équipondérées au capital initial et fonde le verdict sur une statistique Newey-West HAC des rendements journaliers nets de l'achat-conservation. Les transactions ne comptent dans l'échantillon OOS que si leur entrée et leur sortie sont toutes deux dans cette période ; une position reportée reste valorisée au jour le jour, sans être comptée comme trade entièrement OOS. Les timestamps des titres et benchmarks doivent être strictement identiques, timezone-aware et croissants. Les paramètres `split`, `alpha`, frais et glissement sont validés avant le calcul.

Toutes ces routes sont authentifiées, exigent des données OHLCV horodatées et ne créent aucun ordre. Elles ne modifient pas le registre des stratégies actives. Le scoreboard portefeuille conserve un portefeuille continu entre les fenêtres chronologiques OOS, utilise un warmup minimum propre à chaque stratégie, compare au buy-and-hold équipondéré et à l'indice choisi, applique Bonferroni sur la famille complète de 50 stratégies (43 règles par titre + 7 stratégies de portefeuille), un t-stat Newey-West et un second scénario à frais/glissement doublés. Il enregistre aussi les poids quotidiens de chaque actif et des liquidités ; le scoreboard présente sur la période OOS les poids moyens/maximaux, le pourcentage de jours exposés, le HHI de concentration des positions et le nombre maximal de titres simultanément détenus. Les expositions par actif sont donc mesurées, mais la concentration sectorielle, les spreads et la liquidité ne sont pas validés. Il renvoie aussi une matrice Pearson de corrélation des rendements OOS journaliers entre stratégies, sur leurs dates communes. Cette matrice ne certifie pas les expositions sous-jacentes, la concentration sectorielle ou la liquidité. La prévisualisation de sélection reste toujours à 100 % de liquidités et n'autorise aucun capital ; tout candidat reste en revue obligatoire avant Paper. Les paramètres sont figés ; aucune optimisation n'est réalisée sur l'OOS. Multi-Factor nécessite des snapshots historiques point-in-time pour chaque titre ; le dernier snapshot n'est appliqué qu'à partir de son timestamp public `available_at`. En l'absence de snapshots, elle est explicitement marquée non évaluée. Des fondamentaux statiques sont rejetés.

## 4. Validation exécutée

### Base Trade Pro 7 consolidée

- `python -m compileall -q app.py research_v1` : réussi.
- `python -m pytest -q` : **702 passed, 11 skipped, 202 subtests passed** (exécution finale après durcissements du scoreboard), code de sortie 0 ; deux avertissements de dépréciation FastAPI subsistent.
- Les 11 tests ignorés sont les intégrations PostgreSQL exigeant `TRADER_PRO_TEST_DATABASE_URL` et l'opt-in explicite d'une base jetable.
- Import FastAPI réussi avec `BROKER=sim` et mot de passe de test ; les quatre routes de recherche sont enregistrées.
- Tests ciblés du moteur V1 isolé : 8 passés ; les 43 types individuels ont été évalués sans exception sur des barres synthétiques.
- Contrats HTTP de recherche : catalogue, dry-run individuels et portefeuille, scoreboard mono-titre, backtest portefeuille et nouveau scoreboard portefeuille ; aucun ordre créé.
- 31 tests ciblés sur les deux scoreboards, le backtest portefeuille, les snapshots fondamentaux point-in-time et les contrats HTTP : passés. Ils couvrent les sept stratégies, les warmups, les fenêtres chronologiques, les données synchronisées, l'exécution au prochain open, les coûts et le verrouillage de l'exécution.
- Smoke-test du scoreboard multi-actifs sur 1 100 barres pseudo-aléatoires synthétiques : sept lignes sont retournées ; six stratégies sont évaluées et Multi-Factor est explicitement bloquée sans snapshots point-in-time. Une stratégie a passé les filtres sur ce jeu artificiel ; la prévisualisation reste néanmoins à 100 % en liquidités avec `capital_authorized=false` et statut de revue obligatoire. Aucun ordre ni activation. Ce test valide le chemin logiciel, pas la performance des stratégies ; ses résultats ne sont pas utilisés comme preuve financière.
- Normalisation PostgreSQL : trois tests passés ; les URL `postgres://` et `postgresql://` sont converties vers `postgresql+psycopg://`.
- `python -m compileall -q .` et `node --check frontend/public/sw.js` : réussis.
- Deux avertissements FastAPI de dépréciation subsistent sur les gestionnaires `on_event` historiques ; ils n'ont pas fait échouer les tests.

### Mesure de l'exposition par actif (23 novembre)

Le moteur multi-actifs conserve désormais la valeur de marché par ligne et la part de liquidités à chaque clôture. Le scoreboard publie, sur la période OOS, le poids moyen et maximal par symbole, la part des séances exposées, le HHI moyen des positions et le nombre maximal de positions simultanées. `portfolio_risk_review` distingue les expositions mesurées des validations de risque encore manquantes : revue manuelle, secteurs/facteurs, liquidité et spreads. La prévisualisation demeure 100 % cash et le capital est toujours non autorisé.

### Durcissement statistique du scoreboard individuel (23 novembre)

- La statistique décisionnelle est un Newey-West HAC sur les rendements journaliers du portefeuille agrégé comparés au buy-and-hold, avec cinq retards maximum. Le t-stat des trades n'est conservé qu'à titre descriptif.
- Seuls les trades disposant d'indices d'entrée et de sortie explicites, tous deux entièrement situés dans l'OOS, alimentent l'espérance et le nombre de trades OOS. Les positions ouvertes avant le split contribuent toujours aux rendements journaliers OOS, sans être artificiellement comptées comme nouveaux trades.
- La validation rejette les historiques et benchmarks non synchronisés ou mal horodatés, ainsi que les paramètres de split, de significativité et de coûts invalides.
- Vérifications ciblées : 31 tests réussis ; la suite complète finale compte 702 tests réussis, 11 ignorés et 202 sous-tests réussis.

### Branche V1 source

- Tests ciblés stratégies/quant/régression : **208 passed**.
- Suite V1 entière : la collecte échoue sur `backend/monitoring/smoke_test.py`, qui exécute `sys.exit` si les identifiants Alpaca sont absents.
- En ignorant ce script de smoke-test, résultat : **569 passed, 1 failed**. L'échec est un ancien contrat API : `POST /api/v1/plan?budget=1000` renvoie HTTP 200 alors que le test attend une erreur 400 structurée (`error.code=validation_error`). Le code API V1 n'a pas été repris.

### Frontend

- Le code React/TypeScript existant est conservé. Le serveur continue à utiliser `page.html` tant que `frontend/dist/index.html` n'est pas produit.
- `npm install` n'a pas abouti dans cet environnement (délai d'exécution dépassé ; aucun `node_modules` ni `package-lock.json` créé). Le typecheck et le build Vite n'ont donc pas été certifiés ici.

## 5. Blocages externes restants

- PostgreSQL réel/Neon : non testé dans cette passe. Les tests PostgreSQL locaux sont ignorés faute de base jetable configurée ; les contrôles Neon disponibles sont en lecture seule.
- Alpaca Paper authentifié : non testé, aucune clé Paper accessible dans cet environnement. Aucun ordre Paper ni Live n'a été envoyé.
- Le smoke-test Paper avec soumission/annulation d'un ordre n'a pas été exécuté ; il exige une autorisation explicite distincte.
- Frontend : build TypeScript/Vite et validation navigateur/mobile en attente des dépendances npm.
- Données OHLCV réelles : aucune stratégie n'a été évaluée sur des historiques authentifiés dans cette passe. Le scoreboard mono-titre et le scoreboard portefeuille sont disponibles côté code, mais ils doivent encore être exécutés avec une source de données configurée, des historiques ajustés des opérations sur titres et plusieurs univers représentatifs. Les snapshots de fondamentaux doivent être des versions point-in-time réelles et inclure leur date de publication publique ; la provenance reste à vérifier via le fournisseur.

## 6. Règles de sécurité et rentabilité

- `BROKER=sim` reste le défaut ; une sélection Alpaca explicite ne bascule jamais silencieusement vers le simulateur.
- Live reste verrouillé.
- Le moteur V1 isolé ne communique pas avec le courtier ; le chemin d'exécution V2, le contrôle de risque et l'approbation restent les seules frontières autorisées.
- Aucune stratégie n'est présumée rentable. Les verdicts OOS sont propres à l'univers, à la période, aux frais et au glissement utilisés. Un verdict « prometteuse » ne garantit aucun rendement futur.
- Aucune optimisation de paramètres sur la période OOS n'est autorisée.

## 7. Prochaines étapes techniques automatiques

1. Brancher un flux fondamental historisé point-in-time (avec dates/versions publiques vérifiables), puis exécuter les deux scoreboards avec des historiques OHLCV réels authentifiés, ajustés des opérations sur titres ; auditer survivorship, look-ahead, liquidité, spreads et concentration sectorielle.
2. Construire une politique de sélection de recherche avec repli explicite à 100 % cash, plafonds par titre/secteur/régime et aucune activation automatique en l'absence de preuve suffisante.
3. Terminer la parité numérique V1/V2 sur les mêmes OHLCV et l'attribution des performances par actif/régime.
4. Compiler React/TypeScript/PWA et raccorder un tableau de bord de recherche en lecture seule.
5. Valider PostgreSQL test/restore et concurrence, puis Alpaca Paper en lecture seule et son cycle de vie ; le test d'un ordre Paper reste séparé et explicitement autorisé.


Détail du nouvel incrément Phase 9 : `PHASE9-PORTFOLIO-WALK-FORWARD.md`.


## Incrément du 23 novembre — fondamentaux Multi-Factor point-in-time

- `simulate_portfolio("multi_factor", ...)` exige désormais un dictionnaire symbole -> snapshots chronologiques. Chaque snapshot comporte `available_at` (timestamp ISO avec fuseau horaire), `as_of` facultatif et un ou plusieurs facteurs `eps`, `growth_pct`, `margin_pct`. Les valeurs sont converties en numérique fini et les booléens sont refusés.
- Le moteur applique le snapshot le plus récent uniquement lorsque `available_at` est inférieur ou égal au timestamp de la séance étudiée. Aucun snapshot futur n'est utilisé. Les symboles absents, champs inconnus, timestamps non croissants/naïfs, snapshots vides et valeurs invalides déclenchent une erreur.
- Sans snapshot, le scoreboard renvoie Multi-Factor avec `evaluated=false` et `blocked_by=point_in_time_fundamentals_missing`, et affiche `evaluated_count=6` si les six autres stratégies sont testables. Les valeurs fondamentales statiques ne sont pas autorisées dans un backtest historique.
- Tests ajoutés : causalité (pas d'achat avant la publication), snapshots absents, données booléennes invalides, exclusion du scoreboard sans PIT et refus HTTP 422 sur le backtest Multi-Factor sans PIT.
- Limite : le moteur valide le schéma et les horodatages, mais ne peut pas prouver à lui seul que le timestamp `available_at` ou les chiffres ont été fournis correctement par un fournisseur tiers.

### Attribution des résultats par régime de marché (incrément supplémentaire du 23 novembre)

- Le scoreboard portefeuille attribue désormais les rendements OOS journaliers à trois régimes : `risk_on`, `sideways` et `risk_off`.
- Le régime est déterminé à partir du rendement du proxy de marché sur les 63 séances précédentes, avec seuils de +/-5 %. L'information utilisée s'arrête à la clôture précédente, avant le rendement OOS attribué : aucune donnée de la séance évaluée ne sert à classer son propre rendement.
- Pour chaque régime, le rapport donne le nombre d'observations, le rendement composé de la stratégie, celui du benchmark équipondéré, leur écart et un indicateur de taille d'échantillon (minimum 20 observations). Les séances trop anciennes pour disposer de 63 observations antérieures sont signalées comme non classifiées.
- Cette attribution est descriptive et ne modifie pas les verdicts ni l'allocation. Les régimes trop peu échantillonnés restent insuffisants ; `market_regime_analysis_validated=false`, capital autorisé=false et 100 % cash restent inchangés.
- Tests dédiés : 9 réussis dans `tests/test_research_v1_portfolio_scoreboard.py`, incluant la vérification de l'information disponible à la clôture précédente et le maintien de l'interdiction d'allocation.

### Vérification finale après cet incrément

- `python -m pytest -q` : **704 passed, 11 skipped, 202 subtests passed**, code de sortie 0, en 21,30 s.
- `python -m compileall -q .` : réussi.
- `node --check frontend/public/sw.js` : réussi.
- Deux avertissements FastAPI `on_event` dépréciés subsistent.
- Les tests PostgreSQL restent ignorés faute de base de test jetable ; PostgreSQL réel/Neon, Alpaca Paper authentifié et build npm/React ne sont toujours pas validés.


## 8. Durcissement du risque global de portefeuille — 23 novembre 2026

### Modifications

- `portfolio_snapshot()` applique désormais `min_cash` comme pourcentage minimal de liquidités dans l'état global du portefeuille. Une réserve insuffisante produit un statut `BREACH`.
- Le rapport de risque expose `sector_exposure_hhi` et `issuer_exposure_hhi`, calculés sur les expositions classifiées investies, ainsi que `sector_classification_coverage_pct` et `issuer_classification_coverage_pct`.
- Deux limites facultatives ont été ajoutées : `max_sector_hhi` et `max_issuer_hhi`. Elles doivent être comprises entre 0 et 1. Lorsqu'elles sont configurées, toute classification manquante bloque le contrôle.
- `pre_trade_check()` calcule l'impact HHI de l'achat projeté avant approbation ; il bloque si la limite serait dépassée ou si une classification nécessaire manque.
- Le contrôle VaR/CVaR/stress en snapshot a été dédupliqué afin qu'une même violation ne soit pas remontée deux fois.

### Validation exécutée sur l'archive R3 exacte

- Base R3 avant modification : **709 passed, 11 skipped, 202 subtests passed**.
- Tests ciblés après modification (risque institutionnel, service de risque, routes et ordres) : **87 passed**.
- Suite complète après modification : **715 passed, 11 skipped, 202 subtests passed**, 2 avertissements FastAPI `on_event` dépréciés.
- `python -m compileall -q .` : réussi.
- `node --check frontend/public/sw.js` : réussi.

### Portée et limites

Les seuils HHI restent optionnels et ne changent pas silencieusement les limites des comptes existants. Les données de classification sectorielle/émetteur doivent provenir d'une source de référence fiable et récente ; le moteur vérifie leur présence, pas leur vérité externe. Les métriques HHI sont des mesures de concentration, pas des mesures complètes de risque de marché. La VaR, la CVaR, la corrélation et la liquidité nécessitent toujours des données de marché fiables, datées et réconciliées.

Cette passe ne constitue pas une validation PostgreSQL réelle, Alpaca Paper, un test d'exécution réel ou une preuve de rentabilité. Aucun ordre n'a été soumis ; Live reste verrouillé.


## 9. Durcissement du calcul du risque sur données incomplètes — incrément R5

### Défaut corrigé

Le service de risque construisait auparavant ses métriques de portefeuille à partir des seuls symboles dont l'historique comportait plus de 30 clôtures. Si un titre détenu avait un historique absent ou plus court, il pouvait être omis silencieusement du calcul VaR/CVaR, de la corrélation et du bêta. Le résultat pouvait donc sous-estimer le risque du portefeuille réel.

### Changement

- Le calcul avancé est maintenant interrompu si une seule position détenue ne dispose pas d'au moins 31 clôtures.
- Les séries des positions détenues doivent avoir la même longueur que celle du benchmark SPY ; sinon les métriques sont refusées.
- En cas de couverture partielle ou de longueur désalignée, le snapshot de risque précédent est effacé afin qu'il ne puisse pas être réutilisé pour autoriser un ordre.
- Le rapport expose le nombre de positions couvertes, le nombre total de positions, la longueur du benchmark et l'état de vérification de l'alignement.
- Limite explicitement conservée : l'ancien lecteur ne fournit que des listes de clôtures, sans horodatages par symbole. L'égalité des longueurs n'est donc pas une preuve d'alignement séance par séance. Une future migration vers le contrat OHLCV horodaté est nécessaire pour certifier cela.

### Validation exécutée sur la base R4 exacte

- Tests ciblés `tests/test_risk_service.py`, `tests/test_market_data_service.py` et `tests/test_ohlcv_market_data.py` : **64 passed, 24 subtests passed**.
- Suite complète : **715 passed, 11 skipped, 202 subtests passed**, 2 avertissements FastAPI `on_event` dépréciés.
- `python -m compileall -q .` : réussi.
- `node --check frontend/public/sw.js` : réussi.

### Limites

Aucun historique réel multi-titres n'a été connecté pendant cette passe. La vérification par horodatage reste à réaliser. Les 11 tests ignorés, PostgreSQL réel, Alpaca Paper et la validation prolongée restent des blocages distincts. Aucun ordre n'a été soumis ; Live reste verrouillé.
