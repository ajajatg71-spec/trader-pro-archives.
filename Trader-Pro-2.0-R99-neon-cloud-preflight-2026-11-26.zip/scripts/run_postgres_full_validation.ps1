# Full, disposable PostgreSQL 16 validation for Windows + Docker Desktop.
# Includes migrations, real PostgreSQL integration tests, regression suites,
# and an in-container pg_dump/pg_restore round-trip. No broker calls or orders.
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Push-Location $projectRoot
$compose = @('compose', '-f', 'compose.test.yaml')
$container = 'trader-pro-postgres-test'
$backupDir = Join-Path $projectRoot 'artifacts\postgres-validation'
$backupName = 'trader_pro_validation.dump'
$containerBackup = "/tmp/$backupName"

function Invoke-DockerChecked {
    param([Parameter(Mandatory = $true)][string[]]$Arguments, [Parameter(Mandatory = $true)][string]$Failure)
    & docker @Arguments
    if ($LASTEXITCODE -ne 0) { throw $Failure }
}

$composeAttempted = $false
try {
    if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { throw 'Docker Desktop est requis et doit être démarré.' }
    Invoke-DockerChecked -Arguments @('compose', 'version') -Failure 'Docker Compose v2 requis.'
    $composeAttempted = $true
    Invoke-DockerChecked -Arguments ($compose + @('up', '-d', '--wait')) -Failure 'Impossible de démarrer PostgreSQL 16 isolé.'

    $env:TRADER_PRO_TEST_DATABASE_DISPOSABLE = 'YES'
    $env:TRADER_PRO_TEST_DATABASE_URL = 'postgresql+psycopg://trader_pro:trader_pro_test_only@127.0.0.1:55432/trader_pro_test'
    $env:TRADER_PRO_RESTORE_DATABASE_URL = 'postgresql+psycopg://trader_pro:trader_pro_test_only@127.0.0.1:55432/trader_pro_restore'
    $env:DATABASE_URL = $env:TRADER_PRO_TEST_DATABASE_URL

    & python -c "import sqlalchemy, psycopg, alembic, pytest"
    if ($LASTEXITCODE -ne 0) { throw 'Dépendances Python manquantes. Installer requirements.txt et requirements-dev.txt dans le venv.' }

    Write-Host '[1/7] Migrations Alembic sur PostgreSQL 16 réel'
    & python -m alembic upgrade head
    if ($LASTEXITCODE -ne 0) { throw 'Échec des migrations PostgreSQL.' }

    Write-Host '[2/7] Tests d’intégration PostgreSQL'
    $integrationOutput = & python -m pytest -q tests/test_postgres_integration.py -rs 2>&1
    $integrationExit = $LASTEXITCODE
    $integrationOutput | ForEach-Object { Write-Host $_ }
    if ($integrationExit -ne 0) { throw 'Échec des tests PostgreSQL.' }
    if (($integrationOutput -join "`n") -match '\b[0-9]+\s+skipped\b') { throw 'Au moins un test PostgreSQL a été ignoré : validation réelle incomplète.' }
    if (($integrationOutput -join "`n") -notmatch '\b[0-9]+\s+passed\b') { throw 'Aucun test PostgreSQL réussi détecté.' }

    Write-Host '[3/7] Suite complète Pytest'
    & python -m pytest -q
    if ($LASTEXITCODE -ne 0) { throw 'Échec de la suite Pytest.' }

    Write-Host '[4/7] Suite Unittest et compilation'
    & python -m unittest discover -q
    if ($LASTEXITCODE -ne 0) { throw 'Échec de la suite Unittest.' }
    & python -m compileall -q .
    if ($LASTEXITCODE -ne 0) { throw 'Échec de compilation.' }

    Write-Host '[5/7] Création du backup avec pg_dump dans le conteneur'
    New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
    $hostBackup = Join-Path $backupDir $backupName
    Invoke-DockerChecked -Arguments @('exec', $container, 'pg_dump', '-U', 'trader_pro', '-d', 'trader_pro_test', '-Fc', '-f', $containerBackup) -Failure 'Échec pg_dump.'
    Invoke-DockerChecked -Arguments @('cp', "${container}:$containerBackup", $hostBackup) -Failure 'Impossible de copier le backup vers Windows.'
    $hash = (Get-FileHash -Algorithm SHA256 $hostBackup).Hash.ToLower()
    Set-Content -Path "$hostBackup.sha256" -Value $hash -NoNewline

    Write-Host '[6/7] Restauration dans la base _restore distincte'
    Invoke-DockerChecked -Arguments @('exec', $container, 'pg_restore', '--exit-on-error', '--no-owner', '--no-acl', '-U', 'trader_pro', '-d', 'trader_pro_restore', $containerBackup) -Failure 'Échec pg_restore dans la base dédiée.'

    Write-Host '[7/7] Comparaison en lecture seule du schéma, de toutes les tables, des lignes et de la révision Alembic'
    & python scripts/verify_postgres_restore.py
    if ($LASTEXITCODE -ne 0) { throw 'La base restaurée ne correspond pas à la base source.' }

    Write-Host 'POSTGRES_FULL_VALIDATION_PASSED'
    Write-Host "Backup: $hostBackup"
    Write-Host "SHA256: $hash"
    Write-Host 'Aucun appel Alpaca et aucun ordre n’ont été envoyés.'
}
finally {
    if ($composeAttempted -and (Get-Command docker -ErrorAction SilentlyContinue)) {
        & docker @compose down --volumes --remove-orphans
        if ($LASTEXITCODE -ne 0) { Write-Warning 'Nettoyage Docker incomplet : vérifier le conteneur de test.' }
    }
    Pop-Location
}
