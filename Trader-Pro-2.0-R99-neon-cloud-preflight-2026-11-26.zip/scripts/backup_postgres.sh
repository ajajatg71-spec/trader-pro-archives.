#!/usr/bin/env bash
# Explicit PostgreSQL backup. Requires pg_dump and DATABASE_URL; never logs credentials.
set -euo pipefail
: "${DATABASE_URL:?DATABASE_URL is required}"
command -v pg_dump >/dev/null || { echo "pg_dump is required" >&2; exit 2; }
DEST_DIR="${BACKUP_DIR:-backups/postgres}"
mkdir -p "$DEST_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$DEST_DIR/trader_pro_$STAMP.dump"
pg_dump --dbname="$DATABASE_URL" --format=custom --no-owner --no-acl --file="$OUT"
pg_restore --list "$OUT" >/dev/null
sha256sum "$OUT" > "$OUT.sha256"
echo "Backup created and archive listing verified: $OUT"
