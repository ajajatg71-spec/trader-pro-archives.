"""Run the durable broker-event inbox processor (Paper-only, read-only reconciliation)."""
from __future__ import annotations

import argparse
import logging
import os
import signal
import sys
import threading
import time


def validate_environment(env: dict[str, str]) -> tuple[str, str]:
    """Validate Paper-only worker prerequisites without printing credentials."""
    database_url = env.get("DATABASE_URL", "").strip()
    broker_mode = env.get("BROKER", "alpaca").strip().lower()
    base_url = env.get("ALPACA_BASE_URL", "https://paper-api.alpaca.markets").strip()
    key = env.get("APCA_API_KEY_ID", "").strip()
    secret = env.get("APCA_API_SECRET_KEY", "").strip()
    if broker_mode != "alpaca":
        raise ValueError("Le worker d'événements exige BROKER=alpaca (Paper uniquement)")
    if not database_url.startswith(("postgresql://", "postgresql+psycopg://")):
        raise ValueError("DATABASE_URL doit désigner PostgreSQL (SQLite interdit pour ce worker)")
    if base_url != "https://paper-api.alpaca.markets":
        raise ValueError("Seul l'endpoint officiel Alpaca Paper est autorisé")
    if not key or not secret:
        raise ValueError("Clés Alpaca Paper manquantes dans l'environnement")
    return database_url, base_url


def run_periodic_reconciliation(reconciliation):
    """Run a full broker snapshot independently of notification delivery."""
    from services.broker_events import BrokerEventProcessor
    report = reconciliation.run()
    if not BrokerEventProcessor._is_complete_reconciliation(report):
        raise RuntimeError("Réconciliation périodique incomplète ou tronquée")
    return report


def record_reconciliation_outcome(repository, *, success: bool, error_type: str | None = None) -> None:
    """Move the durable safety state conservatively; never auto-enable trading."""
    if repository is None:
        raise RuntimeError("Dépôt de sécurité globale indisponible")
    state = repository.get_system_safety_state()
    current = state.get("status")
    if success:
        if current == "DEGRADED":
            repository.transition_system_safety_state(
                status="RECONCILING", reason="Services rétablis ; validation opérateur encore requise",
                actor="worker")
        return
    if current in {"READY", "RECONCILING"}:
        repository.transition_system_safety_state(
            status="DEGRADED", reason=f"Réconciliation périodique en échec ({error_type or 'unknown'})",
            actor="worker")


def periodic_reconciliation_delay(*, failures: int, interval_seconds: int,
                                  retry_base_seconds: int = 5,
                                  retry_max_seconds: int = 60) -> int:
    """Return the delay before the next full reconciliation.

    Successful runs use the normal interval (failures=0). Failed runs retry
    quickly with capped exponential backoff, never later than the normal
    interval. This avoids leaving a worker blind for five minutes after a
    transient broker outage while also preventing a hot retry loop.
    """
    values = (failures, interval_seconds, retry_base_seconds, retry_max_seconds)
    if any(not isinstance(value, int) or isinstance(value, bool) for value in values):
        raise ValueError("Paramètres de planification invalides")
    if failures < 0 or interval_seconds < 30 or retry_base_seconds < 1 or retry_max_seconds < retry_base_seconds:
        raise ValueError("Paramètres de planification hors limites")
    if failures == 0:
        return interval_seconds
    exponent = min(failures - 1, 30)
    return min(retry_base_seconds * (2 ** exponent), retry_max_seconds, interval_seconds)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--once", action="store_true", help="Traiter un seul lot puis quitter")
    parser.add_argument("--poll-seconds", type=int, default=5)
    parser.add_argument("--batch-size", type=int, default=100)
    parser.add_argument("--reconcile-interval-seconds", type=int, default=300,
                        help="Réconciliation broker indépendante des notifications (30..3600 s)")
    parser.add_argument("--reconcile-retry-base-seconds", type=int, default=5,
                        help="Délai initial de reprise après échec de réconciliation (1..60 s)")
    parser.add_argument("--reconcile-retry-max-seconds", type=int, default=60,
                        help="Délai maximal entre reprises après échec (1..300 s)")
    args = parser.parse_args()
    if (not 1 <= args.poll_seconds <= 300 or not 1 <= args.batch_size <= 1000
            or not 30 <= args.reconcile_interval_seconds <= 3600
            or not 1 <= args.reconcile_retry_base_seconds <= 60
            or not args.reconcile_retry_base_seconds <= args.reconcile_retry_max_seconds <= 300):
        parser.error("poll-seconds: 1..300, batch-size: 1..1000, reconcile-interval-seconds: 30..3600, retry-base: 1..60, retry-max: retry-base..300")

    try:
        database_url, _ = validate_environment(dict(os.environ))
    except ValueError as exc:
        print(f"Configuration refusée : {exc}", file=sys.stderr)
        return 2

    # Imports after the safety gate: importing broker enforces the Paper URL guard.
    import broker
    from db.order_repository import OrderRepository
    from db.session import build_engine, build_session_factory
    from services.broker_events import BrokerEventProcessor
    from services.reconciliation import ReconciliationService
    from services.strategy_engine.persistence import StrategyPersistence

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logger = logging.getLogger("trader_pro.broker_event_worker")
    engine = build_engine(database_url)
    sessions = build_session_factory(engine)
    repository = OrderRepository(sessions)
    strategy_persistence = StrategyPersistence(sessions)
    reconciliation = ReconciliationService(repository, broker, strategy_persistence)
    processor = BrokerEventProcessor(sessions, reconciliation)

    stop = threading.Event()
    def request_stop(signum, frame):  # noqa: ARG001
        logger.info("Arrêt demandé (%s)", signum)
        stop.set()
    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGINT, request_stop)

    next_periodic_reconcile = 0.0  # Always reconcile immediately after worker startup.
    reconciliation_failures = 0
    try:
        while not stop.is_set():
            now = time.monotonic()
            if now >= next_periodic_reconcile:
                try:
                    report = run_periodic_reconciliation(reconciliation)
                    record_reconciliation_outcome(repository, success=True)
                    reconciliation_failures = 0
                    delay = periodic_reconciliation_delay(
                        failures=0, interval_seconds=args.reconcile_interval_seconds,
                        retry_base_seconds=args.reconcile_retry_base_seconds,
                        retry_max_seconds=args.reconcile_retry_max_seconds)
                    logger.info("Réconciliation périodique terminée : orders=%s fills=%s health=%s next=%ss",
                        report.get("remote_orders_seen"), report.get("fills_seen"),
                        (report.get("execution_health") or {}).get("status", "unknown"), delay)
                except Exception as exc:
                    try:
                        record_reconciliation_outcome(repository, success=False, error_type=type(exc).__name__)
                    except Exception as state_exc:
                        logger.critical("Impossible de mettre à jour l'état global (%s)", type(state_exc).__name__)
                    reconciliation_failures += 1
                    delay = periodic_reconciliation_delay(
                        failures=reconciliation_failures, interval_seconds=args.reconcile_interval_seconds,
                        retry_base_seconds=args.reconcile_retry_base_seconds,
                        retry_max_seconds=args.reconcile_retry_max_seconds)
                    logger.error("Réconciliation périodique en échec (%s), nouvelle tentative dans %ss",
                                 type(exc).__name__, delay)
                next_periodic_reconcile = time.monotonic() + delay
            try:
                result = processor.process_pending(limit=args.batch_size)
                if result["claimed"]:
                    logger.info("Lot broker traité : claimed=%s processed=%s failed=%s dead_letter=%s",
                        result["claimed"], result["processed"], result["failed"],
                        result.get("dead_letter", False))
            except Exception as exc:
                # No credentials, request bodies, or provider payloads in logs.
                logger.error("Cycle worker en échec (%s)", type(exc).__name__)
            if args.once:
                break
            stop.wait(args.poll_seconds)
    finally:
        engine.dispose()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
