$ErrorActionPreference = 'Stop'
$Python = if ($env:PYTHON_BIN) { $env:PYTHON_BIN } else { 'py -3' }
$Venv = if ($env:VENV_DIR) { $env:VENV_DIR } else { '.venv' }
if ($Python -eq 'py -3') { & py -3 -m venv $Venv } else { & $Python -m venv $Venv }
if ($LASTEXITCODE -ne 0) { throw 'La création de l’environnement Python a échoué.' }
& "$Venv\Scripts\python.exe" -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'La mise à jour de pip a échoué.' }
& "$Venv\Scripts\python.exe" -m pip install -r requirements-dev.txt
if ($LASTEXITCODE -ne 0) { throw 'L’installation des dépendances a échoué.' }
Write-Host "Environnement prêt. Activation : $Venv\Scripts\Activate.ps1"
