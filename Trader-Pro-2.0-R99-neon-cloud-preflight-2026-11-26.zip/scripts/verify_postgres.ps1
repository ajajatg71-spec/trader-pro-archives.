# End-to-end PostgreSQL verification. Uses only explicitly disposable databases.
$ErrorActionPreference = 'Stop'

if ($env:TRADER_PRO_TEST_DATABASE_DISPOSABLE -ne 'YES') { throw 'Définir TRADER_PRO_TEST_DATABASE_DISPOSABLE=YES uniquement pour une base locale jetable.' }

foreach ($name in @('TRADER_PRO_TEST_DATABASE_URL', 'TRADER_PRO_RESTORE_DATABASE_URL')) {
    if ([string]::IsNullOrWhiteSpace([Environment]::GetEnvironmentVariable($name))) {
        throw "Définir $name avant de lancer ce script."
    }
}
foreach ($tool in @('alembic', 'pytest', 'psql', 'pg_dump', 'pg_restore', 'python')) {
    if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) { throw "Commande requise absente: $tool" }
}

$urls = @(& python -c "import os; from sqlalchemy.engine import make_url; a=make_url(os.environ['TRADER_PRO_TEST_DATABASE_URL']); b=make_url(os.environ['TRADER_PRO_RESTORE_DATABASE_URL']); assert a.database and a.database.lower().endswith('_test'), 'La base de test doit finir par _test'; assert b.database and b.database.lower().endswith('_restore'), 'La base restore doit finir par _restore'; assert (a.host,a.port,a.database)!=(b.host,b.port,b.database), 'Bases identiques'; assert (a.host or '').lower() in ('localhost','127.0.0.1','::1') and (b.host or '').lower() in ('localhost','127.0.0.1','::1'), 'Validation destructive réservée à PostgreSQL local jetable'; print(a.set(drivername='postgresql').render_as_string(hide_password=False)); print(b.set(drivername='postgresql').render_as_string(hide_password=False))")
if ($LASTEXITCODE -ne 0 -or $urls.Count -ne 2) { throw 'Impossible de préparer les URL PostgreSQL.' }
$testUrl = $urls[0]
$restoreUrl = $urls[1]

$tableCount = (& psql $restoreUrl -v ON_ERROR_STOP=1 -Atqc "SELECT count(*) FROM information_schema.tables WHERE table_schema='public'").Trim()
if ($LASTEXITCODE -ne 0) { throw 'Impossible de vérifier la base _restore.' }
if ($tableCount -ne '0') { throw "Refus: la base _restore doit être vide (tables publiques: $tableCount)." }

$env:DATABASE_URL = $env:TRADER_PRO_TEST_DATABASE_URL
Write-Host '[1/5] Migrations Alembic'
& alembic upgrade head
if ($LASTEXITCODE -ne 0) { throw 'Échec migrations Alembic.' }

Write-Host '[2/5] Tests PostgreSQL intégration'
& pytest -q tests/test_postgres_integration.py
if ($LASTEXITCODE -ne 0) { throw 'Échec tests PostgreSQL.' }

Write-Host '[3/5] Backup PostgreSQL'
$backupDir = if ($env:BACKUP_DIR) { $env:BACKUP_DIR } else { 'backups/postgres' }
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
$stamp = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ')
$backupFile = Join-Path $backupDir "trader_pro_verify_$stamp.dump"
& pg_dump --dbname=$testUrl --format=custom --no-owner --no-acl --file=$backupFile
if ($LASTEXITCODE -ne 0) { throw 'Échec pg_dump.' }
& pg_restore --list $backupFile | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Backup illisible par pg_restore.' }
(Get-FileHash -Algorithm SHA256 $backupFile).Hash.ToLower() | Set-Content "$backupFile.sha256"

Write-Host '[4/5] Restauration vers base _restore vide'
& pg_restore --exit-on-error --no-owner --no-acl --dbname=$restoreUrl $backupFile
if ($LASTEXITCODE -ne 0) { throw 'Échec restauration.' }

Write-Host '[5/5] Comparaison en lecture seule du schéma, de toutes les tables, des lignes et de la révision Alembic'
& python scripts/verify_postgres_restore.py
if ($LASTEXITCODE -ne 0) { throw 'La base restaurée ne correspond pas à la base source.' }
Write-Host "POSTGRES_MIGRATION_INTEGRATION_BACKUP_RESTORE_OK"
Write-Host "Backup: $backupFile"
