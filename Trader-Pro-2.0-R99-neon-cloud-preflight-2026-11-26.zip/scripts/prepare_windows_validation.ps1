# Prepare a reproducible Windows validation environment for Trader Pro 2.0.
# This script installs project dependencies in a local virtual environment,
# runs the offline suite, and optionally launches disposable PostgreSQL 16.
[CmdletBinding()]
param(
    [switch]$RunPostgres,
    [switch]$RunNeonReadOnly
)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Push-Location $projectRoot
try {
    $pythonLauncher = Get-Command py -ErrorAction SilentlyContinue
    if ($pythonLauncher) {
        & py -3.12 --version *> $null
        if ($LASTEXITCODE -eq 0) { $python = 'py'; $pythonArgs = @('-3.12') }
        else {
            & py -3.11 --version *> $null
            if ($LASTEXITCODE -eq 0) { $python = 'py'; $pythonArgs = @('-3.11') }
            else { throw 'Python 3.11 ou 3.12 est requis. Installez Python depuis python.org.' }
        }
    } else {
        $pythonCommand = Get-Command python -ErrorAction SilentlyContinue
        if (-not $pythonCommand) { throw 'Python est introuvable. Installez Python 3.11 ou 3.12.' }
        $python = $pythonCommand.Source
        $version = & $python -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")'
        if ($version -notin @('3.11', '3.12')) { throw "Python 3.11 ou 3.12 requis; version détectée: $version" }
        $pythonArgs = @()
    }

    if (-not (Test-Path '.venv/Scripts/python.exe')) {
        & $python @pythonArgs -m venv .venv
        if ($LASTEXITCODE -ne 0) { throw 'Création de .venv impossible.' }
    }
    $venvPython = Join-Path $projectRoot '.venv/Scripts/python.exe'
    & $venvPython -m pip install --upgrade pip
    if ($LASTEXITCODE -ne 0) { throw 'Mise à jour de pip impossible.' }
    & $venvPython -m pip install -r requirements-dev.txt
    if ($LASTEXITCODE -ne 0) { throw 'Installation des dépendances impossible.' }

    & $venvPython -m compileall -q .
    if ($LASTEXITCODE -ne 0) { throw 'Échec compileall.' }
    & $venvPython -m pytest -q
    if ($LASTEXITCODE -ne 0) { throw 'Échec de la suite pytest.' }
    & $venvPython -m unittest discover -q
    if ($LASTEXITCODE -ne 0) { throw 'Échec de la suite unittest.' }

    if ($RunPostgres) {
        $docker = Get-Command docker -ErrorAction SilentlyContinue
        if (-not $docker) { throw 'Docker Desktop est requis pour PostgreSQL local. Alternative: workflow GitHub Actions postgres-integration.yml.' }
        & docker compose version
        if ($LASTEXITCODE -ne 0) { throw 'Docker Compose v2 indisponible. Démarrez Docker Desktop et réessayez.' }
        & $venvPython -m alembic --version
        if ($LASTEXITCODE -ne 0) { throw 'Alembic indisponible dans .venv.' }
        $env:VIRTUAL_ENV = Join-Path $projectRoot '.venv'
        $env:PATH = (Join-Path $projectRoot '.venv/Scripts') + ';' + $env:PATH
        & (Join-Path $PSScriptRoot 'run_postgres_full_validation.ps1')
        if ($LASTEXITCODE -ne 0) { throw 'Échec de la validation PostgreSQL 16 complète (intégration + sauvegarde/restauration).' }
    }
    if ($RunNeonReadOnly) {
        $env:VIRTUAL_ENV = Join-Path $projectRoot '.venv'
        $env:PATH = (Join-Path $projectRoot '.venv/Scripts') + ';' + $env:PATH
        & (Join-Path $PSScriptRoot 'run_neon_readonly_preflight.ps1')
        if ($LASTEXITCODE -ne 0) { throw 'Échec du précontrôle SQLAlchemy Neon en lecture seule.' }
    }
    Write-Host 'TRADER_PRO_WINDOWS_VALIDATION_ENVIRONMENT_READY'
} finally {
    Pop-Location
}
