"""Read-only SQLAlchemy preflight for the dedicated Trader Pro Neon test DB.

Usage:
  TRADER_PRO_TEST_DATABASE_URL='postgresql://...' \
    python scripts/verify_neon_sqlalchemy_readonly.py

This script is intentionally non-destructive. It only accepts the exact
`trader_pro_test` database and sets the PostgreSQL transaction READ ONLY
before issuing any inspection query.
"""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# Make direct execution (`python scripts/...py`) resolve the project package.
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from sqlalchemy import inspect, text
from sqlalchemy.engine import make_url

from db.session import build_engine

ENV_NAME = "TRADER_PRO_TEST_DATABASE_URL"
EXPECTED_DATABASE = "trader_pro_test"
EXPECTED_ALEMBIC_HEAD = "f19a6c3d8b42"
REQUIRED_TABLES = {
    "account_snapshots",
    "alembic_version",
    "audit_events",
    "broker_event_inbox",
    "corporate_action_revisions",
    "fills",
    "operator_auth_attempts",
    "operator_totp_state",
    "orders",
    "position_snapshots",
    "reconciliation_runs",
    "research_hypothesis_families",
    "risk_control_state",
    "risk_events",
    "strategy_configs",
    "strategy_proposals",
    "system_safety_state",
}
EXPECTED_APPEND_ONLY_TRIGGER = "trg_corporate_action_revisions_append_only"


class PreflightError(RuntimeError):
    """Raised when the target or database state fails the read-only preflight."""


def validate_database_url(raw_url: str | None):
    if not raw_url or not raw_url.strip():
        raise PreflightError(f"{ENV_NAME} is required")
    try:
        url = make_url(raw_url.strip())
    except Exception as exc:  # pragma: no cover - SQLAlchemy parser details vary
        raise PreflightError("Database URL is invalid") from exc
    if url.get_backend_name() != "postgresql":
        raise PreflightError("Only PostgreSQL is supported by this preflight")
    if url.database != EXPECTED_DATABASE:
        raise PreflightError(
            f"Refusing database {url.database!r}; only {EXPECTED_DATABASE!r} is allowed"
        )
    host = (url.host or "").lower().rstrip(".")
    if not host.endswith(".neon.tech"):
        raise PreflightError("Only a Neon PostgreSQL endpoint is allowed")
    sslmode = url.query.get("sslmode")
    if isinstance(sslmode, (tuple, list)):
        sslmode = sslmode[-1] if sslmode else None
    if sslmode not in {"require", "verify-ca", "verify-full"}:
        raise PreflightError("Neon connection must require TLS with sslmode=require or stronger")
    return url


def run_preflight(raw_url: str | None = None) -> dict[str, Any]:
    raw_url = raw_url if raw_url is not None else os.getenv(ENV_NAME)
    validate_database_url(raw_url)
    engine = build_engine(raw_url)
    try:
        with engine.connect() as connection:
            with connection.begin():
                # Must be the first statement in the transaction.
                connection.execute(text("SET TRANSACTION READ ONLY"))
                identity = connection.execute(text(
                    "SELECT current_database() AS database, "
                    "current_setting('transaction_read_only') AS transaction_read_only, "
                    "current_setting('server_version') AS server_version"
                )).mappings().one()
                if identity["database"] != EXPECTED_DATABASE:
                    raise PreflightError("Connected database does not match the required target")
                if str(identity["transaction_read_only"]).lower() not in {"on", "true", "1"}:
                    raise PreflightError("PostgreSQL did not confirm a read-only transaction")

                inspector = inspect(connection)
                tables = sorted(inspector.get_table_names(schema="public"))
                missing_tables = sorted(REQUIRED_TABLES - set(tables))
                alembic_head = connection.execute(text(
                    "SELECT version_num FROM public.alembic_version"
                )).scalar_one_or_none()
                trigger_rows = connection.execute(text("""
                    SELECT t.tgname, t.tgenabled, pg_get_triggerdef(t.oid) AS definition
                    FROM pg_trigger AS t
                    JOIN pg_class AS c ON c.oid = t.tgrelid
                    JOIN pg_namespace AS n ON n.oid = c.relnamespace
                    WHERE n.nspname = 'public'
                      AND c.relname = 'corporate_action_revisions'
                      AND t.tgname = :trigger_name
                      AND NOT t.tgisinternal
                """), {"trigger_name": EXPECTED_APPEND_ONLY_TRIGGER}).mappings().all()
                revision_count = connection.execute(text(
                    "SELECT count(*) FROM public.corporate_action_revisions"
                )).scalar_one()
                safety_state = connection.execute(text(
                    "SELECT status FROM public.system_safety_state WHERE id = 1"
                )).scalar_one_or_none()
                risk_paused = connection.execute(text(
                    "SELECT paused FROM public.risk_control_state WHERE id = 1"
                )).scalar_one_or_none()

                if missing_tables:
                    raise PreflightError(f"Required tables are missing: {missing_tables}")
                if alembic_head != EXPECTED_ALEMBIC_HEAD:
                    raise PreflightError(
                        f"Unexpected Alembic head: {alembic_head!r}; "
                        f"expected {EXPECTED_ALEMBIC_HEAD!r}"
                    )
                if len(trigger_rows) != 1 or trigger_rows[0]["tgenabled"] not in {"O", "A"}:
                    raise PreflightError("Append-only trigger is missing or disabled")
                trigger_definition = trigger_rows[0]["definition"].upper()
                if "BEFORE DELETE OR UPDATE" not in trigger_definition:
                    raise PreflightError("Append-only trigger does not protect UPDATE and DELETE")

                return {
                    "status": "passed",
                    "checked_at": datetime.now(timezone.utc).isoformat(),
                    "database": identity["database"],
                    "server_version": identity["server_version"],
                    "transaction_read_only": str(identity["transaction_read_only"]),
                    "alembic_head": alembic_head,
                    "public_table_count": len(tables),
                    "required_tables_present": True,
                    "append_only_trigger": {
                        "name": trigger_rows[0]["tgname"],
                        "enabled_code": trigger_rows[0]["tgenabled"],
                        "definition": trigger_rows[0]["definition"],
                    },
                    "corporate_action_revision_count": int(revision_count),
                    "system_safety_state": safety_state,
                    "risk_control_paused": risk_paused,
                    "writes_performed": False,
                }
    finally:
        engine.dispose()


def main() -> int:
    try:
        result = run_preflight()
    except Exception as exc:
        # Never print arbitrary driver errors: they may contain connection details.
        message = str(exc).splitlines()[0] if isinstance(exc, PreflightError) else type(exc).__name__
        print(json.dumps({"status": "failed", "error": message}, indent=2))
        return 1
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
