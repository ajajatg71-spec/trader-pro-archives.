"""Read-only connectivity check for an explicitly configured Alpaca Paper account.

This script never submits, replaces, or cancels an order. Run only after setting
BROKER=alpaca and the Paper API credentials in the local environment.
"""
from __future__ import annotations

import math
import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

os.environ.setdefault("BROKER", "alpaca")

from config import BASE, KEY, SECRET, SIM  # noqa: E402
from broker import bars3, account, clock, is_approved_paper_url, positions  # noqa: E402


def main() -> int:
    if SIM:
        print("REFUS: BROKER=sim détecté; configurez explicitement BROKER=alpaca.", file=sys.stderr)
        return 2
    if not is_approved_paper_url(BASE):
        print("REFUS: seule l'URL officielle Alpaca Paper HTTPS est autorisée.", file=sys.stderr)
        return 2
    if not KEY or not SECRET:
        print("REFUS: APCA_API_KEY_ID ou APCA_API_SECRET_KEY manquant.", file=sys.stderr)
        return 2

    try:
        acct = account()
        pos = positions()
        market_clock = clock()
        timestamps, closes, volumes = bars3("SPY", limit=5)
        if not isinstance(acct, dict) or not isinstance(pos, list) or not isinstance(market_clock, dict):
            raise RuntimeError("Réponse Alpaca mal formée")
        status = acct.get("status")
        trading_blocked = acct.get("trading_blocked")
        if not isinstance(status, str) or not status.strip() or not isinstance(trading_blocked, bool):
            raise RuntimeError("Réponse du compte incomplète : statut ou trading_blocked absent")
        if trading_blocked:
            raise RuntimeError("Le compte Paper est bloqué par le courtier")
        for position in pos:
            if (not isinstance(position, dict)
                    or not isinstance(position.get("symbol"), str)
                    or not position.get("symbol", "").strip()
                    or position.get("qty") is None
                    or position.get("side") not in {"long", "short"}):
                raise RuntimeError("Réponse des positions mal formée")
        if not isinstance(market_clock.get("is_open"), bool):
            raise RuntimeError("Réponse de l'horloge de marché incomplète")
        if not (len(timestamps) == len(closes) == len(volumes) and len(closes) >= 1):
            raise RuntimeError("Données SPY absentes ou incohérentes")
        for stamp, close, volume in zip(timestamps, closes, volumes):
            try:
                close_value = float(close)
                volume_value = float(volume)
            except (TypeError, ValueError):
                raise RuntimeError("Barre SPY contenant des valeurs non numériques") from None
            if (not isinstance(stamp, str) or not stamp.strip()
                    or not math.isfinite(close_value) or close_value <= 0
                    or not math.isfinite(volume_value) or volume_value < 0):
                raise RuntimeError("Barre SPY contenant des valeurs invalides")
    except Exception as exc:
        print(f"ÉCHEC CONNEXION PAPER: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1

    print("ALPACA_PAPER_READ_ONLY_OK")
    print(f"account_status={acct.get('status', 'unknown')}")
    print(f"trading_blocked={acct.get('trading_blocked', 'unknown')}")
    print(f"market_open={market_clock.get('is_open', 'unknown')}")
    print(f"positions_count={len(pos)}")
    print(f"spy_daily_bars={len(closes)}")
    print("orders_submitted=0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
