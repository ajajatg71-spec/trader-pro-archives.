# Disposable PostgreSQL 16 container for real integration tests.
# The database is stored in tmpfs and the container is removed in finally.
$ErrorActionPreference = 'Stop'
& docker compose version
if ($LASTEXITCODE -ne 0) { throw 'Docker Compose v2 est requis.' }
$compose = @('compose', '-f', 'compose.test.yaml')
try {
    & docker @compose up -d --wait
    if ($LASTEXITCODE -ne 0) { throw 'Impossible de démarrer PostgreSQL 16 de test.' }
    $env:TRADER_PRO_TEST_DATABASE_DISPOSABLE = 'YES'
$env:TRADER_PRO_TEST_DATABASE_URL = 'postgresql+psycopg://trader_pro:trader_pro_test_only@127.0.0.1:55432/trader_pro_test'
    $env:TRADER_PRO_RESTORE_DATABASE_URL = 'postgresql+psycopg://trader_pro:trader_pro_test_only@127.0.0.1:55432/trader_pro_restore'
    $env:DATABASE_URL = $env:TRADER_PRO_TEST_DATABASE_URL
    & python -m alembic upgrade head
    if ($LASTEXITCODE -ne 0) { throw 'Échec des migrations PostgreSQL.' }
    & python -m pytest -q tests/test_postgres_integration.py
    if ($LASTEXITCODE -ne 0) { throw 'Échec des tests PostgreSQL réels.' }
    & python -m pytest -q
    if ($LASTEXITCODE -ne 0) { throw 'Échec de la suite Pytest.' }
    & python -m unittest discover -q
    if ($LASTEXITCODE -ne 0) { throw 'Échec de la suite Unittest.' }
    & python -m compileall -q .
    if ($LASTEXITCODE -ne 0) { throw 'Échec de compilation.' }
    Write-Host 'DISPOSABLE_POSTGRES_16_INTEGRATION_TESTS_PASSED'
}
finally {
    & docker @compose down --volumes --remove-orphans
}
