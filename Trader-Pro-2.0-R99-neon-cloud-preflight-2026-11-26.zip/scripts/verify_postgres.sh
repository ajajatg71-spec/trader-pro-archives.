#!/usr/bin/env bash
# End-to-end PostgreSQL verification. All databases must be explicitly disposable.
set -euo pipefail
: "${TRADER_PRO_TEST_DATABASE_URL:?Set TRADER_PRO_TEST_DATABASE_URL to a disposable database ending in _test}"
: "${TRADER_PRO_TEST_DATABASE_DISPOSABLE:?Set TRADER_PRO_TEST_DATABASE_DISPOSABLE=YES only for a disposable local database}"
[[ "$TRADER_PRO_TEST_DATABASE_DISPOSABLE" == "YES" ]] || { echo "Refus : TRADER_PRO_TEST_DATABASE_DISPOSABLE must be YES" >&2; exit 2; }
: "${TRADER_PRO_RESTORE_DATABASE_URL:?Set TRADER_PRO_RESTORE_DATABASE_URL to a separate empty disposable database ending in _restore}"
command -v alembic >/dev/null || { echo "alembic is required" >&2; exit 2; }
command -v pytest >/dev/null || { echo "pytest is required" >&2; exit 2; }
command -v psql >/dev/null || { echo "psql is required" >&2; exit 2; }
command -v pg_dump >/dev/null || { echo "pg_dump is required" >&2; exit 2; }
command -v pg_restore >/dev/null || { echo "pg_restore is required" >&2; exit 2; }

# Convert SQLAlchemy's postgresql+psycopg URL into a libpq-compatible URI for
# pg_dump/pg_restore/psql. Keep credentials out of command output.
mapfile -t PG_TOOL_URLS < <(python - "$TRADER_PRO_TEST_DATABASE_URL" "$TRADER_PRO_RESTORE_DATABASE_URL" <<'PGURLS'
import sys
from sqlalchemy.engine import make_url
source, restore = map(make_url, sys.argv[1:])
if not source.database or not source.database.lower().endswith("_test"):
    raise SystemExit("Refus : la base de test doit se terminer par _test")
if not restore.database or not restore.database.lower().endswith("_restore"):
    raise SystemExit("Refus : la base de restauration doit se terminer par _restore")
if (source.host, source.port, source.database) == (restore.host, restore.port, restore.database):
    raise SystemExit("Refus : source et cible de restauration identiques")
for url in (source, restore):
    if (url.host or "").lower() not in {"localhost", "127.0.0.1", "::1"}:
        raise SystemExit("Refus : la validation destructive exige un PostgreSQL local jetable; aucun serveur distant n'est accepté")
    print(url.set(drivername="postgresql").render_as_string(hide_password=False))
PGURLS
)
if [[ ${#PG_TOOL_URLS[@]} -ne 2 ]]; then
  echo "Impossible de préparer les URL PostgreSQL pour les outils natifs." >&2
  exit 2
fi
PG_TEST_URL="${PG_TOOL_URLS[0]}"
PG_RESTORE_URL="${PG_TOOL_URLS[1]}"

# Refuse to restore over any existing public table; never overwrite user data.
RESTORE_TABLE_COUNT="$(psql "$PG_RESTORE_URL" -v ON_ERROR_STOP=1 -Atqc \
  "SELECT count(*) FROM information_schema.tables WHERE table_schema='public'")"
if [[ "$RESTORE_TABLE_COUNT" != "0" ]]; then
  echo "Refus : la base _restore doit être vide (tables publiques détectées: $RESTORE_TABLE_COUNT)." >&2
  exit 2
fi

export DATABASE_URL="$TRADER_PRO_TEST_DATABASE_URL"
echo "[1/5] Apply Alembic migrations to dedicated test database"
alembic upgrade head

echo "[2/5] Run PostgreSQL integration tests (at least one real test must pass; skips are forbidden)"
if ! PG_INTEGRATION_OUTPUT="$(pytest -q -rs tests/test_postgres_integration.py 2>&1)"; then
  printf '%s\n' "$PG_INTEGRATION_OUTPUT" >&2
  echo "Échec des tests d’intégration PostgreSQL." >&2
  exit 1
fi
printf '%s\n' "$PG_INTEGRATION_OUTPUT"
if grep -Eq '[0-9]+ skipped' <<<"$PG_INTEGRATION_OUTPUT"; then
  echo "Refus : au moins un test PostgreSQL a été ignoré ; validation réelle incomplète." >&2
  exit 1
fi
if ! grep -Eq '[0-9]+ passed' <<<"$PG_INTEGRATION_OUTPUT"; then
  echo "Refus : aucun test PostgreSQL réussi détecté." >&2
  exit 1
fi

echo "[3/5] Create and validate custom-format backup"
mkdir -p "${BACKUP_DIR:-backups/postgres}"
BACKUP_FILE="${BACKUP_DIR:-backups/postgres}/trader_pro_verify_$(date -u +%Y%m%dT%H%M%SZ).dump"
pg_dump --dbname="$PG_TEST_URL" --format=custom --no-owner --no-acl --file="$BACKUP_FILE"
pg_restore --list "$BACKUP_FILE" >/dev/null
sha256sum "$BACKUP_FILE" > "$BACKUP_FILE.sha256"

echo "[4/5] Restore backup into a separate empty _restore database"
pg_restore --exit-on-error --no-owner --no-acl --dbname="$PG_RESTORE_URL" "$BACKUP_FILE"

echo "[5/5] Compare restored schema, every table row count and Alembic revision (read-only)"
python scripts/verify_postgres_restore.py

echo "PostgreSQL migration, integration, backup and restore checks passed. Backup: $BACKUP_FILE"
