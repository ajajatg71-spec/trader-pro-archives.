#!/usr/bin/env bash
set -euo pipefail
PYTHON_BIN="${PYTHON_BIN:-python3}"
ENV_DIR="${VENV_DIR:-.venv}"
"${PYTHON_BIN}" -m venv "${ENV_DIR}"
"${ENV_DIR}/bin/python" -m pip install --upgrade pip
"${ENV_DIR}/bin/python" -m pip install -r requirements-dev.txt
printf '\nEnvironment ready. Activate with: source %s/bin/activate\n' "${ENV_DIR}"
