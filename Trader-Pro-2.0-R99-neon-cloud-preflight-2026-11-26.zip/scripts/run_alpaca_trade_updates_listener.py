"""Listen to Alpaca Paper trade_updates and persist notifications to PostgreSQL."""
from __future__ import annotations

import argparse
import json
import logging
import os
import signal
import sys
import threading
import time
from urllib.parse import urlsplit

PAPER_STREAM_URL = "wss://paper-api.alpaca.markets/stream"


def validate_environment(env: dict[str, str]) -> tuple[str, str, str, str]:
    database_url = env.get("DATABASE_URL", "").strip()
    broker_mode = env.get("BROKER", "alpaca").strip().lower()
    base_url = env.get("ALPACA_BASE_URL", "https://paper-api.alpaca.markets").strip()
    stream_url = env.get("ALPACA_TRADE_UPDATES_URL", PAPER_STREAM_URL).strip()
    key = env.get("APCA_API_KEY_ID", "").strip()
    secret = env.get("APCA_API_SECRET_KEY", "").strip()
    if broker_mode != "alpaca":
        raise ValueError("Le listener exige BROKER=alpaca (Paper uniquement)")
    if not database_url.startswith(("postgresql://", "postgresql+psycopg://")):
        raise ValueError("DATABASE_URL doit désigner PostgreSQL")
    if base_url != "https://paper-api.alpaca.markets":
        raise ValueError("Seul l'endpoint Alpaca Paper officiel est autorisé")
    parsed = urlsplit(stream_url)
    if (stream_url != PAPER_STREAM_URL or parsed.scheme != "wss"
            or parsed.hostname != "paper-api.alpaca.markets"):
        raise ValueError("Seul le WebSocket officiel Alpaca Paper est autorisé")
    if not key or not secret:
        raise ValueError("Clés Alpaca Paper manquantes")
    return database_url, stream_url, key, secret


def _decode_frame(frame):
    if isinstance(frame, bytes):
        frame = frame.decode("utf-8")
    return json.loads(frame)


def serve_connection(ws, processor, key: str, secret: str, stop: threading.Event,
                     logger: logging.Logger) -> None:
    """Authenticate, subscribe, and persist each trade update until disconnect."""
    from services.alpaca_trade_updates import persist_trade_update
    from websocket import WebSocketTimeoutException
    ws.settimeout(2.0)
    ws.send(json.dumps({"action": "auth", "key": key, "secret": secret}))
    authorized = False
    deadline = time.monotonic() + 15
    while not stop.is_set() and time.monotonic() < deadline:
        try:
            response = _decode_frame(ws.recv())
        except WebSocketTimeoutException:
            continue
        if not isinstance(response, dict):
            continue
        if response.get("stream") == "authorization":
            status = (response.get("data") or {}).get("status")
            if status != "authorized":
                raise RuntimeError("Authentification Alpaca Paper refusée")
            authorized = True
            break
    if not authorized:
        raise RuntimeError("Délai d'authentification Alpaca dépassé")
    ws.send(json.dumps({"action": "listen", "data": {"streams": ["trade_updates"]}}))
    subscribed = False
    deadline = time.monotonic() + 15
    while not stop.is_set() and time.monotonic() < deadline:
        try:
            response = _decode_frame(ws.recv())
        except WebSocketTimeoutException:
            continue
        if not isinstance(response, dict):
            continue
        if response.get("stream") == "authorization":
            raise RuntimeError("Autorisation Alpaca refusée lors de l'abonnement")
        if response.get("stream") == "listening":
            streams = (response.get("data") or {}).get("streams") or []
            if "trade_updates" not in streams:
                raise RuntimeError("Alpaca n'a pas confirmé trade_updates")
            subscribed = True
            break
    if not subscribed:
        raise RuntimeError("Délai de confirmation trade_updates dépassé")
    logger.info("Flux Alpaca Paper trade_updates connecté")
    while not stop.is_set():
        try:
            frame = ws.recv()
        except WebSocketTimeoutException:
            continue
        try:
            message = _decode_frame(frame)
        except (UnicodeDecodeError, json.JSONDecodeError, TypeError):
            logger.warning("Trame trade_updates invalide ignorée")
            continue
        if isinstance(message, dict) and message.get("stream") == "trade_updates":
            inserted = persist_trade_update(message, processor)
            logger.info("Notification broker persistée (nouvelle=%s)", inserted)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--max-reconnect-seconds", type=int, default=60)
    args = parser.parse_args()
    if not 1 <= args.max_reconnect_seconds <= 600:
        parser.error("max-reconnect-seconds doit être entre 1 et 600")
    try:
        database_url, stream_url, key, secret = validate_environment(dict(os.environ))
    except ValueError as exc:
        print(f"Configuration refusée : {exc}", file=sys.stderr)
        return 2

    import websocket
    from db.session import build_engine, build_session_factory
    from services.broker_events import BrokerEventProcessor
    from services.reconciliation import ReconciliationService
    from db.order_repository import OrderRepository
    import broker
    from services.strategy_engine.persistence import StrategyPersistence

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logger = logging.getLogger("trader_pro.alpaca_trade_updates")
    engine = build_engine(database_url)
    sessions = build_session_factory(engine)
    reconciliation = ReconciliationService(OrderRepository(sessions), broker,
                                           StrategyPersistence(sessions))
    processor = BrokerEventProcessor(sessions, reconciliation)
    stop = threading.Event()
    def request_stop(signum, frame):  # noqa: ARG001
        logger.info("Arrêt demandé (%s)", signum)
        stop.set()
    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGINT, request_stop)
    delay = 1
    try:
        while not stop.is_set():
            ws = None
            try:
                ws = websocket.create_connection(stream_url, timeout=10,
                    enable_multithread=True, sslopt={"cert_reqs": 2})
                serve_connection(ws, processor, key, secret, stop, logger)
                delay = 1
            except Exception as exc:
                if not stop.is_set():
                    logger.warning("Flux Alpaca interrompu (%s); reconnexion dans %ss",
                                   type(exc).__name__, delay)
                    stop.wait(delay)
                    delay = min(delay * 2, args.max_reconnect_seconds)
            finally:
                if ws is not None:
                    try:
                        ws.close()
                    except Exception:
                        pass
    finally:
        engine.dispose()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
