#!/usr/bin/env python3
"""Read-only verification that a restored disposable PostgreSQL DB matches its source."""
from __future__ import annotations

import os
import sys

from sqlalchemy import create_engine, inspect, text
from sqlalchemy.engine import make_url


def _validated_url(name: str, suffix: str):
    raw = os.environ.get(name)
    if not raw:
        raise RuntimeError(f"Variable {name} absente")
    url = make_url(raw)
    if not url.database or not url.database.lower().endswith(suffix):
        raise RuntimeError(f"{name}: la base doit se terminer par {suffix}")
    if (url.host or "").lower() not in {"localhost", "127.0.0.1", "::1"}:
        raise RuntimeError(f"{name}: validation de restauration limitée à localhost")
    return url


def _snapshot(url) -> tuple[set[str], dict[str, int], tuple[str, ...]]:
    engine = create_engine(url, pool_pre_ping=True)
    try:
        with engine.connect() as connection:
            with connection.begin():
                connection.execute(text("SET TRANSACTION READ ONLY"))
                inspector = inspect(connection)
                tables = set(inspector.get_table_names(schema="public"))
                counts: dict[str, int] = {}
                for table in sorted(tables):
                    # Table names come from PostgreSQL's own inspector and are
                    # quoted as identifiers; no user-provided SQL is interpolated.
                    quoted = connection.dialect.identifier_preparer.quote(table)
                    counts[table] = int(
                        connection.execute(
                            text(f"SELECT count(*) FROM public.{quoted}")
                        ).scalar_one()
                    )
                versions: tuple[str, ...] = ()
                if "alembic_version" in tables:
                    versions = tuple(
                        str(row[0])
                        for row in connection.execute(
                            text("SELECT version_num FROM public.alembic_version ORDER BY version_num")
                        )
                    )
                return tables, counts, versions
    finally:
        engine.dispose()


def main() -> int:
    source_url = _validated_url("TRADER_PRO_TEST_DATABASE_URL", "_test")
    restore_url = _validated_url("TRADER_PRO_RESTORE_DATABASE_URL", "_restore")
    if (source_url.host, source_url.port, source_url.database) == (
        restore_url.host,
        restore_url.port,
        restore_url.database,
    ):
        raise RuntimeError("Source et cible de restauration identiques")

    source_tables, source_counts, source_versions = _snapshot(source_url)
    restored_tables, restored_counts, restored_versions = _snapshot(restore_url)
    if source_tables != restored_tables:
        missing = sorted(source_tables - restored_tables)
        extra = sorted(restored_tables - source_tables)
        raise RuntimeError(f"Schémas différents; tables absentes={missing}, supplémentaires={extra}")
    mismatches = {
        table: (source_counts[table], restored_counts[table])
        for table in sorted(source_tables)
        if source_counts[table] != restored_counts[table]
    }
    if mismatches:
        raise RuntimeError(f"Nombre de lignes différent (source, restaurée): {mismatches}")
    if source_versions != restored_versions:
        raise RuntimeError(
            f"Versions Alembic différentes: source={source_versions}, restaurée={restored_versions}"
        )

    print(
        "Restauration PostgreSQL vérifiée en lecture seule: "
        f"{len(source_tables)} tables, {sum(source_counts.values())} lignes, "
        f"Alembic={source_versions or 'non présent'}"
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:  # concise failure for CI; never print database URLs
        print(f"Échec de vérification PostgreSQL: {exc}", file=sys.stderr)
        raise SystemExit(1)
