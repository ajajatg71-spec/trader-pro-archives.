#!/usr/bin/env bash
# Start a disposable local PostgreSQL 16 container, run real integration tests,
# then destroy the container and its tmpfs data. Never uses the application DB.
set -euo pipefail
command -v docker >/dev/null || { echo "Docker is required for this isolated test environment." >&2; exit 2; }
docker compose version >/dev/null
COMPOSE=(docker compose -f compose.test.yaml)
cleanup() { "${COMPOSE[@]}" down --volumes --remove-orphans >/dev/null 2>&1 || true; }
trap cleanup EXIT INT TERM
"${COMPOSE[@]}" up -d --wait
export TRADER_PRO_TEST_DATABASE_DISPOSABLE='YES'
export TRADER_PRO_TEST_DATABASE_URL='postgresql+psycopg://trader_pro:trader_pro_test_only@127.0.0.1:55432/trader_pro_test'
export TRADER_PRO_RESTORE_DATABASE_URL='postgresql+psycopg://trader_pro:trader_pro_test_only@127.0.0.1:55432/trader_pro_restore'
export DATABASE_URL="$TRADER_PRO_TEST_DATABASE_URL"
python -m alembic upgrade head
python -m pytest -q tests/test_postgres_integration.py
python -m pytest -q
python -m unittest discover -q
python -m compileall -q .
echo 'DISPOSABLE_POSTGRES_16_INTEGRATION_TESTS_PASSED'
