#!/usr/bin/env bash
# Generate a real npm lockfile from the declared package.json, then validate it.
# Requires Node.js/npm and access to the configured npm registry.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT/frontend"
command -v npm >/dev/null || { echo "npm is required" >&2; exit 2; }
node --version
npm --version
npm install --package-lock-only --ignore-scripts --no-audit --no-fund
test -s package-lock.json || { echo "npm did not generate package-lock.json" >&2; exit 1; }
npm ci --ignore-scripts --no-audit --no-fund
npm run typecheck
npm run build
echo "Frontend lockfile, clean install, typecheck and Vite build passed."
