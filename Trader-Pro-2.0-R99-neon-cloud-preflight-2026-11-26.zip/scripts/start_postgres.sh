#!/usr/bin/env sh
set -eu

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker n'est pas installé. Installe Docker Desktop, puis relance ce script." >&2
  exit 2
fi
if [ ! -f .env ]; then
  echo "Fichier .env absent. Copie .env.example vers .env et définis POSTGRES_PASSWORD." >&2
  exit 2
fi

docker compose up -d postgres
printf '%s\n' "Attente de PostgreSQL..."
for i in $(seq 1 60); do
  if docker compose exec -T postgres pg_isready -U "$(grep '^POSTGRES_USER=' .env | cut -d= -f2 | tr -d '\r' || true)" >/dev/null 2>&1; then
    echo "PostgreSQL répond. Lance ensuite : alembic upgrade head"
    exit 0
  fi
  sleep 2
done
echo "PostgreSQL n'est pas devenu disponible dans le délai prévu." >&2
exit 1
