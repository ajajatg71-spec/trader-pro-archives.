"""Fail-closed production configuration checks; never prints secret values."""
from __future__ import annotations

import argparse
import base64
import os
import sys
import ipaddress
from urllib.parse import urlparse

PAPER_URL = "https://paper-api.alpaca.markets"


def _valid_base32(value: str) -> bool:
    if not value:
        return False
    try:
        base64.b32decode(value.upper() + "=" * ((8 - len(value) % 8) % 8), casefold=True)
        return True
    except Exception:
        return False


def validate_environment(env: dict[str, str]) -> list[str]:
    errors: list[str] = []
    if env.get("BROKER", "").strip().lower() != "alpaca":
        errors.append("BROKER doit être explicitement défini sur 'alpaca' pour le contrôle Paper de production.")
    raw_base_url = env.get("ALPACA_BASE_URL", "").strip()
    if not raw_base_url:
        errors.append("ALPACA_BASE_URL doit être explicitement défini sur l'endpoint Paper.")
    base_url = raw_base_url.rstrip("/")
    parsed = urlparse(base_url)
    if base_url != PAPER_URL or parsed.scheme != "https" or parsed.hostname != "paper-api.alpaca.markets":
        errors.append("ALPACA_BASE_URL doit être exactement l'endpoint officiel Alpaca Paper.")
    if not env.get("APCA_API_KEY_ID", "").strip() or not env.get("APCA_API_SECRET_KEY", "").strip():
        errors.append("Les deux identifiants Alpaca Paper sont requis.")
    if not env.get("SEC_USER_AGENT", "").strip():
        errors.append("SEC_USER_AGENT doit être défini avec un contact opérateur valide.")
    app_password = env.get("APP_PASSWORD", "")
    if len(app_password) < 12:
        errors.append("APP_PASSWORD doit contenir au moins 12 caractères.")
    totp = env.get("TOTP_SECRET", "")
    if not _valid_base32(totp):
        errors.append("TOTP_SECRET doit être un secret Base32 valide.")
    db_url = env.get("DATABASE_URL", "").strip()
    if not db_url.startswith(("postgresql://", "postgresql+psycopg://")):
        errors.append("DATABASE_URL doit pointer vers PostgreSQL via psycopg.")
    operator_password = env.get("TRADER_OPERATOR_PASSWORD", "")
    if len(operator_password) < 20:
        errors.append("TRADER_OPERATOR_PASSWORD doit contenir au moins 20 caractères.")
    operator_totp = env.get("TRADER_OPERATOR_TOTP_SECRET", "")
    if not _valid_base32(operator_totp):
        errors.append("TRADER_OPERATOR_TOTP_SECRET doit être un secret Base32 valide.")
    secrets = [value for value in (app_password, totp, operator_password, operator_totp) if value]
    if len(secrets) != len(set(secrets)):
        errors.append("Les mots de passe et secrets TOTP doivent tous être distincts.")
    proxy_value = env.get("TRUSTED_PROXY_IPS", "").strip()
    if proxy_value:
        try:
            for item in proxy_value.split(","):
                item = item.strip()
                if not item or item == "*":
                    raise ValueError("empty or wildcard")
                network = ipaddress.ip_network(item, strict=False)
                # Require a narrowly scoped proxy range; broad trust defeats proxy validation.
                min_prefix = 16 if network.version == 4 else 32
                if network.prefixlen < min_prefix:
                    raise ValueError("proxy range too broad")
        except ValueError:
            errors.append("TRUSTED_PROXY_IPS doit contenir uniquement des IP/CIDR valides et précis (IPv4 /16 minimum, IPv6 /32 minimum).")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-db", action="store_true", help="teste aussi la connexion PostgreSQL")
    args = parser.parse_args()
    errors = validate_environment(dict(os.environ))
    if args.check_db and not errors:
        try:
            from sqlalchemy import create_engine, text
            from db.session import normalize_database_url
            engine = create_engine(normalize_database_url(os.environ["DATABASE_URL"]), pool_pre_ping=True)
            with engine.connect() as connection:
                connection.execute(text("SELECT 1"))
            engine.dispose()
        except Exception as exc:  # avoid leaking DSN/credentials in deployment logs
            errors.append(f"Connexion PostgreSQL impossible ({type(exc).__name__}).")
    if errors:
        print("PRÉVOL DÉPLOIEMENT : ÉCHEC")
        for error in errors:
            print(f"- {error}")
        return 1
    print("PRÉVOL DÉPLOIEMENT : configuration cohérente. (Aucune commande de trading n'a été envoyée.)")
    if not args.check_db:
        print("Connexion PostgreSQL non testée : relancer avec --check-db.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
