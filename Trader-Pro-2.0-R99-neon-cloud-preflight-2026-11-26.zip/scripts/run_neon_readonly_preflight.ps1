# Run the R97 SQLAlchemy preflight against Neon trader_pro_test without exposing credentials.
# The URL is entered as a SecureString, held only for this process, and never written to disk.
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Push-Location $projectRoot
$secureUrl = $null
$bstr = [IntPtr]::Zero
try {
    $venvPython = Join-Path $projectRoot '.venv\Scripts\python.exe'
    if (-not (Test-Path $venvPython)) {
        throw 'Environnement .venv absent. Exécutez d’abord scripts\prepare_windows_validation.ps1.'
    }
    & $venvPython -c 'import sqlalchemy, psycopg' *> $null
    if ($LASTEXITCODE -ne 0) {
        throw 'Pilote PostgreSQL manquant. Exécutez d’abord scripts\prepare_windows_validation.ps1.'
    }

    $secureUrl = Read-Host 'Collez l’URL Neon de trader_pro_test (saisie masquée; ne la partagez pas)' -AsSecureString
    if ($null -eq $secureUrl -or $secureUrl.Length -eq 0) { throw 'URL Neon vide.' }
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureUrl)
    $env:TRADER_PRO_TEST_DATABASE_URL = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)

    & $venvPython 'scripts/verify_neon_sqlalchemy_readonly.py'
    if ($LASTEXITCODE -ne 0) { throw 'Le précontrôle SQLAlchemy Neon a échoué. Consulter uniquement le code d’erreur, jamais l’URL.' }
    Write-Host 'NEON_SQLALCHEMY_READONLY_PREFLIGHT_PASSED'
}
finally {
    Remove-Item Env:TRADER_PRO_TEST_DATABASE_URL -ErrorAction SilentlyContinue
    if ($bstr -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
    if ($null -ne $secureUrl) { $secureUrl.Dispose() }
    Pop-Location
}
