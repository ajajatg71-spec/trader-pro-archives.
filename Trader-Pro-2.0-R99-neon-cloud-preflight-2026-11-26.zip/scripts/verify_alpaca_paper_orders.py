"""Opt-in Alpaca Paper write test: place one non-marketable limit order, then cancel it.

This is deliberately separate from the read-only connectivity check. It requires
an explicit environment confirmation and the official Paper endpoint. It never
supports the Live endpoint.
"""
from __future__ import annotations

import os
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

os.environ.setdefault("BROKER", "alpaca")

from config import BASE, KEY, SECRET, SIM  # noqa: E402
from broker import (  # noqa: E402
    account, cancel, clock, is_approved_paper_url, limit_order, order_get, _r,
)

SYMBOL = "F"  # Liquid, lower-priced US equity to keep the Paper notional modest.
QTY = "1"
TERMINAL = {"canceled", "cancelled", "filled", "expired", "rejected"}


def cancel_and_confirm(order_id: str, attempts: int = 30) -> dict:
    """Cancel a Paper order and confirm a zero-fill canceled terminal state."""
    cancel(order_id)
    current = {}
    last_status = "unknown"
    for attempt in range(attempts):
        current = order_get(order_id)
        last_status = str(current.get("status", "unknown")).lower()
        if last_status in TERMINAL:
            break
        if attempt + 1 < attempts:
            time.sleep(1)
    if last_status != "canceled":
        raise RuntimeError(f"Annulation non confirmée; statut final={last_status}; vérifier l'ordre {order_id}")
    try:
        filled_qty = float(current.get("filled_qty") or 0)
    except (TypeError, ValueError):
        raise RuntimeError(f"Quantité exécutée illisible pour l'ordre {order_id}")
    if filled_qty != 0:
        raise RuntimeError(f"Ordre annulé avec quantité exécutée inattendue: {current.get('filled_qty')}")
    return current


def main() -> int:
    if os.getenv("TRADER_PRO_ENABLE_PAPER_ORDER_TEST") != "YES_I_CONFIRM_PAPER_ONLY":
        print("REFUS: définir TRADER_PRO_ENABLE_PAPER_ORDER_TEST=YES_I_CONFIRM_PAPER_ONLY pour autoriser un ordre Paper.", file=sys.stderr)
        return 2
    if SIM or not is_approved_paper_url(BASE):
        print("REFUS: seul le endpoint officiel Alpaca Paper est autorisé.", file=sys.stderr)
        return 2
    if not KEY or not SECRET:
        print("REFUS: identifiants Alpaca Paper manquants.", file=sys.stderr)
        return 2

    client_id = f"tp-paper-check-{uuid.uuid4().hex[:24]}"
    broker_order_id = None
    try:
        acct = account()
        if not isinstance(acct, dict) or acct.get("status") != "ACTIVE" or acct.get("trading_blocked") is True:
            raise RuntimeError("Compte Paper inactif ou bloqué")
        market_clock = clock()
        if not isinstance(market_clock, dict) or market_clock.get("is_open") is not True:
            raise RuntimeError("Marché actions fermé : aucun ordre de test n'a été envoyé")
        asset = _r("GET", f"/v2/assets/{SYMBOL}")
        if not isinstance(asset, dict) or asset.get("tradable") is not True:
            raise RuntimeError(f"Actif {SYMBOL} non négociable sur ce compte")
        quote_response = _r("GET", f"/v2/stocks/{SYMBOL}/quotes/latest", base="https://data.alpaca.markets",
                            params={"feed": "iex"})
        quote = quote_response.get("quote") if isinstance(quote_response, dict) else None
        from decimal import Decimal, ROUND_DOWN
        if not isinstance(quote, dict):
            raise RuntimeError("Cotation IEX absente pour déterminer un prix limite sûr")
        stamp = quote.get("t")
        if not isinstance(stamp, str):
            raise RuntimeError("Horodatage de cotation IEX absent")
        quote_time = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
        if quote_time.tzinfo is None:
            raise RuntimeError("Horodatage de cotation sans fuseau horaire")
        age_seconds = (datetime.now(timezone.utc) - quote_time.astimezone(timezone.utc)).total_seconds()
        if age_seconds < -5 or age_seconds > 120:
            raise RuntimeError(f"Cotation IEX périmée ou future (âge={age_seconds:.1f}s)")
        bid = Decimal(str(quote.get("bp", "0")))
        ask = Decimal(str(quote.get("ap", "0")))
        if not bid.is_finite() or not ask.is_finite() or bid <= 0 or ask < bid:
            raise RuntimeError("Cotation IEX invalide ou croisée")
        # One percent below the current bid: non-marketable by construction at
        # quote time, but close enough to avoid an arbitrary extreme limit price.
        limit_price = (bid * Decimal("0.99")).quantize(Decimal("0.01"), rounding=ROUND_DOWN)
        if limit_price <= 0 or limit_price >= bid:
            raise RuntimeError("Impossible de construire un prix limite non marketable")
        limit_price_text = format(limit_price, ".2f")

        created = limit_order(SYMBOL, "buy", QTY, limit_price_text, client_id)
        if not isinstance(created, dict) or not created.get("id"):
            raise RuntimeError("Le broker n'a pas retourné d'identifiant d'ordre")
        broker_order_id = str(created["id"])
        if created.get("client_order_id") != client_id:
            raise RuntimeError("client_order_id retourné différent de celui demandé")
        if str(created.get("status", "")).lower() == "filled":
            raise RuntimeError("L'ordre de test a été exécuté immédiatement; contrôle manuel requis")

        # Verify lookup-by-client-ID resolves the exact same broker order.
        looked_up = _r("GET", "/v2/orders:by_client_order_id", params={"client_order_id": client_id})
        if str(looked_up.get("id")) != broker_order_id:
            raise RuntimeError("Recherche par client_order_id incohérente")

        current = cancel_and_confirm(broker_order_id)
        last_status = str(current.get("status", "unknown")).lower()

        print("ALPACA_PAPER_ORDER_CANCEL_OK")
        print(f"account_status={acct.get('status')}; market_open={market_clock.get('is_open')}")
        print(f"symbol={SYMBOL}; qty={QTY}; limit_price={limit_price_text}; reference_bid={bid}")
        print(f"client_order_id={client_id}")
        print(f"broker_order_id={broker_order_id}")
        print(f"final_status={last_status}; filled_qty={current.get('filled_qty', '0')}")
        print("orders_created=1; orders_canceled=1; live_orders=0")
        return 0
    except Exception as exc:
        print(f"ÉCHEC TEST PAPER: {type(exc).__name__}: {exc}", file=sys.stderr)
        if broker_order_id:
            # Best-effort cleanup on every failure after broker acceptance. This
            # does not hide the original error and never retries order creation.
            try:
                cleanup = cancel_and_confirm(broker_order_id, attempts=10)
                print(f"NETTOYAGE: ordre {broker_order_id} annulé; filled_qty={cleanup.get('filled_qty', '0')}", file=sys.stderr)
            except Exception as cleanup_exc:
                print(f"NETTOYAGE NON CONFIRMÉ: {type(cleanup_exc).__name__}: {cleanup_exc}", file=sys.stderr)
                print(f"ACTION MANUELLE: vérifier immédiatement l'ordre {broker_order_id} dans Alpaca Paper.", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
