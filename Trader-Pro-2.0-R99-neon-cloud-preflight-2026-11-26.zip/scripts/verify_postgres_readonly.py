"""Read-only PostgreSQL/Neon connectivity and schema probe.

This script never runs migrations, writes rows, creates tables, or performs
backup/restore. It is intended for the explicitly named Neon validation DBs.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from sqlalchemy import create_engine, text  # noqa: E402
from sqlalchemy.engine import make_url  # noqa: E402

ALLOWED_DATABASES = {"trader_pro_test", "trader_pro_restore"}
REQUIRED_TABLES = {
    "alembic_version",
    "orders",
    "fills",
    "strategy_proposals",
    "position_snapshots",
    "risk_control_state",
    "system_safety_state",
}


def validate_target_url(raw_url: str):
    """Accept only the known Neon validation databases over required TLS."""
    try:
        url = make_url(raw_url)
    except Exception:
        raise ValueError("URL PostgreSQL invalide") from None

    if not url.drivername.startswith("postgresql"):
        raise ValueError("Seul PostgreSQL est accepté")
    host = (url.host or "").lower().rstrip(".")
    if not host.endswith(".neon.tech"):
        raise ValueError("Seul un hôte Neon est accepté par ce contrôle distant")
    if url.database not in ALLOWED_DATABASES:
        raise ValueError("Base refusée : utiliser trader_pro_test ou trader_pro_restore")
    sslmode = str((url.query or {}).get("sslmode", "")).lower()
    if sslmode not in {"require", "verify-ca", "verify-full"}:
        raise ValueError("TLS obligatoire : ajouter sslmode=require à l'URL")
    return url


def main() -> int:
    raw_url = os.getenv("TRADER_PRO_READONLY_DATABASE_URL", "").strip()
    if not raw_url:
        print("REFUS : définir TRADER_PRO_READONLY_DATABASE_URL dans les secrets de l'environnement.", file=sys.stderr)
        return 2

    try:
        validate_target_url(raw_url)
    except ValueError as exc:
        print(f"REFUS : {exc}", file=sys.stderr)
        return 2

    engine = None
    try:
        # PostgreSQL en lecture seule au niveau de la session, en plus de
        # SET TRANSACTION READ ONLY dans la transaction de contrôle.
        engine = create_engine(
            raw_url,
            pool_pre_ping=True,
            connect_args={"options": "-c default_transaction_read_only=on"},
        )
        with engine.connect() as connection:
            with connection.begin():
                connection.exec_driver_sql("SET TRANSACTION READ ONLY")
                database, server_version_num, read_only = connection.execute(text(
                    "SELECT current_database(), current_setting('server_version_num'), "
                    "current_setting('transaction_read_only')"
                )).one()
                tables = set(connection.execute(text(
                    "SELECT table_name FROM information_schema.tables "
                    "WHERE table_schema = 'public' AND table_type = 'BASE TABLE'"
                )).scalars())
                if "alembic_version" not in tables:
                    raise RuntimeError("Table alembic_version absente : migrations non détectées")
                revision = connection.execute(text(
                    "SELECT version_num FROM alembic_version"
                )).scalar_one_or_none()
                missing = sorted(REQUIRED_TABLES - tables)
                if missing:
                    raise RuntimeError("Tables applicatives manquantes : " + ", ".join(missing))
                if str(read_only).lower() not in {"on", "true", "1"}:
                    raise RuntimeError("La transaction n'est pas en lecture seule")
                major = int(server_version_num) // 10000
                if database not in ALLOWED_DATABASES:
                    raise RuntimeError("La base connectée ne correspond pas à la cible autorisée")

        print("POSTGRES_NEON_READ_ONLY_OK")
        print(f"database={database}")
        print(f"postgres_major={major}")
        print(f"alembic_revision={revision or 'unknown'}")
        print(f"required_tables={len(REQUIRED_TABLES)}")
        print("transaction_read_only=on")
        print("writes_performed=0")
        return 0
    except Exception as exc:
        # Do not print exception strings: database drivers can include
        # connection details in them. Keep credentials out of logs.
        print(f"ÉCHEC CONTRÔLE POSTGRESQL: {type(exc).__name__}", file=sys.stderr)
        return 1
    finally:
        if engine is not None:
            engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
