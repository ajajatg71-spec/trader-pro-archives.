# Phase 7 — validation de la garde de cohérence inter-fournisseurs

Date : 11/11/2026

## Modification

`require_consistent_daily_bars` ne fait plus confiance aveuglément à un objet `MarketDataComparison` fourni par l'appelant. La garde valide les sources, les comptages, le recouvrement, les verdicts booléens et les métriques d'écart avant d'appliquer les seuils.

Les cas `NaN`, infinis, booléens utilisés comme nombres de bougies, sources identiques, métriques absentes et rapports incohérents échouent fermés. Les dates équivalentes dans des fuseaux horaires différents sont comparées après normalisation UTC.

## Vérifications exécutées

- `python -m pytest -q tests/test_market_data_service.py tests/test_twelvedata_adapter.py` : 58 tests et 23 sous-tests réussis.
- `python -m pytest -q` : 407 réussis, 3 ignorés, 83 sous-tests réussis.
- `python -m unittest discover -q` : 403 tests réussis.
- `python -m compileall -q .` : réussi.

## Limites non levées

- Aucun appel authentifié réel Alpaca ou Twelve Data n'a été exécuté.
- Le flux Alpaca utilisé par l'application est IEX et ne représente pas le volume consolidé du marché américain.
- Le périmètre exact du volume Twelve Data dépend du produit/compte et reste à vérifier ; les volumes ne doivent pas être considérés comparables par défaut.
- Le contrôle inter-fournisseurs reste opt-in et n'est pas raccordé au chemin d'envoi des ordres.
- Les tests PostgreSQL réels et les tests Paper de bout en bout restent en attente.
