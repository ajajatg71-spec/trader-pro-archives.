# Trader Pro 2.0 — R93 : ingestion Alpaca vers le registre durable

Date : 2026-11-26  
Base : R92

## Objectif
Relier le lecteur Alpaca Corporate Actions (R84) au registre de révisions PostgreSQL/SQLAlchemy (R91-R92), sans inventer l'heure historique d'annonce d'un événement et sans accepter de lot incomplet.

## Modifications
- `db/corporate_action_repository.py` : ajout de `latest_revision(source, event_id)` pour récupérer la dernière révision persistée.
- `services/corporate_actions_ingestion.py` : nouveau service d'ingestion idempotente.
  - Refuse tout lot dont la pagination n'est pas explicitement complète.
  - Utilise l'heure de récupération du lot comme première heure de connaissance (`available_at`) et comme horodatage d'enregistrement ; ne backdate jamais un événement historique à son ex-date/process-date.
  - Ne crée pas de nouvelle révision si l'économie de l'événement est inchangée, même lors d'une récupération ultérieure.
  - Crée une nouvelle révision append-only lorsque les paramètres économiques changent.
  - Exige une résolution explicite de devise lorsque le fournisseur ne renseigne pas la devise d'un dividende. Aucune devise n'est devinée.
- `tests/test_corporate_actions_ingestion_r93.py` : couverture de la première persistance, idempotence, révision, devise explicite et rejet des lots incomplets.

## Validation locale
- Tests ciblés R93 + R91 + R92 + adaptateur R84 : **27 passed**.
- Suite complète : **1002 passed, 11 skipped, 205 subtests passed**.
- `python -m compileall -q .` : OK.
- Aucune suppression de fichier ou modification des règles de risque/exécution.

## Validation externe et limites
- Alpaca Paper est authentifié et les données de marché/corporate actions AAPL et MSFT ont été récupérées en lecture seule dans cette session.
- Aucun ordre Paper ou Live n'a été envoyé.
- Neon `trader_pro_test` contient le registre R91, ses contraintes et son trigger append-only actif. La base a été vérifiée en lecture seule après application ; aucun événement de test n'a été conservé.
- Important : l'application complète de la chaîne Alembic historique et un test d'intégration du service R93 directement contre Neon restent à effectuer. Le schéma du registre présent dans `trader_pro_test` ne prouve pas à lui seul que toutes les migrations historiques du projet ont été appliquées. Ne pas déclarer la phase PostgreSQL complète à ce stade.
- La branche Neon `production` n'a pas été modifiée. Aucun ordre réel n'a été envoyé. Le mode Live reste interdit.

## Décision de pilotage
La phase 3 (PostgreSQL) est conservée comme exigence d'architecture, mais intégrée en continu aux phases métier et infrastructure au lieu d'être un jalon isolé.
