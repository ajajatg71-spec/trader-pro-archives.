# R68 — Alignement temporel actif / benchmark

Date : 26 novembre 2026
Base : Trader Pro 2.0 R67 (candidat local, non déployé)

## Audit préalable — travail déjà présent
R67 contenait déjà :
- contrat OHLCV journalier et validation des séries O/H/L/C/V ;
- timestamps timezone-aware, strictement croissants et sans doublons exacts ;
- contrôle de couverture des séances boursières (`inspect_ohlcv_daily_bar_coverage`) ;
- comparaison inter-fournisseurs des séries de clôture/volume sur timestamps UTC identiques ;
- adaptateur OHLCV vers la recherche.

Le contrôle R25 de couverture OHLCV était donc déjà réalisé. Il n'a pas été recopié.

## Lacune constatée
L'alignement actif/benchmark dans `research_v1/quant/features.py` utilisait `bar.ts[:10]` comme clé et construisait un dictionnaire des clôtures benchmark. Cela :
- comparait le préfixe textuel ISO plutôt que la date de séance dans le fuseau de la place ;
- ne validait pas les horodatages, leur ordre ni les doublons de séance à cet endroit ;
- pouvait masquer des anomalies et ne fournissait pas de diagnostic explicite de couverture.
`research_v1/adapter.py` utilisait le même découpage `ts[:10]` pour vérifier la synchronisation des univers.

## Implémentation R68
Ajout de `research_v1/quant/alignment.py` :
- conversion des horodatages ISO ou datetime en instants UTC ;
- obligation d'un fuseau explicite ;
- ordre strictement croissant ;
- rejet de plusieurs barres dans une même séance journalière ;
- calcul de la date de séance dans le fuseau de marché configurable (défaut `America/New_York`) ;
- appariement par date de séance, jamais par position ;
- aucune interpolation, aucun forward-fill ;
- rapport des séances communes, manquantes, du taux de recouvrement et de la méthode.

Intégration :
- `Features` utilise désormais cet alignement pour les séries RS/RS_SMA/RS_ROC ;
- `Features.benchmark_alignment()` expose le diagnostic de couverture ;
- `evaluate_universe` vérifie les calendriers via les mêmes clés de séance validées, au lieu du préfixe textuel ISO.

Aucun changement des règles de risque, sizing, signaux d'ordre, broker, exécution, migrations ou interface.

## Tests
Six tests nouveaux :
- conversion correcte entre UTC et date locale de séance ;
- séance benchmark absente conservée comme `None` (pas de forward-fill) ;
- doublon de séance rejeté ;
- horodatage sans fuseau et ordre invalide rejetés ;
- clôture non finie et fuseau invalide rejetés ;
- intégration dans les séries relatives `Features`.

Résultats :
- tests ciblés alignement + adaptateur : 11 réussis ;
- suite complète : **888 passed, 11 skipped, 202 subtests passed**.
- Les 11 tests ignorés restent ceux nécessitant PostgreSQL externe.
- Aucun test Neon/PostgreSQL réel ni Alpaca Paper authentifié dans cette exécution.

## Préservation et sécurité
- R67 est conservé intact.
- R68 est une copie distincte.
- Les modifications sont limitées à `research_v1/quant/features.py` et `research_v1/adapter.py`.
- Ajouts : `research_v1/quant/alignment.py`, `tests/test_benchmark_alignment.py`, ce rapport.
- Aucun ordre Paper/Live envoyé ; aucun accès Replit.
- Module de recherche uniquement : pas d'accès broker ni d'autorisation d'exécution.
