# Trader Pro 2.0 — R73 : provenance explicite des ajustements

Date : 2026-11-26  
Base : R72 (`Trader-Pro-2.0-R72-cagr-interval-correction-2026-11-26.zip`)

## Objectif

Empêcher qu'une comparaison inter-fournisseurs de cours soit considérée comme fiable lorsque les séries ne déclarent pas le même traitement des opérations sur titres.

## Modifications

- `DailyBars` et `OHLCVDailyBars` portent désormais `adjustment_mode`, avec `unknown` par défaut pour préserver la compatibilité sans inventer de provenance.
- `MarketDataComparison` expose les modes primaire/secondaire et un verdict `adjustment_verified`.
- `compare_daily_bars` conserve la comparaison diagnostique des valeurs, mais enregistre explicitement la provenance connue ou inconnue.
- `require_consistent_daily_bars` refuse une validation stricte si un mode est inconnu, invalide ou différent. Deux modes déclarés identiques sont nécessaires.
- Twelve Data déclare explicitement `unknown` dans l'adaptateur actuel : aucun ajustement n'est supposé.
- Les tests couvrent les modes identiques, inconnus et différents ainsi que le maintien des contrôles précédents.

Modes reconnus : `raw`, `split`, `dividend`, `all`, `unknown`. Ces libellés décrivent la déclaration du fournisseur ; ils ne transforment pas les cours.

## Validation

- Tests ciblés marché + Twelve Data : 66 réussis, 28 sous-tests réussis.
- Suite complète : 898 réussis, 11 ignorés, 202 sous-tests réussis.
- Les 11 tests ignorés nécessitent un PostgreSQL externe ; ils ne sont pas comptés comme validations PostgreSQL.
- Aucun ordre envoyé ; Live reste désactivé.

## Limites

- La provenance n'est pas encore transportée de bout en bout par tous les lecteurs historiques : R74 traite le contrat de transport.
- Twelve Data reste `unknown` tant que son mode n'est pas établi par une documentation/API vérifiable.
- La comparaison ne constitue pas une validation de rendement total incluant les dividendes.
- Pas de déploiement Replit, de validation Neon réelle, ni de session Alpaca Paper authentifiée dans cette exécution.
