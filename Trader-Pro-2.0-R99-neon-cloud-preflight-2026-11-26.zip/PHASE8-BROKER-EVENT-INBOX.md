# Phase 8 — durable broker event inbox

**Status: implemented and locally tested; integration into a live event transport/worker remains pending.**

## Purpose

Broker notifications are treated as triggers for an authoritative broker reconciliation, not as standalone proof of an order or portfolio state. This avoids applying out-of-order or incomplete websocket/webhook payloads directly to the order ledger.

## Delivered

- `db.models.BrokerEventRecord` maps the `broker_event_inbox` durable inbox.
- Alembic revision `91c7d3e5a2b4` creates the table, uniqueness constraint, status/attempt checks, and lookup indexes.
- Alembic revision `a72c9e41b5d0` adds `next_attempt_at`, its index, and the terminal `dead_letter` state. The migration supports SQLite batch DDL and PostgreSQL constraint changes.
- `services/broker_events.py` validates the event envelope and persists only an allowlist of operational order fields; arbitrary headers, credentials, and unknown envelope fields are not retained.
- `event_id` is unique. An exact replay is idempotent; reuse with different content is rejected.
- Batch processing claims due pending/failed events and stale processing leases, then runs a full `ReconciliationService` snapshot. Events are marked processed only after reconciliation succeeds and the acknowledgement is durably committed.
- Added `scripts/run_broker_event_worker.py`: a graceful-stop CLI worker with bounded polling/batch settings. It refuses simulator mode, SQLite, missing keys, and any endpoint other than the official Alpaca Paper URL. It logs only aggregate counts and exception types; it never submits or retries orders.
- The worker is intentionally separate from event transport: it can drain inbox rows, but no Alpaca websocket receiver currently inserts them.
- Failures are persisted with a bounded error type and retried with capped exponential backoff (default 30 seconds, maximum one hour).
- After eight failed attempts by default, an event enters `dead_letter` and is no longer automatically claimed. The attempt limit and delay bounds are validated at processor construction.
- Stale `processing` records can be reclaimed after a configurable lease timeout.
- `FOR UPDATE SKIP LOCKED` is used for concurrent PostgreSQL workers.
- This component never submits, retries, replaces, or cancels an order. It only invokes reconciliation.

## Verification in this development environment

- New focused tests: event allowlist, exact duplicate, conflicting event ID, invalid envelope, batch processing, failure persistence, stale lease recovery, and invalid limits.
- Focused inbox and worker guard tests: **14 passed**, including backoff, no immediate retry, dead-letter cutoff, Paper-only endpoint and PostgreSQL-only worker configuration.
- Full pytest and unittest results are recorded in `TRADER-PRO-2-STATUS.md` after the final run.
- `compileall`: passed.
- Alembic upgrade to head, downgrade one revision, and re-upgrade on a disposable SQLite database: passed; head `a72c9e41b5d0`.
- Compose and GitHub Actions YAML parsing: unchanged from the previous archive; no new workflow was added in this increment.

## Not yet delivered / not claimed

- No Alpaca websocket or webhook receiver is wired to `BrokerEventProcessor`; the new CLI only drains events already present in the inbox.
- The CLI worker exists, but it has not been deployed or run against a real PostgreSQL database or Alpaca Paper account.
- PostgreSQL concurrency/`SKIP LOCKED` behavior and the new migration have not been run against a PostgreSQL server.
- No authenticated Alpaca Paper event stream has been received.
- Event ID derivation for a provider transport without a stable event identifier must be implemented and tested at the adapter boundary; this inbox intentionally requires a stable caller-supplied ID.

## Safety invariant

A notification can trigger reconciliation, but cannot directly mutate order status or trigger a new order. If reconciliation fails, the event remains retryable and no order retry is attempted.


## Durcissement de l'accusé de traitement (13 novembre 2026)

La boîte de réception n'accuse désormais un événement qu'après une réconciliation complète : snapshot de compte persisté, snapshots d'ordres et d'exécutions non tronqués, et rapport de santé présent. Un rapport incomplet ou tronqué suit la politique de reprise exponentielle ; il n'est pas marqué `processed`. Le statut de santé (healthy/warning/critical) reste distinct de l'accusé de traitement : l'inbox confirme le traitement technique de la notification, pas l'autorisation de trader.

Tests ajoutés : snapshot d'ordres tronqué et snapshot de compte non persisté ne peuvent pas être acquittés.

## Incrément 2026-11-13 — adaptateur Alpaca Paper et réconciliation périodique

- Ajout de `services/alpaca_trade_updates.py` : validation de l'enveloppe `trade_updates`, identifiant stable utilisant `event_id`, puis `execution_id`, puis un hash SHA-256 canonique si le fournisseur n'en donne pas ; persistance exclusivement via l'inbox.
- Ajout de `scripts/run_alpaca_trade_updates_listener.py` : connexion WebSocket sur l'endpoint Paper exact `wss://paper-api.alpaca.markets/stream`, authentification Alpaca, abonnement `trade_updates`, vérification de l'accusé d'abonnement, persistance, reconnexion exponentielle bornée et arrêt propre.
- Le listener refuse SIM, SQLite, des clés absentes, un endpoint REST Live ou un WebSocket différent de l'endpoint Paper officiel. Les secrets ne sont pas écrits dans les logs.
- Le worker de l'inbox effectue maintenant aussi une réconciliation complète périodique, indépendamment de la réception de notifications. Cela permet de retrouver les écarts même si une notification WebSocket a été manquée ; une réconciliation incomplète/tronquée est signalée comme échec.
- Ajout de `websocket-client` aux dépendances et de tests unitaires sur les garde-fous, les identifiants stables, les enveloppes et la réconciliation périodique.
- Tests locaux après cet incrément : **490 pytest réussis, 7 ignorés, 88 sous-tests réussis ; 486 unittest réussis ; compileall réussi**.
- Non effectué : aucune connexion réseau Alpaca authentifiée, aucun stream réel reçu, aucun PostgreSQL réel, aucun déploiement de worker. Les tests vérifient le protocole via les adaptateurs/mocks et les protections locales, pas la disponibilité externe.
