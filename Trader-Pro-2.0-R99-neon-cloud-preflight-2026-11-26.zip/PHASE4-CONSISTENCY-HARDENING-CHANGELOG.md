# Phase 4 — Provider consistency hardening

## Changes
- Hardened read-only comparison of daily bars from independent providers.
- Rejects comparisons across different symbols or the same provider identity.
- Rejects duplicate timestamps rather than silently overwriting bars in a dictionary.
- Validates timezone-aware timestamps and finite, strictly positive close prices before comparison.
- Validates tolerance conversion, finiteness, and non-negative range.
- Normalizes timestamps to UTC instants for matching across equivalent timezone offsets.
- Keeps original provider prices unchanged; this feature reports deviations only.

## Verification in this development environment
- `python -m compileall -q .` — passed.
- `python -m pytest -q` — 183 passed (includes 4 subtests).
- `python -m unittest discover -q` — 179 passed.

## Not verified here
- Native Windows execution: not run in this Linux environment. The repository contains a GitHub Actions Windows workflow, but it requires a GitHub run to provide Windows evidence.
- PostgreSQL integration/migrations: deferred until the user's Windows setup is available.
- Live market-provider credentials and live broker connectivity: not configured or tested.

## 2026-11-11 — risk market-data boundary hardening
- Removed the risk-model `cbars()` shortcut that called `broker.bars()` directly and bypassed provider-chain validation, timestamp checks, exchange-session freshness, and circuit-breaker behavior.
- Risk-model closes now use the same `MarketDataService` and XNYS freshness gate as signal generation through `validated_daily_closes()`.
- Live/Paper mode requires provider timestamps; the deterministic local simulator remains explicitly exempt from exchange timestamps.
- Added tests for malformed timestamps and stale sessions through the shared risk-consumer helper.
