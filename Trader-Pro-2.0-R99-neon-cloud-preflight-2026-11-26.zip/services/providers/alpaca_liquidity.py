"""Alpaca Paper/IEX liquidity snapshot adapter.

Fetches a current IEX best bid/ask plus up to 20 recent daily bars. Dollar ADV
is a transparent close-times-volume proxy, not consolidated market-wide volume.
No order endpoints are used and no impact coefficient is invented.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import math
import re
import time
from email.utils import parsedate_to_datetime

import requests


class AlpacaLiquidityError(RuntimeError):
    """Sanitized liquidity-feed error; credentials and provider payloads stay private."""


class AlpacaLiquiditySnapshot:
    BASE_URL = "https://data.alpaca.markets"
    _SYMBOL = re.compile(r"^[A-Z][A-Z0-9.\-]{0,14}$")

    def __init__(self, api_key: str, secret_key: str, *, session=None,
                 timeout: float = 10.0, max_quote_age_seconds: float = 120.0, max_bar_age_days: float = 45.0, max_retries: int = 2,
                 retry_backoff_seconds: float = 0.25, sleep_fn=time.sleep,
                 utc_clock=lambda: datetime.now(timezone.utc)):
        if not str(api_key or "").strip() or not str(secret_key or "").strip():
            raise ValueError("Clés Alpaca requises")
        if not math.isfinite(float(timeout)) or timeout <= 0:
            raise ValueError("timeout doit être positif")
        if not math.isfinite(float(max_quote_age_seconds)) or max_quote_age_seconds <= 0:
            raise ValueError("max_quote_age_seconds doit être positif")
        if not math.isfinite(float(max_bar_age_days)) or max_bar_age_days <= 0:
            raise ValueError("max_bar_age_days doit être positif")
        self.session = session or requests.Session()
        self.headers = {"APCA-API-KEY-ID": str(api_key).strip(),
                        "APCA-API-SECRET-KEY": str(secret_key).strip()}
        self.timeout = float(timeout)
        self.max_quote_age_seconds = float(max_quote_age_seconds)
        self.max_bar_age_days = float(max_bar_age_days)
        if isinstance(max_retries, bool) or int(max_retries) != max_retries or max_retries < 0 or max_retries > 3:
            raise ValueError("max_retries doit être compris entre 0 et 3")
        if not math.isfinite(float(retry_backoff_seconds)) or retry_backoff_seconds < 0:
            raise ValueError("retry_backoff_seconds doit être positif ou nul")
        self.max_retries = int(max_retries)
        self.retry_backoff_seconds = float(retry_backoff_seconds)
        self.sleep_fn = sleep_fn
        self.utc_clock = utc_clock

    def _retry_delay(self, response, attempt):
        raw = response.headers.get("Retry-After") if response is not None else None
        if raw:
            try:
                return min(2.0, max(0.0, float(raw)))
            except (TypeError, ValueError):
                try:
                    retry_at = parsedate_to_datetime(raw)
                    if retry_at.tzinfo is None:
                        retry_at = retry_at.replace(tzinfo=timezone.utc)
                    return min(2.0, max(0.0, (retry_at - self.utc_clock()).total_seconds()))
                except (TypeError, ValueError, OverflowError):
                    pass
        return min(2.0, self.retry_backoff_seconds * (2 ** attempt))

    def _get(self, path, params):
        last_error = None
        for attempt in range(self.max_retries + 1):
            response = None
            try:
                response = self.session.get(self.BASE_URL + path, headers=self.headers,
                                            params=params, timeout=self.timeout)
                status = getattr(response, "status_code", None)
                if status in {429, 500, 502, 503, 504}:
                    if attempt < self.max_retries:
                        self.sleep_fn(self._retry_delay(response, attempt))
                        continue
                response.raise_for_status()
                payload = response.json()
            except requests.RequestException as exc:
                last_error = exc
                retryable = isinstance(exc, (requests.Timeout, requests.ConnectionError))
                if retryable and attempt < self.max_retries:
                    self.sleep_fn(self._retry_delay(response, attempt))
                    continue
                raise AlpacaLiquidityError(f"Flux de liquidité indisponible ({type(exc).__name__})") from None
            except (ValueError, TypeError):
                raise AlpacaLiquidityError("Réponse de liquidité illisible") from None
            if not isinstance(payload, dict):
                raise AlpacaLiquidityError("Format de réponse de liquidité invalide")
            return payload
        # Defensive fallback; normally the loop returns or raises above.
        raise AlpacaLiquidityError(f"Flux de liquidité indisponible ({type(last_error).__name__ if last_error else 'ProviderError'})")

    def __call__(self, symbol: str) -> dict:
        sym = str(symbol or "").strip().upper()
        if not self._SYMBOL.fullmatch(sym):
            raise AlpacaLiquidityError("Symbole invalide")
        quote_payload = self._get(f"/v2/stocks/{sym}/quotes/latest", {"feed": "iex"})
        quote = quote_payload.get("quote")
        if not isinstance(quote, dict):
            raise AlpacaLiquidityError("Meilleure cotation IEX absente")
        try:
            bid, ask = float(quote["bp"]), float(quote["ap"])
            quote_time = datetime.fromisoformat(str(quote["t"]).replace("Z", "+00:00"))
            if quote_time.tzinfo is None or quote_time.utcoffset() is None:
                raise ValueError("timezone")
            quote_time = quote_time.astimezone(timezone.utc)
            if not math.isfinite(bid) or not math.isfinite(ask) or bid <= 0 or ask < bid:
                raise ValueError("quote")
        except (KeyError, TypeError, ValueError, OverflowError):
            raise AlpacaLiquidityError("Meilleure cotation IEX invalide") from None

        now = self.utc_clock()
        if not isinstance(now, datetime) or now.tzinfo is None or now.utcoffset() is None:
            raise AlpacaLiquidityError("Horloge locale invalide pour contrôler la fraîcheur")
        now = now.astimezone(timezone.utc)
        quote_age = (now - quote_time).total_seconds()
        if quote_age < -5.0 or quote_age > self.max_quote_age_seconds:
            raise AlpacaLiquidityError("Meilleure cotation IEX périmée ou horodatée dans le futur")
        start = (now - timedelta(days=60)).strftime("%Y-%m-%dT%H:%M:%SZ")
        bars_payload = self._get(f"/v2/stocks/{sym}/bars", {
            "timeframe": "1Day", "start": start, "limit": 50,
            "adjustment": "split", "feed": "iex", "sort": "desc"})
        bars = bars_payload.get("bars")
        if not isinstance(bars, list):
            raise AlpacaLiquidityError("Historique IEX absent")
        dollar_volumes = []
        observed_sessions = set()
        complete_sessions = set()
        for bar in bars:
            if not isinstance(bar, dict):
                raise AlpacaLiquidityError("Bougie IEX invalide")
            try:
                close, volume = float(bar["c"]), float(bar["v"])
                bar_time = datetime.fromisoformat(str(bar["t"]).replace("Z", "+00:00"))
                if bar_time.tzinfo is None or bar_time.utcoffset() is None:
                    raise ValueError("timezone")
                bar_time = bar_time.astimezone(timezone.utc)
            except (KeyError, TypeError, ValueError, OverflowError):
                raise AlpacaLiquidityError("Bougie IEX sans horodatage valide") from None
            bar_age = (now - bar_time).total_seconds()
            session_date = bar_time.date()
            if session_date > now.date():
                raise AlpacaLiquidityError("Historique IEX horodaté dans le futur")
            if bar_age > self.max_bar_age_days * 86400:
                raise AlpacaLiquidityError("Historique IEX périmé")
            if session_date in observed_sessions:
                raise AlpacaLiquidityError("Historique IEX contenant des séances dupliquées")
            observed_sessions.add(session_date)
            if not math.isfinite(close) or close <= 0 or not math.isfinite(volume) or volume < 0:
                raise AlpacaLiquidityError("Volume quotidien IEX invalide")
            # A daily candle stamped today may still be in progress. Exclude it
            # from ADV rather than treating partial-session volume as a full day.
            if session_date == now.date():
                continue
            complete_sessions.add(session_date)
            # Zero-volume sessions are observations too. Dropping them would
            # bias ADV upward for illiquid or halted instruments.
            dollar_volumes.append(close * volume)
            if len(dollar_volumes) == 20:
                break
        if len(dollar_volumes) < 10:
            raise AlpacaLiquidityError("Historique IEX insuffisant pour calculer l'ADV")
        adv = sum(dollar_volumes) / len(dollar_volumes)
        if not math.isfinite(adv) or adv <= 0:
            raise AlpacaLiquidityError("ADV IEX invalide")
        return {
            "source": "alpaca_iex",
            "as_of": quote_time.timestamp(),
            "bid": bid,
            "ask": ask,
            "avg_daily_dollar_volume": adv,
            "adv_observations": len(dollar_volumes),
            "adv_as_of": max(complete_sessions).isoformat(),
        }
