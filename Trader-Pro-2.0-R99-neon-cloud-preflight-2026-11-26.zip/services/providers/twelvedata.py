"""Twelve Data daily-bar adapter (optional; requires an API key).

Returns the same timestamp/close/volume tuple consumed by ProviderChain.
No trading or order endpoints are used by this adapter.
"""
from __future__ import annotations

from datetime import datetime
import math
import os
from typing import Any
from zoneinfo import ZoneInfo

import requests


class TwelveDataError(RuntimeError):
    """Sanitized provider error; never includes the request URL or API key."""


class TwelveDataDailyBars:
    BASE_URL = "https://api.twelvedata.com/time_series"
    source_name = "twelvedata"
    adjustment_mode = "unknown"  # API request/response contract does not prove a mode here.

    def __init__(self, api_key: str | None = None, *, session=None, timeout: float = 15.0,
                 include_ohlc: bool = False):
        self.api_key = (api_key if api_key is not None else os.getenv("TWELVEDATA_API_KEY", "")).strip()
        if not self.api_key:
            raise ValueError("TWELVEDATA_API_KEY est requis pour activer Twelve Data")
        if not math.isfinite(float(timeout)) or timeout <= 0:
            raise ValueError("timeout doit être positif")
        if not isinstance(include_ohlc, bool):
            raise ValueError("include_ohlc doit être booléen")
        self.session = session or requests.Session()
        self.timeout = float(timeout)
        self.include_ohlc = include_ohlc

    def __call__(self, symbol: str, limit: int):
        if not isinstance(symbol, str) or not symbol or len(symbol) > 15:
            raise ValueError("Symbole invalide")
        if not isinstance(limit, int) or isinstance(limit, bool) or not 2 <= limit <= 5000:
            raise ValueError("limit doit être compris entre 2 et 5000")
        params = {
            "symbol": symbol,
            "interval": "1day",
            "outputsize": limit,
            "order": "ASC",
            "timezone": "America/New_York",
            "apikey": self.api_key,
        }
        try:
            response = self.session.get(self.BASE_URL, params=params, timeout=self.timeout)
            response.raise_for_status()
            payload = response.json()
        except requests.RequestException as exc:
            raise TwelveDataError(f"Échec réseau ({type(exc).__name__})") from None
        except (ValueError, TypeError) as exc:
            raise TwelveDataError(f"Réponse JSON invalide ({type(exc).__name__})") from None
        if not isinstance(payload, dict):
            raise TwelveDataError("Format de réponse invalide")
        if payload.get("status") == "error" or "code" in payload and "values" not in payload:
            # Twelve Data may echo request details in its message; do not surface them.
            code = payload.get("code")
            safe_code = str(code)[:12] if isinstance(code, (str, int)) else "provider_error"
            raise TwelveDataError(f"Erreur fournisseur ({safe_code})")
        values = payload.get("values")
        if not isinstance(values, list) or len(values) < 2:
            raise TwelveDataError("Historique quotidien insuffisant")
        tz = ZoneInfo("America/New_York")
        parsed = []
        for row in values:
            if not isinstance(row, dict):
                raise TwelveDataError("Bougie quotidienne mal formée")
            try:
                raw_stamp = row["datetime"]
                # Daily bars are exchange-session dates, not UTC-midnight instants.
                stamp = datetime.strptime(str(raw_stamp), "%Y-%m-%d").replace(tzinfo=tz)
                close = float(row["close"])
                volume = float(row["volume"])
                if self.include_ohlc:
                    open_price = float(row["open"])
                    high = float(row["high"])
                    low = float(row["low"])
                else:
                    open_price = high = low = None
            except (KeyError, TypeError, ValueError, OverflowError):
                raise TwelveDataError("Champs de bougie invalides") from None
            prices = (close,) if not self.include_ohlc else (open_price, high, low, close)
            if (any(not math.isfinite(value) or value <= 0 for value in prices)
                    or not math.isfinite(volume) or volume < 0):
                raise TwelveDataError("Valeurs de bougie invalides")
            if self.include_ohlc and (high < max(open_price, low, close) or low > min(open_price, high, close)):
                raise TwelveDataError("Géométrie OHLC incohérente")
            if self.include_ohlc:
                parsed.append((stamp, open_price, high, low, close, volume))
            else:
                parsed.append((stamp, close, volume))
        parsed.sort(key=lambda item: item[0])
        if any(left[0] >= right[0] for left, right in zip(parsed, parsed[1:])):
            raise TwelveDataError("Dates quotidiennes dupliquées ou désordonnées")
        parsed = parsed[-limit:]
        if self.include_ohlc:
            return ([item[0] for item in parsed],
                    [item[1] for item in parsed],
                    [item[2] for item in parsed],
                    [item[3] for item in parsed],
                    [item[4] for item in parsed],
                    [item[5] for item in parsed])
        return ([item[0] for item in parsed],
                [item[1] for item in parsed],
                [item[2] for item in parsed])
