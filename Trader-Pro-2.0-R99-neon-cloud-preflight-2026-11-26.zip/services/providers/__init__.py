"""Optional independent market-data provider adapters."""
