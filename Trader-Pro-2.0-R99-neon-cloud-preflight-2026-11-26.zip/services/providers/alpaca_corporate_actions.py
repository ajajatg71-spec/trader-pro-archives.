"""Read-only adapter for Alpaca's Market Data Corporate Actions endpoint.

The adapter returns sourced records, not backtest-ready events: Alpaca documents
that announcement availability can be delayed and this endpoint does not expose
a historical declaration timestamp for every record. Callers must provide an
independently recorded available_at before converting a record to an event.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
import math
import os
import requests


class AlpacaCorporateActionsError(RuntimeError):
    """Sanitized provider error; never includes credentials or request URLs."""


@dataclass(frozen=True)
class AlpacaCorporateActionRecord:
    provider_id: str
    symbol: str
    action_type: str
    ex_date: date
    process_date: date
    source: str
    retrieved_at: datetime
    split_ratio: Decimal | None = None
    cash_amount: Decimal | None = None
    currency: str | None = None

    def to_event(self, *, available_at: datetime):
        """Convert only when caller supplies an explicit knowledge timestamp."""
        from research_v1.quant.corporate_actions import CorporateActionEvent
        if not isinstance(available_at, datetime) or available_at.tzinfo is None or available_at.utcoffset() is None:
            raise ValueError("available_at explicite et horodaté requis")
        if self.action_type == "split":
            return CorporateActionEvent(self.symbol, "split", self.ex_date, available_at,
                self.source, split_ratio=self.split_ratio, event_id=self.provider_id)
        return CorporateActionEvent(self.symbol, "dividend", self.ex_date, available_at,
            self.source, cash_amount=self.cash_amount, currency=self.currency, event_id=self.provider_id)


@dataclass(frozen=True)
class AlpacaCorporateActionBatch:
    records: tuple[AlpacaCorporateActionRecord, ...]
    requested_symbols: tuple[str, ...]
    start_date: date
    end_date: date
    retrieved_at: datetime
    pages_fetched: int
    pagination_complete: bool


class AlpacaCorporateActionsReader:
    BASE_URL = "https://data.alpaca.markets/v1/corporate-actions"
    source_name = "alpaca"

    def __init__(self, api_key: str | None = None, api_secret: str | None = None,
                 *, session=None, timeout: float = 15.0, utc_clock=lambda: datetime.now(timezone.utc)):
        self.api_key = (api_key if api_key is not None else os.getenv("APCA_API_KEY_ID", "")).strip()
        self.api_secret = (api_secret if api_secret is not None else os.getenv("APCA_API_SECRET_KEY", "")).strip()
        if not self.api_key or not self.api_secret:
            raise ValueError("APCA_API_KEY_ID et APCA_API_SECRET_KEY requis")
        if not math.isfinite(float(timeout)) or timeout <= 0:
            raise ValueError("timeout doit être positif")
        self.session = session or requests.Session()
        self.timeout = float(timeout)
        self.utc_clock = utc_clock

    @staticmethod
    def _decimal(value, label):
        try: number = Decimal(str(value))
        except (InvalidOperation, TypeError, ValueError): raise AlpacaCorporateActionsError(f"{label} invalide") from None
        if not number.is_finite() or number <= 0: raise AlpacaCorporateActionsError(f"{label} invalide")
        return number

    def fetch(self, symbols, start_date: date, end_date: date, *, limit: int = 1000,
              max_pages: int = 20, region: str = "us") -> AlpacaCorporateActionBatch:
        symbols = tuple(sorted(set(symbols)))
        if not symbols or any(not isinstance(s, str) or not s or s != s.upper() for s in symbols):
            raise ValueError("Univers de symboles invalide")
        if not isinstance(start_date, date) or isinstance(start_date, datetime) or not isinstance(end_date, date) or isinstance(end_date, datetime) or end_date < start_date:
            raise ValueError("Période de récupération invalide")
        if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 1000:
            raise ValueError("limit doit être compris entre 1 et 1000")
        if not isinstance(max_pages, int) or isinstance(max_pages, bool) or not 1 <= max_pages <= 100:
            raise ValueError("max_pages doit être compris entre 1 et 100")
        if region not in {"us", "non_us", "all"}: raise ValueError("region invalide")
        headers = {"APCA-API-KEY-ID": self.api_key, "APCA-API-SECRET-KEY": self.api_secret, "accept": "application/json"}
        params = {"symbols": ",".join(symbols), "start": start_date.isoformat(), "end": end_date.isoformat(),
                  "types": "forward_split,reverse_split,cash_dividend", "region": region,
                  "limit": limit, "data_quality": "complete", "sort": "asc"}
        records, token, seen_tokens, seen_ids = [], None, set(), set()
        retrieved_at = self.utc_clock()
        if not isinstance(retrieved_at, datetime) or retrieved_at.tzinfo is None or retrieved_at.utcoffset() is None:
            raise ValueError("utc_clock doit fournir un datetime avec fuseau")
        for page_number in range(max_pages):
            page_params = dict(params)
            if token: page_params["page_token"] = token
            try:
                response = self.session.get(self.BASE_URL, params=page_params, headers=headers, timeout=self.timeout)
                response.raise_for_status(); payload = response.json()
            except requests.RequestException as exc:
                raise AlpacaCorporateActionsError(f"Échec réseau ({type(exc).__name__})") from None
            except (ValueError, TypeError) as exc:
                raise AlpacaCorporateActionsError(f"Réponse JSON invalide ({type(exc).__name__})") from None
            if not isinstance(payload, dict) or not isinstance(payload.get("corporate_actions"), dict):
                raise AlpacaCorporateActionsError("Contrat corporate_actions absent ou invalide")
            groups = payload["corporate_actions"]
            supported = {"forward_splits", "reverse_splits", "cash_dividends"}
            if any(key not in supported and value for key, value in groups.items()):
                raise AlpacaCorporateActionsError("Type d'opération non pris en charge dans la réponse")
            for group, action_type in (("forward_splits", "split"), ("reverse_splits", "split"), ("cash_dividends", "dividend")):
                rows = groups.get(group, [])
                if not isinstance(rows, list): raise AlpacaCorporateActionsError("Groupe corporate action mal formé")
                for row in rows:
                    if not isinstance(row, dict): raise AlpacaCorporateActionsError("Événement corporate action mal formé")
                    try:
                        event_id, symbol = str(row["id"]), str(row["symbol"]).upper()
                        ex_date, process_date = date.fromisoformat(row["ex_date"]), date.fromisoformat(row["process_date"])
                        if not event_id or symbol not in symbols: raise ValueError()
                        if event_id in seen_ids: raise AlpacaCorporateActionsError("Identifiant Alpaca dupliqué")
                        seen_ids.add(event_id)
                        if action_type == "split":
                            ratio = self._decimal(row["new_rate"], "new_rate") / self._decimal(row["old_rate"], "old_rate")
                            record = AlpacaCorporateActionRecord(event_id, symbol, action_type, ex_date, process_date,
                                self.source_name, retrieved_at, split_ratio=ratio)
                        else:
                            currency = row.get("currency")
                            # The Alpaca corporate-actions payload may omit currency
                            # (as observed in live US cash-dividend responses). Keep
                            # it unknown here; the ingestion layer must resolve it
                            # explicitly rather than making the reader reject the
                            # entire provider batch or silently guessing.
                            if currency is not None and (
                                not isinstance(currency, str) or len(currency) != 3
                                or not currency.isalpha() or currency != currency.upper()
                            ):
                                raise AlpacaCorporateActionsError("Devise de dividende invalide")
                            record = AlpacaCorporateActionRecord(event_id, symbol, action_type, ex_date, process_date,
                                self.source_name, retrieved_at, cash_amount=self._decimal(row["rate"], "rate"), currency=currency)
                    except AlpacaCorporateActionsError: raise
                    except (KeyError, TypeError, ValueError, OverflowError):
                        raise AlpacaCorporateActionsError("Champs corporate action requis absents ou invalides") from None
                    records.append(record)
            next_token = payload.get("next_page_token")
            if not next_token:
                return AlpacaCorporateActionBatch(tuple(records), symbols, start_date, end_date,
                    retrieved_at, page_number + 1, True)
            next_token = str(next_token)
            if next_token in seen_tokens or next_token == token:
                raise AlpacaCorporateActionsError("Pagination Alpaca incohérente")
            seen_tokens.add(next_token); token = next_token
        raise AlpacaCorporateActionsError("Pagination incomplète : plafond de pages atteint")
