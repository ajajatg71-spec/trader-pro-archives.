"""Portfolio application service, independent from FastAPI and broker globals."""
from __future__ import annotations

from typing import Any, Callable

import portfolio as portfolio_domain


class PortfolioService:
    """Orchestrates portfolio reads while preserving the V1 domain calculations.

    Broker access is injected as callables so this service is deterministic in
    tests and can later be backed by a repository without changing HTTP routes.
    """

    def __init__(
        self,
        fills_reader: Callable[[], list[dict[str, Any]]],
        positions_reader: Callable[[], list[dict[str, Any]]],
        fee_pct: float = 0.0,
        fee_min: float = 0.0,
        domain: Any = portfolio_domain,
    ) -> None:
        self._fills_reader = fills_reader
        self._positions_reader = positions_reader
        self._fee_pct = float(fee_pct)
        self._fee_min = float(fee_min)
        self._domain = domain

    def snapshot(self) -> tuple[Any, list[dict[str, Any]], float, float, dict[str, float]]:
        lots, realized, fees, invested = self._domain.process(
            self._fills_reader(), self._fee_pct, self._fee_min
        )
        prices = {
            str(position["symbol"]): float(position["current_price"])
            for position in self._positions_reader()
        }
        return lots, realized, fees, invested, prices

    def summary(self) -> dict[str, Any]:
        return self._domain.summary(*self.snapshot())

    def realized(self) -> list[dict[str, Any]]:
        return self.snapshot()[1]

    def tax(self, realized: list[dict[str, Any]], year: int, rate: float, carry: float) -> dict[str, Any]:
        return self._domain.tax(realized, year, rate, carry)
