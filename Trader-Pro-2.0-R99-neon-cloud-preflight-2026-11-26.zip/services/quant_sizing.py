"""Research-only volatility-targeted position sizing and pre-trade TCA.

This module produces estimates only. It cannot approve, allocate, or submit orders.
All live order controls remain in Risk Governor / OrderService.
"""
from __future__ import annotations

import math
from typing import Any, Sequence


def _finite_positive(value: float, name: str) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{name} doit être un nombre fini strictement positif") from exc
    if not math.isfinite(result) or result <= 0:
        raise ValueError(f"{name} doit être un nombre fini strictement positif")
    return result


def compute_atr(
    highs: Sequence[float], lows: Sequence[float], closes: Sequence[float],
    period: int = 14,
) -> float | None:
    """Wilder ATR; returns None for insufficient or malformed market history."""
    if isinstance(period, bool) or not isinstance(period, int) or not 1 <= period <= 500:
        raise ValueError("Période ATR invalide")
    if not (len(highs) == len(lows) == len(closes)):
        raise ValueError("Séries OHLC de longueurs différentes")
    if len(closes) < period + 1:
        return None
    trs: list[float] = []
    for i in range(1, len(closes)):
        try:
            h, low, prev_c = float(highs[i]), float(lows[i]), float(closes[i - 1])
        except (TypeError, ValueError, OverflowError):
            return None
        if not all(math.isfinite(x) for x in (h, low, prev_c)) or h < low or low <= 0 or prev_c <= 0:
            return None
        trs.append(max(h - low, abs(h - prev_c), abs(low - prev_c)))
    if len(trs) < period:
        return None
    atr = sum(trs[:period]) / period
    for tr in trs[period:]:
        atr = (atr * (period - 1) + tr) / period
    return atr if math.isfinite(atr) and atr > 0 else None


def volatility_targeted_notional(
    *, equity: float, price: float, atr: float | None = None,
    annualized_vol_pct: float | None = None, risk_budget_pct: float = 0.75,
    atr_stop_multiplier: float = 2.0, max_position_pct: float = 20.0,
    regime: str | None = None,
) -> dict[str, Any]:
    """Estimate a long-only notional, capped by the caller's position limit."""
    equity = _finite_positive(equity, "Equity")
    price = _finite_positive(price, "Prix")
    risk_budget_pct = _finite_positive(risk_budget_pct, "Budget de risque")
    atr_stop_multiplier = _finite_positive(atr_stop_multiplier, "Multiplicateur ATR")
    max_position_pct = _finite_positive(max_position_pct, "Plafond de position")
    if not 0.05 <= risk_budget_pct <= 5.0:
        raise ValueError("risk_budget_pct hors limites (0.05 % - 5.0 %)")
    if max_position_pct > 100.0:
        raise ValueError("max_position_pct ne peut pas dépasser 100 %")
    if atr is not None:
        atr = _finite_positive(atr, "ATR")
    if annualized_vol_pct is not None:
        annualized_vol_pct = _finite_positive(annualized_vol_pct, "Volatilité annualisée")
    regime_norm = (regime or "").strip().lower()
    regime_scale = 0.5 if any(k in regime_norm for k in ("high", "élev", "stress", "bear", "crisis")) else 1.0
    effective_risk = equity * (risk_budget_pct / 100.0) * regime_scale
    if atr is not None:
        stop_distance = atr * atr_stop_multiplier
        stop_pct = (stop_distance / price) * 100.0
        raw_notional = (effective_risk / stop_distance) * price
        method = f"ATR({atr_stop_multiplier:.1f}x)"
    elif annualized_vol_pct is not None:
        daily_vol = (annualized_vol_pct / 100.0) / math.sqrt(252.0)
        stop_pct = max(daily_vol * atr_stop_multiplier * 100.0, 0.5)
        raw_notional = effective_risk / (stop_pct / 100.0)
        method = "Volatilité annualisée"
    else:
        stop_pct = 5.0
        raw_notional = effective_risk / 0.05
        method = "Défaut conservateur (5 %)"
    cap = equity * (max_position_pct / 100.0)
    final = min(raw_notional, cap)
    if not math.isfinite(final) or final < 0:
        raise ValueError("Résultat de dimensionnement invalide")
    return {
        "recommended_notional": round(final, 2),
        "raw_risk_notional": round(raw_notional, 2),
        "cap_notional": round(cap, 2),
        "capped": raw_notional > cap,
        "risk_usd": round(effective_risk, 2),
        "implied_stop_pct": round(stop_pct, 2),
        "regime_scale": regime_scale,
        "method": method,
        "research_only": True,
    }


def estimate_pretrade_tca(
    *, notional: float, spread_pct: float = 0.04,
    adv_usd: float | None = None, volatility_pct: float = 22.0,
) -> dict[str, float]:
    """Estimate spread + square-root impact; not a broker quote or guarantee."""
    notional = float(notional)
    spread_pct = float(spread_pct)
    volatility_pct = float(volatility_pct)
    if not math.isfinite(notional) or notional < 0:
        raise ValueError("Notional invalide")
    if not math.isfinite(spread_pct) or spread_pct < 0:
        raise ValueError("Spread invalide")
    if not math.isfinite(volatility_pct) or volatility_pct < 0:
        raise ValueError("Volatilité invalide")
    if adv_usd is not None:
        adv_usd = float(adv_usd)
        if not math.isfinite(adv_usd) or adv_usd <= 0:
            raise ValueError("ADV invalide")
    if notional == 0:
        return {"spread_cost_usd": 0.0, "impact_cost_usd": 0.0, "total_cost_usd": 0.0, "total_bps": 0.0}
    half_spread_bps = spread_pct * 50.0
    participation = notional / adv_usd if adv_usd is not None else 0.0005
    impact_bps = (volatility_pct / 16.0) * 10.0 * math.sqrt(participation)
    total_bps = half_spread_bps + impact_bps
    spread_usd = notional * half_spread_bps / 10000.0
    impact_usd = notional * impact_bps / 10000.0
    return {
        "spread_cost_usd": round(spread_usd, 2),
        "impact_cost_usd": round(impact_usd, 2),
        "total_cost_usd": round(spread_usd + impact_usd, 2),
        "total_bps": round(total_bps, 2),
    }
