"""Application services for Trader Pro."""
