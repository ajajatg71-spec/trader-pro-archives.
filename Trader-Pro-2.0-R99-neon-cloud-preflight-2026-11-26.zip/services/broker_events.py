"""Durable broker notification inbox.

Notifications are hints, not authoritative order state. Processing always invokes
full broker reconciliation; this module never submits, replaces, or cancels orders.
"""
from __future__ import annotations

from datetime import datetime, timezone, timedelta
from uuid import uuid4
from typing import Any, Callable

from sqlalchemy import select, or_, and_
from sqlalchemy.exc import IntegrityError

from db.models import BrokerEventRecord, AuditEventRecord


class BrokerEventError(RuntimeError):
    pass


# Keep only operational fields. Never persist arbitrary headers, credentials, or
# complete provider envelopes supplied by an upstream webhook handler.
_ALLOWED_ORDER_FIELDS = {
    "id", "client_order_id", "symbol", "side", "status", "qty", "filled_qty",
    "filled_avg_price", "type", "time_in_force", "limit_price", "stop_price",
    "updated_at", "submitted_at", "filled_at", "canceled_at", "expired_at",
}


def _safe_payload(event: dict[str, Any]) -> tuple[dict[str, Any], str | None, str | None]:
    if not isinstance(event, dict):
        raise BrokerEventError("Événement broker invalide")
    event_type = str(event.get("event") or event.get("event_type") or "").strip().lower()
    if not event_type or len(event_type) > 48:
        raise BrokerEventError("Type d'événement broker invalide")
    order = event.get("order") or {}
    if not isinstance(order, dict):
        raise BrokerEventError("Objet ordre de l'événement invalide")
    safe_order = {key: order[key] for key in _ALLOWED_ORDER_FIELDS if key in order}
    safe = {"event": event_type, "timestamp": event.get("timestamp"), "order": safe_order}
    # JSON round-trip validates serializability and strips custom Python objects.
    import json
    try:
        safe = json.loads(json.dumps(safe, allow_nan=False, separators=(",", ":")))
    except (TypeError, ValueError) as exc:
        raise BrokerEventError("Contenu d'événement non sérialisable") from exc
    broker_id = str(safe_order.get("id") or "") or None
    client_id = str(safe_order.get("client_order_id") or "") or None
    return safe, broker_id, client_id


class BrokerEventProcessor:
    def __init__(self, session_factory, reconciliation: Any, *, max_attempts: int = 8,
                 retry_base_seconds: int = 30, retry_max_seconds: int = 3600):
        if not isinstance(max_attempts, int) or isinstance(max_attempts, bool) or not 1 <= max_attempts <= 100:
            raise ValueError("max_attempts doit être compris entre 1 et 100")
        if not isinstance(retry_base_seconds, int) or isinstance(retry_base_seconds, bool) or retry_base_seconds < 1:
            raise ValueError("retry_base_seconds doit être positif")
        if not isinstance(retry_max_seconds, int) or isinstance(retry_max_seconds, bool) or retry_max_seconds < retry_base_seconds:
            raise ValueError("retry_max_seconds doit être supérieur ou égal au délai initial")
        self.session_factory = session_factory
        self.reconciliation = reconciliation
        self.max_attempts = max_attempts
        self.retry_base_seconds = retry_base_seconds
        self.retry_max_seconds = retry_max_seconds

    def _retry_delay(self, attempts: int) -> int:
        # Exponential backoff, capped to prevent unbounded retry intervals.
        return min(self.retry_base_seconds * (2 ** max(0, attempts - 1)), self.retry_max_seconds)

    @staticmethod
    def _is_complete_reconciliation(report: Any) -> bool:
        """Only acknowledge an event after a durable, non-truncated snapshot.

        A healthy/critical execution-health label is operational information; the
        inbox acknowledges that reconciliation ran, not that the account is safe
        to trade. Missing or truncated core snapshots must remain retryable.
        """
        if not isinstance(report, dict):
            return False
        if report.get("account_snapshot_saved") is not True:
            return False
        if report.get("truncated_order_snapshot") is not False:
            return False
        if report.get("truncated_fill_snapshot") is not False:
            return False
        if not isinstance(report.get("execution_health"), dict):
            return False
        return True

    def receive(self, *, event_id: str, event: dict[str, Any]) -> bool:
        """Persist one notification. Returns False for an identical replay."""
        if not isinstance(event_id, str) or not event_id.strip() or len(event_id) > 160:
            raise BrokerEventError("Identifiant d'événement invalide")
        safe, broker_id, client_id = _safe_payload(event)
        event_type = safe["event"]
        try:
            with self.session_factory.begin() as session:
                session.add(BrokerEventRecord(event_id=event_id.strip(), event_type=event_type,
                    broker_order_id=broker_id, client_order_id=client_id, payload=safe,
                    status="pending", attempts=0))
                session.add(AuditEventRecord(event_type="broker_event_received",
                    message=f"Notification broker reçue: {event_type}",
                    correlation_id=client_id, details={"event_id": event_id.strip(),
                    "broker_order_id": broker_id, "event_type": event_type}))
            return True
        except IntegrityError:
            # An event ID is immutable: a replay is harmless; a collision with a
            # different payload is not silently accepted.
            with self.session_factory() as session:
                existing = session.scalar(select(BrokerEventRecord).where(
                    BrokerEventRecord.event_id == event_id.strip()))
                if existing is not None and existing.payload == safe and existing.event_type == event_type:
                    return False
            raise BrokerEventError("Identifiant d'événement réutilisé avec un contenu différent")
        except BrokerEventError:
            raise
        except Exception as exc:
            raise BrokerEventError(f"Persistance de l'événement impossible ({type(exc).__name__})") from exc

    def process_pending(self, *, limit: int = 100, stale_after_seconds: int = 300) -> dict[str, Any]:
        """Reconcile a due batch, then durably acknowledge it.

        Failures use capped exponential backoff and move to dead_letter after
        max_attempts. A crash after reconciliation but before acknowledgement can
        cause another read-only reconciliation; it can never cause an order retry.
        """
        if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 1000:
            raise BrokerEventError("Limite d'événements invalide")
        if not isinstance(stale_after_seconds, int) or isinstance(stale_after_seconds, bool) or not 30 <= stale_after_seconds <= 86400:
            raise BrokerEventError("Délai de reprise des événements invalide")
        claimed: list[str] = []
        claim_token = str(uuid4())
        try:
            with self.session_factory.begin() as session:
                now = datetime.now(timezone.utc)
                stale_cutoff = now - timedelta(seconds=stale_after_seconds)
                eligible = or_(
                    BrokerEventRecord.status == "pending",
                    and_(BrokerEventRecord.status == "failed",
                         or_(BrokerEventRecord.next_attempt_at.is_(None),
                             BrokerEventRecord.next_attempt_at <= now)),
                    and_(BrokerEventRecord.status == "processing",
                         BrokerEventRecord.processing_at.is_not(None),
                         BrokerEventRecord.processing_at <= stale_cutoff))
                rows = session.scalars(select(BrokerEventRecord)
                    .where(eligible).order_by(BrokerEventRecord.id).limit(limit)
                    .with_for_update(skip_locked=True)).all()
                for row in rows:
                    row.status = "processing"
                    row.processing_at = datetime.now(timezone.utc)
                    row.processing_token = claim_token
                    row.attempts += 1
                    row.last_error = None
                    claimed.append(row.event_id)
        except Exception as exc:
            raise BrokerEventError(f"Réservation des événements impossible ({type(exc).__name__})") from exc
        if not claimed:
            return {"claimed": 0, "processed": 0, "failed": 0, "event_ids": []}

        try:
            reconciliation_report = self.reconciliation.run()
            if not self._is_complete_reconciliation(reconciliation_report):
                raise BrokerEventError("Rapport de réconciliation incomplet ou tronqué")
        except Exception as exc:
            try:
                with self.session_factory.begin() as session:
                    rows = session.scalars(select(BrokerEventRecord).where(
                        BrokerEventRecord.event_id.in_(claimed),
                        BrokerEventRecord.status == "processing",
                        BrokerEventRecord.processing_token == claim_token)).all()
                    failed_at = datetime.now(timezone.utc)
                    failed_count = len(rows)
                    for row in rows:
                        row.processing_at = None
                        row.processing_token = None
                        row.last_error = type(exc).__name__
                        if row.attempts >= self.max_attempts:
                            row.status = "dead_letter"
                            row.next_attempt_at = None
                        else:
                            row.status = "failed"
                            row.next_attempt_at = failed_at + timedelta(
                                seconds=self._retry_delay(row.attempts))
                    if rows:
                        session.add(AuditEventRecord(event_type="broker_event_batch_failed",
                            message="Réconciliation déclenchée par notification en échec",
                            details={"event_ids": [row.event_id for row in rows],
                                     "error_type": type(exc).__name__}))
            except Exception as persist_exc:
                raise BrokerEventError("Échec de réconciliation et impossibilité de persister l'échec") from persist_exc
            with self.session_factory() as session:
                dead = session.scalar(select(BrokerEventRecord.id).where(
                    BrokerEventRecord.event_id.in_(claimed),
                    BrokerEventRecord.status == "dead_letter").limit(1)) is not None
            return {"claimed": len(claimed), "processed": 0, "failed": failed_count,
                    "superseded": len(claimed) - failed_count,
                    "dead_letter": dead, "event_ids": claimed, "error_type": type(exc).__name__}

        try:
            with self.session_factory.begin() as session:
                rows = session.scalars(select(BrokerEventRecord).where(
                    BrokerEventRecord.event_id.in_(claimed),
                    BrokerEventRecord.status == "processing",
                    BrokerEventRecord.processing_token == claim_token)).all()
                for row in rows:
                    row.status = "processed"
                    row.processing_at = None
                    row.processing_token = None
                    row.processed_at = datetime.now(timezone.utc)
                    row.next_attempt_at = None
                    row.last_error = None
                if rows:
                    session.add(AuditEventRecord(event_type="broker_event_batch_processed",
                        message="Notifications broker traitées par réconciliation complète",
                        details={"event_ids": [row.event_id for row in rows], "reconciliation_status":
                            (reconciliation_report or {}).get("execution_health", {}).get("status", "unknown")}))
                superseded = len(claimed) - len(rows)
        except Exception as exc:
            # Leave events in processing; a later operator recovery can safely
            # replay the read-only reconciliation. Do not mark them processed.
            raise BrokerEventError("Réconciliation terminée mais accusé durable impossible") from exc
        return {"claimed": len(claimed), "processed": len(claimed) - superseded,
                "superseded": superseded, "failed": 0,
                "event_ids": claimed, "reconciliation": reconciliation_report}
