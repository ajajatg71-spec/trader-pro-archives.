"""Strategy configuration application service, independent from FastAPI."""
from __future__ import annotations

from typing import Any, Callable


class StrategyServiceError(Exception):
    """Transport-neutral strategy validation error."""

    def __init__(self, detail: str, status_code: int = 400):
        super().__init__(detail)
        self.detail = detail
        self.status_code = status_code


class StrategyService:
    """Validates and persists strategy settings without enabling Live execution."""

    def __init__(self, *, state: dict[str, Any], lock: Any,
                 save: Callable[[], None], history: Callable[..., Any],
                 paper_mode: bool) -> None:
        self.state, self.lock = state, lock
        self.save, self.history, self.paper_mode = save, history, paper_mode

    def update(self, config: Any) -> dict[str, Any]:
        if not (5 <= config.scan_minutes <= 1440
                and 1 <= config.rebalance_days <= 90
                and 1 <= config.trade_amount <= 1e6):
            raise StrategyServiceError("Valeurs hors limites")
        if config.auto_execute and not self.paper_mode:
            raise StrategyServiceError("Exécution automatique réservée au compte paper")
        watchlist = [x.upper() for x in config.watchlist.replace(",", " ").split()][:20]
        with self.lock:
            self.state["strategy"] = {
                "enabled": config.enabled,
                "auto_execute": config.auto_execute,
                "scan_minutes": config.scan_minutes,
                "rebalance_days": config.rebalance_days,
                "trade_amount": config.trade_amount,
                "watchlist": watchlist,
            }
            self.save()
            result = dict(self.state["strategy"])
        self.history("config", "Stratégie modifiée", strategy=result)
        return result
