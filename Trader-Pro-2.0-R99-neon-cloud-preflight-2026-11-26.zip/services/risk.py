"""Risk application service; preserves the V1 risk-domain calculations."""
from __future__ import annotations

from typing import Any, Callable
from datetime import timezone
import time

import core
import portfolio
import risklib
from services.institutional_risk import InstitutionalRiskEngine


class RiskService:
    """Builds risk snapshots from injected account, position and market providers.

    The financial formulas remain delegated to the original V1 modules. This
    service only orchestrates their inputs and output, without FastAPI globals.
    """

    def __init__(
        self,
        account_reader: Callable[[], dict[str, Any]],
        positions_reader: Callable[[], list[dict[str, Any]]],
        state_reader: Callable[[], dict[str, Any]],
        market_bars_reader: Callable[[str], list[float]],
        orders_today_reader: Callable[[], int],
        broker_error_type: type[Exception],
        market_history_reader: Callable[[str], Any] | None = None,
    ) -> None:
        self._account_reader = account_reader
        self._positions_reader = positions_reader
        self._state_reader = state_reader
        self._market_bars_reader = market_bars_reader
        self._market_history_reader = market_history_reader
        self._orders_today_reader = orders_today_reader
        self._broker_error_type = broker_error_type
        self._institutional = InstitutionalRiskEngine()

    def _advanced(self, positions: list[dict[str, Any]], equity: float, state: dict[str, Any]) -> dict[str, Any]:
        limits = state["limits"]
        out = {"orders_today": self._orders_today_reader(), "max_orders_day": int(limits["max_orders_day"])}
        try:
            values = {p["symbol"]: float(p["market_value"]) for p in positions}
            closes = {}
            if self._market_history_reader is not None:
                spy_history = self._market_history_reader("SPY")
                spy = list(spy_history.closes)
                if not spy_history.timestamps:
                    # Simulation/legacy providers may intentionally have no
                    # exchange timestamps. In that case use the validated
                    # close-only reader, label the limitation, and never treat
                    # it as timestamp-certified market risk.
                    spy = self._market_bars_reader("SPY")
                    missing_symbols = []
                    for symbol in values:
                        bars = self._market_bars_reader(symbol)
                        if len(bars) <= 30:
                            missing_symbols.append(symbol)
                        else:
                            closes[symbol] = bars
                    if missing_symbols:
                        return {**out, "error": "historique insuffisant pour toutes les positions",
                                "missing_symbols": sorted(missing_symbols)}
                    if closes and any(len(bars) != len(spy) for bars in closes.values()):
                        return {**out, "error": "historiques de marché désalignés en longueur",
                                "alignment": "unverified"}
                    out["risk_data_coverage"] = {
                        "held_symbols": len(values), "covered_symbols": len(closes),
                        "benchmark_observations": len(spy), "lengths_aligned": True,
                        "timestamp_alignment": "not_available_simulation_or_legacy",
                    }
                else:
                    spy_stamps = tuple(
                        stamp.astimezone(timezone.utc) for stamp in spy_history.timestamps
                    )
                    if len(spy) <= 30 or len(spy_stamps) != len(spy):
                        return {**out, "error": "historique benchmark insuffisant ou non horodaté",
                                "alignment": "unverified"}
                    if any(left >= right for left, right in zip(spy_stamps, spy_stamps[1:])):
                        return {**out, "error": "horodatages benchmark invalides",
                                "alignment": "unverified"}
                    missing_symbols = []
                    misaligned_symbols = []
                    for symbol in values:
                        history = self._market_history_reader(symbol)
                        bars = list(history.closes)
                        stamps = tuple(
                            stamp.astimezone(timezone.utc) for stamp in history.timestamps
                        )
                        if len(bars) <= 30 or len(stamps) != len(bars):
                            missing_symbols.append(symbol)
                        elif stamps != spy_stamps:
                            misaligned_symbols.append(symbol)
                        else:
                            closes[symbol] = bars
                    if missing_symbols:
                        return {**out, "error": "historique insuffisant pour toutes les positions",
                                "missing_symbols": sorted(missing_symbols), "alignment": "timestamped"}
                    if misaligned_symbols:
                        return {**out, "error": "séances de marché désalignées",
                                "misaligned_symbols": sorted(misaligned_symbols),
                                "alignment": "timestamped"}
                    out["risk_data_coverage"] = {
                        "held_symbols": len(values), "covered_symbols": len(closes),
                        "benchmark_observations": len(spy), "lengths_aligned": True,
                        "timestamp_alignment": "verified_exact_session_timestamps",
                    }
            else:
                spy = self._market_bars_reader("SPY")
                missing_symbols = []
                for symbol in values:
                    bars = self._market_bars_reader(symbol)
                    if len(bars) <= 30:
                        missing_symbols.append(symbol)
                    else:
                        closes[symbol] = bars
                # Never compute portfolio risk from a partial subset. The
                # legacy close-only reader can check lengths, not exact sessions.
                if missing_symbols:
                    return {**out, "error": "historique insuffisant pour toutes les positions",
                            "missing_symbols": sorted(missing_symbols)}
                if closes and any(len(bars) != len(spy) for bars in closes.values()):
                    return {**out, "error": "historiques de marché désalignés en longueur",
                            "alignment": "unverified"}
                if closes:
                    out["risk_data_coverage"] = {
                        "held_symbols": len(values), "covered_symbols": len(closes),
                        "benchmark_observations": len(spy), "lengths_aligned": True,
                        "timestamp_alignment": "not_verifiable_with_legacy_close_reader",
                    }
            out["regime"] = risklib.regime(spy)
        except self._broker_error_type:
            return {**out, "error": "données de marché indisponibles"}
        except Exception:
            return {**out, "error": "données de marché indisponibles ou invalides"}
        except self._broker_error_type:
            return {**out, "error": "données de marché indisponibles"}

        out["stops"] = [
            {"symbol": p["symbol"], "stop_price": risklib.stop_price(
                float(p["avg_entry_price"]), state["highs"].get(p["symbol"], 0.0), limits
            )}
            for p in positions
            if risklib.stop_price(float(p["avg_entry_price"]), state["highs"].get(p["symbol"], 0.0), limits)
        ]
        if closes and equity:
            weights = {symbol: values[symbol] / equity for symbol in closes}
            portfolio_returns = risklib.portfolio_returns(weights, closes)
            var_cvar = risklib.var_cvar(portfolio_returns)
            returns = {symbol: risklib.returns(bars) for symbol, bars in closes.items()}
            market_returns = risklib.returns(spy)
            betas = {symbol: risklib.beta(series, market_returns) or 1.0
                     for symbol, series in returns.items()}
            if var_cvar:
                out.update(var95_pct=round(var_cvar[0] * 100, 2),
                           var95_usd=round(var_cvar[0] * equity, 2),
                           cvar95_pct=round(var_cvar[1] * 100, 2))
            out.update(
                vol_ann_pct=round(risklib.stdev(portfolio_returns) * 252 ** .5 * 100, 1),
                avg_corr=risklib.avg_corr(returns),
                eff_n=risklib.effective_n([value / sum(weights.values()) for value in weights.values()]),
                beta=round(sum(weights[symbol] * betas[symbol] for symbol in weights), 2),
                stress={str(-shock): round(risklib.stress(
                    {symbol: values[symbol] for symbol in values}, shock, betas
                )[1], 2) for shock in (10, 20, 30)},
            )
        return out

    def snapshot(self) -> dict[str, Any]:
        account = self._account_reader()
        positions = self._positions_reader()
        state = self._state_reader()
        limits = state["limits"]
        equity = float(account["equity"])
        peak = max(float(state.get("peak") or 0), equity)
        adv = self._advanced(positions, equity, state)
        market_risk: dict[str, Any] = {}
        for key in ("var95_pct", "cvar95_pct"):
            if key in adv:
                market_risk[key] = adv[key]
        stress_values = adv.get("stress")
        if isinstance(stress_values, dict) and equity > 0 and stress_values:
            market_risk["stress_loss_pct"] = max(max(-float(value), 0.0) for value in stress_values.values()) / equity * 100.0
        for key in ("avg_corr", "eff_n"):
            if key in adv:
                market_risk[key] = adv[key]
        # Keep only the latest computed risk snapshot for the approval gate.
        # If market data are unavailable, clear it so stale values cannot pass.
        if isinstance(state, dict):
            if market_risk:
                state["market_risk"] = {**market_risk, "as_of": time.time()}
            else:
                state.pop("market_risk", None)
        try:
            institutional = self._institutional.portfolio_snapshot(
                account, positions, state, market_risk=market_risk
            )
        except (ValueError, TypeError, OverflowError):
            institutional = {"status": "UNAVAILABLE", "breaches": ["Données de risque institutionnel indisponibles"], "metrics": {}}
        return {
            "institutional": institutional,
            "daily": round(core.daily_loss(account), 2),
            "drawdown": round(portfolio.drawdown(equity, peak), 2),
            "cash_pct": round(float(account["cash"]) / equity * 100, 1) if equity else 0,
            "limits": limits,
            "paused": state["paused"],
            "positions": [
                {"symbol": position["symbol"],
                 "pct": round(float(position["market_value"]) / equity * 100, 1)}
                for position in positions
            ],
            "alerts": portfolio.risk_alerts(
                equity, float(account.get("last_equity") or 0), peak, positions, limits
            ),
            "adv": adv,
        }
