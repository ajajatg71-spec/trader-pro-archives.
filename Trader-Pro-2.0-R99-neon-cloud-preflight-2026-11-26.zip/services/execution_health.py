"""Operator-facing execution health summary built from reconciliation evidence.

This module classifies exceptions only. It never retries, cancels, or mutates orders.
"""
from __future__ import annotations

from typing import Any

_UNCERTAIN = {
    "submitting": "submission_in_progress",
    "submission_unknown": "submission_outcome_unknown",
    "submission_failed": "submission_requires_review",
    "pending_cancel": "cancel_confirmation_pending",
    "pending_replace": "replace_confirmation_pending",
    "partially_filled": "partial_execution_open",
    "accepted": "broker_order_open",
    "new": "broker_order_open",
    "pending_new": "broker_order_open",
    "held": "broker_order_held",
}


def build_execution_health(*, local_orders: list[dict[str, Any]],
                           order_by_client: dict[str, dict[str, Any]],
                           order_by_broker: dict[str, dict[str, Any]],
                           report: dict[str, Any]) -> dict[str, Any]:
    """Summarize unresolved execution conditions for an operator dashboard."""
    exceptions: list[dict[str, Any]] = []
    fill_checks = {item.get("client_order_id"): item
                   for item in report.get("fill_quantity_checks", [])
                   if isinstance(item, dict)}

    for local in local_orders:
        client_id = str(local.get("client_order_id") or "")
        local_status = str(local.get("status") or "").lower()
        remote = order_by_client.get(client_id)
        if remote is None and local.get("broker_order_id"):
            remote = order_by_broker.get(str(local["broker_order_id"]))
        # Prefer the latest broker-observed state for pending-action reporting;
        # transition validation elsewhere prevents stale observations overwriting
        # a newer local terminal state.
        status = str((remote or {}).get("status") or local_status).lower()

        if remote is None and local_status not in {"filled", "canceled", "cancelled", "expired", "rejected", "replaced"}:
            exceptions.append({
                "client_order_id": client_id,
                "category": "broker_order_missing",
                "local_status": local_status,
                "severity": "critical" if local_status in {"submitting", "submission_unknown", "submission_failed"} else "warning",
                "action": "lookup_by_client_order_id_and_review_before_any_retry",
                "automatic_retry": False,
            })
        elif status in _UNCERTAIN:
            reason = _UNCERTAIN[status]
            exceptions.append({
                "client_order_id": client_id,
                "category": reason,
                "local_status": local_status,
                "broker_status": str((remote or {}).get("status") or "").lower() or None,
                "severity": "critical" if status in {"submission_unknown", "submission_failed"} else "warning",
                "action": "reconcile_with_broker_and_review",
                "automatic_retry": False,
            })

        check = fill_checks.get(client_id)
        if check and check.get("status") != "consistent":
            exceptions.append({
                "client_order_id": client_id,
                "category": "fill_ledger_mismatch",
                "local_status": status,
                "severity": "critical",
                "action": "investigate_broker_activities_and_local_fill_ledger",
                "automatic_retry": False,
                "difference": check.get("difference"),
            })

    for warning in report.get("warnings", []):
        if "Transition de statut refusée" in str(warning):
            exceptions.append({
                "category": "stale_or_invalid_broker_transition",
                "severity": "warning",
                "action": "inspect_order_history_and_broker_snapshot",
                "automatic_retry": False,
                "message": str(warning),
            })

    financial_status = (report.get("financial_reconciliation") or {}).get("status")
    if financial_status == "mismatch":
        exceptions.append({
            "category": "financial_ledger_mismatch",
            "severity": "critical",
            "action": "pause_trading_and_investigate_financial_discrepancies",
            "automatic_retry": False,
        })

    if report.get("truncated_order_snapshot") or report.get("truncated_fill_snapshot"):
        exceptions.append({
            "category": "incomplete_broker_snapshot",
            "severity": "warning",
            "action": "repeat_reconciliation_with_complete_pagination",
            "automatic_retry": False,
        })

    critical = sum(item.get("severity") == "critical" for item in exceptions)
    warnings = sum(item.get("severity") == "warning" for item in exceptions)
    status = "critical" if critical else "warning" if warnings else "healthy"
    return {
        "status": status,
        "automatic_retry_permitted": False,
        "exceptions_count": len(exceptions),
        "critical_count": critical,
        "warning_count": warnings,
        "exceptions": exceptions,
    }
