"""Trusted adapter from candle-confluence evaluation to research execution.

Only backend callers may use this adapter. Hypothesis IDs use the exact form
``pattern|horizon_bars|policy``. The baseline ``candle_only`` is excluded from
paired hypotheses because it has no paired comparison p-value.
"""
from __future__ import annotations

from types import SimpleNamespace
from typing import Any, Mapping

from research_v1.validation.candle_confluence import evaluate_candle_confluence


class CandleResearchAdapterError(ValueError):
    pass


def evaluate_preregistered_candle_family(manifest: Mapping[str, Any], snapshot: Any) -> dict[str, float]:
    if not isinstance(manifest, Mapping) or not isinstance(snapshot, Mapping):
        raise CandleResearchAdapterError("Manifeste et snapshot structurés requis")
    if manifest.get("study") not in {"candle_confluence", "candles_confluence"}:
        raise CandleResearchAdapterError("Famille non compatible avec l'étude candle_confluence")
    bars_payload = snapshot.get("bars")
    if not isinstance(bars_payload, list) or not bars_payload:
        raise CandleResearchAdapterError("Snapshot OHLCV absent")
    bars = []
    for index, item in enumerate(bars_payload):
        if not isinstance(item, Mapping) or any(k not in item for k in ("o", "h", "l", "c", "v")):
            raise CandleResearchAdapterError(f"Barre OHLCV invalide à l'index {index}")
        bars.append(SimpleNamespace(**{k: item[k] for k in ("o", "h", "l", "c", "v")}))

    metadata = manifest.get("metadata") or {}
    if not isinstance(metadata, Mapping):
        raise CandleResearchAdapterError("Métadonnées de protocole invalides")
    config = {
        "horizons": tuple(metadata.get("horizons", (1, 3, 5))),
        "commission_bps_per_side": metadata.get("commission_bps_per_side", 5.0),
        "slippage_bps_per_side": metadata.get("slippage_bps_per_side", 5.0),
        "development_fraction": metadata.get("development_fraction", 0.70),
        "min_observations": metadata.get("min_observations", 20),
    }
    evaluation = evaluate_candle_confluence(bars, **config)
    rows = evaluation.get("results")
    if not isinstance(rows, list):
        raise CandleResearchAdapterError("Sortie du moteur de recherche invalide")

    by_id: dict[str, float] = {}
    for row in rows:
        inference = row.get("paired_candle_only_comparison") or {}
        raw_p = inference.get("p_value_raw")
        if raw_p is None:
            continue
        hypothesis_id = f"{row['pattern']}|{int(row['horizon_bars'])}|{row['policy']}"
        if row["policy"] == "candle_only":
            continue
        by_id[hypothesis_id] = float(raw_p)

    expected = manifest.get("hypotheses")
    if not isinstance(expected, list) or not expected:
        raise CandleResearchAdapterError("Hypothèses pré-enregistrées absentes")
    expected_ids = {str(x) for x in expected}
    missing = sorted(expected_ids - set(by_id))
    unexpected = sorted(set(by_id) - expected_ids)
    if missing:
        raise CandleResearchAdapterError(
            "Famille incomplète : p-value appariée indisponible pour " + ", ".join(missing[:8])
        )
    # The registry locks a complete family; do not silently drop unregistered tests.
    if unexpected:
        by_id = {key: value for key, value in by_id.items() if key in expected_ids}
    return {key: by_id[key] for key in sorted(expected_ids)}
