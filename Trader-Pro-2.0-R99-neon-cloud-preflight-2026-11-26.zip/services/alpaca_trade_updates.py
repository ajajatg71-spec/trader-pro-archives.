"""Alpaca Paper trade_updates transport adapter.

The stream is only a notification source: accepted messages are persisted to the
broker inbox. It never mutates positions or order state and never submits orders.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any

from services.broker_events import BrokerEventError

PAPER_STREAM_URL = "wss://paper-api.alpaca.markets/stream"


class AlpacaTradeUpdatesError(RuntimeError):
    pass


def stable_event_id(data: dict[str, Any]) -> str:
    """Prefer Alpaca's event/execution IDs; otherwise hash canonical event JSON."""
    if not isinstance(data, dict):
        raise AlpacaTradeUpdatesError("Payload trade_updates invalide")
    provider_id = data.get("event_id") or data.get("execution_id")
    if provider_id:
        value = str(provider_id).strip()
        if not value or len(value) > 140:
            raise AlpacaTradeUpdatesError("Identifiant événement Alpaca invalide")
        return f"alpaca:{value}"
    try:
        canonical = json.dumps(data, sort_keys=True, separators=(",", ":"),
                               ensure_ascii=True, allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise AlpacaTradeUpdatesError("Payload trade_updates non sérialisable") from exc
    digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    return f"alpaca:sha256:{digest}"


def persist_trade_update(message: Any, processor) -> bool:
    """Validate the stream envelope and persist its event data idempotently."""
    if isinstance(message, bytes):
        try:
            message = message.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise AlpacaTradeUpdatesError("Trame Alpaca non UTF-8; codec non pris en charge") from exc
    if isinstance(message, str):
        try:
            message = json.loads(message)
        except json.JSONDecodeError as exc:
            raise AlpacaTradeUpdatesError("Message Alpaca JSON invalide") from exc
    if not isinstance(message, dict) or message.get("stream") != "trade_updates":
        raise AlpacaTradeUpdatesError("Flux Alpaca inattendu")
    data = message.get("data")
    if not isinstance(data, dict) or not isinstance(data.get("event"), str):
        raise AlpacaTradeUpdatesError("Événement Alpaca incomplet")
    event_id = stable_event_id(data)
    try:
        return processor.receive(event_id=event_id, event=data)
    except BrokerEventError as exc:
        raise AlpacaTradeUpdatesError("Persistance inbox de l'événement impossible") from exc
