"""Order lifecycle application service, independent from FastAPI routes."""
from __future__ import annotations

from typing import Any, Callable
import math

from services.risk_controls import risk_halt_reason
from trading_mandate import DEFAULT_TRADING_MANDATE


class OrderServiceError(Exception):
    """Transport-neutral order failure with an HTTP-compatible status code."""

    def __init__(self, status_code: int, detail: str):
        super().__init__(detail)
        self.status_code = status_code
        self.detail = detail


class OrderService:
    """Coordinates approvals and broker calls using injected dependencies.

    The existing V1 risk predicate, broker idempotency key, and state format are
    deliberately preserved. This service does not enable or select Live mode.
    """

    def __init__(
        self, *, state: dict[str, Any], lock: Any, save: Callable[[], None],
        history: Callable[..., Any], account_reader: Callable[[], dict[str, Any]],
        positions_reader: Callable[[], list[dict[str, Any]]],
        orders_reader: Callable[..., list[dict[str, Any]]],
        order_submitter: Callable[[str, str, float, str], dict[str, Any]],
        order_canceller: Callable[[str], Any], daily_loss: Callable[[dict[str, Any]], float],
        order_checker: Callable[..., str | None], orders_today_reader: Callable[[], int],
        status_writer: Callable[..., None] | None = None,
        order_persistence: Any | None = None,
        risk_engine: Any | None = None,
        risk_decision_writer: Callable[..., None] | None = None,
        operational_pause_writer: Callable[..., None] | None = None,
        operational_pause_reader: Callable[[], dict[str, Any]] | None = None,
        liquidity_reader: Callable[[str], dict[str, Any]] | None = None,
        system_safety_reader: Callable[[], dict[str, Any]] | None = None,
        instrument_reader: Callable[[str], dict[str, Any]] | None = None,
    ) -> None:
        self.state, self.lock, self.save, self.history = state, lock, save, history
        self.account_reader, self.positions_reader = account_reader, positions_reader
        self.orders_reader, self.order_submitter = orders_reader, order_submitter
        self.order_canceller, self.daily_loss = order_canceller, daily_loss
        self.order_checker, self.orders_today_reader = order_checker, orders_today_reader
        self.status_writer = status_writer
        self.order_persistence = order_persistence
        self.risk_engine = risk_engine
        self.risk_decision_writer = risk_decision_writer
        self.operational_pause_writer = operational_pause_writer
        self.operational_pause_reader = operational_pause_reader
        self.liquidity_reader = liquidity_reader
        self.system_safety_reader = system_safety_reader
        self.instrument_reader = instrument_reader

    def _audit_risk_decision(self, pending: dict[str, Any], oid: str, decision: str,
                             gate: str, reason: str | None = None, account: dict[str, Any] | None = None,
                             positions: list[dict[str, Any]] | None = None) -> None:
        if self.risk_decision_writer is None:
            return
        metrics = {
            "equity": account.get("equity") if account else None,
            "position_count": len(positions) if positions is not None else None,
            "trading_mode": self.state.get("mode", "unknown"),
        }
        self.risk_decision_writer(client_order_id=oid, symbol=pending["sym"],
            side=pending["side"], notional=float(pending["amt"]), decision=decision,
            gate=gate, reason=reason, metrics=metrics)

    def list_orders(self) -> list[dict[str, Any]]:
        fields = ("id", "symbol", "side", "notional", "qty", "status", "filled_avg_price", "submitted_at")
        return [{key: order.get(key) for key in fields} for order in self.orders_reader("all", 20)]

    def _open_buy_reservations(self) -> tuple[float, list[dict[str, Any]]]:
        """Return a complete broker snapshot and normalized buy reservations."""
        try:
            open_orders = self.orders_reader("open", 10000)
            if not isinstance(open_orders, list):
                raise ValueError("snapshot des ordres ouverts invalide")
            if len(open_orders) >= 10000:
                raise ValueError("snapshot des ordres ouverts potentiellement tronqué")
            reservations: list[dict[str, Any]] = []
            amounts: list[float] = []
            for item in open_orders:
                if not isinstance(item, dict):
                    raise ValueError("ordre ouvert mal formé")
                side = item.get("side")
                if side not in {"buy", "sell"}:
                    raise ValueError("sens d'ordre ouvert invalide")
                if side != "buy":
                    continue
                status = str(item.get("status") or "").strip().lower()
                raw_notional = item.get("notional")
                raw_qty, raw_filled = item.get("qty"), item.get("filled_qty")
                raw_limit = item.get("limit_price")
                amount = None
                # Prefer the remaining quantity at the limit price when the
                # broker supplies complete execution fields. This avoids
                # reserving the already-filled portion twice.
                if raw_qty not in (None, "") and raw_filled not in (None, ""):
                    if isinstance(raw_qty, bool) or isinstance(raw_filled, bool):
                        raise ValueError("quantité d'ordre ouvert invalide")
                    quantity, filled = float(raw_qty), float(raw_filled)
                    if (not math.isfinite(quantity) or quantity <= 0
                            or not math.isfinite(filled) or filled < 0 or filled > quantity):
                        raise ValueError("quantité exécutée d'ordre ouvert invalide")
                    remaining = quantity - filled
                    if remaining <= 0:
                        raise ValueError("ordre déclaré ouvert sans quantité restante")
                    if raw_limit not in (None, ""):
                        if isinstance(raw_limit, bool):
                            raise ValueError("prix limite d'ordre ouvert invalide")
                        limit_price = float(raw_limit)
                        if not math.isfinite(limit_price) or limit_price <= 0:
                            raise ValueError("prix limite d'ordre ouvert invalide")
                        amount = remaining * limit_price
                    elif raw_notional not in (None, ""):
                        if isinstance(raw_notional, bool):
                            raise ValueError("montant d'ordre ouvert invalide")
                        original_notional = float(raw_notional)
                        if not math.isfinite(original_notional) or original_notional <= 0:
                            raise ValueError("montant d'ordre ouvert invalide")
                        amount = original_notional * remaining / quantity
                elif status == "partially_filled":
                    # Never guess how much cash remains committed.
                    raise ValueError("quantité exécutée d'un ordre partiellement rempli indisponible")
                elif raw_notional not in (None, ""):
                    if isinstance(raw_notional, bool):
                        raise ValueError("montant d'un ordre achat ouvert invalide")
                    amount = float(raw_notional)
                elif raw_qty not in (None, "") and raw_limit not in (None, ""):
                    if isinstance(raw_qty, bool) or isinstance(raw_limit, bool):
                        raise ValueError("quantité/prix d'ordre ouvert invalide")
                    amount = float(raw_qty) * float(raw_limit)
                if amount is None or not math.isfinite(amount) or amount <= 0:
                    raise ValueError("montant restant d'un ordre achat ouvert indisponible ou invalide")
                broker_id = item.get("id") or item.get("broker_order_id")
                symbol = item.get("symbol")
                if not isinstance(broker_id, str) or not broker_id.strip():
                    raise ValueError("identifiant d'un ordre achat ouvert indisponible")
                if not isinstance(symbol, str) or not symbol.strip():
                    raise ValueError("symbole d'un ordre achat ouvert indisponible")
                amounts.append(amount)
                reservations.append({"broker_order_id": broker_id, "symbol": symbol.upper(),
                                     "notional": amount})
            total = math.fsum(amounts)
            if not math.isfinite(total):
                raise ValueError("total des réservations non fini")
            return total, reservations
        except Exception as exc:
            raise OrderServiceError(423,
                "Réservations des ordres ouverts indisponibles : approbation bloquée") from exc

    def _atomic_buy_reservation_ceiling(self, account: dict[str, Any],
                                        positions: list[dict[str, Any]], symbol: str) -> tuple[float, float]:
        """Compute aggregate buy-reservation headroom for the DB-locked claim."""
        try:
            equity = float(account["equity"])
            cash = float(account["cash"])
            if not math.isfinite(equity) or equity <= 0 or not math.isfinite(cash) or cash < 0:
                raise ValueError("compte invalide")
            limits = self.state["limits"]
            max_gross = float(limits.get("max_gross", 100.0))
            min_cash = float(limits.get("min_cash", 0.0))
            if not math.isfinite(max_gross) or not 0 <= max_gross <= 1000:
                raise ValueError("limite brute invalide")
            if not math.isfinite(min_cash) or not 0 <= min_cash <= 100:
                raise ValueError("réserve minimale invalide")
            gross = math.fsum(float(position["market_value"]) for position in positions)
            if not math.isfinite(gross) or gross < 0:
                raise ValueError("positions invalides")
            cash_headroom = cash - equity * min_cash / 100.0
            gross_headroom = equity * max_gross / 100.0 - gross
            max_pos = float(limits.get("max_pos", 100.0))
            if not math.isfinite(max_pos) or not 0 <= max_pos <= 100:
                raise ValueError("limite par position invalide")
            symbol = symbol.upper()
            current_symbol = math.fsum(float(position["market_value"]) for position in positions
                if str(position.get("symbol", "")).upper() == symbol)
            symbol_headroom = equity * max_pos / 100.0 - current_symbol
            ceiling = min(cash_headroom, gross_headroom)
            if not math.isfinite(ceiling):
                raise ValueError("plafond de réservation invalide")
            return max(0.0, ceiling), max(0.0, symbol_headroom)
        except Exception as exc:
            raise OrderServiceError(423,
                "Plafond de réservation agrégé indisponible : approbation bloquée") from exc

    def approve(self, oid: str) -> dict[str, Any]:
        with self.lock:
            pending = self.state["pending"].get(oid)
            if not pending:
                raise OrderServiceError(404, "Ordre introuvable ou déjà traité")
            if self.system_safety_reader is None:
                raise OrderServiceError(423, "État global de sécurité non configuré : ordre bloqué")
            try:
                safety = self.system_safety_reader()
                if not isinstance(safety, dict) or safety.get("status") != "READY":
                    status = safety.get("status", "UNKNOWN") if isinstance(safety, dict) else "UNKNOWN"
                    reason = safety.get("reason") if isinstance(safety, dict) else None
                    raise ValueError(f"état global {status}: {reason or 'non prêt'}")
            except Exception as exc:
                self._audit_risk_decision(pending, oid, "blocked", "SYSTEM_SAFETY_STATE",
                    f"État global non prêt ({type(exc).__name__})")
                raise OrderServiceError(423, "État global de sécurité non prêt : ordre bloqué") from None
            if self.operational_pause_reader is not None:
                try:
                    durable_pause = self.operational_pause_reader()
                    if not isinstance(durable_pause, dict) or not isinstance(durable_pause.get("paused"), bool):
                        raise ValueError("État durable du coupe-circuit invalide")
                    # The database is authoritative across workers/processes.
                    self.state["paused"] = durable_pause["paused"]
                    if durable_pause.get("reason"):
                        self.state["pause_reason"] = durable_pause["reason"]
                    elif not durable_pause["paused"]:
                        self.state.pop("pause_reason", None)
                except Exception:
                    self.state["paused"] = True
                    reason = "État durable du coupe-circuit indisponible : ordre bloqué"
                    self._audit_risk_decision(pending, oid, "blocked", "PAUSE_STATE_UNAVAILABLE", reason)
                    raise OrderServiceError(423, reason) from None
            if self.state["paused"]:
                reason = self.state.get("pause_reason") or "Trading en pause"
                self._audit_risk_decision(pending, oid, "blocked", "PAUSE", reason)
                raise OrderServiceError(423, reason)
            # Broker instrument metadata is authoritative; unknown data blocks orders.
            if self.instrument_reader is None:
                self._audit_risk_decision(pending, oid, "blocked", "INSTRUMENT_UNIVERSE",
                    "Classification broker non configurée : ordre bloqué")
                raise OrderServiceError(423, "Classification de l'instrument indisponible : ordre bloqué")
            try:
                instrument = self.instrument_reader(pending["sym"])
                if not isinstance(instrument, dict):
                    raise ValueError("métadonnées invalides")
                if str(instrument.get("symbol", "")).strip().upper() != str(pending["sym"]).strip().upper():
                    raise ValueError("symbole incohérent")
                allowed = DEFAULT_TRADING_MANDATE.instrument_allowed(
                    asset_class=instrument.get("asset_class"),
                    tradable=instrument.get("tradable") is True,
                    active=instrument.get("active") is True,
                )
                if not allowed:
                    raise ValueError("classe ou statut non autorisé")
            except Exception as exc:
                reason = f"Instrument hors univers ou non vérifié ({type(exc).__name__})"
                self._audit_risk_decision(pending, oid, "blocked", "INSTRUMENT_UNIVERSE", reason)
                raise OrderServiceError(423, "Instrument non autorisé ou classification indisponible : ordre bloqué") from None

            account, positions = self.account_reader(), self.positions_reader()
            halt_reason = risk_halt_reason(self.state, account)
            if halt_reason:
                self._audit_risk_decision(pending, oid, "blocked", "PORTFOLIO_HALT", halt_reason, account, positions)
                if halt_reason.startswith("Arrêt d'urgence"):
                    if self.operational_pause_writer is not None:
                        self.operational_pause_writer(paused=True, reason=halt_reason, actor="risk_engine")
                    self.state["paused"] = True
                    self.save()
                    self.history("alert", halt_reason)
                    raise OrderServiceError(423, halt_reason)
                raise OrderServiceError(409, halt_reason)
            limits = self.state["limits"]
            reserved, external_buy_reservations = self._open_buy_reservations()
            reason = self.order_checker(
                (pending["sym"], pending["side"], pending["amt"]), account, positions,
                limits, self.state["blocked"], reserved, self.orders_today_reader(),
            )
            if reason:
                self._audit_risk_decision(pending, oid, "blocked", "V1_ORDER_CHECK", reason, account, positions)
                pending["why"] = reason
                self.save()
                self.history("block", f"{pending['sym']} refusé : {reason}")
                raise OrderServiceError(409, reason)
            if self.risk_engine is not None:
                liquidity_controls = {"max_participation_pct", "max_spread_pct", "max_estimated_impact_pct"}
                if pending["side"] == "buy" and liquidity_controls.intersection(limits):
                    if self.liquidity_reader is None:
                        reason = "Source de liquidité non configurée : ordre bloqué"
                        self._audit_risk_decision(pending, oid, "blocked", "LIQUIDITY_DATA", reason, account, positions)
                        raise OrderServiceError(409, reason)
                    try:
                        snapshot = self.liquidity_reader(pending["sym"])
                        if not isinstance(snapshot, dict):
                            raise ValueError("snapshot invalide")
                        metadata = self.state.setdefault("risk_metadata", {})
                        existing = metadata.get(pending["sym"], {})
                        if not isinstance(existing, dict):
                            existing = {}
                        # Preserve sector/factor reference data while replacing every
                        # market-derived liquidity field with the fresh provider result.
                        existing.update(snapshot)
                        metadata[pending["sym"]] = existing
                    except Exception as exc:
                        reason = f"Données de liquidité indisponibles : {type(exc).__name__}"
                        self._audit_risk_decision(pending, oid, "blocked", "LIQUIDITY_DATA", reason, account, positions)
                        raise OrderServiceError(409, reason) from None
                institutional_reason = self.risk_engine.pre_trade_check(
                    symbol=pending["sym"], side=pending["side"], notional=pending["amt"],
                    account=account, positions=positions, state=self.state,
                    reserved_buy_notional=reserved,
                    stop_price=pending.get("stop_price"), entry_price=pending.get("entry_price"),
                )
                if institutional_reason:
                    self._audit_risk_decision(pending, oid, "blocked", "INSTITUTIONAL_RISK", institutional_reason, account, positions)
                    pending["why"] = institutional_reason
                    self.save()
                    self.history("risk_block", f"{pending['sym']} refusé : {institutional_reason}")
                    raise OrderServiceError(409, institutional_reason)
            # Persist the transition before the external side effect. The same oid
            # remains the broker idempotency key if a process stops mid-submission.
            if self.order_persistence is not None:
                # Atomically serialize the durable pause and aggregate buy-budget
                # reservation with the creation of the submission intent.
                stage = getattr(self.order_persistence, "stage_order_if_trading_enabled", None)
                try:
                    if stage is not None:
                        atomic_reservation_ceiling, symbol_reservation_ceiling = (
                            self._atomic_buy_reservation_ceiling(account, positions, pending["sym"])
                            if pending["side"] == "buy" else (None, None))
                        staged = stage(client_order_id=oid, symbol=pending["sym"],
                            side=pending["side"], notional=pending["amt"],
                            source=pending.get("source", "manual"),
                            max_total_buy_reservations=atomic_reservation_ceiling,
                            max_symbol_buy_reservation=symbol_reservation_ceiling,
                            external_open_buy_orders=external_buy_reservations)
                    else:
                        # Compatibility for injected legacy persistence adapters.
                        staged = self.order_persistence.stage_order(client_order_id=oid,
                            symbol=pending["sym"], side=pending["side"], notional=pending["amt"],
                            source=pending.get("source", "manual"))
                except PermissionError as exc:
                    self.state["paused"] = True
                    self.state["pause_reason"] = str(exc)
                    self._audit_risk_decision(pending, oid, "blocked",
                        "DURABLE_PAUSE_ATOMIC_CLAIM", str(exc), account, positions)
                    raise OrderServiceError(423, str(exc)) from None
                if staged is False:
                    # A durable intent already exists. Its remote outcome must be
                    # reconciled before any second submission, even with same CID.
                    raise OrderServiceError(409, "Ordre déjà soumis ou en cours : réconciliation obligatoire avant nouvel essai")
            # Approval is recorded only after the atomic durable pause/intent claim.
            # A blocked claim must never leave a misleading approved decision.
            self._audit_risk_decision(pending, oid, "approved", "ALL_PRETRADE_GATES", None, account, positions)
            if self.status_writer and pending.get("source") == "strategy_engine":
                self.status_writer(oid, "SUBMITTING")
            try:
                result = self.order_submitter(pending["sym"], pending["side"], pending["amt"], oid)
                # A successful HTTP exchange is not enough: an empty or malformed
                # payload may follow broker acceptance. Treat it as unknown, never
                # as permission to discard the durable intent or submit again.
                if not isinstance(result, dict):
                    raise ValueError("Réponse de soumission broker invalide")
                broker_order_id = result.get("id")
                broker_status = result.get("status")
                if not isinstance(broker_order_id, str) or not broker_order_id.strip():
                    raise ValueError("Identifiant broker absent après soumission")
                if not isinstance(broker_status, str) or not broker_status.strip():
                    raise ValueError("Statut broker absent après soumission")
                broker_status = broker_status.strip().lower()
                raw_quantity = result.get("qty")
                broker_quantity = None
                if raw_quantity not in (None, ""):
                    if isinstance(raw_quantity, bool):
                        raise ValueError("Quantité broker invalide après soumission")
                    broker_quantity = float(raw_quantity)
                    if not math.isfinite(broker_quantity) or broker_quantity <= 0:
                        raise ValueError("Quantité broker invalide après soumission")
            except Exception as exc:
                # Network errors and malformed success payloads can both occur
                # after broker acceptance; do not label either as safely failed.
                if self.order_persistence is not None:
                    self.order_persistence.update_order(oid, status="submission_unknown", reason=type(exc).__name__)
                if self.status_writer and pending.get("source") == "strategy_engine":
                    # A transport exception does not prove broker rejection. Keep
                    # the strategy proposal in an explicit ambiguous state so it
                    # cannot be presented as safely retryable after restart.
                    self.status_writer(oid, "SUBMISSION_UNKNOWN", reason=type(exc).__name__)
                raise
            if self.order_persistence is not None:
                self.order_persistence.update_order(oid, status=broker_status,
                    broker_order_id=broker_order_id, quantity=broker_quantity)
            if self.status_writer and pending.get("source") == "strategy_engine":
                self.status_writer(oid, "SUBMITTED", broker_order_id=broker_order_id)
            self.state["pending"].pop(oid, None)
            self.save()
            self.history("order", f"{pending['side']} {pending['sym']} {pending['amt']:.2f} $ → {result.get('status')}",
                         order_id=result.get("id"))
            return result

    def reject(self, oid: str) -> dict[str, bool]:
        with self.lock:
            pending = self.state["pending"].get(oid)
            if pending and self.status_writer and pending.get("source") == "strategy_engine":
                self.status_writer(oid, "REJECTED")
            pending = self.state["pending"].pop(oid, None)
            self.save()
        if pending:
            self.history("reject", f"Refusé : {pending['side']} {pending['sym']} {pending['amt']:.2f} $")
        return {"ok": True}

    def cancel(self, oid: str) -> dict[str, bool]:
        """Request broker cancellation and durably record the request, not its outcome.

        A successful DELETE is not proof that the order was canceled: it may fill
        while the cancellation is in flight. The next broker reconciliation owns
        the transition to a terminal status.
        """
        client_order_id = None
        if self.order_persistence is not None:
            try:
                finder = getattr(self.order_persistence, "list_orders_for_reconciliation", None)
                if finder is not None:
                    local = next((row for row in finder()
                                  if str(row.get("broker_order_id") or "") == str(oid)), None)
                    if local is not None:
                        client_order_id = local.get("client_order_id")
            except Exception as exc:
                # Do not send an external cancellation if we cannot establish
                # the local correlation needed for a durable audit trail.
                raise OrderServiceError(503, "État local des ordres indisponible : annulation bloquée") from exc
        try:
            self.order_canceller(oid)
        except Exception as exc:
            recorder = getattr(self.order_persistence, "record_order_cancel_event", None) if self.order_persistence is not None else None
            if recorder is not None:
                try:
                    recorder(client_order_id=client_order_id, broker_order_id=str(oid),
                             outcome="request_failed", reason=type(exc).__name__)
                except Exception as audit_exc:
                    raise OrderServiceError(503, "Échec d'annulation et journalisation indisponible") from audit_exc
            self.history("cancel_error", f"Échec de la demande d'annulation : ordre {str(oid)[:8]}", order_id=oid)
            raise OrderServiceError(502, "Demande d'annulation courtier non confirmée") from exc
        recorder = getattr(self.order_persistence, "record_order_cancel_event", None) if self.order_persistence is not None else None
        if recorder is not None:
            try:
                recorder(client_order_id=client_order_id, broker_order_id=str(oid), outcome="requested")
            except Exception as exc:
                # Broker may have accepted the cancellation; report uncertainty
                # rather than pretending the local state was durably updated.
                raise OrderServiceError(503, "Annulation demandée au courtier, mais audit local indisponible ; réconciliation obligatoire") from exc
        self.history("cancel", f"Annulation demandée : ordre {str(oid)[:8]}", order_id=oid)
        return {"ok": True}

    def _cancel_open_orders_after_pause(self) -> dict[str, Any]:
        """Request cancellation of broker-open orders after the durable pause commits.

        A successful DELETE is only a cancellation request; final status is left
        pending_cancel until a later broker reconciliation confirms canceled/filled.
        """
        report: dict[str, Any] = {"open_orders_seen": 0, "cancel_requests": 0,
                                  "cancel_request_failures": [], "snapshot_error": None,
                                  "snapshot_may_be_truncated": False}
        try:
            remote_orders = self.orders_reader("open", 10000)
            if not isinstance(remote_orders, list):
                raise ValueError("snapshot broker invalide")
        except Exception as exc:
            report["snapshot_error"] = type(exc).__name__
            self.history("pause_cancel_warning", "Pause active, mais lecture des ordres ouverts impossible")
            return report

        open_statuses = {"new", "accepted", "accepted_for_bidding", "pending_new",
                         "partially_filled", "pending_cancel", "pending_replace", "held"}
        report["open_orders_seen"] = len(remote_orders)
        report["snapshot_may_be_truncated"] = len(remote_orders) >= 10000
        if report["snapshot_may_be_truncated"]:
            self.history("pause_cancel_warning",
                "Au moins 10 000 ordres ouverts : plafond de sécurité atteint, réconciliation requise")
        for item in remote_orders:
            if not isinstance(item, dict):
                report["cancel_request_failures"].append({"reason": "invalid_order_record"})
                continue
            status = str(item.get("status") or "").lower()
            broker_id = str(item.get("id") or "")
            client_id = str(item.get("client_order_id") or "") or None
            if status not in open_statuses:
                continue
            if not broker_id:
                report["cancel_request_failures"].append({
                    "client_order_id": client_id, "reason": "broker_order_id_missing"})
                continue
            # Persist the cancellation intent before the external side effect.
            if self.order_persistence is not None:
                try:
                    self.order_persistence.record_order_cancel_event(
                        client_order_id=client_id, broker_order_id=broker_id,
                        outcome="requested")
                except Exception as exc:
                    report["cancel_request_failures"].append({
                        "client_order_id": client_id, "broker_order_id": broker_id,
                        "reason": f"durable_intent_failed:{type(exc).__name__}"})
                    continue
            try:
                self.order_canceller(broker_id)
                report["cancel_requests"] += 1
                # Do not mark canceled here: broker acceptance of DELETE is not
                # proof that a concurrent fill did not win the race.
            except Exception as exc:
                reason = type(exc).__name__
                report["cancel_request_failures"].append({
                    "client_order_id": client_id, "broker_order_id": broker_id,
                    "reason": reason})
                if self.order_persistence is not None:
                    try:
                        self.order_persistence.record_order_cancel_event(
                            client_order_id=client_id, broker_order_id=broker_id,
                            outcome="request_failed", reason=reason)
                    except Exception:
                        # Pause remains active even if secondary audit persistence fails.
                        pass
        return report

    def toggle_pause(self) -> dict[str, Any]:
        with self.lock:
            # Prefer the durable state when available; stale worker memory must not
            # accidentally resume trading after another worker changed the switch.
            current_paused = bool(self.state.get("paused", False))
            if self.operational_pause_reader is not None:
                try:
                    durable = self.operational_pause_reader()
                    if not isinstance(durable, dict) or not isinstance(durable.get("paused"), bool):
                        raise ValueError("État durable invalide")
                    current_paused = durable["paused"]
                except Exception as exc:
                    self.state["paused"] = True
                    self.state["pause_reason"] = "État durable indisponible : reprise interdite"
                    raise OrderServiceError(503, "État durable du coupe-circuit indisponible") from exc
            paused = not current_paused
            # Durable state + audit must succeed before the in-memory switch changes.
            if self.operational_pause_writer is not None:
                try:
                    self.operational_pause_writer(paused=paused, reason=("Pause manuelle" if paused else None),
                                                  actor="operator")
                except Exception as exc:
                    if paused:
                        self.state["paused"] = True
                    raise OrderServiceError(503, "Impossible de persister le changement du coupe-circuit") from exc
            self.state["paused"] = paused
            if paused:
                self.state["pause_reason"] = "Pause manuelle"
            else:
                self.state.pop("pause_reason", None)
            self.save()
        self.history("pause", "Pause" if paused else "Reprise")
        if not paused:
            return {"paused": False, "cancellation": None}
        # Cancellation is deliberately best-effort after the pause is durable.
        # Failure never re-enables trading; reconciliation must confirm outcomes.
        return {"paused": True, "cancellation": self._cancel_open_orders_after_pause()}
