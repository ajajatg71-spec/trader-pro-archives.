"""Validated, bounded-cache market data boundary for strategy/quant consumers.

The provider is injected (broker adapter in production, deterministic fake in tests).
This layer deliberately does not calculate indicators or trading decisions.
"""
from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import math
import re
import threading
import time
from typing import Callable, Sequence

_SYMBOL = re.compile(r"^[A-Z][A-Z0-9.\-]{0,14}$")


class MarketDataError(ValueError):
    """Raised when a symbol or provider payload is invalid/unavailable."""


class ProviderChain:
    """Try independent market-data readers and retain secret-free diagnostics."""

    def __init__(self, providers, *, monotonic_clock=time.monotonic,
                 utc_clock=lambda: datetime.now(timezone.utc),
                 failure_threshold: int = 3, cooldown_seconds: float = 30.0):
        self.providers = tuple(providers)
        if not self.providers:
            raise ValueError("Au moins un fournisseur de données est requis")
        names = [name for name, reader in self.providers]
        if any(not str(name).strip() or not callable(reader) for name, reader in self.providers):
            raise ValueError("Chaque fournisseur doit avoir un nom et une fonction")
        if len(set(names)) != len(names):
            raise ValueError("Les noms de fournisseurs doivent être uniques")
        if not isinstance(failure_threshold, int) or failure_threshold < 1:
            raise ValueError("failure_threshold doit être un entier positif")
        if not math.isfinite(float(cooldown_seconds)) or cooldown_seconds <= 0:
            raise ValueError("cooldown_seconds doit être positif")
        self._failure_threshold = failure_threshold
        self._cooldown_seconds = float(cooldown_seconds)
        self._monotonic = monotonic_clock
        self._utc_clock = utc_clock
        self._circuit_open_until = {}
        self._half_open_inflight = set()
        self._health_lock = threading.RLock()
        self._health = {str(name): {
            "attempts": 0, "successes": 0, "failures": 0,
            "consecutive_failures": 0, "last_attempt_at": None,
            "last_success_at": None, "last_error_type": None,
            "last_latency_ms": None, "circuit_state": "closed",
            "circuit_skips": 0,
        } for name, _ in self.providers}
        self._last_selected_source = None
        self._last_selection_at = None

    def health_snapshot(self):
        """Return an immutable-by-copy, credential-free provider health view."""
        with self._health_lock:
            return {
                "providers": {name: dict(values) for name, values in self._health.items()},
                "last_selected_source": self._last_selected_source,
                "last_selection_at": self._last_selection_at,
            }

    def __call__(self, symbol, limit):
        failures = []
        for name, reader in self.providers:
            name = str(name)
            started = self._monotonic()
            with self._health_lock:
                open_until = self._circuit_open_until.get(name, 0.0)
                if started < open_until:
                    self._health[name]["circuit_skips"] += 1
                    failures.append(f"{name}: CircuitOpen")
                    continue
                if open_until:
                    # Permit only one concurrent recovery probe after cooldown.
                    if name in self._half_open_inflight:
                        self._health[name]["circuit_skips"] += 1
                        failures.append(f"{name}: CircuitOpen")
                        continue
                    self._half_open_inflight.add(name)
                    self._health[name]["circuit_state"] = "half_open"
                attempted_at = self._utc_clock()
                stats = self._health[name]
                stats["attempts"] += 1
                stats["last_attempt_at"] = attempted_at
            try:
                payload = reader(symbol, limit)
                if not isinstance(payload, (list, tuple)) or len(payload) not in (2, 3):
                    raise ValueError("format de réponse invalide")
                if len(payload) == 2:
                    timestamps = None
                    closes, volumes = payload
                else:
                    timestamps, closes, volumes = payload
                if not isinstance(closes, (list, tuple)) or not isinstance(volumes, (list, tuple)) or len(closes) < 2 or len(closes) != len(volumes):
                    raise ValueError("historique vide ou désaligné")
                numeric_closes = [float(value) for value in closes]
                numeric_volumes = [float(value) for value in volumes]
                if any(not math.isfinite(value) or value <= 0 for value in numeric_closes):
                    raise ValueError("cours non valides")
                if any(not math.isfinite(value) or value < 0 for value in numeric_volumes):
                    raise ValueError("volumes non valides")
                if timestamps is not None:
                    if not isinstance(timestamps, (list, tuple)) or len(timestamps) != len(closes):
                        raise ValueError("horodatages désalignés")
                    parsed = [stamp if isinstance(stamp, datetime) else datetime.fromisoformat(str(stamp).replace("Z", "+00:00")) for stamp in timestamps]
                    if any(stamp.tzinfo is None or stamp.utcoffset() is None for stamp in parsed):
                        raise ValueError("horodatage sans fuseau")
                    if any(left >= right for left, right in zip(parsed, parsed[1:])):
                        raise ValueError("horodatages désordonnés")
                elapsed_ms = max(0.0, (self._monotonic() - started) * 1000.0)
                with self._health_lock:
                    stats = self._health[name]
                    stats["successes"] += 1
                    stats["consecutive_failures"] = 0
                    stats["last_success_at"] = self._utc_clock()
                    stats["last_error_type"] = None
                    stats["last_latency_ms"] = round(elapsed_ms, 3)
                    stats["circuit_state"] = "closed"
                    self._circuit_open_until.pop(name, None)
                    self._half_open_inflight.discard(name)
                    self._last_selected_source = name
                    self._last_selection_at = stats["last_success_at"]
                adjustment_mode = getattr(reader, "adjustment_mode", "unknown")
                if not isinstance(adjustment_mode, str) or adjustment_mode not in {"unknown", "raw", "split", "dividend", "all"}:
                    raise ValueError("provenance d'ajustement fournisseur invalide")
                return (timestamps, closes, volumes, adjustment_mode, name)
            except Exception as exc:
                elapsed_ms = max(0.0, (self._monotonic() - started) * 1000.0)
                with self._health_lock:
                    stats = self._health[name]
                    stats["failures"] += 1
                    stats["consecutive_failures"] += 1
                    stats["last_error_type"] = type(exc).__name__
                    stats["last_latency_ms"] = round(elapsed_ms, 3)
                    self._half_open_inflight.discard(name)
                    if stats["consecutive_failures"] >= self._failure_threshold:
                        stats["circuit_state"] = "open"
                        self._circuit_open_until[name] = self._monotonic() + self._cooldown_seconds
                    else:
                        stats["circuit_state"] = "closed"
                # Keep exception messages out of diagnostics/log summaries: they
                # can contain URLs, query parameters or provider response details.
                failures.append(f"{name}: {type(exc).__name__}")
        raise MarketDataError("Tous les fournisseurs sont indisponibles (" + "; ".join(failures) + ")")


@dataclass(frozen=True)
class DailyBars:
    symbol: str
    closes: tuple[float, ...]
    volumes: tuple[float, ...]
    fetched_at: datetime
    source: str = "broker"
    # Exchange/provider bar times, distinct from fetched_at. Empty only for
    # legacy or simulated readers that cannot supply timestamps.
    timestamps: tuple[datetime, ...] = ()
    # Provider-declared corporate-action treatment; legacy payloads remain unknown.
    adjustment_mode: str = "unknown"

    @property
    def count(self) -> int:
        return len(self.closes)


@dataclass(frozen=True)
class OHLCVDailyBars:
    """Full OHLCV history kept separate from the legacy close/volume contract."""
    symbol: str
    opens: tuple[float, ...]
    highs: tuple[float, ...]
    lows: tuple[float, ...]
    closes: tuple[float, ...]
    volumes: tuple[float, ...]
    fetched_at: datetime
    source: str = "broker"
    timestamps: tuple[datetime, ...] = ()
    adjustment_mode: str = "unknown"

    @property
    def count(self) -> int:
        return len(self.closes)


@dataclass(frozen=True)
class MarketDataComparison:
    """Read-only comparison of two provider histories; never changes prices."""
    primary_source: str
    secondary_source: str
    matched_bars: int
    primary_only_bars: int
    secondary_only_bars: int
    max_close_deviation_pct: float | None
    mean_close_deviation_pct: float | None
    within_tolerance: bool
    max_volume_deviation_pct: float | None = None
    mean_volume_deviation_pct: float | None = None
    within_volume_tolerance: bool = True
    overlap_pct: float = 0.0
    close_tolerance_pct: float = 0.5
    volume_tolerance_pct: float = 10.0
    primary_adjustment_mode: str = "unknown"
    secondary_adjustment_mode: str = "unknown"
    adjustment_verified: bool = False


def require_consistent_daily_bars(
    comparison: MarketDataComparison, *,
    min_overlap_pct: float = 95.0,
    require_volume: bool = True,
) -> MarketDataComparison:
    """Fail closed unless two provider histories meet explicit quality gates.

    This is an opt-in validation helper. It does not select, average, or alter
    prices and is deliberately not wired into the trading path until a second
    independently configured provider has been verified.
    """
    try:
        overlap = float(min_overlap_pct)
    except (TypeError, ValueError, OverflowError) as exc:
        raise MarketDataError("Le recouvrement minimal doit être compris entre 0 et 100") from exc
    if not math.isfinite(overlap) or not 0 <= overlap <= 100:
        raise MarketDataError("Le recouvrement minimal doit être compris entre 0 et 100")
    if not isinstance(require_volume, bool):
        raise MarketDataError("require_volume doit être booléen")
    if not isinstance(comparison, MarketDataComparison):
        raise MarketDataError("Comparaison inter-fournisseurs invalide")

    # This guard is public and its dataclass can be constructed by callers.
    # Validate the report itself rather than trusting booleans/NaN values that
    # could otherwise bypass a fail-closed quality gate.
    if (not isinstance(comparison.primary_source, str) or not comparison.primary_source.strip()
            or not isinstance(comparison.secondary_source, str) or not comparison.secondary_source.strip()
            or comparison.primary_source == comparison.secondary_source):
        raise MarketDataError("Sources de comparaison invalides")
    counts = (comparison.matched_bars, comparison.primary_only_bars,
              comparison.secondary_only_bars)
    if any(not isinstance(value, int) or isinstance(value, bool) or value < 0 for value in counts):
        raise MarketDataError("Comptages de comparaison invalides")
    if comparison.matched_bars < 2:
        raise MarketDataError("Comparaison insuffisante : au moins deux bougies communes sont requises")
    primary_count = comparison.matched_bars + comparison.primary_only_bars
    secondary_count = comparison.matched_bars + comparison.secondary_only_bars
    expected_overlap = comparison.matched_bars / max(primary_count, secondary_count) * 100.0
    try:
        overlap_pct = float(comparison.overlap_pct)
    except (TypeError, ValueError, OverflowError) as exc:
        raise MarketDataError("Taux de recouvrement invalide") from exc
    if (not math.isfinite(overlap_pct) or not 0 <= overlap_pct <= 100
            or not math.isclose(overlap_pct, expected_overlap, rel_tol=1e-9, abs_tol=1e-9)):
        raise MarketDataError("Taux de recouvrement invalide ou incohérent avec les comptages")
    if not isinstance(comparison.within_tolerance, bool) or not isinstance(comparison.within_volume_tolerance, bool):
        raise MarketDataError("Verdicts de comparaison invalides")
    try:
        close_tolerance = float(comparison.close_tolerance_pct)
        volume_tolerance = float(comparison.volume_tolerance_pct)
    except (TypeError, ValueError, OverflowError) as exc:
        raise MarketDataError("Seuils de tolérance invalides") from exc
    if (not math.isfinite(close_tolerance) or close_tolerance < 0
            or not math.isfinite(volume_tolerance) or volume_tolerance < 0):
        raise MarketDataError("Seuils de tolérance invalides")

    def validate_deviation(value, label, *, optional=False, maximum=None):
        if value is None and optional:
            return None
        try:
            numeric = float(value)
        except (TypeError, ValueError, OverflowError) as exc:
            raise MarketDataError(f"Mesure d'écart {label} invalide") from exc
        if (not math.isfinite(numeric) or numeric < 0
                or (maximum is not None and numeric > maximum)):
            raise MarketDataError(f"Mesure d'écart {label} invalide")
        return numeric

    # Close deviation is expressed relative to the primary close and can
    # legitimately exceed 100%; volume deviation uses max(A, B) as denominator.
    max_close = validate_deviation(comparison.max_close_deviation_pct, "clôture")
    mean_close = validate_deviation(comparison.mean_close_deviation_pct, "moyen clôture")
    if mean_close > max_close:
        raise MarketDataError("Mesures d'écart de clôture incohérentes")
    max_volume = validate_deviation(comparison.max_volume_deviation_pct, "volume", optional=True, maximum=100)
    mean_volume = validate_deviation(comparison.mean_volume_deviation_pct, "moyen volume", optional=True, maximum=100)
    if require_volume and (comparison.max_volume_deviation_pct is None
                           or comparison.mean_volume_deviation_pct is None):
        raise MarketDataError("Mesures de volume absentes")
    if max_volume is not None and mean_volume is not None and mean_volume > max_volume:
        raise MarketDataError("Mesures d'écart de volume incohérentes")

    if comparison.within_tolerance != (max_close <= close_tolerance):
        raise MarketDataError("Verdict de clôture incohérent avec la mesure et le seuil")
    if max_volume is not None and comparison.within_volume_tolerance != (max_volume <= volume_tolerance):
        raise MarketDataError("Verdict de volume incohérent avec la mesure et le seuil")
    if overlap_pct < overlap:
        raise MarketDataError("Recouvrement inter-fournisseurs insuffisant")
    if not comparison.within_tolerance:
        raise MarketDataError("Écart de clôture supérieur à la tolérance")
    if require_volume and not comparison.within_volume_tolerance:
        raise MarketDataError("Écart de volume supérieur à la tolérance")
    allowed_adjustments = {"unknown", "raw", "split", "dividend", "all"}
    modes = (comparison.primary_adjustment_mode, comparison.secondary_adjustment_mode)
    if any(not isinstance(mode, str) or mode not in allowed_adjustments for mode in modes):
        raise MarketDataError("Provenance d'ajustement invalide")
    expected_adjustment_verification = modes[0] != "unknown" and modes[0] == modes[1]
    if not isinstance(comparison.adjustment_verified, bool) or comparison.adjustment_verified != expected_adjustment_verification:
        raise MarketDataError("Verdict de provenance d'ajustement incohérent")
    if not comparison.adjustment_verified:
        raise MarketDataError("Comparaison refusée : mode d'ajustement inconnu ou différent")
    return comparison


def compare_daily_bars(primary: DailyBars, secondary: DailyBars, *,
                       tolerance_pct: float = 0.5,
                       volume_tolerance_pct: float = 10.0) -> MarketDataComparison:
    """Compare close prices on identical UTC bar timestamps.

    Timestamp-less simulation/legacy series are intentionally rejected: matching
    array positions is not sufficient evidence that two providers cover the same bars.
    """
    try:
        tolerance = float(tolerance_pct)
    except (TypeError, ValueError, OverflowError) as exc:
        raise MarketDataError("La tolérance doit être un pourcentage positif ou nul") from exc
    if not math.isfinite(tolerance) or tolerance < 0:
        raise MarketDataError("La tolérance doit être un pourcentage positif ou nul")
    try:
        volume_tolerance = float(volume_tolerance_pct)
    except (TypeError, ValueError, OverflowError) as exc:
        raise MarketDataError("La tolérance de volume doit être un pourcentage positif ou nul") from exc
    if not math.isfinite(volume_tolerance) or volume_tolerance < 0:
        raise MarketDataError("La tolérance de volume doit être un pourcentage positif ou nul")
    allowed_adjustments = {"unknown", "raw", "split", "dividend", "all"}
    modes = (getattr(primary, "adjustment_mode", "unknown"), getattr(secondary, "adjustment_mode", "unknown"))
    if any(not isinstance(mode, str) or mode not in allowed_adjustments for mode in modes):
        raise MarketDataError("Provenance d'ajustement invalide")
    if primary.symbol != secondary.symbol:
        raise MarketDataError("Comparaison impossible entre deux symboles différents")
    if primary.source == secondary.source:
        raise MarketDataError("La comparaison exige deux fournisseurs distincts")
    if not primary.timestamps or not secondary.timestamps:
        raise MarketDataError("Comparaison impossible sans horodatages des deux fournisseurs")
    if (len(primary.timestamps) != len(primary.closes)
            or len(secondary.timestamps) != len(secondary.closes)
            or len(primary.volumes) != len(primary.closes)
            or len(secondary.volumes) != len(secondary.closes)):
        raise MarketDataError("Historique horodaté ou volumes désalignés")

    def indexed_history(bars):
        indexed = {}
        for stamp, close, volume in zip(bars.timestamps, bars.closes, bars.volumes):
            if not isinstance(stamp, datetime) or stamp.tzinfo is None or stamp.utcoffset() is None:
                raise MarketDataError("Horodatage invalide dans l'historique comparé")
            try:
                price = float(close)
            except (TypeError, ValueError, OverflowError) as exc:
                raise MarketDataError("Cours invalide dans l'historique comparé") from exc
            if not math.isfinite(price) or price <= 0:
                raise MarketDataError("Cours invalide dans l'historique comparé")
            try:
                numeric_volume = float(volume)
            except (TypeError, ValueError, OverflowError) as exc:
                raise MarketDataError("Volume invalide dans l'historique comparé") from exc
            if not math.isfinite(numeric_volume) or numeric_volume < 0:
                raise MarketDataError("Volume invalide dans l'historique comparé")
            key = stamp.astimezone(timezone.utc)
            if key in indexed:
                raise MarketDataError("Horodatage dupliqué dans l'historique comparé")
            indexed[key] = (price, numeric_volume)
        return indexed

    left = indexed_history(primary)
    right = indexed_history(secondary)
    shared = sorted(left.keys() & right.keys())
    if not shared:
        raise MarketDataError("Aucune bougie commune entre les fournisseurs")
    close_deviations = [
        abs(left[t][0] - right[t][0]) / max(abs(left[t][0]), 1e-12) * 100
        for t in shared
    ]
    volume_deviations = [
        (0.0 if max(left[t][1], right[t][1]) == 0 else
         abs(left[t][1] - right[t][1]) / max(left[t][1], right[t][1]) * 100)
        for t in shared
    ]
    maximum = max(close_deviations)
    mean = sum(close_deviations) / len(close_deviations)
    max_volume = max(volume_deviations)
    mean_volume = sum(volume_deviations) / len(volume_deviations)
    overlap = len(shared) / max(len(left), len(right)) * 100
    return MarketDataComparison(
        primary_source=primary.source,
        secondary_source=secondary.source,
        matched_bars=len(shared),
        primary_only_bars=len(left.keys() - right.keys()),
        secondary_only_bars=len(right.keys() - left.keys()),
        max_close_deviation_pct=maximum,
        mean_close_deviation_pct=mean,
        within_tolerance=maximum <= tolerance,
        max_volume_deviation_pct=max_volume,
        mean_volume_deviation_pct=mean_volume,
        within_volume_tolerance=max_volume <= volume_tolerance,
        overlap_pct=overlap,
        close_tolerance_pct=tolerance,
        volume_tolerance_pct=volume_tolerance,
        primary_adjustment_mode=modes[0],
        secondary_adjustment_mode=modes[1],
        adjustment_verified=(modes[0] != "unknown" and modes[0] == modes[1]),
    )


def require_fresh_daily_bars(
    bars: DailyBars, *,
    now: datetime | None = None,
    calendar_name: str = "XNYS",
    publication_delay: timedelta = timedelta(minutes=15),
    require_timestamps: bool = True,
) -> timedelta:
    """Reject daily bars older than the last completed exchange session.

    Session labels are derived in the exchange timezone (New York for XNYS),
    while session opens/closes come from ``exchange_calendars``. This handles
    weekends, exchange holidays, DST and early closes without a fixed
    calendar-day age threshold. The provider timestamp must identify the
    exchange-local session date; fetched_at is never used as a substitute.
    A short publication delay avoids treating the closing auction as stale
    immediately at the scheduled close.
    """
    if not isinstance(publication_delay, timedelta) or publication_delay < timedelta(0):
        raise ValueError("publication_delay doit être une durée positive ou nulle")
    if not bars.timestamps:
        if require_timestamps:
            raise MarketDataError("Données non vérifiables : horodatages de marché absents")
        return timedelta(0)
    if len(bars.timestamps) != len(bars.closes):
        raise MarketDataError("Données non vérifiables : horodatages désalignés")
    current = now or datetime.now(timezone.utc)
    if current.tzinfo is None or current.utcoffset() is None:
        raise ValueError("now doit inclure un fuseau horaire")
    current = current.astimezone(timezone.utc)

    try:
        import exchange_calendars as xcals
        from zoneinfo import ZoneInfo
        calendar = xcals.get_calendar(calendar_name)
        exchange_tz = ZoneInfo(calendar.tz.zone if hasattr(calendar.tz, "zone") else str(calendar.tz))
    except Exception as exc:
        raise MarketDataError(f"Calendrier boursier indisponible ({calendar_name})") from exc

    parsed = []
    for stamp in bars.timestamps:
        if not isinstance(stamp, datetime) or stamp.tzinfo is None or stamp.utcoffset() is None:
            raise MarketDataError("Horodatage de marché sans fuseau horaire")
        utc_stamp = stamp.astimezone(timezone.utc)
        if utc_stamp > current:
            raise MarketDataError("Horodatage de marché situé dans le futur")
        parsed.append(utc_stamp)
    if any(left >= right for left, right in zip(parsed, parsed[1:])):
        raise MarketDataError("Horodatages de marché dupliqués ou désordonnés")

    last_stamp = parsed[-1]
    local_session_date = last_stamp.astimezone(exchange_tz).date()
    current_local_date = current.astimezone(exchange_tz).date()
    try:
        # Daily Alpaca bars carry a timestamp on their exchange-local session
        # date. Reject dates that are not actual sessions (weekends/holidays).
        session = calendar.date_to_session(str(local_session_date), direction="none")
        start = str(current_local_date - timedelta(days=14))
        end = str(current_local_date)
        schedule = calendar.schedule.loc[start:end]
        completed = schedule[schedule["close"] + publication_delay <= current]
        if completed.empty:
            # Before the first completed session in this window, widen safely.
            sessions = calendar.sessions_in_range(
                str(current_local_date - timedelta(days=30)), str(current_local_date)
            )
            schedule = calendar.schedule.loc[sessions[0]:sessions[-1]] if len(sessions) else schedule
            completed = schedule[schedule["close"] + publication_delay <= current]
        if completed.empty:
            raise MarketDataError("Impossible de déterminer la dernière séance boursière clôturée")
        expected_session = completed.index[-1]
    except MarketDataError:
        raise
    except Exception as exc:
        raise MarketDataError("Date de bougie absente du calendrier boursier ou calendrier incomplet") from exc

    if session > expected_session:
        raise MarketDataError("Données de marché en avance sur la dernière séance clôturée")
    if session < expected_session:
        raise MarketDataError(
            f"Données périmées : dernière séance {session.date()} ; "
            f"séance clôturée attendue {expected_session.date()} ({calendar_name})"
        )
    return current - last_stamp


def validated_daily_bar_series(
    service: "MarketDataService", symbol: str, *, limit: int = 250,
    now: datetime | None = None, calendar_name: str = "XNYS",
    require_timestamps: bool = True,
) -> DailyBars:
    """Return the complete validated timestamped daily-bar object.

    Unlike the legacy close-only helper, this preserves exchange timestamps so
    portfolio risk consumers can align every held asset to the same sessions.
    """
    bars = service.daily_bars(symbol, limit)
    require_fresh_daily_bars(
        bars, now=now, calendar_name=calendar_name,
        require_timestamps=require_timestamps,
    )
    return bars


def validated_daily_closes(
    service: "MarketDataService", symbol: str, *, limit: int = 250,
    now: datetime | None = None, calendar_name: str = "XNYS",
    require_timestamps: bool = True,
) -> tuple[float, ...]:
    """Fetch daily closes only after exchange-session freshness validation.

    Shared by signal generation and risk models so no consumer can silently
    bypass the provider boundary, timestamp checks or freshness policy.
    """
    bars = service.daily_bars(symbol, limit)
    require_fresh_daily_bars(
        bars, now=now, calendar_name=calendar_name,
        require_timestamps=require_timestamps,
    )
    return bars.closes


@dataclass(frozen=True)
class DailyBarCoverage:
    """Expected exchange sessions represented by a timestamped daily series."""
    expected_sessions: int
    observed_sessions: int
    missing_sessions: tuple[str, ...]

    @property
    def complete(self) -> bool:
        return not self.missing_sessions


def inspect_ohlcv_daily_bar_coverage(
    bars: OHLCVDailyBars, *, calendar_name: str = "XNYS", max_missing_sessions: int | None = None
) -> DailyBarCoverage:
    """Inspect exchange-session coverage for a full OHLCV daily series.

    This is intentionally diagnostic unless ``max_missing_sessions`` is set.
    It reuses the same exchange-calendar rules as the legacy close/volume
    series and never fills or interpolates missing bars.
    """
    if not isinstance(bars, OHLCVDailyBars):
        raise MarketDataError("Historique OHLCV invalide pour le contrôle de couverture")
    if len(bars.timestamps) != bars.count or not bars.timestamps:
        raise MarketDataError("Couverture OHLCV impossible sans horodatages complets")
    legacy_view = DailyBars(
        symbol=bars.symbol, closes=bars.closes, volumes=bars.volumes,
        fetched_at=bars.fetched_at, source=bars.source, timestamps=bars.timestamps,
    )
    return inspect_daily_bar_coverage(
        legacy_view, calendar_name=calendar_name,
        max_missing_sessions=max_missing_sessions,
    )


def inspect_daily_bar_coverage(
    bars: DailyBars, *, calendar_name: str = "XNYS", max_missing_sessions: int | None = None
) -> DailyBarCoverage:
    """Report missing exchange sessions between the first and last daily bars.

    Weekends and exchange holidays are excluded by the exchange calendar. This
    is diagnostic rather than an unconditional data rejection: callers may
    decide how to handle halts, symbol suspensions or provider-specific gaps.
    A non-None max_missing_sessions applies a fail-closed threshold.
    """
    if max_missing_sessions is not None and (
        not isinstance(max_missing_sessions, int) or max_missing_sessions < 0
    ):
        raise ValueError("max_missing_sessions doit être un entier positif ou nul")
    if not bars.timestamps:
        raise MarketDataError("Contrôle de couverture impossible sans horodatages")
    if len(bars.timestamps) != len(bars.closes):
        raise MarketDataError("Couverture impossible : horodatages désalignés")
    try:
        import exchange_calendars as xcals
        from zoneinfo import ZoneInfo
        calendar = xcals.get_calendar(calendar_name)
        exchange_tz = ZoneInfo(calendar.tz.zone if hasattr(calendar.tz, "zone") else str(calendar.tz))
    except Exception as exc:
        raise MarketDataError(f"Calendrier boursier indisponible ({calendar_name})") from exc

    observed = set()
    previous = None
    for stamp in bars.timestamps:
        if not isinstance(stamp, datetime) or stamp.tzinfo is None or stamp.utcoffset() is None:
            raise MarketDataError("Horodatage de marché sans fuseau horaire")
        utc_stamp = stamp.astimezone(timezone.utc)
        if previous is not None and utc_stamp <= previous:
            raise MarketDataError("Horodatages de marché dupliqués ou désordonnés")
        previous = utc_stamp
        session_date = utc_stamp.astimezone(exchange_tz).date()
        try:
            session = calendar.date_to_session(str(session_date), direction="none")
        except Exception as exc:
            raise MarketDataError(f"Bougie datée d'un jour non ouvré : {session_date}") from exc
        observed.add(session)

    first, last = min(observed), max(observed)
    expected = calendar.sessions_in_range(first, last)
    missing = tuple(str(session.date()) for session in expected if session not in observed)
    report = DailyBarCoverage(len(expected), len(observed), missing)
    if max_missing_sessions is not None and len(missing) > max_missing_sessions:
        raise MarketDataError(
            f"Historique incomplet : {len(missing)} séance(s) manquante(s) "
            f"({', '.join(missing)}) ; maximum autorisé {max_missing_sessions}"
        )
    return report


@dataclass(frozen=True)
class NewsHeadlines:
    symbol: str
    headlines: tuple[str, ...]
    fetched_at: datetime
    source: str = "broker"


class MarketDataService:
    """Validates provider responses and caches them for a bounded TTL."""

    def __init__(self, bars_reader: Callable[[str, int], tuple[Sequence, Sequence]],
                 news_reader: Callable[[str, int], Sequence[str]] | None = None,
                 *, ohlcv_reader: Callable[[str, int], tuple] | None = None,
                 ttl_seconds: float = 60.0, max_entries: int = 256,
                 clock: Callable[[], float] = time.monotonic):
        if ttl_seconds <= 0 or max_entries < 1:
            raise ValueError("ttl_seconds doit être positif et max_entries >= 1")
        self._bars_reader = bars_reader
        self._ohlcv_reader = ohlcv_reader
        self._news_reader = news_reader
        self._ttl = float(ttl_seconds)
        self._max_entries = int(max_entries)
        self._clock = clock
        self._lock = threading.RLock()
        self._bars_cache: OrderedDict[tuple[str, int], tuple[float, DailyBars]] = OrderedDict()
        self._ohlcv_cache: OrderedDict[tuple[str, int], tuple[float, OHLCVDailyBars]] = OrderedDict()
        self._news_cache: OrderedDict[tuple[str, int], tuple[float, NewsHeadlines]] = OrderedDict()

    @staticmethod
    def normalize_symbol(symbol: str) -> str:
        value = str(symbol or "").strip().upper()
        if not _SYMBOL.fullmatch(value):
            raise MarketDataError("Symbole boursier invalide")
        return value

    def _cached(self, cache, key):
        item = cache.get(key)
        if item is None:
            return None
        expires, value = item
        if self._clock() >= expires:
            del cache[key]
            return None
        cache.move_to_end(key)
        return value

    def _store(self, cache, key, value):
        cache[key] = (self._clock() + self._ttl, value)
        cache.move_to_end(key)
        while len(cache) > self._max_entries:
            cache.popitem(last=False)

    def daily_bars(self, symbol: str, limit: int = 250) -> DailyBars:
        sym = self.normalize_symbol(symbol)
        if not isinstance(limit, int) or limit < 2 or limit > 10000:
            raise MarketDataError("La limite doit être comprise entre 2 et 10000")
        key = (sym, limit)
        with self._lock:
            cached = self._cached(self._bars_cache, key)
            if cached is not None:
                return cached
        try:
            payload = self._bars_reader(sym, limit)
        except MarketDataError as exc:
            raise MarketDataError(f"Données indisponibles pour {sym}: {exc}") from exc
        except Exception as exc:
            raise MarketDataError(f"Données indisponibles pour {sym}: {type(exc).__name__}") from exc
        if not isinstance(payload, (list, tuple)) or len(payload) not in (2, 3, 4, 5):
            raise MarketDataError("Réponse fournisseur mal formée")
        source = "broker"
        adjustment_mode = getattr(self._bars_reader, "adjustment_mode", "unknown")
        if len(payload) == 5:
            raw_timestamps, closes, volumes, adjustment_mode, source = payload
            has_timestamps = raw_timestamps is not None
            if not has_timestamps:
                raw_timestamps = ()
        elif len(payload) == 4:
            raw_timestamps, closes, volumes, source = payload
            has_timestamps = True
        elif len(payload) == 3:
            # Three-field payloads are (timestamps, closes, volumes), except
            # ProviderChain's untimestamped result (closes, volumes, source).
            if isinstance(payload[2], str):
                closes, volumes, source = payload
                raw_timestamps = ()
                has_timestamps = False
            else:
                raw_timestamps, closes, volumes = payload
                has_timestamps = True
        else:
            closes, volumes = payload
            raw_timestamps = ()
            has_timestamps = False
        if not isinstance(closes, (list, tuple)) or not isinstance(volumes, (list, tuple)):
            raise MarketDataError("Réponse fournisseur mal formée")
        if len(closes) != len(volumes) or len(closes) < 2:
            raise MarketDataError("Historique insuffisant ou séries désalignées")
        if has_timestamps and (not isinstance(raw_timestamps, (list, tuple)) or len(raw_timestamps) != len(closes)):
            raise MarketDataError("Horodatages absents ou désalignés")
        if len(closes) > limit:
            closes, volumes = closes[-limit:], volumes[-limit:]
            if has_timestamps:
                raw_timestamps = raw_timestamps[-limit:]
        try:
            c = tuple(float(x) for x in closes)
            v = tuple(float(x) for x in volumes)
        except (TypeError, ValueError, OverflowError) as exc:
            raise MarketDataError("Valeur de marché non numérique") from exc
        if any(not math.isfinite(x) or x <= 0 for x in c):
            raise MarketDataError("Cours nul, négatif ou non fini")
        if any(not math.isfinite(x) or x < 0 for x in v):
            raise MarketDataError("Volume négatif ou non fini")
        timestamps = ()
        if has_timestamps:
            try:
                parsed = tuple(
                    x if isinstance(x, datetime) else datetime.fromisoformat(str(x).replace("Z", "+00:00"))
                    for x in raw_timestamps
                )
            except (TypeError, ValueError) as exc:
                raise MarketDataError("Horodatage de marché invalide") from exc
            if any(x.tzinfo is None or x.utcoffset() is None for x in parsed):
                raise MarketDataError("Horodatage de marché sans fuseau horaire")
            if any(a >= b for a, b in zip(parsed, parsed[1:])):
                raise MarketDataError("Horodatages de marché non strictement croissants")
            timestamps = tuple(x.astimezone(timezone.utc) for x in parsed)
        if not isinstance(adjustment_mode, str) or adjustment_mode not in {"unknown", "raw", "split", "dividend", "all"}:
            raise MarketDataError("Provenance d'ajustement fournisseur invalide")
        result = DailyBars(sym, c, v, datetime.now(timezone.utc), source=str(source),
                           timestamps=timestamps, adjustment_mode=adjustment_mode)
        with self._lock:
            self._store(self._bars_cache, key, result)
        return result

    def daily_ohlcv(self, symbol: str, limit: int = 250) -> OHLCVDailyBars:
        """Return validated full candles from an explicitly configured OHLCV reader.

        Accepted reader payloads are (opens, highs, lows, closes, volumes),
        (timestamps, opens, highs, lows, closes, volumes), or either form with
        a final source-name string. The legacy daily_bars API is unchanged.
        """
        sym = self.normalize_symbol(symbol)
        if not isinstance(limit, int) or isinstance(limit, bool) or not 2 <= limit <= 10000:
            raise MarketDataError("La limite OHLCV doit être comprise entre 2 et 10000")
        if self._ohlcv_reader is None:
            raise MarketDataError("Fournisseur OHLCV complet non configuré")
        key = (sym, limit)
        with self._lock:
            cached = self._cached(self._ohlcv_cache, key)
            if cached is not None:
                return cached
        try:
            payload = self._ohlcv_reader(sym, limit)
        except Exception as exc:
            raise MarketDataError(f"Données OHLCV indisponibles pour {sym}: {type(exc).__name__}") from exc
        if not isinstance(payload, (list, tuple)):
            raise MarketDataError("Réponse OHLCV fournisseur mal formée")
        fields = list(payload)
        source = str(getattr(self._ohlcv_reader, "source_name", "broker"))
        adjustment_mode = getattr(self._ohlcv_reader, "adjustment_mode", "unknown")
        if fields and isinstance(fields[-1], str):
            source = fields.pop()
        if len(fields) == 5:
            raw_timestamps = ()
            has_timestamps = False
            raw_opens, raw_highs, raw_lows, raw_closes, raw_volumes = fields
        elif len(fields) == 6:
            raw_timestamps, raw_opens, raw_highs, raw_lows, raw_closes, raw_volumes = fields
            has_timestamps = True
        else:
            raise MarketDataError("Format OHLCV attendu: O/H/L/C/V avec horodatages facultatifs")
        series = (raw_opens, raw_highs, raw_lows, raw_closes, raw_volumes)
        if any(not isinstance(values, (list, tuple)) for values in series):
            raise MarketDataError("Séries OHLCV mal formées")
        count = len(raw_closes)
        if count < 2 or any(len(values) != count for values in series):
            raise MarketDataError("Historique OHLCV insuffisant ou séries désalignées")
        if has_timestamps and (not isinstance(raw_timestamps, (list, tuple)) or len(raw_timestamps) != count):
            raise MarketDataError("Horodatages OHLCV absents ou désalignés")
        if count > limit:
            series = tuple(values[-limit:] for values in series)
            if has_timestamps:
                raw_timestamps = raw_timestamps[-limit:]
        try:
            opens, highs, lows, closes, volumes = (tuple(float(x) for x in values) for values in series)
        except (TypeError, ValueError, OverflowError) as exc:
            raise MarketDataError("Valeur OHLCV non numérique") from exc
        for index, (o, h, low, c, v) in enumerate(zip(opens, highs, lows, closes, volumes)):
            if any(not math.isfinite(x) for x in (o, h, low, c, v)):
                raise MarketDataError("Valeur OHLCV non finie")
            if min(o, h, low, c) <= 0 or v < 0:
                raise MarketDataError("Prix OHLCV non positifs ou volume négatif")
            if h < max(o, low, c) or low > min(o, h, c):
                raise MarketDataError(f"Géométrie OHLC incohérente à l'index {index}")
        timestamps = ()
        if has_timestamps:
            try:
                parsed = tuple(x if isinstance(x, datetime) else datetime.fromisoformat(str(x).replace("Z", "+00:00")) for x in raw_timestamps)
            except (TypeError, ValueError) as exc:
                raise MarketDataError("Horodatage OHLCV invalide") from exc
            if any(x.tzinfo is None or x.utcoffset() is None for x in parsed):
                raise MarketDataError("Horodatage OHLCV sans fuseau horaire")
            if any(a >= b for a, b in zip(parsed, parsed[1:])):
                raise MarketDataError("Horodatages OHLCV non strictement croissants")
            timestamps = tuple(x.astimezone(timezone.utc) for x in parsed)
        if not isinstance(adjustment_mode, str) or adjustment_mode not in {"unknown", "raw", "split", "dividend", "all"}:
            raise MarketDataError("Provenance d'ajustement fournisseur invalide")
        result = OHLCVDailyBars(sym, opens, highs, lows, closes, volumes,
                                datetime.now(timezone.utc), source=str(source), timestamps=timestamps,
                                adjustment_mode=adjustment_mode)
        with self._lock:
            self._store(self._ohlcv_cache, key, result)
        return result

    def news(self, symbol: str, limit: int = 15) -> NewsHeadlines:
        sym = self.normalize_symbol(symbol)
        if not isinstance(limit, int) or limit < 1 or limit > 100:
            raise MarketDataError("La limite des actualités doit être comprise entre 1 et 100")
        if self._news_reader is None:
            raise MarketDataError("Fournisseur d'actualités non configuré")
        key = (sym, limit)
        with self._lock:
            cached = self._cached(self._news_cache, key)
            if cached is not None:
                return cached
        try:
            raw = self._news_reader(sym, limit)
        except Exception as exc:
            raise MarketDataError(f"Actualités indisponibles pour {sym}: {type(exc).__name__}") from exc
        if not isinstance(raw, (list, tuple)):
            raise MarketDataError("Réponse actualités mal formée")
        headlines = tuple(str(x).strip() for x in raw[:limit] if str(x).strip())
        result = NewsHeadlines(sym, headlines, datetime.now(timezone.utc))
        with self._lock:
            self._store(self._news_cache, key, result)
        return result

    def invalidate(self, symbol: str | None = None) -> None:
        with self._lock:
            if symbol is None:
                self._bars_cache.clear(); self._ohlcv_cache.clear(); self._news_cache.clear(); return
            sym = self.normalize_symbol(symbol)
            for cache in (self._bars_cache, self._ohlcv_cache, self._news_cache):
                for key in list(cache):
                    if key[0] == sym:
                        del cache[key]
