"""Conservative broker order lifecycle transition policy.

The broker is authoritative for observed state, but stale or out-of-order
snapshots must not silently move a locally terminal order backwards.
"""
from __future__ import annotations

from dataclasses import dataclass

KNOWN_STATUSES = frozenset({
    "submitting", "submission_unknown", "submission_failed", "accepted",
    "accepted_for_bidding", "new", "pending_new", "partially_filled",
    "pending_cancel", "pending_replace", "held", "filled", "canceled",
    "cancelled", "expired", "rejected", "done_for_day", "replaced",
    "stopped", "suspended", "calculated",
})

TERMINAL_STATUSES = frozenset({
    "filled", "canceled", "cancelled", "expired", "rejected", "replaced",
})

_ACTIVE = frozenset({"accepted", "accepted_for_bidding", "new", "pending_new", "held"})
_TERMINAL = TERMINAL_STATUSES | {"done_for_day"}

# Explicit allow-list: unknown transitions are held for operator review.
_TRANSITIONS: dict[str, frozenset[str]] = {
    "submitting": frozenset({"submission_unknown", "submission_failed", *_ACTIVE,
        "partially_filled", "pending_cancel", "pending_replace", *_TERMINAL,
        "stopped", "suspended", "calculated"}),
    "submission_unknown": frozenset({"submission_failed", *_ACTIVE, "partially_filled",
        "pending_cancel", "pending_replace", *_TERMINAL, "stopped", "suspended", "calculated"}),
    "submission_failed": frozenset({*_ACTIVE, "partially_filled", "pending_cancel",
        "pending_replace", *_TERMINAL, "stopped", "suspended", "calculated"}),
    "accepted": frozenset({*_ACTIVE, "partially_filled", "pending_cancel", "pending_replace", *_TERMINAL, "stopped", "suspended", "calculated"}),
    "accepted_for_bidding": frozenset({*_ACTIVE, "partially_filled", "pending_cancel", "pending_replace", *_TERMINAL, "stopped", "suspended", "calculated"}),
    "new": frozenset({*_ACTIVE, "partially_filled", "pending_cancel", "pending_replace", *_TERMINAL, "stopped", "suspended", "calculated"}),
    "pending_new": frozenset({*_ACTIVE, "partially_filled", "pending_cancel", "pending_replace", *_TERMINAL, "stopped", "suspended", "calculated"}),
    "held": frozenset({*_ACTIVE, "partially_filled", "pending_cancel", "pending_replace", *_TERMINAL, "stopped", "suspended", "calculated"}),
    "partially_filled": frozenset({"partially_filled", "pending_cancel", "pending_replace", "filled", "canceled", "cancelled", "expired", "replaced", "done_for_day", "stopped", "suspended", "calculated"}),
    "pending_cancel": frozenset({"pending_cancel", *_ACTIVE, "partially_filled", "filled", "canceled", "cancelled", "expired", "replaced", "done_for_day", "stopped", "suspended", "calculated"}),
    "pending_replace": frozenset({"pending_replace", *_ACTIVE, "partially_filled", "pending_cancel", "filled", "canceled", "cancelled", "expired", "replaced", "done_for_day", "stopped", "suspended", "calculated"}),
    "done_for_day": frozenset({"done_for_day", "new", "accepted", "pending_new", "partially_filled", "filled", "canceled", "cancelled", "expired", "replaced"}),
    "filled": frozenset({"filled"}),
    "canceled": frozenset({"canceled", "cancelled", "filled"}),
    "cancelled": frozenset({"cancelled", "canceled", "filled"}),
    "expired": frozenset({"expired", "filled"}),
    "rejected": frozenset({"rejected"}),
    "replaced": frozenset({"replaced", "filled"}),
    "stopped": frozenset({"stopped", "partially_filled", "filled", "canceled", "cancelled", "expired"}),
    "suspended": frozenset({"suspended", *_ACTIVE, "partially_filled", "pending_cancel", "filled", "canceled", "cancelled", "expired", "rejected"}),
    "calculated": frozenset({"calculated", "filled", "canceled", "cancelled", "expired"}),
}


@dataclass(frozen=True)
class TransitionDecision:
    allowed: bool
    reason: str


def evaluate_transition(current: str, incoming: str) -> TransitionDecision:
    """Return whether an observed broker status may replace the local status."""
    current = str(current or "").strip().lower()
    incoming = str(incoming or "").strip().lower()
    if current not in KNOWN_STATUSES or incoming not in KNOWN_STATUSES:
        return TransitionDecision(False, "unknown_status")
    if current == incoming:
        return TransitionDecision(True, "unchanged")
    if incoming in _TRANSITIONS.get(current, frozenset()):
        return TransitionDecision(True, "allowed_transition")
    return TransitionDecision(False, "stale_or_invalid_transition")
