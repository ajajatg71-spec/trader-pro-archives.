"""Backend-only, provenance-bearing execution for pre-registered research families.

This module deliberately has no HTTP route and no broker/strategy dependency.
A caller must supply an evaluator callable from trusted backend code; browser payloads
are never accepted as results. It records hashes, not raw market data.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import math
import json
import uuid
from typing import Callable, Mapping, Any

from db.hypothesis_registry import HypothesisRegistry, HypothesisRegistryError


def _canonical_hash(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"),
                         ensure_ascii=False, allow_nan=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


class ResearchExecutionError(ValueError):
    pass


class ResearchExecutionService:
    """Run an evaluator server-side and persist immutable provenance with its results."""

    def __init__(self, registry: HypothesisRegistry):
        self.registry = registry

    def execute(self, *, family_id: str, market_data_snapshot: Any,
                code_version: str,
                evaluator: Callable[[Mapping[str, Any], Any], Mapping[str, float]]) -> dict:
        if not callable(evaluator):
            raise ResearchExecutionError("Evaluateur backend requis")
        if not isinstance(code_version, str) or not code_version.strip():
            raise ResearchExecutionError("Version de code obligatoire")
        families = [x for x in self.registry.list_families(limit=200)
                    if x["family_id"] == family_id]
        if not families:
            raise ResearchExecutionError("Famille pré-enregistrée inconnue")
        family = families[0]
        if family["status"] != "PRE_REGISTERED":
            raise ResearchExecutionError("Famille déjà verrouillée")
        started = datetime.now(timezone.utc)
        run_id = uuid.uuid4().hex
        try:
            snapshot_hash = _canonical_hash(market_data_snapshot)
            protocol_hash = _canonical_hash(family["manifest"])
        except (TypeError, ValueError) as exc:
            raise ResearchExecutionError("Snapshot ou protocole non canonique") from exc
        code_hash = hashlib.sha256(code_version.encode("utf-8")).hexdigest()
        # Evaluator is called in backend process with frozen manifest reference and data.
        raw = evaluator(family["manifest"], market_data_snapshot)
        if not isinstance(raw, Mapping):
            raise ResearchExecutionError("Le moteur doit retourner une table de p-values")
        try:
            p_values = {str(k): float(v) for k, v in raw.items()}
        except (TypeError, ValueError, OverflowError) as exc:
            raise ResearchExecutionError("Table de résultats non numérique") from exc
        if not p_values:
            raise ResearchExecutionError("Aucun résultat de recherche")
        if any(not math.isfinite(value) or not 0.0 <= value <= 1.0
               for value in p_values.values()):
            raise ResearchExecutionError("P-values hors domaine [0,1]")
        completed = datetime.now(timezone.utc)
        provenance = {
            "run_id": run_id,
            "started_at": started.isoformat(),
            "completed_at": completed.isoformat(),
            "protocol_hash": protocol_hash,
            "market_data_snapshot_hash": snapshot_hash,
            "code_version": code_version.strip(),
            "code_hash": code_hash,
            "results_hash": _canonical_hash(p_values),
            "execution_origin": "BACKEND_RESEARCH_EXECUTOR",
        }
        return self.registry._record_execution_results(family_id, p_values, provenance)
