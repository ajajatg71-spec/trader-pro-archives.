"""Conservative broker ↔ database reconciliation for Paper trading.

Never retries submissions. Missing broker records remain unresolved; they are not
silently marked rejected. Fills are ingested idempotently by broker activity ID.
"""
from __future__ import annotations
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
import uuid
from typing import Any

from sqlalchemy import select
from db.models import OrderRecord
from db.order_repository import OrderRepository, OrderRepositoryError
from services.order_lifecycle import evaluate_transition
from services.execution_health import build_execution_health

OPEN_OR_UNCERTAIN = {
    "submitting", "submission_unknown", "submission_failed", "accepted", "new",
    "pending_new", "partially_filled", "pending_cancel", "pending_replace", "held",
}


class ReconciliationError(RuntimeError):
    pass


class ReconciliationService:
    def __init__(self, repository: OrderRepository, broker_adapter: Any, strategy_persistence: Any | None = None):
        self.repository = repository
        self.broker = broker_adapter
        self.strategy_persistence = strategy_persistence

    def run(self, *, order_limit: int = 10000, fill_pages: int = 10,
            opening_cash: Decimal | str | float | None = None,
            cash_tolerance: Decimal | str | float = Decimal("0.05"),
            quantity_tolerance: Decimal | str | float = Decimal("0.00001")) -> dict[str, Any]:
        if not 1 <= order_limit <= 10000 or not 1 <= fill_pages <= 100:
            raise ReconciliationError("Limites de réconciliation invalides")
        # Fetch both remote snapshots before mutating local state. If either call
        # fails, report failure and leave the local ledger untouched.
        try:
            remote_orders = self.broker.orders(status="all", limit=order_limit)
            remote_fills = self.broker.fills(pages=fill_pages)
            remote_account = self.broker.account()
            remote_positions = self.broker.positions()
        except Exception as exc:
            raise ReconciliationError(f"Lecture du courtier impossible ({type(exc).__name__})") from exc
        if (not isinstance(remote_orders, list) or not isinstance(remote_fills, list)
                or not isinstance(remote_account, dict) or not isinstance(remote_positions, list)):
            raise ReconciliationError("Réponse du courtier invalide")
        # A malformed element makes the snapshot incomplete. Do not silently skip
        # it: doing so could allow a false complete-reconciliation proof or hide a
        # fill/order from the local ledger. Reject before any recovery or DB write.
        if any(not isinstance(item, dict) for item in remote_orders):
            raise ReconciliationError("Snapshot des ordres contient un enregistrement mal formé")
        if any(not isinstance(item, dict) for item in remote_fills):
            raise ReconciliationError("Historique des exécutions contient un enregistrement mal formé")
        if any(not isinstance(item, dict) for item in remote_positions):
            raise ReconciliationError("Snapshot des positions contient un enregistrement mal formé")

        # Validate the complete fill snapshot before the first local mutation. The
        # broker adapter already enforces this contract, but reconciliation must
        # also defend against alternate adapters, stale fixtures, and malformed
        # provider payloads. Invalid fills must never be downgraded to warnings
        # after account/position snapshots have been committed.
        seen_fill_ids: set[str] = set()
        for item in remote_fills:
            fill_id = str(item.get("id") or item.get("activity_id") or "").strip()
            order_id = str(item.get("order_id") or item.get("orderId") or "").strip()
            symbol = str(item.get("symbol") or "").strip().upper()
            if not fill_id or not order_id or not symbol:
                raise ReconciliationError("Historique des exécutions incomplet : identifiant, ordre ou symbole absent")
            if fill_id in seen_fill_ids:
                raise ReconciliationError("Identifiant d'exécution dupliqué dans le snapshot")
            seen_fill_ids.add(fill_id)
            side = str(item.get("side") or "").strip().lower()
            if side not in {"buy", "sell"}:
                raise ReconciliationError("Historique des exécutions incomplet ou contenant un sens invalide")
            try:
                quantity = Decimal(str(item.get("qty", item.get("quantity"))))
                price = Decimal(str(item.get("price")))
                fee = Decimal(str(item.get("fee") or "0"))
                stamp = item.get("time") or item.get("transaction_time") or item.get("executed_at")
                if (not quantity.is_finite() or quantity <= 0 or not price.is_finite()
                        or price <= 0 or not fee.is_finite() or fee < 0):
                    raise ValueError("données d'exécution hors limites")
                # Execution chronology is part of the immutable fill record. A
                # missing timestamp must invalidate the whole remote snapshot,
                # not be downgraded to a per-fill warning after snapshots commit.
                if not stamp:
                    raise ValueError("horodatage d'exécution absent")
                parsed_stamp = datetime.fromisoformat(str(stamp).replace("Z", "+00:00"))
                if parsed_stamp.tzinfo is None:
                    parsed_stamp = parsed_stamp.replace(tzinfo=timezone.utc)
            except (InvalidOperation, TypeError, ValueError, OverflowError) as exc:
                raise ReconciliationError("Historique des exécutions contient des données invalides") from exc

        # Validate account numerics before stale-submission recovery or any other
        # local mutation. The repository repeats these checks at its write boundary.
        try:
            equity = Decimal(str(remote_account["equity"]))
            cash = Decimal(str(remote_account["cash"]))
            buying_power_raw = remote_account.get("buying_power")
            buying_power = Decimal(str(buying_power_raw)) if buying_power_raw is not None else None
            if (not equity.is_finite() or not cash.is_finite() or equity < 0 or cash < 0
                    or (buying_power is not None and
                        (not buying_power.is_finite() or buying_power < 0))):
                raise ValueError("valeurs de compte hors limites")
        except (KeyError, InvalidOperation, TypeError, ValueError) as exc:
            raise ReconciliationError("Snapshot du compte contient des données numériques invalides") from exc

        # Validate the minimum identity contract for every broker order, including
        # orders unrelated to our local ledger. Otherwise a malformed unrelated
        # order could be hidden while the run is incorrectly considered complete.
        for item in remote_orders:
            required = ("id", "client_order_id", "symbol", "side", "status")
            if any(item.get(key) in (None, "") for key in required):
                raise ReconciliationError("Snapshot des ordres incomplet : champs d'identité/statut absents")
            if str(item["side"]).strip().lower() not in {"buy", "sell"}:
                raise ReconciliationError("Snapshot des ordres contient un sens invalide")
            # Validate quantitative fields on every broker order, not only orders
            # matching a local intent. An unrelated malformed order must not be
            # hidden inside a snapshot later described as complete.
            qty_raw, filled_raw = item.get("qty"), item.get("filled_qty")
            try:
                requested_qty = Decimal(str(qty_raw)) if qty_raw not in (None, "") else None
                filled_qty = Decimal(str(filled_raw)) if filled_raw not in (None, "") else None
                if requested_qty is not None and (not requested_qty.is_finite() or requested_qty <= 0):
                    raise ValueError("quantité demandée invalide")
                if filled_qty is not None and (not filled_qty.is_finite() or filled_qty < 0):
                    raise ValueError("quantité exécutée invalide")
                if requested_qty is not None and filled_qty is not None and filled_qty > requested_qty:
                    raise ValueError("quantité exécutée supérieure à la quantité demandée")
                remote_status = str(item["status"]).strip().lower()
                if requested_qty is not None and filled_qty is not None:
                    if remote_status == "filled" and filled_qty != requested_qty:
                        raise ValueError("statut filled incompatible avec filled_qty")
                    if remote_status == "partially_filled" and not (Decimal("0") < filled_qty < requested_qty):
                        raise ValueError("statut partially_filled incompatible avec filled_qty")
            except (InvalidOperation, TypeError, ValueError, OverflowError) as exc:
                raise ReconciliationError("Snapshot des ordres contient des quantités invalides") from exc

        # Positions are a broker-level snapshot, not optional display data. Require
        # unique symbols and finite, non-zero quantities before persisting anything.
        position_symbols: set[str] = set()
        for item in remote_positions:
            symbol = str(item.get("symbol") or "").strip().upper()
            if not symbol or item.get("qty") in (None, "") or item.get("market_value") in (None, ""):
                raise ReconciliationError("Snapshot des positions incomplet : symbole, quantité ou valeur de marché absente")
            if symbol in position_symbols:
                raise ReconciliationError("Snapshot des positions contient un symbole dupliqué")
            position_symbols.add(symbol)
            try:
                position_qty = Decimal(str(item["qty"]))
                market_value = Decimal(str(item["market_value"]))
                if not position_qty.is_finite() or position_qty == 0:
                    raise ValueError("quantité non finie ou nulle")
                if not market_value.is_finite():
                    raise ValueError("valeur de marché non finie")
                avg_entry = item.get("avg_entry_price")
                if avg_entry not in (None, ""):
                    avg_entry_value = Decimal(str(avg_entry))
                    if not avg_entry_value.is_finite() or avg_entry_value <= 0:
                        raise ValueError("prix moyen invalide")
                unrealized = item.get("unrealized_pl")
                if unrealized not in (None, "") and not Decimal(str(unrealized)).is_finite():
                    raise ValueError("P/L latent non fini")
            except (KeyError, InvalidOperation, TypeError, ValueError) as exc:
                raise ReconciliationError("Snapshot des positions contient des données numériques invalides") from exc

        order_by_client: dict[str, dict] = {}
        order_by_broker: dict[str, dict] = {}
        for item in remote_orders:
            # Normalize only surrounding whitespace for identity keys. Never
            # case-fold opaque broker IDs or client IDs: they are exact tokens.
            cid = str(item.get("client_order_id") or "").strip()
            bid = str(item.get("id") or "").strip()
            if not cid or not bid:
                raise ReconciliationError("Snapshot des ordres contient un identifiant vide")
            if cid in order_by_client:
                raise ReconciliationError("client_order_id dupliqué dans la réponse du courtier")
            if bid in order_by_broker:
                raise ReconciliationError("Identifiant d'ordre courtier dupliqué dans la réponse")
            order_by_client[cid] = item
            order_by_broker[bid] = item

        # A client ID and broker ID must identify the same remote record. Without
        # this cross-index check, contradictory snapshots could be matched via
        # whichever lookup happened to run first.
        for cid, item in order_by_client.items():
            bid = str(item["id"]).strip()
            if order_by_broker.get(bid) is not item:
                raise ReconciliationError("Correspondance client/broker incohérente dans le snapshot")

        # Validate local ↔ remote identity relationships before any local write.
        local_orders = self.repository.list_orders_for_reconciliation()
        for local in local_orders:
            remote = order_by_client.get(local["client_order_id"])
            if remote is None and local.get("broker_order_id"):
                remote = order_by_broker.get(local["broker_order_id"])
            if remote is None:
                continue
            remote_cid = str(remote.get("client_order_id") or "").strip()
            if remote_cid != str(local["client_order_id"]).strip():
                raise ReconciliationError(f"client_order_id différent pour {local['client_order_id']}")
            if str(remote.get("symbol", "")).strip().upper() != local["symbol"].upper():
                raise ReconciliationError(f"Symbole différent pour {local['client_order_id']}")
            if str(remote.get("side", "")).lower() != local["side"].lower():
                raise ReconciliationError(f"Sens différent pour {local['client_order_id']}")
            remote_id = str(remote.get("id") or "")
            if local.get("broker_order_id") and remote_id and local["broker_order_id"] != remote_id:
                raise ReconciliationError(f"Identifiant courtier incohérent pour {local['client_order_id']}")
            # Alpaca exposes original `qty` and cumulative `filled_qty` separately.
            # Validate them before persisting snapshots or statuses; never infer a
            # full fill from status text alone when quantitative fields are present.
            if remote.get("qty") not in (None, "") and remote.get("filled_qty") not in (None, ""):
                try:
                    requested_qty = Decimal(str(remote["qty"]))
                    filled_qty = Decimal(str(remote["filled_qty"]))
                    if (not requested_qty.is_finite() or not filled_qty.is_finite()
                            or requested_qty <= 0 or filled_qty < 0 or filled_qty > requested_qty):
                        raise ValueError("quantités hors limites")
                    remote_status = str(remote.get("status") or "").lower()
                    if remote_status == "filled" and filled_qty != requested_qty:
                        raise ValueError("statut filled incompatible avec filled_qty")
                    if remote_status == "partially_filled" and not (Decimal("0") < filled_qty < requested_qty):
                        raise ValueError("statut partially_filled incompatible avec filled_qty")
                except (InvalidOperation, TypeError, ValueError) as exc:
                    raise ReconciliationError(
                        f"Quantités d'exécution incohérentes pour {local['client_order_id']}"
                    ) from exc

        # Persist the validated broker snapshot before changing any local order
        # lifecycle state. If snapshot persistence fails, stale submissions must
        # remain untouched: an unrecorded broker view cannot justify recovery.
        self.repository.record_reconciliation_snapshot(account=remote_account,
            positions=remote_positions, source="paper")

        # The complete snapshot is now durable; stale submissions can safely be
        # reclassified as unknown (never retried automatically).
        try:
            stale_submissions_recovered = self.repository.recover_stale_submissions()
            # The durable order row and its strategy proposal must tell the same
            # story after a process crash. A stale SUBMITTING proposal is not a
            # fresh approval candidate: mark it ambiguous before returning. If a
            # matching broker order is found below, sync_broker_status() will
            # resolve it to SUBMITTED/REJECTED/CANCELLED.
            if self.strategy_persistence is not None:
                for client_order_id in stale_submissions_recovered:
                    self.strategy_persistence.update_status(
                        client_order_id, "SUBMISSION_UNKNOWN",
                        reason="stale_submission_recovery")
        except Exception as exc:
            raise ReconciliationError("Récupération locale des soumissions impossible") from exc

        report = {
            "account_snapshot_saved": True, "position_snapshot_count": len(remote_positions),
            "remote_orders_seen": len(remote_orders), "local_orders_checked": 0,
            "orders_matched": 0, "orders_missing_remote": [], "orders_updated": 0,
            "stale_submissions_recovered": stale_submissions_recovered,
            "fills_seen": len(remote_fills), "fills_recorded": 0,
            "fills_duplicate": 0, "fills_invalid": 0, "fills_unmatched": [],
            "fill_quantity_checks": [], "truncated_order_snapshot": len(remote_orders) >= order_limit,
            "truncated_fill_snapshot": len(remote_fills) >= fill_pages * 100,
            "safe_to_retry": [], "warnings": [],
            "financial_reconciliation": {"status": "not_run", "reason": "opening_cash_not_configured"},
        }
        report["local_orders_checked"] = len(local_orders)
        for local in local_orders:
            remote = order_by_client.get(local["client_order_id"])
            if remote is None and local.get("broker_order_id"):
                remote = order_by_broker.get(local["broker_order_id"])
            if remote is None:
                report["orders_missing_remote"].append(local["client_order_id"])
                # A missing item is ambiguous (pagination, retention, propagation); never retry automatically.
                continue
            report["orders_matched"] += 1
            status = str(remote.get("status") or "").lower()
            if not status:
                report["warnings"].append(f"Statut absent pour {local['client_order_id']}")
                continue
            broker_id = str(remote.get("id") or local.get("broker_order_id") or "") or None
            qty_raw = remote.get("qty")
            qty = float(qty_raw) if qty_raw not in (None, "") else None
            transition = evaluate_transition(local["status"], status)
            if not transition.allowed:
                report["warnings"].append(
                    f"Transition de statut refusée pour {local['client_order_id']} "
                    f"({local['status']} → {status}: {transition.reason})"
                )
                # Do not let a stale broker snapshot regress a newer local state.
                continue
            if status != local["status"] or broker_id != local.get("broker_order_id") or (qty is not None and qty != local.get("quantity")):
                self.repository.update_order(local["client_order_id"], status=status,
                    broker_order_id=broker_id, quantity=qty, reason="broker_reconciliation")
                report["orders_updated"] += 1
            if self.strategy_persistence is not None:
                self.strategy_persistence.sync_broker_status(local["client_order_id"], status,
                    broker_order_id=broker_id)

        # Resolve broker activity order IDs against the complete order snapshot,
        # then persist by fill ID. Unknown activities are reported, not guessed.
        for fill in remote_fills:
            fill_id = fill.get("id") or fill.get("activity_id")
            broker_order_id = fill.get("order_id") or fill.get("orderId")
            remote_order = order_by_broker.get(str(broker_order_id)) if broker_order_id else None
            client_id = (remote_order or {}).get("client_order_id")
            if not fill_id or not client_id:
                report["fills_unmatched"].append({"fill_id": str(fill_id or ""), "order_id": str(broker_order_id or "")})
                continue
            symbol = fill.get("symbol") or (remote_order or {}).get("symbol")
            fill_side = str(fill.get("side") or (remote_order or {}).get("side") or "").lower()
            order_side = str((remote_order or {}).get("side") or "").lower()
            order_symbol = str((remote_order or {}).get("symbol") or "").strip().upper()
            fill_symbol = str(symbol or "").strip().upper()
            if (fill_side not in {"buy", "sell"}
                    or (order_side and fill_side != order_side)
                    or (order_symbol and fill_symbol != order_symbol)):
                report["fills_invalid"] += 1
                report["warnings"].append(f"Fill {fill_id}: symbole ou sens absent/incompatible avec l'ordre")
                continue
            qty = fill.get("qty") or fill.get("quantity")
            price = fill.get("price")
            stamp = fill.get("time") or fill.get("transaction_time") or fill.get("executed_at")
            try:
                executed_at = datetime.fromisoformat(str(stamp).replace("Z", "+00:00")) if stamp else None
                # Keep provider decimal strings intact through persistence.
                # A missing timestamp is not replaced with ingestion time: that
                # would fabricate execution chronology in the immutable ledger.
                if not stamp:
                    raise ValueError("horodatage d'exécution absent")
                if executed_at is not None and executed_at.tzinfo is None:
                    from datetime import timezone
                    executed_at = executed_at.replace(tzinfo=timezone.utc)
                created = self.repository.record_fill(
                    broker_fill_id=str(fill_id), client_order_id=client_id,
                    symbol=str(symbol), quantity=Decimal(str(qty)), price=Decimal(str(price)),
                    fee=Decimal(str(fill.get("fee") or "0")), executed_at=executed_at)
                report["fills_recorded" if created else "fills_duplicate"] += 1
            except (TypeError, ValueError, OrderRepositoryError) as exc:
                report["fills_invalid"] += 1
                report["warnings"].append(f"Fill {fill_id}: {type(exc).__name__}")

        # Compare the idempotently persisted execution ledger with each broker
        # order's cumulative filled_qty. This catches partial fills arriving during
        # cancellation and prevents treating a cancel request as zero execution.
        try:
            ledger_rows = self.repository.list_fills_for_ledger()
            filled_by_client: dict[str, Decimal] = {}
            for row in ledger_rows:
                cid = str(row["client_order_id"])
                filled_by_client[cid] = filled_by_client.get(cid, Decimal("0")) + Decimal(str(row["quantity"]))
        except (OrderRepositoryError, InvalidOperation, TypeError, ValueError) as exc:
            ledger_rows = []
            filled_by_client = {}
            report["warnings"].append(f"Grand livre des exécutions indisponible ({type(exc).__name__})")

        for local in local_orders:
            remote = order_by_client.get(local["client_order_id"])
            if remote is None and local.get("broker_order_id"):
                remote = order_by_broker.get(local["broker_order_id"])
            if remote is None or remote.get("filled_qty") in (None, ""):
                continue
            try:
                broker_filled = Decimal(str(remote["filled_qty"]))
                ledger_filled = filled_by_client.get(local["client_order_id"], Decimal("0"))
                if not broker_filled.is_finite() or broker_filled < 0:
                    raise ValueError("filled_qty invalide")
                difference = broker_filled - ledger_filled
                check = {
                    "client_order_id": local["client_order_id"],
                    "broker_filled_qty": format(broker_filled, "f"),
                    "ledger_filled_qty": format(ledger_filled, "f"),
                    "difference": format(difference, "f"),
                    "status": "consistent" if difference == 0 else "mismatch",
                    "broker_status": str(remote.get("status") or "").lower(),
                }
                report["fill_quantity_checks"].append(check)
                if difference != 0:
                    report["warnings"].append(
                        f"Quantité exécutée différente du grand livre pour {local['client_order_id']}"
                    )
            except (InvalidOperation, TypeError, ValueError) as exc:
                report["fill_quantity_checks"].append({
                    "client_order_id": local["client_order_id"], "status": "invalid",
                    "reason": type(exc).__name__,
                })
                report["warnings"].append(f"Quantité exécutée invalide pour {local['client_order_id']}")

        # Never authorize a retry automatically. Only terminal rejection with
        # broker confirmation is a candidate for operator review.
        for local in local_orders:
            remote = order_by_client.get(local["client_order_id"])
            if remote and str(remote.get("status", "")).lower() == "rejected":
                report["safe_to_retry"].append({"client_order_id": local["client_order_id"], "requires_manual_review": True})
        if report["truncated_order_snapshot"]:
            report["warnings"].append("Snapshot des ordres potentiellement tronqué ; les absences ne sont pas interprétables")
        if report["truncated_fill_snapshot"]:
            report["warnings"].append("Historique des exécutions potentiellement tronqué ; ingestion incomplète possible")

        # Financial reconciliation is deliberately opt-in: the opening cash must
        # be a known, independently verified baseline for the complete fill ledger.
        if opening_cash is not None:
            try:
                persisted_fill_ids = {row["fill_id"] for row in self.repository.list_fills_for_ledger()}
            except OrderRepositoryError:
                persisted_fill_ids = set()
                report["warnings"].append("Grand livre des fills illisible")
            remote_fill_ids = {str(item.get("id") or item.get("activity_id"))
                               for item in remote_fills if isinstance(item, dict) and (item.get("id") or item.get("activity_id"))}
            prior_fills_missing_remotely = not persisted_fill_ids.issubset(remote_fill_ids)
            report["financial_reconciliation"] = self._reconcile_financials(
                opening_cash=opening_cash,
                broker_account=remote_account,
                broker_positions=remote_positions,
                cash_tolerance=cash_tolerance,
                quantity_tolerance=quantity_tolerance,
                fills_complete=(not report["truncated_fill_snapshot"] and not report["fills_unmatched"]
                                and not report["fills_invalid"] and not prior_fills_missing_remotely
                                and not any(check.get("status") != "consistent"
                                            for check in report["fill_quantity_checks"])),
            )
            financial = report["financial_reconciliation"]
            if financial["status"] == "mismatch":
                report["warnings"].append("Écart financier détecté : trading Paper à suspendre jusqu'à investigation")
                for discrepancy in financial["discrepancies"]:
                    try:
                        self.repository.record_risk_event(
                            severity="critical", rule="broker_ledger_mismatch",
                            message="Écart entre grand livre local et état du courtier Paper",
                            metrics=discrepancy,
                        )
                    except OrderRepositoryError as exc:
                        report["warnings"].append(f"Événement de risque non persisté ({type(exc).__name__})")
        # Operator-facing exception summary. This is observational only: it never
        # changes orders and explicitly forbids automatic retry recommendations.
        report["execution_health"] = build_execution_health(
            local_orders=local_orders,
            order_by_client=order_by_client,
            order_by_broker=order_by_broker,
            report=report,
        )
        # A durable proof is emitted only when the snapshots are not truncated
        # and every order/fill/quantity check is resolved without warnings.
        unresolved = (len(report["orders_missing_remote"]) + len(report["fills_unmatched"])
            + int(report["fills_invalid"]) + sum(1 for c in report["fill_quantity_checks"]
                if c.get("status") != "consistent") + len(report["warnings"]))
        complete = bool(report["account_snapshot_saved"] and not report["truncated_order_snapshot"]
            and not report["truncated_fill_snapshot"] and report["orders_matched"] == report["local_orders_checked"]
            and unresolved == 0)
        evidence_payload = {"source": "paper", "orders": remote_orders, "fills": remote_fills,
            "account": remote_account, "positions": remote_positions, "report": report}
        evidence_hash = hashlib.sha256(json.dumps(evidence_payload, sort_keys=True,
            separators=(",", ":"), default=str).encode("utf-8")).hexdigest()
        run_id = str(uuid.uuid4())
        try:
            proof = self.repository.record_reconciliation_run(
                run_id=run_id, source="paper", status="succeeded" if complete else "inconclusive",
                snapshot_complete=complete, unresolved_count=unresolved,
                orders_seen=len(remote_orders), fills_seen=len(remote_fills),
                positions_seen=len(remote_positions), evidence_hash=evidence_hash,
                details={"local_orders_checked": report["local_orders_checked"],
                         "orders_matched": report["orders_matched"],
                         "fills_recorded": report["fills_recorded"],
                         "fills_duplicate": report["fills_duplicate"],
                         "warnings": report["warnings"]})
        except OrderRepositoryError as exc:
            raise ReconciliationError("Preuve durable de réconciliation non persistée") from exc
        report["reconciliation_evidence"] = proof
        return report

    def _reconcile_financials(self, *, opening_cash: Any, broker_account: dict,
                              broker_positions: list[dict], cash_tolerance: Any,
                              quantity_tolerance: Any, fills_complete: bool) -> dict[str, Any]:
        """Compare fill-derived holdings/cash against broker snapshots.

        Requires a verified opening-cash baseline and a complete activity history.
        It never repairs balances or changes orders/positions.
        """
        try:
            baseline = Decimal(str(opening_cash))
            cash_tol = Decimal(str(cash_tolerance))
            qty_tol = Decimal(str(quantity_tolerance))
            broker_cash = Decimal(str(broker_account["cash"]))
            broker_equity = Decimal(str(broker_account["equity"]))
        except (KeyError, TypeError, ValueError, InvalidOperation):
            return {"status": "inconclusive", "reason": "invalid_financial_baseline_or_snapshot", "discrepancies": []}
        if (not all(value.is_finite() for value in
                    (baseline, cash_tol, qty_tol, broker_cash, broker_equity))
                or baseline < 0 or cash_tol < 0 or qty_tol < 0
                or broker_cash < 0 or broker_equity < 0):
            return {"status": "inconclusive", "reason": "invalid_tolerance_or_opening_cash", "discrepancies": []}
        if not fills_complete:
            return {"status": "inconclusive", "reason": "fill_history_incomplete_or_unmatched", "discrepancies": []}

        ledger_cash = baseline
        ledger_qty: dict[str, Decimal] = {}
        try:
            fills = self.repository.list_fills_for_ledger()
            for fill in fills:
                symbol = str(fill["symbol"]).upper()
                qty, price, fee = (Decimal(str(fill[k])) for k in ("quantity", "price", "fee"))
                side = str(fill["side"]).lower()
                if (not all(value.is_finite() for value in (qty, price, fee))
                        or qty <= 0 or price <= 0 or fee < 0 or side not in {"buy", "sell"}
                        or not symbol):
                    return {"status": "inconclusive", "reason": "invalid_local_fill", "discrepancies": []}
                signed = qty if side == "buy" else -qty
                ledger_qty[symbol] = ledger_qty.get(symbol, Decimal("0")) + signed
                ledger_cash += -(qty * price + fee) if side == "buy" else (qty * price - fee)
        except (OrderRepositoryError, InvalidOperation, TypeError, ValueError):
            return {"status": "inconclusive", "reason": "local_fill_ledger_unavailable", "discrepancies": []}

        broker_qty: dict[str, Decimal] = {}
        market_value = Decimal("0")
        try:
            for position in broker_positions:
                symbol = str(position["symbol"]).upper()
                qty = Decimal(str(position["qty"]))
                value = Decimal(str(position["market_value"]))
                if (not symbol or symbol in broker_qty or not qty.is_finite()
                        or not value.is_finite()):
                    return {"status": "inconclusive", "reason": "invalid_or_duplicate_broker_position", "discrepancies": []}
                broker_qty[symbol] = qty
                market_value += value
        except (KeyError, TypeError, ValueError, InvalidOperation):
            return {"status": "inconclusive", "reason": "invalid_broker_position_snapshot", "discrepancies": []}

        discrepancies: list[dict[str, Any]] = []
        for symbol in sorted(set(ledger_qty) | set(broker_qty)):
            expected = ledger_qty.get(symbol, Decimal("0"))
            actual = broker_qty.get(symbol, Decimal("0"))
            delta = actual - expected
            if abs(delta) > qty_tol:
                discrepancies.append({"type": "position_quantity", "symbol": symbol,
                    "ledger_quantity": str(expected), "broker_quantity": str(actual), "difference": str(delta)})
        cash_delta = broker_cash - ledger_cash
        if abs(cash_delta) > cash_tol:
            discrepancies.append({"type": "cash", "ledger_cash": str(ledger_cash),
                "broker_cash": str(broker_cash), "difference": str(cash_delta)})
        expected_equity = ledger_cash + market_value
        equity_delta = broker_equity - expected_equity
        if abs(equity_delta) > cash_tol:
            discrepancies.append({"type": "equity", "ledger_cash_plus_broker_market_value": str(expected_equity),
                "broker_equity": str(broker_equity), "difference": str(equity_delta)})
        decimal_text = lambda value: format(value.normalize(), "f")
        return {"status": "mismatch" if discrepancies else "consistent",
            "opening_cash": decimal_text(baseline), "ledger_cash": decimal_text(ledger_cash),
            "broker_cash": decimal_text(broker_cash), "broker_equity": decimal_text(broker_equity),
            "ledger_equity_estimate": decimal_text(expected_equity), "cash_tolerance": decimal_text(cash_tol),
            "quantity_tolerance": decimal_text(qty_tol), "fills_in_ledger": len(fills),
            "symbols_compared": len(set(ledger_qty) | set(broker_qty)),
            "discrepancies": discrepancies}
