"""Institutional portfolio and pre-trade risk controls.

This layer is deliberately deterministic and fail-closed. It complements, but
never replaces, the V1 risk formulas and the existing order checker.
"""
from __future__ import annotations

import math
import time
from typing import Any, Mapping, Sequence


class RiskInputError(ValueError):
    """Risk inputs are missing, malformed, or non-finite."""


def _number(value: Any, name: str, *, minimum: float | None = None) -> float:
    if isinstance(value, bool):
        raise RiskInputError(f"{name}: valeur numérique invalide")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise RiskInputError(f"{name}: valeur numérique invalide") from exc
    if not math.isfinite(result) or (minimum is not None and result < minimum):
        raise RiskInputError(f"{name}: valeur numérique invalide")
    return result


def _limit(limits: Mapping[str, Any], key: str, default: float) -> float:
    value = limits.get(key, default)
    return _number(value, f"limite {key}", minimum=0.0)


class InstitutionalRiskEngine:
    """Portfolio exposure, concentration, liquidity and order-risk policy."""

    @staticmethod
    def _classified_exposure(
        positions: Sequence[Mapping[str, Any]], metadata: Mapping[str, Any],
        field: str,
    ) -> tuple[dict[str, float], list[str]]:
        exposure: dict[str, float] = {}
        missing: list[str] = []
        for position in positions:
            symbol = str(position.get("symbol", "")).strip().upper()
            details = metadata.get(symbol, {})
            group = details.get(field) if isinstance(details, Mapping) else None
            if not isinstance(group, str) or not group.strip():
                missing.append(symbol or "?")
                continue
            key = group.strip().casefold()
            exposure[key] = exposure.get(key, 0.0) + _number(
                position.get("market_value"), f"position {symbol}", minimum=0.0
            )
        return exposure, missing

    @staticmethod
    def _market_risk_breaches(limits: Mapping[str, Any], market_risk: Mapping[str, Any] | None) -> list[str]:
        breaches: list[str] = []
        for key, metric, label in (
            ("max_var95_pct", "var95_pct", "VaR 95 %"),
            ("max_cvar95_pct", "cvar95_pct", "CVaR 95 %"),
            ("max_stress_loss_pct", "stress_loss_pct", "perte en scénario de stress"),
        ):
            if key not in limits:
                continue
            cap = _limit(limits, key, 0.0)
            if market_risk is None or metric not in market_risk:
                breaches.append(f"Mesure {label} indisponible : contrôle bloqué")
                continue
            try:
                observed = _number(market_risk[metric], metric, minimum=0.0)
            except RiskInputError:
                breaches.append(f"Mesure {label} invalide : contrôle bloqué")
                continue
            if observed > cap + 1e-9:
                breaches.append(f"Limite {label} dépassée")
        return breaches

    def portfolio_snapshot(
        self, account: Mapping[str, Any], positions: Sequence[Mapping[str, Any]],
        state: Mapping[str, Any], *, pending_buy_notional: float = 0.0,
        market_risk: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        equity = _number(account.get("equity"), "equity", minimum=0.0000001)
        cash = _number(account.get("cash", 0), "cash", minimum=0.0)
        pending = _number(pending_buy_notional, "ordres réservés", minimum=0.0)
        limits = state.get("limits", {})
        if not isinstance(limits, Mapping):
            raise RiskInputError("Configuration des limites invalide")
        by_symbol: dict[str, float] = {}
        for position in positions:
            symbol = str(position.get("symbol", "")).strip().upper()
            if not symbol:
                raise RiskInputError("Symbole de position manquant")
            value = _number(position.get("market_value"), f"position {symbol}")
            if value < 0:
                raise RiskInputError(f"Position {symbol}: valeur négative non prise en charge")
            by_symbol[symbol] = by_symbol.get(symbol, 0.0) + value
        gross = sum(by_symbol.values())
        net = gross  # long-only portfolio model; short exposure is not enabled.
        concentration = max(by_symbol.values(), default=0.0) / equity * 100.0
        gross_pct, net_pct, cash_pct = gross / equity * 100.0, net / equity * 100.0, cash / equity * 100.0
        reserved_gross_pct = (gross + pending) / equity * 100.0
        peak = _number(state.get("peak", equity) or equity, "peak", minimum=0.0)
        drawdown_pct = (equity - max(peak, equity)) / max(peak, equity) * 100.0
        metrics = {
            "equity": round(equity, 2), "gross_exposure_pct": round(gross_pct, 4),
            "net_exposure_pct": round(net_pct, 4), "cash_pct": round(cash_pct, 4),
            "largest_position_pct": round(concentration, 4),
            "position_count": len(by_symbol), "reserved_gross_exposure_pct": round(reserved_gross_pct, 4),
            "drawdown_pct": round(drawdown_pct, 4),
        }
        breaches: list[str] = []
        gross_limit = _limit(limits, "max_gross", 100.0)
        pos_limit = _limit(limits, "max_pos", 100.0)
        count_limit = int(_limit(limits, "max_positions", 100.0))
        if reserved_gross_pct > gross_limit + 1e-9:
            breaches.append("Exposition brute maximale dépassée")
        if concentration > pos_limit + 1e-9:
            breaches.append("Concentration d'une position dépassée")
        if len(by_symbol) > count_limit:
            breaches.append("Nombre maximal de positions dépassé")
        min_cash_pct = _limit(limits, "min_cash", 0.0)
        if cash_pct < min_cash_pct - 1e-9:
            breaches.append("Réserve minimale de liquidités non respectée")

        metadata = state.get("risk_metadata", {})
        if not isinstance(metadata, Mapping):
            raise RiskInputError("Métadonnées de risque invalides")
        sector_cap = _limit(limits, "max_sector_pct", 100.0)
        issuer_cap = _limit(limits, "max_issuer_pct", 100.0)
        sector_exposure, missing_sector = self._classified_exposure(positions, metadata, "sector")
        issuer_exposure, missing_issuer = self._classified_exposure(positions, metadata, "issuer")
        sector_pct = {key: round(value / equity * 100.0, 4) for key, value in sector_exposure.items()}
        issuer_pct = {key: round(value / equity * 100.0, 4) for key, value in issuer_exposure.items()}
        if sector_cap < 100.0 and missing_sector:
            breaches.append("Classification sectorielle manquante : " + ", ".join(sorted(set(missing_sector))))
        if issuer_cap < 100.0 and missing_issuer:
            breaches.append("Classification émetteur manquante : " + ", ".join(sorted(set(missing_issuer))))
        if any(value > sector_cap + 1e-9 for value in sector_pct.values()):
            breaches.append("Limite de concentration sectorielle dépassée")
        if any(value > issuer_cap + 1e-9 for value in issuer_pct.values()):
            breaches.append("Limite de concentration par émetteur dépassée")

        def _hhi(exposure: Mapping[str, float]) -> float:
            total = sum(exposure.values())
            return sum((value / total) ** 2 for value in exposure.values()) if total > 0 else 0.0

        sector_hhi = _hhi(sector_exposure)
        issuer_hhi = _hhi(issuer_exposure)
        sector_classified = sum(sector_exposure.values())
        issuer_classified = sum(issuer_exposure.values())
        metrics.update({
            "sector_exposure_hhi": round(sector_hhi, 6),
            "issuer_exposure_hhi": round(issuer_hhi, 6),
            "sector_classification_coverage_pct": round(sector_classified / gross * 100.0, 3) if gross > 0 else 100.0,
            "issuer_classification_coverage_pct": round(issuer_classified / gross * 100.0, 3) if gross > 0 else 100.0,
        })
        for hhi_key, observed, missing, label in (
            ("max_sector_hhi", sector_hhi, missing_sector, "sectorielle"),
            ("max_issuer_hhi", issuer_hhi, missing_issuer, "par émetteur"),
        ):
            if hhi_key not in limits:
                continue
            cap = _limit(limits, hhi_key, 1.0)
            if cap > 1.0:
                raise RiskInputError(f"limite {hhi_key}: doit être comprise entre 0 et 1")
            if missing:
                breaches.append(f"Classification {label} incomplète : contrôle HHI bloqué")
            elif observed > cap + 1e-9:
                breaches.append(f"Indice HHI de concentration {label} dépassé")
        # Factor loadings come from the quantitative attribution layer.
        # Aggregate using portfolio weights; never infer missing betas.
        factor_caps = limits.get("max_factor_exposure", {})
        if factor_caps:
            if not isinstance(factor_caps, Mapping):
                raise RiskInputError("Limites d'exposition factorielle invalides")
            factor_totals: dict[str, float] = {}
            missing_factors: list[str] = []
            for position in positions:
                symbol = str(position.get("symbol", "")).strip().upper()
                details = metadata.get(symbol, {})
                loadings = details.get("factor_loadings") if isinstance(details, Mapping) else None
                if not isinstance(loadings, Mapping):
                    missing_factors.append(symbol or "?")
                    continue
                weight = _number(position.get("market_value"), f"position {symbol}", minimum=0.0) / equity
                for factor, loading in loadings.items():
                    if not isinstance(factor, str) or not factor.strip():
                        raise RiskInputError("Nom de facteur invalide")
                    factor_totals[factor] = factor_totals.get(factor, 0.0) + weight * _number(loading, f"exposition facteur {factor}")
            if missing_factors:
                breaches.append("Expositions factorielles manquantes : " + ", ".join(sorted(set(missing_factors))))
            for factor, raw_cap in factor_caps.items():
                cap = _number(raw_cap, f"limite facteur {factor}", minimum=0.0)
                if factor not in factor_totals:
                    breaches.append(f"Exposition au facteur {factor} indisponible : contrôle bloqué")
                elif abs(factor_totals[factor]) > cap + 1e-9:
                    breaches.append(f"Limite d'exposition au facteur {factor} dépassée")
            metrics["factor_exposure"] = {key: round(value, 6) for key, value in factor_totals.items()}

        breaches.extend(self._market_risk_breaches(limits, market_risk))
        if "max_avg_correlation" in limits or "min_effective_n" in limits:
            if not isinstance(market_risk, Mapping):
                breaches.append("Mesures de corrélation indisponibles : contrôle bloqué")
            else:
                if "max_avg_correlation" in limits:
                    cap = _number(limits["max_avg_correlation"], "limite corrélation", minimum=0.0)
                    try:
                        observed = _number(market_risk.get("avg_corr"), "corrélation moyenne", minimum=-1.0)
                        if observed > 1.0:
                            raise RiskInputError("corrélation hors limites")
                        if observed > cap + 1e-9:
                            breaches.append("Limite de corrélation moyenne dépassée")
                    except RiskInputError:
                        breaches.append("Mesure de corrélation invalide : contrôle bloqué")
                if "min_effective_n" in limits:
                    floor = _number(limits["min_effective_n"], "minimum nombre effectif", minimum=0.0)
                    try:
                        observed_n = _number(market_risk.get("eff_n"), "nombre effectif", minimum=0.0)
                        if observed_n < floor - 1e-9:
                            breaches.append("Diversification effective insuffisante")
                    except RiskInputError:
                        breaches.append("Nombre effectif de positions indisponible : contrôle bloqué")
        metrics["sector_exposure_pct"] = sector_pct
        metrics["issuer_exposure_pct"] = issuer_pct
        return {"metrics": metrics, "breaches": breaches, "status": "BREACH" if breaches else "WITHIN_LIMITS"}

    def pre_trade_check(
        self, *, symbol: str, side: str, notional: Any,
        account: Mapping[str, Any], positions: Sequence[Mapping[str, Any]],
        state: Mapping[str, Any], reserved_buy_notional: float = 0.0,
        stop_price: Any | None = None, entry_price: Any | None = None,
    ) -> str | None:
        try:
            amount = _number(notional, "montant de l'ordre", minimum=0.0000001)
            equity = _number(account.get("equity"), "equity", minimum=0.0000001)
            cash = _number(account.get("cash"), "cash", minimum=0.0)
            reserved = _number(reserved_buy_notional, "ordres réservés", minimum=0.0)
            if not isinstance(symbol, str) or not symbol.strip():
                return "Contrôle de risque impossible : symbole invalide"
            if side not in {"buy", "sell"}:
                return "Contrôle de risque impossible : sens d'ordre invalide"
            if side == "sell":
                return None  # Existing core checker validates sell quantity/position.
            limits = state.get("limits", {})
            if not isinstance(limits, Mapping):
                return "Contrôle de risque impossible : limites invalides"
            current = {str(p["symbol"]).upper(): _number(p.get("market_value"), "valeur de position")
                       for p in positions}
            current_symbol = current.get(symbol.upper(), 0.0)
            max_order_pct = _limit(limits, "max_order_pct", 100.0)
            if amount / equity * 100.0 > max_order_pct + 1e-9:
                return "Ordre trop gros selon la limite de risque institutionnelle"
            max_pos_pct = _limit(limits, "max_pos", 100.0)
            if (current_symbol + amount) / equity * 100.0 > max_pos_pct + 1e-9:
                return "Limite de concentration par position dépassée"
            max_gross_pct = _limit(limits, "max_gross", 100.0)
            if (sum(current.values()) + reserved + amount) / equity * 100.0 > max_gross_pct + 1e-9:
                return "Limite d'exposition brute dépassée (ordres réservés inclus)"
            max_positions = int(_limit(limits, "max_positions", 100.0))
            if symbol.upper() not in current and len(current) >= max_positions:
                return "Nombre maximal de positions dépassé"

            metadata = state.get("risk_metadata", {})
            if not isinstance(metadata, Mapping):
                return "Contrôle de risque impossible : métadonnées invalides"
            asset = metadata.get(symbol.upper(), {})
            if not isinstance(asset, Mapping):
                asset = {}
            for field, cap_key, label in (("sector", "max_sector_pct", "sectorielle"),
                                          ("issuer", "max_issuer_pct", "par émetteur")):
                cap = _limit(limits, cap_key, 100.0)
                if cap >= 100.0:
                    continue
                group = asset.get(field)
                if not isinstance(group, str) or not group.strip():
                    return f"Classification {label} manquante : ordre bloqué"
                existing = 0.0
                for position in positions:
                    pos_symbol = str(position.get("symbol", "")).strip().upper()
                    pos_meta = metadata.get(pos_symbol, {})
                    if isinstance(pos_meta, Mapping) and str(pos_meta.get(field, "")).strip().casefold() == group.strip().casefold():
                        existing += _number(position.get("market_value"), f"position {pos_symbol}", minimum=0.0)
                if (existing + amount) / equity * 100.0 > cap + 1e-9:
                    return f"Limite de concentration {label} dépassée"

            # Optional HHI limits screen concentration across the whole projected
            # portfolio, not only the candidate's individual sector/issuer cap.
            for field, hhi_key, label in (
                ("sector", "max_sector_hhi", "sectorielle"),
                ("issuer", "max_issuer_hhi", "par émetteur"),
            ):
                if hhi_key not in limits:
                    continue
                groups: dict[str, float] = {}
                for position in positions:
                    pos_symbol = str(position.get("symbol", "")).strip().upper()
                    pos_meta = metadata.get(pos_symbol, {})
                    group = pos_meta.get(field) if isinstance(pos_meta, Mapping) else None
                    if not isinstance(group, str) or not group.strip():
                        return f"Classification {label} incomplète : ordre bloqué"
                    value = _number(position.get("market_value"), f"position {pos_symbol}", minimum=0.0)
                    key = group.strip().casefold()
                    groups[key] = groups.get(key, 0.0) + value
                candidate_group = asset.get(field)
                if not isinstance(candidate_group, str) or not candidate_group.strip():
                    return f"Classification {label} manquante : ordre bloqué"
                key = candidate_group.strip().casefold()
                groups[key] = groups.get(key, 0.0) + amount
                total = sum(groups.values())
                hhi = sum((value / total) ** 2 for value in groups.values()) if total > 0 else 0.0
                hhi_cap = _limit(limits, hhi_key, 1.0)
                if hhi_cap > 1.0:
                    return f"Configuration de limite HHI {label} invalide"
                if hhi > hhi_cap + 1e-9:
                    return f"Indice HHI de concentration {label} dépassé"

            # Factor caps use the same quantitative loadings as attribution.
            factor_caps = limits.get("max_factor_exposure", {})
            if factor_caps:
                if not isinstance(factor_caps, Mapping):
                    return "Contrôle de risque impossible : limites factorielles invalides"
                candidate = metadata.get(symbol.upper(), {})
                candidate_loadings = candidate.get("factor_loadings") if isinstance(candidate, Mapping) else None
                if not isinstance(candidate_loadings, Mapping):
                    return "Exposition factorielle manquante : ordre bloqué"
                for factor, raw_cap in factor_caps.items():
                    cap = _number(raw_cap, f"limite facteur {factor}", minimum=0.0)
                    total = 0.0
                    for position in positions:
                        pos_symbol = str(position.get("symbol", "")).strip().upper()
                        pos_meta = metadata.get(pos_symbol, {})
                        loadings = pos_meta.get("factor_loadings") if isinstance(pos_meta, Mapping) else None
                        if not isinstance(loadings, Mapping) or factor not in loadings:
                            return f"Exposition au facteur {factor} indisponible : ordre bloqué"
                        total += _number(position.get("market_value"), f"position {pos_symbol}", minimum=0.0) / equity * _number(loadings[factor], f"exposition facteur {factor}")
                    total += amount / equity * _number(candidate_loadings.get(factor), f"exposition facteur {factor}")
                    if abs(total) > cap + 1e-9:
                        return f"Limite d'exposition au facteur {factor} dépassée"

            # Market-risk thresholds are enforced only when configured. If a
            # threshold is active, a missing/stale risk snapshot blocks approval.
            market_risk = state.get("market_risk")
            for key, metric, label in (("max_var95_pct", "var95_pct", "VaR 95 %"),
                                       ("max_cvar95_pct", "cvar95_pct", "CVaR 95 %"),
                                       ("max_stress_loss_pct", "stress_loss_pct", "stress"),
                                       ("max_avg_correlation", "avg_corr", "corrélation"),
                                       ("min_effective_n", "eff_n", "diversification")):
                if key not in limits:
                    continue
                cap = _limit(limits, key, 0.0)
                if not isinstance(market_risk, Mapping) or metric not in market_risk:
                    return f"Mesure {label} indisponible : ordre bloqué"
                as_of = market_risk.get("as_of")
                try:
                    timestamp = _number(as_of, "horodatage du risque", minimum=0.0)
                    max_age = _limit(limits, "market_risk_max_age_seconds", 900.0)
                    if timestamp > time.time() + 5.0 or time.time() - timestamp > max_age:
                        return f"Mesure {label} périmée : ordre bloqué"
                    observed = _number(market_risk[metric], metric,
                                       minimum=-1.0 if key == "max_avg_correlation" else 0.0)
                    if key == "max_avg_correlation" and observed > 1.0:
                        raise RiskInputError("corrélation hors limites")
                except RiskInputError:
                    return f"Mesure {label} invalide : ordre bloqué"
                if key == "min_effective_n":
                    if observed < cap - 1e-9:
                        return "Diversification effective insuffisante"
                elif observed > cap + 1e-9:
                    return f"Limite {label} dépassée"

            # Liquidity and execution-cost controls are opt-in. Inputs must come
            # from a trusted instrument reference / quote feed; never estimate
            # missing volume or prices from unrelated fields.
            liquidity = metadata.get(symbol.upper(), {})
            if not isinstance(liquidity, Mapping):
                liquidity = {}
            liquidity_controls_active = any(key in limits for key in (
                "max_participation_pct", "max_spread_pct", "max_estimated_impact_pct"))
            if liquidity_controls_active:
                source = liquidity.get("source")
                if not isinstance(source, str) or not source.strip():
                    return "Provenance des données de liquidité absente : ordre bloqué"
                try:
                    as_of = _number(liquidity.get("as_of"), "horodatage de liquidité", minimum=0.0)
                    max_age = _limit(limits, "liquidity_max_age_seconds", 120.0)
                    now = time.time()
                    if as_of > now + 5.0 or now - as_of > max_age:
                        return "Données de liquidité périmées : ordre bloqué"
                except RiskInputError:
                    return "Horodatage de liquidité absent ou invalide : ordre bloqué"
            liquidity_keys = ("max_participation_pct", "max_estimated_impact_pct")
            adv = None
            if any(key in limits for key in liquidity_keys):
                try:
                    adv = _number(liquidity.get("avg_daily_dollar_volume"),
                                  "volume quotidien moyen en dollars", minimum=0.0000001)
                except RiskInputError:
                    return "Liquidité indisponible ou invalide : ordre bloqué"
            if "max_participation_pct" in limits:
                participation = amount / adv * 100.0
                cap = _limit(limits, "max_participation_pct", 0.0)
                if participation > cap + 1e-9:
                    return "Participation au volume quotidien maximale dépassée"
            if "max_spread_pct" in limits:
                try:
                    bid = _number(liquidity.get("bid"), "meilleure offre acheteur", minimum=0.0000001)
                    ask = _number(liquidity.get("ask"), "meilleure offre vendeur", minimum=0.0000001)
                    if ask < bid:
                        raise RiskInputError("cotation croisée invalide")
                    spread_pct = (ask - bid) / ((ask + bid) / 2.0) * 100.0
                except RiskInputError:
                    return "Spread indisponible ou invalide : ordre bloqué"
                if spread_pct > _limit(limits, "max_spread_pct", 0.0) + 1e-9:
                    return "Spread maximal autorisé dépassé"
            if "max_estimated_impact_pct" in limits:
                try:
                    coefficient = _number(liquidity.get("impact_coefficient"),
                                          "coefficient d'impact", minimum=0.0)
                    # Square-root impact proxy: coefficient × sqrt(order / ADV).
                    # This is a configurable screening estimate, not a fill guarantee.
                    impact_pct = coefficient * math.sqrt(amount / adv) * 100.0
                except RiskInputError:
                    return "Paramètre d'impact de marché indisponible ou invalide : ordre bloqué"
                if impact_pct > _limit(limits, "max_estimated_impact_pct", 0.0) + 1e-9:
                    return "Impact de marché estimé maximal dépassé"

            min_cash_pct = _limit(limits, "min_cash", 0.0)
            if cash - reserved - amount < equity * min_cash_pct / 100.0 - 0.01:
                return "Réserve minimale de liquidités non respectée"
            # If a stop is explicitly provided, enforce the configured per-trade
            # risk budget. No stop is fabricated when the strategy has none.
            if stop_price is not None:
                entry = _number(entry_price, "prix d'entrée", minimum=0.0000001)
                stop = _number(stop_price, "stop", minimum=0.0000001)
                if stop >= entry:
                    return "Stop invalide pour une position acheteuse"
                risk_pct = _limit(limits, "risk_per_trade", 1.0)
                risk_budget = equity * risk_pct / 100.0
                estimated_loss = amount * (entry - stop) / entry
                if estimated_loss > risk_budget + 0.01:
                    return "Budget de risque par transaction dépassé"
        except (RiskInputError, KeyError, TypeError, ValueError, OverflowError):
            return "Contrôle de risque impossible : données financières invalides"
        return None

    @staticmethod
    def position_size(*, equity: Any, entry_price: Any, stop_price: Any,
                      risk_pct: Any, max_position_pct: Any) -> float:
        """Return a long position notional capped by both risk and concentration."""
        eq = _number(equity, "equity", minimum=0.0000001)
        entry = _number(entry_price, "prix d'entrée", minimum=0.0000001)
        stop = _number(stop_price, "stop", minimum=0.0000001)
        risk = _number(risk_pct, "risque par transaction", minimum=0.0000001)
        cap = _number(max_position_pct, "plafond de position", minimum=0.0000001)
        if stop >= entry or risk > 100 or cap > 100:
            raise RiskInputError("Paramètres de dimensionnement incohérents")
        risk_budget = eq * risk / 100.0
        loss_fraction = (entry - stop) / entry
        return round(min(risk_budget / loss_fraction, eq * cap / 100.0), 2)
