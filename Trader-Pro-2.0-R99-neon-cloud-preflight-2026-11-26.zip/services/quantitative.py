"""Quantitative analysis facade preserving the validated V1 formulas.

This service orchestrates existing pure calculations; it does not redefine or
silently tune indicators, scoring weights, risk limits, or trading thresholds.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Mapping, Sequence

import risklib
import scoring
from indicators import macd, rsi, sma


class QuantitativeError(ValueError):
    """Invalid price history or quantitative input."""


@dataclass(frozen=True)
class QuantitativeSnapshot:
    observations: int
    last_price: float
    rsi: float | None
    macd: tuple[float, float, float] | None
    sma: float | None
    technical_signal: float | None
    daily_volatility: float | None
    historical_var: float | None
    historical_cvar: float | None
    cumulative_return_pct: float
    max_drawdown_pct: float
    annualized_volatility_pct: float | None
    best_day_pct: float
    worst_day_pct: float


@dataclass(frozen=True)
class MultiAssetSnapshot:
    """Portfolio statistics; all assets must share the same dated observations."""
    symbols: tuple[str, ...]
    observations: int
    weights: tuple[tuple[str, float], ...]
    correlation_matrix: tuple[tuple[float, ...], ...]
    covariance_matrix: tuple[tuple[float, ...], ...]
    average_pairwise_correlation: float | None
    betas_vs_benchmark: tuple[tuple[str, float | None], ...]
    portfolio_daily_returns: tuple[float, ...]
    cumulative_return_pct: float
    daily_volatility_pct: float
    annualized_volatility_pct: float
    historical_var_pct: float | None
    historical_cvar_pct: float | None
    effective_number_of_positions: float | None
    concentration_index: float
    largest_position_weight_pct: float
    sector_exposures_pct: tuple[tuple[str, float], ...]
    risk_contributions_pct: tuple[tuple[str, float], ...]
    stress_scenarios: tuple[tuple[str, float], ...]


@dataclass(frozen=True)
class FactorAttributionSnapshot:
    """OLS factor attribution; coefficients are descriptive, not forecasts."""
    observations: int
    factors: tuple[str, ...]
    alpha_daily_pct: float
    alpha_annualized_pct: float
    factor_loadings: tuple[tuple[str, float], ...]
    r_squared: float
    residual_volatility_daily_pct: float


@dataclass(frozen=True)
class StrategySignalSnapshot:
    """Normalized research signals; these are not orders or trade instructions."""
    observations: int
    momentum: float | None
    trend_following: float | None
    mean_reversion: float | None
    rsi: float | None
    fast_sma: float | None
    slow_sma: float | None
    momentum_return_pct: float | None
    trend_spread_pct: float | None
    model_readiness: tuple[tuple[str, bool], ...]


@dataclass(frozen=True)
class StrategyPerformanceSnapshot:
    """Risk/return diagnostics for one strategy's periodic return series."""
    observations: int
    cumulative_return_pct: float
    annualized_return_pct: float
    annualized_volatility_pct: float
    sharpe_ratio: float | None
    sortino_ratio: float | None
    max_drawdown_pct: float
    calmar_ratio: float | None
    hit_rate_pct: float
    profit_factor: float | None
    average_period_return_pct: float
    best_period_pct: float
    worst_period_pct: float
    beta_vs_benchmark: float | None
    correlation_vs_benchmark: float | None


@dataclass(frozen=True)
class StrategyComparisonSnapshot:
    """Comparable diagnostics for multiple strategies over a common calendar."""
    strategies: tuple[tuple[str, StrategyPerformanceSnapshot], ...]
    correlation_matrix: tuple[tuple[float, ...], ...]


@dataclass(frozen=True)
class QuantitativeEvaluation:
    snapshot: QuantitativeSnapshot
    score: float | None
    coverage: float
    action: str
    reasons: tuple[str, ...]


class QuantitativeEngine:
    """Stable orchestration layer around the original V1 quant functions."""

    @staticmethod
    def _finite_float(value: object, label: str) -> float:
        """Convert a genuine numeric input; bool is deliberately not a number here."""
        if isinstance(value, bool):
            raise QuantitativeError(f"Valeur booléenne interdite pour {label}")
        try:
            result = float(value)
        except (TypeError, ValueError, OverflowError) as exc:
            raise QuantitativeError(f"Valeur non numérique pour {label}") from exc
        if not math.isfinite(result):
            raise QuantitativeError(f"Valeur non finie pour {label}")
        return result

    @classmethod
    def _finite_sequence(cls, values: Sequence[float], label: str) -> tuple[float, ...]:
        try:
            return tuple(cls._finite_float(value, label) for value in values)
        except TypeError as exc:
            raise QuantitativeError(f"Séquence invalide pour {label}") from exc

    def strategy_signals(
        self,
        closes: Sequence[float],
        *,
        momentum_lookback: int = 20,
        fast_lookback: int = 20,
        slow_lookback: int = 50,
        rsi_lookback: int = 14,
        momentum_scale_pct: float = 10.0,
        trend_scale_pct: float = 5.0,
    ) -> StrategySignalSnapshot:
        """Build transparent momentum, trend and mean-reversion research signals.

        Scores are clipped to [-1, 1]. Missing warm-up windows return None;
        no score is fabricated and no execution decision is made. Inputs are
        chronological closes. Scales are explicit calibration parameters,
        not optimized defaults or investment recommendations.
        """
        if isinstance(closes, (str, bytes)) or not isinstance(closes, Sequence):
            raise QuantitativeError("L'historique doit être une séquence de clôtures")
        if any(isinstance(value, bool) for value in (momentum_lookback, fast_lookback,
                                                      slow_lookback, rsi_lookback)):
            raise QuantitativeError("Les périodes doivent être des entiers")
        periods = (momentum_lookback, fast_lookback, slow_lookback, rsi_lookback)
        if any(not isinstance(value, int) or value < 2 for value in periods):
            raise QuantitativeError("Chaque période doit être un entier supérieur ou égal à 2")
        if fast_lookback >= slow_lookback:
            raise QuantitativeError("La période rapide doit être inférieure à la période lente")
        momentum_scale = self._finite_float(momentum_scale_pct, "l'échelle momentum")
        trend_scale = self._finite_float(trend_scale_pct, "l'échelle de tendance")
        if (not math.isfinite(momentum_scale) or momentum_scale <= 0
                or not math.isfinite(trend_scale) or trend_scale <= 0):
            raise QuantitativeError("Les échelles de normalisation doivent être finies et positives")
        if len(closes) < 2:
            raise QuantitativeError("Au moins deux clôtures sont requises")
        prices = self._finite_sequence(closes, "les cours de clôture")
        if any(not math.isfinite(value) or value <= 0 for value in prices):
            raise QuantitativeError("Les cours doivent être finis et strictement positifs")

        momentum_return = (prices[-1] / prices[-1 - momentum_lookback] - 1.0) * 100.0 \
            if len(prices) > momentum_lookback else None
        momentum = (max(-1.0, min(1.0, momentum_return / momentum_scale))
                    if momentum_return is not None else None)
        fast_sma = sma(prices, fast_lookback)
        slow_sma = sma(prices, slow_lookback)
        trend_spread = ((fast_sma / slow_sma - 1.0) * 100.0
                        if fast_sma is not None and slow_sma is not None else None)
        trend = (max(-1.0, min(1.0, trend_spread / trend_scale))
                 if trend_spread is not None else None)
        rsi_value = rsi(prices, rsi_lookback) if len(prices) > rsi_lookback else None
        mean_reversion = (max(-1.0, min(1.0, (50.0 - rsi_value) / 20.0))
                          if rsi_value is not None else None)
        return StrategySignalSnapshot(
            observations=len(prices), momentum=momentum,
            trend_following=trend, mean_reversion=mean_reversion,
            rsi=rsi_value, fast_sma=fast_sma, slow_sma=slow_sma,
            momentum_return_pct=momentum_return, trend_spread_pct=trend_spread,
            model_readiness=(("momentum", momentum is not None),
                             ("trend_following", trend is not None),
                             ("mean_reversion", mean_reversion is not None)),
        )

    def snapshot(self, closes: Sequence[float]) -> QuantitativeSnapshot:
        if isinstance(closes, (str, bytes)) or not isinstance(closes, Sequence):
            raise QuantitativeError("L'historique de clôture doit être une séquence numérique")
        if len(closes) < 2:
            raise QuantitativeError("Au moins deux cours de clôture sont requis")
        prices = self._finite_sequence(closes, "les cours de clôture")
        if any(not math.isfinite(value) or value <= 0 for value in prices):
            raise QuantitativeError("Les cours doivent être finis et strictement positifs")

        # Deliberately call the original functions: phase 5 modularizes the
        # orchestration without changing V1 formula semantics.
        rsi_value = rsi(prices) if len(prices) > 14 else None
        macd_value = macd(prices)
        sma_value = sma(prices, min(50, len(prices)))
        technical = scoring.tech_signal(prices)
        daily_returns = risklib.returns(prices)
        daily_volatility = risklib.daily_vol(prices)
        historical_var, historical_cvar = risklib.var_cvar(daily_returns) or (None, None)
        peak = prices[0]
        max_drawdown = 0.0
        for price in prices:
            peak = max(peak, price)
            if peak > 0:
                max_drawdown = min(max_drawdown, price / peak - 1.0)
        annualized_volatility = (
            daily_volatility * math.sqrt(252) if daily_volatility is not None else None
        )

        return QuantitativeSnapshot(
            observations=len(prices),
            last_price=prices[-1],
            rsi=rsi_value,
            macd=tuple(macd_value) if macd_value is not None else None,
            sma=sma_value,
            technical_signal=technical,
            daily_volatility=daily_volatility,
            historical_var=historical_var,
            historical_cvar=historical_cvar,
            cumulative_return_pct=(prices[-1] / prices[0] - 1.0) * 100.0,
            max_drawdown_pct=max_drawdown * 100.0,
            annualized_volatility_pct=(
                annualized_volatility * 100.0 if annualized_volatility is not None else None
            ),
            best_day_pct=max(daily_returns) * 100.0,
            worst_day_pct=min(daily_returns) * 100.0,
        )

    def multi_asset_snapshot(
        self,
        closes_by_symbol: Mapping[str, Sequence[float]],
        weights: Mapping[str, float],
        benchmark_closes: Sequence[float],
        *,
        sector_by_symbol: Mapping[str, str] | None = None,
        stress_shocks_pct: Mapping[str, float] | None = None,
    ) -> MultiAssetSnapshot:
        """Analyze a weighted portfolio without silently aligning unlike calendars.

        Every close series must have equal length and be in the same chronological
        date order. Callers must align timestamps upstream before using this API.
        Weights must be positive and sum to one (within 1e-8). Optional sector
        labels are descriptive classifications supplied by the caller. Stress
        shocks are positive market-decline magnitudes (e.g. 10 means -10%).
        """
        if not isinstance(closes_by_symbol, Mapping) or not closes_by_symbol:
            raise QuantitativeError("Les historiques multi-actifs doivent être un dictionnaire non vide")
        if not isinstance(weights, Mapping) or set(weights) != set(closes_by_symbol):
            raise QuantitativeError("Les pondérations doivent correspondre exactement aux actifs")

        symbols = tuple(closes_by_symbol.keys())
        if any(not isinstance(symbol, str) or not symbol.strip() for symbol in symbols):
            raise QuantitativeError("Chaque actif doit avoir un symbole valide")

        histories: dict[str, tuple[float, ...]] = {}
        expected_length = None
        for symbol in symbols:
            raw = closes_by_symbol[symbol]
            if isinstance(raw, (str, bytes)) or not isinstance(raw, Sequence):
                raise QuantitativeError(f"Historique invalide pour {symbol}")
            if expected_length is None:
                expected_length = len(raw)
            elif len(raw) != expected_length:
                raise QuantitativeError("Les historiques doivent avoir la même longueur et le même calendrier")
            if len(raw) < 3:
                raise QuantitativeError("Au moins trois clôtures par actif sont requises")
            prices = self._finite_sequence(raw, f"les cours de {symbol}")
            if any(not math.isfinite(value) or value <= 0 for value in prices):
                raise QuantitativeError(f"Cours invalide pour {symbol}")
            histories[symbol] = prices

        normalized_weights = {
            symbol: self._finite_float(weights[symbol], f"la pondération de {symbol}")
            for symbol in symbols
        }
        if any(not math.isfinite(value) or value <= 0 for value in normalized_weights.values()):
            raise QuantitativeError("Chaque pondération doit être finie et strictement positive")
        if not math.isclose(sum(normalized_weights.values()), 1.0, rel_tol=0.0, abs_tol=1e-8):
            raise QuantitativeError("La somme des pondérations doit être égale à 1")

        if isinstance(benchmark_closes, (str, bytes)) or not isinstance(benchmark_closes, Sequence):
            raise QuantitativeError("Le benchmark doit être une séquence de cours")
        benchmark = self._finite_sequence(benchmark_closes, "les cours du benchmark")
        if (len(benchmark) != expected_length
                or any(not math.isfinite(value) or value <= 0 for value in benchmark)):
            raise QuantitativeError("Le benchmark doit partager le calendrier et contenir des cours valides")

        asset_returns = {symbol: tuple(risklib.returns(histories[symbol])) for symbol in symbols}
        benchmark_returns = tuple(risklib.returns(benchmark))
        if any(not math.isfinite(value) for values in (*asset_returns.values(), benchmark_returns) for value in values):
            raise QuantitativeError("Rendements dérivés non finis : vérifier les amplitudes des cours")
        correlation = tuple(
            tuple(float(risklib.corr(asset_returns[a], asset_returns[b])) for b in symbols)
            for a in symbols
        )
        covariance = []
        for a in symbols:
            row = []
            for b in symbols:
                mean_a = sum(asset_returns[a]) / len(asset_returns[a])
                mean_b = sum(asset_returns[b]) / len(asset_returns[b])
                cov = sum((x - mean_a) * (y - mean_b)
                          for x, y in zip(asset_returns[a], asset_returns[b])) / (len(asset_returns[a]) - 1)
                row.append(cov)
            covariance.append(tuple(row))

        portfolio_returns = risklib.portfolio_returns(normalized_weights, histories)
        daily_volatility = risklib.stdev(portfolio_returns)
        var_cvar = risklib.var_cvar(portfolio_returns)
        cumulative_equity = math.prod(1.0 + value for value in portfolio_returns)
        if not math.isfinite(cumulative_equity) or cumulative_equity <= 0.0:
            raise QuantitativeError("Rendement composé du portefeuille hors limites numériques")
        cumulative = cumulative_equity - 1.0
        average_corr = risklib.avg_corr(asset_returns)
        betas = tuple((symbol, risklib.beta(asset_returns[symbol], benchmark_returns))
                      for symbol in symbols)
        beta_map = {symbol: beta for symbol, beta in betas if beta is not None}

        # Portfolio concentration and Euler-style contributions to variance.
        concentration = sum(value * value for value in normalized_weights.values())
        max_weight = max(normalized_weights.values())
        variance = sum(
            normalized_weights[a] * normalized_weights[b] * covariance[i][j]
            for i, a in enumerate(symbols)
            for j, b in enumerate(symbols)
        )
        if variance > 0:
            risk_contributions = []
            for i, symbol in enumerate(symbols):
                marginal = sum(normalized_weights[other] * covariance[i][j]
                               for j, other in enumerate(symbols))
                risk_contributions.append((symbol, normalized_weights[symbol] * marginal / variance * 100.0))
        else:
            risk_contributions = [(symbol, 0.0) for symbol in symbols]

        if sector_by_symbol is None:
            sector_exposures = (("Non classé", 1.0),)
        else:
            if not isinstance(sector_by_symbol, Mapping) or set(sector_by_symbol) != set(symbols):
                raise QuantitativeError("Les secteurs doivent couvrir exactement les actifs")
            sectors: dict[str, float] = {}
            for symbol in symbols:
                sector = sector_by_symbol[symbol]
                if not isinstance(sector, str) or not sector.strip():
                    raise QuantitativeError(f"Secteur invalide pour {symbol}")
                label = sector.strip()
                sectors[label] = sectors.get(label, 0.0) + normalized_weights[symbol]
            sector_exposures = tuple(sorted(sectors.items()))

        shocks = stress_shocks_pct if stress_shocks_pct is not None else {
            "marché_-10_pct": 10.0, "marché_-20_pct": 20.0, "marché_-30_pct": 30.0
        }
        if not isinstance(shocks, Mapping):
            raise QuantitativeError("Les scénarios de stress doivent être un dictionnaire")
        stress_results = []
        for label, shock in shocks.items():
            if not isinstance(label, str) or not label.strip():
                raise QuantitativeError("Nom de scénario invalide")
            shock_value = self._finite_float(shock, f"le choc {label}")
            if not math.isfinite(shock_value) or not 0 < shock_value <= 100:
                raise QuantitativeError("Un choc de stress doit être compris entre 0 et 100 %")
            _, portfolio_loss = risklib.stress(normalized_weights, shock_value, beta_map)
            stress_results.append((label.strip(), portfolio_loss * 100.0))

        return MultiAssetSnapshot(
            symbols=symbols,
            observations=expected_length,
            weights=tuple((symbol, normalized_weights[symbol]) for symbol in symbols),
            correlation_matrix=correlation,
            covariance_matrix=tuple(covariance),
            average_pairwise_correlation=average_corr,
            betas_vs_benchmark=betas,
            portfolio_daily_returns=tuple(portfolio_returns),
            cumulative_return_pct=cumulative * 100.0,
            daily_volatility_pct=daily_volatility * 100.0,
            annualized_volatility_pct=daily_volatility * math.sqrt(252) * 100.0,
            historical_var_pct=var_cvar[0] * 100.0 if var_cvar else None,
            historical_cvar_pct=var_cvar[1] * 100.0 if var_cvar else None,
            effective_number_of_positions=risklib.effective_n(normalized_weights.values()),
            concentration_index=concentration,
            largest_position_weight_pct=max_weight * 100.0,
            sector_exposures_pct=tuple((sector, weight * 100.0) for sector, weight in sector_exposures),
            risk_contributions_pct=tuple(risk_contributions),
            stress_scenarios=tuple(stress_results),
        )

    @staticmethod
    def _validated_period_returns(values: Sequence[float], label: str) -> tuple[float, ...]:
        if isinstance(values, (str, bytes)) or not isinstance(values, Sequence) or len(values) < 2:
            raise QuantitativeError(f"La série de rendements {label} doit contenir au moins deux périodes")
        result = QuantitativeEngine._finite_sequence(values, f"les rendements {label}")
        if any(not math.isfinite(value) or value <= -1.0 for value in result):
            raise QuantitativeError(f"Les rendements de {label} doivent être finis et supérieurs à -100 %")
        return result

    def strategy_performance(
        self,
        period_returns: Sequence[float],
        *,
        benchmark_returns: Sequence[float] | None = None,
        risk_free_daily: float = 0.0,
    ) -> StrategyPerformanceSnapshot:
        """Calculate strategy-level risk-adjusted performance from aligned periodic returns.

        Returns are decimal fractions (0.01 = +1%) at a daily frequency. If a
        benchmark is supplied it must have the same length and date order.
        Annualization uses 252 sessions; metrics are descriptive, not forecasts.
        """
        returns = self._validated_period_returns(period_returns, "de stratégie")
        risk_free = self._finite_float(risk_free_daily, "le taux sans risque quotidien")
        if not math.isfinite(risk_free) or risk_free <= -1.0:
            raise QuantitativeError("Taux sans risque quotidien invalide")

        benchmark = None
        if benchmark_returns is not None:
            benchmark = self._validated_period_returns(benchmark_returns, "benchmark")
            if len(benchmark) != len(returns):
                raise QuantitativeError("La stratégie et le benchmark doivent partager le même calendrier")

        equity = 1.0
        peak = 1.0
        max_drawdown = 0.0
        for value in returns:
            equity *= 1.0 + value
            if not math.isfinite(equity) or equity <= 0.0:
                raise QuantitativeError("Capital composé hors limites numériques")
            peak = max(peak, equity)
            max_drawdown = min(max_drawdown, equity / peak - 1.0)

        mean_return = sum(returns) / len(returns)
        excess = tuple(value - risk_free for value in returns)
        daily_vol = risklib.stdev(returns)
        excess_vol = risklib.stdev(excess)
        downside_deviation = math.sqrt(sum(min(value, 0.0) ** 2 for value in excess) / len(excess))
        annualized_return = (equity ** (252.0 / len(returns)) - 1.0) if equity > 0 else -1.0
        annualized_volatility = daily_vol * math.sqrt(252.0)
        sharpe = (sum(excess) / len(excess)) / excess_vol * math.sqrt(252.0) if excess_vol > 0 else None
        sortino = (sum(excess) / len(excess)) / downside_deviation * math.sqrt(252.0) if downside_deviation > 0 else None
        calmar = annualized_return / abs(max_drawdown) if max_drawdown < 0 else None
        gains = sum(value for value in returns if value > 0)
        losses = -sum(value for value in returns if value < 0)
        profit_factor = gains / losses if losses > 0 else None
        beta = risklib.beta(returns, benchmark) if benchmark is not None else None
        correlation = risklib.corr(returns, benchmark) if benchmark is not None else None

        return StrategyPerformanceSnapshot(
            observations=len(returns),
            cumulative_return_pct=(equity - 1.0) * 100.0,
            annualized_return_pct=annualized_return * 100.0,
            annualized_volatility_pct=annualized_volatility * 100.0,
            sharpe_ratio=sharpe,
            sortino_ratio=sortino,
            max_drawdown_pct=max_drawdown * 100.0,
            calmar_ratio=calmar,
            hit_rate_pct=sum(value > 0 for value in returns) / len(returns) * 100.0,
            profit_factor=profit_factor,
            average_period_return_pct=mean_return * 100.0,
            best_period_pct=max(returns) * 100.0,
            worst_period_pct=min(returns) * 100.0,
            beta_vs_benchmark=beta,
            correlation_vs_benchmark=correlation,
        )

    def compare_strategy_performance(
        self,
        returns_by_strategy: Mapping[str, Sequence[float]],
        *,
        benchmark_returns: Sequence[float] | None = None,
        risk_free_daily: float = 0.0,
    ) -> StrategyComparisonSnapshot:
        """Compare strategy streams on one common calendar; never truncate histories."""
        if not isinstance(returns_by_strategy, Mapping) or not returns_by_strategy:
            raise QuantitativeError("Au moins une série de stratégie est requise")
        names = tuple(returns_by_strategy.keys())
        if any(not isinstance(name, str) or not name.strip() for name in names):
            raise QuantitativeError("Chaque stratégie doit avoir un nom valide")
        normalized = {
            name: self._validated_period_returns(returns_by_strategy[name], name)
            for name in names
        }
        lengths = {len(values) for values in normalized.values()}
        if len(lengths) != 1:
            raise QuantitativeError("Les stratégies doivent partager le même calendrier et la même longueur")
        snapshots = tuple(
            (name, self.strategy_performance(
                normalized[name], benchmark_returns=benchmark_returns,
                risk_free_daily=risk_free_daily,
            ))
            for name in names
        )
        correlation = tuple(
            tuple(float(risklib.corr(normalized[left], normalized[right])) for right in names)
            for left in names
        )
        return StrategyComparisonSnapshot(strategies=snapshots, correlation_matrix=correlation)

    @staticmethod
    def _solve_linear_system(matrix: list[list[float]], vector: list[float]) -> list[float]:
        """Solve a small system with partial pivoting; reject singular designs."""
        size = len(vector)
        augmented = [list(matrix[row]) + [vector[row]] for row in range(size)]
        scale = max((abs(value) for row in matrix for value in row), default=0.0)
        tolerance = max(1e-14, scale * 1e-12)
        for column in range(size):
            pivot = max(range(column, size), key=lambda row: abs(augmented[row][column]))
            if abs(augmented[pivot][column]) <= tolerance:
                raise QuantitativeError("Facteurs colinéaires : attribution impossible")
            augmented[column], augmented[pivot] = augmented[pivot], augmented[column]
            divisor = augmented[column][column]
            for j in range(column, size + 1):
                augmented[column][j] /= divisor
            for row in range(size):
                if row == column:
                    continue
                multiplier = augmented[row][column]
                for j in range(column, size + 1):
                    augmented[row][j] -= multiplier * augmented[column][j]
        return [augmented[row][size] for row in range(size)]

    def factor_attribution(
        self,
        asset_closes: Sequence[float],
        factor_returns: Mapping[str, Sequence[float]],
    ) -> FactorAttributionSnapshot:
        """Fit daily asset returns to supplied, already aligned factor returns.

        The model includes an intercept and uses ordinary least squares. It
        requires more observations than estimated coefficients and rejects
        singular/collinear factor sets instead of silently regularizing them.
        """
        if not isinstance(factor_returns, Mapping) or not factor_returns:
            raise QuantitativeError("Au moins un facteur doit être fourni")
        asset = self.snapshot(asset_closes)
        y = tuple(risklib.returns(tuple(float(v) for v in asset_closes)))
        names = tuple(factor_returns.keys())
        if any(not isinstance(name, str) or not name.strip() for name in names):
            raise QuantitativeError("Chaque facteur doit avoir un nom valide")
        if len(y) <= len(names) + 1:
            raise QuantitativeError("Historique insuffisant pour le nombre de facteurs")

        factors: list[tuple[float, ...]] = []
        for name in names:
            raw = factor_returns[name]
            if isinstance(raw, (str, bytes)) or not isinstance(raw, Sequence) or len(raw) != len(y):
                raise QuantitativeError(f"Le facteur {name} doit être aligné sur les rendements de l'actif")
            values = self._finite_sequence(raw, f"le facteur {name}")
            if any(value <= -1.0 for value in values):
                raise QuantitativeError(f"Rendement de facteur inférieur ou égal à -100 % : {name}")
            factors.append(values)

        # Design matrix: intercept followed by each factor.
        columns = [(1.0,) * len(y), *factors]
        xtx = [[sum(a * b for a, b in zip(left, right))
                for right in columns] for left in columns]
        xty = [sum(a * target for a, target in zip(column, y)) for column in columns]
        coefficients = self._solve_linear_system(xtx, xty)
        fitted = [sum(coefficients[j] * columns[j][i] for j in range(len(columns)))
                  for i in range(len(y))]
        mean_y = sum(y) / len(y)
        total_sum_squares = sum((value - mean_y) ** 2 for value in y)
        residuals = [actual - estimate for actual, estimate in zip(y, fitted)]
        residual_sum_squares = sum(value * value for value in residuals)
        if total_sum_squares <= 1e-24:
            raise QuantitativeError("Rendements de l'actif constants : R² indéfini")
        r_squared = max(0.0, min(1.0, 1.0 - residual_sum_squares / total_sum_squares))
        residual_variance = residual_sum_squares / (len(y) - len(coefficients))
        alpha = coefficients[0]
        return FactorAttributionSnapshot(
            observations=len(y),
            factors=names,
            alpha_daily_pct=alpha * 100.0,
            alpha_annualized_pct=alpha * 252.0 * 100.0,
            factor_loadings=tuple((name, coefficients[index + 1])
                                  for index, name in enumerate(names)),
            r_squared=r_squared,
            residual_volatility_daily_pct=math.sqrt(max(0.0, residual_variance)) * 100.0,
        )

    def evaluate(
        self,
        closes: Sequence[float],
        signals: Mapping[str, float | None],
        *,
        held: bool,
    ) -> QuantitativeEvaluation:
        if not isinstance(signals, Mapping):
            raise QuantitativeError("Les signaux doivent être fournis sous forme de dictionnaire")
        if not isinstance(held, bool):
            raise QuantitativeError("held doit être booléen")
        normalized_signals = dict(signals)
        for name, value in normalized_signals.items():
            if name not in scoring.W or value is None:
                continue
            try:
                numeric = float(value)
            except (TypeError, ValueError, OverflowError) as exc:
                raise QuantitativeError(f"Signal non numérique : {name}") from exc
            if not math.isfinite(numeric) or not -1.0 <= numeric <= 1.0:
                raise QuantitativeError(f"Signal hors limites [-1, 1] : {name}")
            normalized_signals[name] = numeric
        snapshot = self.snapshot(closes)
        combined = scoring.combine(normalized_signals)
        if combined is None:
            return QuantitativeEvaluation(
                snapshot=snapshot, score=None, coverage=0.0,
                action="garder", reasons=("aucune donnée",),
            )
        score, coverage = combined
        action, reasons = scoring.decide(score, snapshot.rsi, held, coverage)
        return QuantitativeEvaluation(
            snapshot=snapshot, score=score, coverage=coverage,
            action=action, reasons=tuple(reasons),
        )
