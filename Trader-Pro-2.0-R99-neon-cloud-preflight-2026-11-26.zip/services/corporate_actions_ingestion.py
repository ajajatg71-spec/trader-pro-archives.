"""Idempotent, point-in-time ingestion of complete Alpaca corporate-action batches."""
from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime
from typing import Callable

from db.corporate_action_repository import CorporateActionRepository, CorporateActionRepositoryError
from research_v1.quant.corporate_action_ledger import CorporateActionRevision
from services.providers.alpaca_corporate_actions import AlpacaCorporateActionBatch


class CorporateActionIngestionError(RuntimeError):
    """A provider batch could not be safely persisted."""


@dataclass(frozen=True)
class CorporateActionIngestionResult:
    received: int
    inserted: int
    unchanged: int
    revised: int
    source: str
    observed_at: datetime


def _same_economics(left, right) -> bool:
    """Compare provider economics, excluding the time we happened to observe them."""
    if left is None or right is None:
        return left is right
    fields = ("symbol", "action_type", "ex_date", "source", "split_ratio",
              "cash_amount", "currency", "event_id")
    return all(getattr(left, field) == getattr(right, field) for field in fields)


def ingest_alpaca_corporate_action_batch(
    batch: AlpacaCorporateActionBatch,
    repository: CorporateActionRepository,
    *,
    currency_resolver: Callable[[str], str] | None = None,
) -> CorporateActionIngestionResult:
    """Persist provider records using retrieval time as first-observed knowledge time.

    Historical announcement time is not exposed by the provider contract. Therefore
    this function never backdates availability to ex-date/process-date. For US
    dividend rows whose currency is omitted by the provider, an explicit resolver
    is mandatory; no currency is guessed.
    """
    if not isinstance(batch, AlpacaCorporateActionBatch):
        raise CorporateActionIngestionError("Lot Alpaca invalide")
    if not isinstance(repository, CorporateActionRepository):
        raise CorporateActionIngestionError("Repository de persistance invalide")
    if batch.pagination_complete is not True or batch.pages_fetched < 1:
        raise CorporateActionIngestionError("Lot Alpaca incomplet : persistance refusée")
    if not isinstance(batch.retrieved_at, datetime) or batch.retrieved_at.tzinfo is None or batch.retrieved_at.utcoffset() is None:
        raise CorporateActionIngestionError("Horodatage d'observation invalide")

    inserted = unchanged = revised = 0
    for record in batch.records:
        normalized = record
        if record.action_type == "dividend" and not record.currency:
            if currency_resolver is None:
                raise CorporateActionIngestionError(
                    f"Devise absente pour {record.symbol}; résolution explicite requise"
                )
            currency = currency_resolver(record.symbol)
            if not isinstance(currency, str) or len(currency) != 3 or not currency.isalpha() or currency != currency.upper():
                raise CorporateActionIngestionError("Résolveur de devise invalide")
            normalized = replace(record, currency=currency)
        try:
            # Retrieval time is the earliest defensible knowledge timestamp here.
            event = normalized.to_event(available_at=batch.retrieved_at)
            previous = repository.latest_revision(source=record.source, event_id=record.provider_id)
            if previous is not None and previous.status == "active" and _same_economics(previous.event, event):
                unchanged += 1
                continue
            next_revision = previous.revision + 1 if previous is not None else 1
            revision = CorporateActionRevision(
                source=record.source,
                event_id=record.provider_id,
                revision=next_revision,
                recorded_at=batch.retrieved_at,
                status="active",
                event=event,
            )
            created = repository.append_revision(revision)
            if created:
                if previous is None:
                    inserted += 1
                else:
                    revised += 1
            else:
                unchanged += 1
        except (ValueError, CorporateActionRepositoryError) as exc:
            raise CorporateActionIngestionError(
                f"Événement Alpaca {record.provider_id} non persisté ({type(exc).__name__})"
            ) from exc
    return CorporateActionIngestionResult(
        received=len(batch.records), inserted=inserted, unchanged=unchanged,
        revised=revised, source="alpaca", observed_at=batch.retrieved_at,
    )
