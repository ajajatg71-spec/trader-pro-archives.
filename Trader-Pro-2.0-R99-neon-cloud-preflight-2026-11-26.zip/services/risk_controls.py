"""Shared fail-closed portfolio halt checks used before staging and approval."""
from __future__ import annotations

import math
from typing import Any


def risk_halt_reason(state: dict[str, Any], account: dict[str, Any]) -> str | None:
    """Return a hard-stop reason for broker blocks, daily loss, drawdown or week loss."""
    if account.get("trading_blocked"):
        return "Compte bloqué par le courtier"
    try:
        equity = float(account.get("equity") or 0)
        last_equity = float(account.get("last_equity") or 0)
        peak = float(state.get("peak") or 0)
        limits = state.get("limits", {})
        if not math.isfinite(equity) or equity <= 0:
            return "Valeur du portefeuille invalide"
        daily_limit = float(limits.get("max_daily_loss", 0) or 0)
        if last_equity > 0 and daily_limit > 0:
            daily_change = (equity - last_equity) / last_equity * 100
            if daily_change < -daily_limit:
                return f"Arrêt d'urgence : perte journalière maximale atteinte ({daily_change:.2f} %)"
        drawdown_limit = float(limits.get("max_drawdown", 0) or 0)
        if peak > 0 and drawdown_limit > 0:
            drawdown = (equity - peak) / peak * 100
            if drawdown < -drawdown_limit:
                return f"Arrêt d'urgence : drawdown maximal atteint ({drawdown:.2f} %)"
        week = state.get("week") or {}
        week_equity = float(week.get("eq") or 0)
        weekly_limit = float(limits.get("max_weekly_loss", 0) or 0)
        if week_equity > 0 and weekly_limit > 0:
            weekly_change = (equity - week_equity) / week_equity * 100
            if weekly_change < -weekly_limit:
                return f"Arrêt d'urgence : perte hebdomadaire maximale atteinte ({weekly_change:.2f} %)"
    except (TypeError, ValueError, OverflowError):
        return "Contrôle de risque impossible : données financières invalides"
    return None
