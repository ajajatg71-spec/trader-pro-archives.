"""State and append-only history service, independent from FastAPI routes."""
from __future__ import annotations

import json
import os
import threading
import time
from typing import Any

import store


class StateService:
    """Owns the legacy JSON state and history files behind a small service API.

    Paths intentionally remain relative to the process working directory to
    preserve the V1 deployment/storage contract.
    """

    def __init__(
        self,
        limits: dict[str, Any],
        strategy_defaults: dict[str, Any],
        secret: str = "",
        state_path: str = "state.json",
        history_path: str = "history.jsonl",
        backup_dir: str = "backups",
        lock: threading.RLock | None = None,
    ) -> None:
        self.limits = dict(limits)
        self.strategy_defaults = dict(strategy_defaults)
        self.secret = secret
        self.state_path = state_path
        self.history_path = history_path
        self.backup_dir = backup_dir
        self.lock = lock or threading.RLock()

    def load(self) -> dict[str, Any]:
        state: dict[str, Any] = {
            "targets": [], "limits": {}, "blocked": [], "paused": False,
            "pending": {}, "inst": {}, "congress": {}, "last": {},
            "peak": 0.0, "alerted": {}, "week": {}, "highs": {},
        }
        state.update(store.load_json(self.state_path, {}, backup_dir=self.backup_dir))
        state["limits"] = {**self.limits, **state["limits"]}
        state["strategy"] = {**self.strategy_defaults, **state.get("strategy", {})}
        return state

    def save(self, state: dict[str, Any]) -> None:
        with self.lock:
            store.save_json(self.state_path, state)

    def append_history(self, kind: str, message: str, **fields: Any) -> None:
        message = str(message)
        if self.secret:
            message = message.replace(self.secret, "***")
        record = {
            "t": time.strftime("%Y-%m-%d %H:%M:%S"),
            "kind": kind,
            "msg": message,
            **fields,
        }
        with self.lock, open(self.history_path, "a", encoding="utf-8") as stream:
            stream.write(json.dumps(record, ensure_ascii=False) + "\n")

    def tail(self, count: int) -> list[dict[str, Any]]:
        try:
            with open(self.history_path, encoding="utf-8") as stream:
                lines = stream.read().splitlines()[-count:]
        except FileNotFoundError:
            return []
        return [json.loads(line) for line in reversed(lines)]

    def backup(self, files: list[str], keep: int = 14) -> str:
        return store.backup(files, backup_dir=self.backup_dir, keep=keep)
