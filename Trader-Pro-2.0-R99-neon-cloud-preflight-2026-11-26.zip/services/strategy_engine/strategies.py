"""Initial deterministic strategy adapters built on the validated quant engine."""
from __future__ import annotations

from datetime import datetime
from typing import Sequence

from services.quantitative import QuantitativeEngine, QuantitativeError
from .base import BaseStrategy
from .models import Direction, StrategyConfig, StrategyError, StrategyMetadata, StrategySignal


class QuantSignalStrategy(BaseStrategy):
    signal_name = "momentum"
    default_lookback = 20
    default_scale = 10.0
    metadata = StrategyMetadata("momentum", "Momentum", "1.0.0", "Signal de momentum normalisé")

    def __init__(self, engine: QuantitativeEngine | None = None) -> None:
        self.engine = engine or QuantitativeEngine()

    def validate_config(self, config: StrategyConfig) -> None:
        if not isinstance(config, StrategyConfig):
            raise StrategyError("Configuration de stratégie invalide")
        lookback = config.parameters.get("lookback", self.default_lookback)
        scale = config.parameters.get("scale_pct", self.default_scale)
        if isinstance(lookback, bool) or not isinstance(lookback, int) or lookback < 2:
            raise StrategyError("lookback doit être un entier >= 2")
        if isinstance(scale, bool) or not isinstance(scale, (int, float)) or scale <= 0:
            raise StrategyError("scale_pct doit être positif")

    def generate_signal(self, symbol: str, closes: Sequence[float], *,
                        timestamp: datetime, config: StrategyConfig) -> StrategySignal:
        self.validate_config(config)
        lookback = config.parameters.get("lookback", self.default_lookback)
        scale = config.parameters.get("scale_pct", self.default_scale)
        try:
            snapshot = self.engine.strategy_signals(
                closes, momentum_lookback=lookback, fast_lookback=5,
                slow_lookback=max(lookback + 1, 10), rsi_lookback=14,
                momentum_scale_pct=float(scale), trend_scale_pct=5.0)
        except QuantitativeError as exc:
            raise StrategyError(str(exc)) from exc
        raw = getattr(snapshot, self.signal_name)
        if raw is None:
            direction, strength, confidence = Direction.NEUTRAL, 0.0, 0.0
            explanation = f"Historique insuffisant pour {self.signal_name}"
        else:
            direction = Direction.BUY if raw > 0 else Direction.SELL if raw < 0 else Direction.NEUTRAL
            strength = min(1.0, abs(float(raw)))
            confidence = strength
            explanation = f"{self.signal_name} normalisé: {float(raw):.4f}"
        return StrategySignal(self.metadata.strategy_id, symbol.upper(), direction,
                              strength, confidence, timestamp, config.version, explanation)


class MomentumStrategy(QuantSignalStrategy):
    pass


class TrendFollowingStrategy(QuantSignalStrategy):
    signal_name = "trend_following"
    metadata = StrategyMetadata("trend_following", "Trend Following", "1.0.0", "Signal de tendance basé sur moyennes mobiles")


class MeanReversionStrategy(QuantSignalStrategy):
    signal_name = "mean_reversion"
    metadata = StrategyMetadata("mean_reversion", "Mean Reversion", "1.0.0", "Signal contrariant normalisé basé sur RSI")


class BreakoutStrategy(BaseStrategy):
    metadata = StrategyMetadata("breakout", "Breakout", "1.0.0", "Cassure du plus haut/bas de la fenêtre")

    def validate_config(self, config: StrategyConfig) -> None:
        lookback = config.parameters.get("lookback", 20) if isinstance(config, StrategyConfig) else None
        if isinstance(lookback, bool) or not isinstance(lookback, int) or lookback < 2:
            raise StrategyError("lookback doit être un entier >= 2")

    def generate_signal(self, symbol: str, closes: Sequence[float], *,
                        timestamp: datetime, config: StrategyConfig) -> StrategySignal:
        self.validate_config(config)
        try:
            # Reuse the quantitative input gate so NaN, infinity, zero and
            # non-numeric closes are rejected consistently across strategies.
            QuantitativeEngine().strategy_signals(closes)
        except QuantitativeError as exc:
            raise StrategyError(str(exc)) from exc
        lookback = config.parameters.get("lookback", 20)
        if len(closes) <= lookback:
            direction, strength, confidence = Direction.NEUTRAL, 0.0, 0.0
            explanation = "Historique insuffisant pour confirmer une cassure"
        else:
            history = [float(value) for value in closes[-lookback-1:-1]]
            last = float(closes[-1])
            high, low = max(history), min(history)
            if last > high:
                direction, strength = Direction.BUY, min(1.0, (last / high - 1) * 100)
            elif last < low:
                direction, strength = Direction.SELL, min(1.0, (low / last - 1) * 100)
            else:
                direction, strength = Direction.NEUTRAL, 0.0
            confidence = strength
            explanation = f"Clôture comparée à la plage des {lookback} clôtures précédentes"
        return StrategySignal("breakout", symbol.upper(), direction, strength,
                              confidence, timestamp, config.version, explanation)
