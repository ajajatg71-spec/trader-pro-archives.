"""Version-aware strategy registry with explicit activation controls."""
from __future__ import annotations

from dataclasses import dataclass
from threading import RLock

from .base import BaseStrategy
from .models import StrategyError


@dataclass(frozen=True)
class RegisteredStrategy:
    strategy: BaseStrategy
    active: bool = False


class StrategyRegistry:
    def __init__(self) -> None:
        self._items: dict[str, RegisteredStrategy] = {}
        self._lock = RLock()

    def register(self, strategy: BaseStrategy) -> None:
        metadata = strategy.get_metadata()
        strategy_id = metadata.strategy_id
        if not strategy_id or not metadata.version:
            raise StrategyError("Métadonnées de stratégie incomplètes")
        with self._lock:
            if strategy_id in self._items:
                raise StrategyError(f"Stratégie déjà enregistrée: {strategy_id}")
            self._items[strategy_id] = RegisteredStrategy(strategy)

    def get(self, strategy_id: str) -> BaseStrategy:
        with self._lock:
            item = self._items.get(strategy_id)
            if item is None:
                raise StrategyError(f"Stratégie inconnue: {strategy_id}")
            return item.strategy

    def activate(self, strategy_id: str) -> None:
        with self._lock:
            strategy = self.get(strategy_id)
            if not strategy.health_check():
                raise StrategyError(f"Stratégie non opérationnelle: {strategy_id}")
            strategy.initialize()
            self._items[strategy_id] = RegisteredStrategy(strategy, True)

    def deactivate(self, strategy_id: str) -> None:
        with self._lock:
            strategy = self.get(strategy_id)
            self._items[strategy_id] = RegisteredStrategy(strategy, False)

    def is_active(self, strategy_id: str) -> bool:
        with self._lock:
            item = self._items.get(strategy_id)
            return bool(item and item.active)

    def list_metadata(self) -> tuple:
        with self._lock:
            return tuple(item.strategy.get_metadata() for item in self._items.values())
