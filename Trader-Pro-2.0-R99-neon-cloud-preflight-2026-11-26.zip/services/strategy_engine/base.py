"""Base contract: strategies produce research signals, never broker orders."""
from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Sequence

from .models import StrategyConfig, StrategyMetadata, StrategySignal


class BaseStrategy(ABC):
    metadata: StrategyMetadata

    @abstractmethod
    def validate_config(self, config: StrategyConfig) -> None:
        """Raise StrategyError when configuration is invalid."""

    @abstractmethod
    def generate_signal(self, symbol: str, closes: Sequence[float], *,
                        timestamp: datetime, config: StrategyConfig) -> StrategySignal:
        """Return a normalized signal; implementations must not place orders."""

    def initialize(self) -> None:
        """Hook for deterministic initialization; no external side effects by default."""

    def health_check(self) -> bool:
        return True

    def get_metadata(self) -> StrategyMetadata:
        return self.metadata
