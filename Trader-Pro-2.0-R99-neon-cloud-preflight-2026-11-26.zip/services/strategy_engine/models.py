"""Validated, transport-neutral strategy signal models."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
import math
import re
from typing import Mapping


class StrategyError(ValueError):
    """Invalid strategy configuration, metadata, or market input."""


class Direction(str, Enum):
    BUY = "BUY"
    SELL = "SELL"
    NEUTRAL = "NEUTRAL"


@dataclass(frozen=True)
class StrategySignal:
    strategy_id: str
    symbol: str
    direction: Direction
    strength: float
    confidence: float
    timestamp: datetime
    parameters_version: str
    explanation: str

    def __post_init__(self) -> None:
        if not re.fullmatch(r"[a-z][a-z0-9_.-]{1,63}", self.strategy_id):
            raise StrategyError("Identifiant de stratégie invalide")
        if not isinstance(self.symbol, str) or not re.fullmatch(r"[A-Z0-9][A-Z0-9._/-]{0,19}", self.symbol):
            raise StrategyError("Symbole invalide")
        if not isinstance(self.direction, Direction):
            raise StrategyError("Direction de signal invalide")
        for name, value in (("strength", self.strength), ("confidence", self.confidence)):
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 <= value <= 1:
                raise StrategyError(f"{name} doit être compris entre 0 et 1")
        if not isinstance(self.timestamp, datetime) or self.timestamp.tzinfo is None or self.timestamp.utcoffset() is None:
            raise StrategyError("Le timestamp doit inclure un fuseau horaire")
        if not isinstance(self.parameters_version, str) or not self.parameters_version.strip():
            raise StrategyError("Version des paramètres obligatoire")
        if not isinstance(self.explanation, str) or not self.explanation.strip():
            raise StrategyError("Une explication du signal est obligatoire")


@dataclass(frozen=True)
class StrategyMetadata:
    strategy_id: str
    name: str
    version: str
    description: str
    supported_directions: tuple[Direction, ...] = (Direction.BUY, Direction.SELL, Direction.NEUTRAL)


@dataclass(frozen=True)
class StrategyConfig:
    parameters: Mapping[str, float | int]
    version: str = "1.0.0"

    def __post_init__(self) -> None:
        if not isinstance(self.parameters, Mapping):
            raise StrategyError("Les paramètres doivent être une table clé/valeur")
        for key, value in self.parameters.items():
            if not isinstance(key, str) or not key.strip():
                raise StrategyError("Chaque paramètre doit avoir un nom non vide")
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise StrategyError(f"Valeur numérique invalide pour le paramètre {key}")
            try:
                finite = math.isfinite(float(value))
            except (OverflowError, TypeError, ValueError):
                finite = False
            if not finite:
                raise StrategyError(f"Valeur non finie pour le paramètre {key}")
        if not isinstance(self.version, str) or not self.version.strip():
            raise StrategyError("Version de configuration obligatoire")
