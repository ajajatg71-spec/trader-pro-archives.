"""Strategy lifecycle, correlation-aware signal aggregation and risk-gated proposals.

This module creates research/allocation proposals only. It has no broker or
order-submission dependency; an external Risk Management service must approve
any proposal before a separate Paper Execution component can act on it.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import math
from threading import RLock
from typing import Callable, Mapping, Sequence

from .models import Direction, StrategyConfig, StrategyError, StrategySignal
from .registry import StrategyRegistry


class StrategyState(str, Enum):
    STOPPED = "STOPPED"
    INITIALIZING = "INITIALIZING"
    ACTIVE = "ACTIVE"
    ERROR = "ERROR"


@dataclass(frozen=True)
class StrategyRun:
    signals: tuple[StrategySignal, ...]
    errors: tuple[tuple[str, str], ...]
    states: tuple[tuple[str, StrategyState], ...]


@dataclass(frozen=True)
class AggregatedSignal:
    symbol: str
    direction: Direction
    strength: float
    confidence: float
    contributing_strategies: tuple[str, ...]
    independent_groups: int
    explanation: str


@dataclass(frozen=True)
class AllocationProposal:
    symbol: str
    direction: Direction
    allocation_pct: float
    confidence: float
    source_strategies: tuple[str, ...]
    approved_by_risk: bool = False
    status: str = "PENDING_RISK"


# Momentum and trend-following are deliberately treated as one evidence family.
# Breakout remains a separate family; this avoids counting near-duplicate signals
# as independent votes without claiming statistical independence.
_DEFAULT_GROUPS = {
    "momentum": "trend_momentum",
    "trend_following": "trend_momentum",
    "mean_reversion": "mean_reversion",
    "breakout": "breakout",
}


class SignalAggregator:
    def __init__(self, correlation_groups: Mapping[str, str] | None = None,
                 minimum_confidence: float = 0.05) -> None:
        if (isinstance(minimum_confidence, bool)
                or not isinstance(minimum_confidence, (int, float))
                or not math.isfinite(minimum_confidence)
                or not 0 <= minimum_confidence <= 1):
            raise StrategyError("Seuil de confiance invalide")
        self.groups = {**_DEFAULT_GROUPS, **dict(correlation_groups or {})}
        self.minimum_confidence = minimum_confidence

    def aggregate(self, signals: Sequence[StrategySignal], *, symbol: str) -> AggregatedSignal:
        normalized_symbol = symbol.upper()
        if any(not isinstance(s, StrategySignal) or s.symbol != normalized_symbol for s in signals):
            raise StrategyError("Signaux de symboles incompatibles ou invalides")
        relevant = list(signals)
        if not relevant:
            return AggregatedSignal(normalized_symbol, Direction.NEUTRAL, 0.0, 0.0, (), 0,
                                    "Aucun signal actif pour ce symbole")
        grouped: dict[str, list[float]] = {}
        contributors: list[str] = []
        for signal in relevant:
            group = self.groups.get(signal.strategy_id, signal.strategy_id)
            signed = (1.0 if signal.direction == Direction.BUY else
                      -1.0 if signal.direction == Direction.SELL else 0.0)
            grouped.setdefault(group, []).append(signed * signal.strength * signal.confidence)
            contributors.append(signal.strategy_id)
        # One vote per configured evidence family, irrespective of how many
        # strategies in that family emitted a signal.
        group_votes = [sum(values) / len(values) for values in grouped.values()]
        score = sum(group_votes) / len(group_votes)
        strength = min(1.0, abs(score))
        confidence = min(1.0, sum(abs(v) for v in group_votes) / len(group_votes))
        direction = (Direction.BUY if score > 0 else Direction.SELL if score < 0
                     else Direction.NEUTRAL)
        if confidence < self.minimum_confidence:
            direction, strength = Direction.NEUTRAL, 0.0
        return AggregatedSignal(
            normalized_symbol, direction, strength, confidence,
            tuple(sorted(set(contributors))), len(grouped),
            f"Agrégation de {len(relevant)} signaux sur {len(grouped)} familles de preuve",
        )


class StrategySelector:
    """Explicit regime allow-list; unknown regimes fail closed."""
    DEFAULTS = {
        "TRENDING": frozenset({"momentum", "trend_following", "breakout"}),
        "RANGING": frozenset({"mean_reversion"}),
        "VOLATILE": frozenset({"mean_reversion", "breakout"}),
        "UNKNOWN": frozenset(),
    }

    def __init__(self, regime_strategies: Mapping[str, Sequence[str]] | None = None) -> None:
        self._map = dict(self.DEFAULTS)
        if regime_strategies:
            self._map.update({str(k).upper(): frozenset(v)
                              for k, v in regime_strategies.items()})

    def select(self, regime: str, active_strategy_ids: Sequence[str]) -> tuple[str, ...]:
        allowed = self._map.get(str(regime).upper(), frozenset())
        return tuple(sorted(set(active_strategy_ids).intersection(allowed)))


class StrategyAllocator:
    """Conservative proposal sizing; output is not an executable order."""
    def __init__(self, max_allocation_pct: float = 5.0,
                 min_confidence: float = 0.20) -> None:
        if (isinstance(max_allocation_pct, bool)
                or not isinstance(max_allocation_pct, (int, float))
                or not math.isfinite(max_allocation_pct)
                or not 0 < max_allocation_pct <= 100):
            raise StrategyError("Allocation maximale invalide")
        if (isinstance(min_confidence, bool)
                or not isinstance(min_confidence, (int, float))
                or not math.isfinite(min_confidence)
                or not 0 <= min_confidence <= 1):
            raise StrategyError("Confiance minimale invalide")
        self.max_allocation_pct = max_allocation_pct
        self.min_confidence = min_confidence

    def propose(self, signal: AggregatedSignal) -> AllocationProposal:
        if signal.direction != Direction.BUY or signal.confidence < self.min_confidence:
            return AllocationProposal(signal.symbol, Direction.NEUTRAL, 0.0,
                                       signal.confidence, signal.contributing_strategies,
                                       status="NO_ALLOCATION")
        allocation = self.max_allocation_pct * min(1.0, signal.strength)
        return AllocationProposal(signal.symbol, Direction.BUY, round(allocation, 6),
                                   signal.confidence, signal.contributing_strategies)


class StrategyManager:
    """Runs active strategies independently and records deterministic lifecycle state."""
    def __init__(self, registry: StrategyRegistry | None = None,
                 audit_logger: Callable[[str, str], None] | None = None) -> None:
        self.registry = registry or StrategyRegistry()
        self.audit_logger = audit_logger or (lambda _event, _detail: None)
        self._states: dict[str, StrategyState] = {}
        self._lock = RLock()

    def register(self, strategy) -> None:
        self.registry.register(strategy)
        self._states[strategy.get_metadata().strategy_id] = StrategyState.STOPPED

    def activate(self, strategy_id: str) -> None:
        with self._lock:
            self._states[strategy_id] = StrategyState.INITIALIZING
            try:
                self.registry.activate(strategy_id)
                self._states[strategy_id] = StrategyState.ACTIVE
                self.audit_logger("strategy_activated", strategy_id)
            except Exception as exc:
                self._states[strategy_id] = StrategyState.ERROR
                self.audit_logger("strategy_error", f"{strategy_id}: {type(exc).__name__}: {exc}")
                raise

    def deactivate(self, strategy_id: str) -> None:
        with self._lock:
            self.registry.deactivate(strategy_id)
            self._states[strategy_id] = StrategyState.STOPPED
            self.audit_logger("strategy_deactivated", strategy_id)

    def states(self) -> tuple[tuple[str, StrategyState], ...]:
        with self._lock:
            return tuple(sorted(self._states.items()))

    def run(self, symbol: str, closes: Sequence[float], *, timestamp,
            configs: Mapping[str, StrategyConfig],
            selected_ids: Sequence[str] | None = None) -> StrategyRun:
        signals: list[StrategySignal] = []
        errors: list[tuple[str, str]] = []
        active = [sid for sid, state in self.states() if state == StrategyState.ACTIVE]
        if selected_ids is not None:
            active = [sid for sid in active if sid in set(selected_ids)]
        for strategy_id in active:
            try:
                strategy = self.registry.get(strategy_id)
                config = configs.get(strategy_id)
                if config is None:
                    raise StrategyError("Configuration absente")
                signal = strategy.generate_signal(symbol, closes, timestamp=timestamp, config=config)
                if signal.strategy_id != strategy_id or signal.symbol != symbol.upper():
                    raise StrategyError("Le signal retourné ne correspond pas à la stratégie/symbole")
                signals.append(signal)
                self.audit_logger("strategy_signal", f"{strategy_id}:{signal.direction.value}:{signal.strength:.6f}")
            except Exception as exc:  # isolate one faulty strategy from the others
                detail = f"{type(exc).__name__}: {exc}"
                errors.append((strategy_id, detail))
                with self._lock:
                    self._states[strategy_id] = StrategyState.ERROR
                self.audit_logger("strategy_error", f"{strategy_id}: {detail}")
        return StrategyRun(tuple(signals), tuple(errors), self.states())


def risk_gate(proposal: AllocationProposal,
              risk_check: Callable[[AllocationProposal], bool]) -> AllocationProposal:
    """Mark a proposal approved only after an external risk service accepts it.

    This function never submits orders. A false/raising risk check fails closed.
    """
    if proposal.allocation_pct <= 0 or proposal.direction != Direction.BUY:
        return AllocationProposal(proposal.symbol, proposal.direction, 0.0,
                                  proposal.confidence, proposal.source_strategies,
                                  status="NO_ALLOCATION")
    try:
        approved = risk_check(proposal) is True
    except Exception:
        approved = False
    return AllocationProposal(
        proposal.symbol, proposal.direction,
        proposal.allocation_pct if approved else 0.0,
        proposal.confidence, proposal.source_strategies,
        approved_by_risk=approved,
        status="APPROVED_FOR_PAPER_REVIEW" if approved else "REJECTED_BY_RISK",
    )

@dataclass(frozen=True)
class MarketRegime:
    label: str
    bias: str | None
    observations: int


class MarketRegimeDetector:
    """Conservative adapter over the already validated V1 market-regime rule."""
    def detect(self, benchmark_closes: Sequence[float]) -> MarketRegime:
        import risklib
        try:
            bias = risklib.regime(benchmark_closes)
        except (TypeError, ValueError, IndexError) as exc:
            raise StrategyError(f"Historique benchmark invalide: {exc}") from exc
        if bias is None:
            return MarketRegime("UNKNOWN", None, len(benchmark_closes))
        normalized = str(bias).lower()
        if normalized not in {"haussier", "baissier"}:
            return MarketRegime("UNKNOWN", None, len(benchmark_closes))
        # The V1 rule identifies direction, not volatility/range regimes.
        # Do not invent a sideways/volatile classification from that signal.
        return MarketRegime("TRENDING", normalized, len(benchmark_closes))


class StrategyEvaluator:
    """Delegates performance calculations to the Phase 5 quantitative engine."""
    def __init__(self, engine=None) -> None:
        from services.quantitative import QuantitativeEngine
        self.engine = engine or QuantitativeEngine()

    def evaluate(self, period_returns: Sequence[float], *, benchmark_returns=None,
                 risk_free_daily: float = 0.0):
        try:
            return self.engine.strategy_performance(
                period_returns, benchmark_returns=benchmark_returns,
                risk_free_daily=risk_free_daily)
        except Exception as exc:
            raise StrategyError(f"Évaluation de stratégie impossible: {exc}") from exc

    def compare(self, returns_by_strategy: Mapping[str, Sequence[float]], *,
                benchmark_returns=None, risk_free_daily: float = 0.0):
        try:
            return self.engine.compare_strategy_performance(
                returns_by_strategy, benchmark_returns=benchmark_returns,
                risk_free_daily=risk_free_daily)
        except Exception as exc:
            raise StrategyError(f"Comparaison des stratégies impossible: {exc}") from exc


@dataclass(frozen=True)
class SignalAuditEntry:
    timestamp: object
    event: str
    detail: str


class SignalLogger:
    """Thread-safe bounded in-memory signal audit; persistence is a later DB task."""
    def __init__(self, max_entries: int = 10_000) -> None:
        from datetime import datetime, timezone
        if isinstance(max_entries, bool) or not isinstance(max_entries, int) or max_entries < 1:
            raise StrategyError("max_entries doit être un entier positif")
        self.max_entries = max_entries
        self._entries: list[SignalAuditEntry] = []
        self._lock = RLock()

    def __call__(self, event: str, detail: str) -> None:
        from datetime import datetime, timezone
        entry = SignalAuditEntry(datetime.now(timezone.utc), str(event), str(detail))
        with self._lock:
            self._entries.append(entry)
            if len(self._entries) > self.max_entries:
                del self._entries[:len(self._entries) - self.max_entries]

    def snapshot(self) -> tuple[SignalAuditEntry, ...]:
        with self._lock:
            return tuple(self._entries)
