"""Transactional persistence for strategy proposals; no broker calls live here."""
from __future__ import annotations
from decimal import Decimal
from typing import Any
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from db.models import StrategyProposalRecord, AuditEventRecord


class StrategyPersistenceError(RuntimeError):
    pass


class StrategyPersistence:
    def __init__(self, session_factory):
        self.session_factory = session_factory

    def stage(self, *, proposal_id: str, symbol: str, notional: float,
              allocation_pct: float, confidence: float, regime: str,
              source_strategies: list[str], signals: list[dict[str, Any]],
              pending_payload: dict[str, Any]) -> None:
        try:
            with self.session_factory.begin() as session:
                existing = session.get(StrategyProposalRecord, proposal_id)
                if existing:
                    same_request = (
                        existing.status == "PENDING_APPROVAL"
                        and existing.symbol == symbol
                        and existing.pending_payload == pending_payload
                        and existing.source_strategies == source_strategies
                    )
                    if same_request:
                        return
                    raise StrategyPersistenceError("Identifiant de proposition déjà utilisé")
                session.add(StrategyProposalRecord(
                    proposal_id=proposal_id, symbol=symbol, side="buy",
                    notional=Decimal(str(notional)), allocation_pct=Decimal(str(allocation_pct)),
                    confidence=Decimal(str(confidence)), regime=regime,
                    source_strategies=source_strategies, signals=signals,
                    pending_payload=pending_payload, status="PENDING_APPROVAL"))
                session.add(AuditEventRecord(
                    event_type="strategy_proposal", message=f"Proposition Paper {symbol} en attente",
                    correlation_id=proposal_id,
                    details={"symbol": symbol, "notional": notional, "regime": regime,
                             "strategies": source_strategies, "risk_status": "PRECHECK_PASSED_RECHECK_REQUIRED"}))
        except StrategyPersistenceError:
            raise
        except IntegrityError as exc:
            raise StrategyPersistenceError("Conflit d'identifiant de proposition") from exc
        except Exception as exc:
            raise StrategyPersistenceError(f"Persistance indisponible ({type(exc).__name__})") from exc

    def update_status(self, proposal_id: str, status: str, *, reason: str | None = None,
                      broker_order_id: str | None = None) -> None:
        allowed = {"SUBMITTING", "SUBMITTED", "REJECTED", "RISK_BLOCKED", "SUBMISSION_FAILED",
                   "SUBMISSION_UNKNOWN", "CANCELLED"}
        if status not in allowed:
            raise StrategyPersistenceError("Transition de statut non autorisée")
        try:
            with self.session_factory.begin() as session:
                record = session.get(StrategyProposalRecord, proposal_id)
                if record is None:
                    raise StrategyPersistenceError("Proposition persistée introuvable")
                record.status = status
                record.risk_reason = reason
                if broker_order_id:
                    record.broker_order_id = broker_order_id
                session.add(AuditEventRecord(
                    event_type="strategy_proposal_status", message=f"{proposal_id}: {status}",
                    correlation_id=proposal_id,
                    details={"status": status, "reason": reason, "broker_order_id": broker_order_id}))
        except StrategyPersistenceError:
            raise
        except Exception as exc:
            raise StrategyPersistenceError(f"Mise à jour persistante impossible ({type(exc).__name__})") from exc

    def sync_broker_status(self, proposal_id: str, broker_status: str, *,
                           broker_order_id: str | None = None) -> bool:
        """Close a restored strategy proposal once its broker order is confirmed."""
        normalized = str(broker_status).lower()
        if normalized == "rejected":
            status = "REJECTED"
        elif normalized in {"canceled", "cancelled", "expired"}:
            status = "CANCELLED"
        else:
            status = "SUBMITTED"
        try:
            with self.session_factory() as session:
                exists = session.get(StrategyProposalRecord, proposal_id) is not None
            if not exists:
                return False
            self.update_status(proposal_id, status, reason=f"broker_status:{normalized}",
                               broker_order_id=broker_order_id)
            return True
        except StrategyPersistenceError:
            raise
        except Exception as exc:
            raise StrategyPersistenceError(f"Synchronisation courtier impossible ({type(exc).__name__})") from exc

    def restore_pending(self) -> dict[str, dict[str, Any]]:
        try:
            with self.session_factory() as session:
                rows = session.scalars(select(StrategyProposalRecord).where(
                    StrategyProposalRecord.status.in_(("PENDING_APPROVAL", "SUBMISSION_FAILED")))).all()
                return {row.proposal_id: dict(row.pending_payload) for row in rows}
        except Exception as exc:
            raise StrategyPersistenceError(f"Restauration des propositions impossible ({type(exc).__name__})") from exc

    def health(self) -> dict[str, Any]:
        try:
            with self.session_factory() as session:
                session.execute(select(StrategyProposalRecord.proposal_id).limit(1))
            return {"configured": True, "reachable": True, "pending_proposals": len(self.restore_pending()), "error": None}
        except Exception as exc:
            return {"configured": True, "reachable": False, "pending_proposals": None, "error": type(exc).__name__}
