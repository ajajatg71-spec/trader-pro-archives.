"""Strategy research engine. Signals must pass through risk controls before execution."""
from .models import Direction, StrategyConfig, StrategyError, StrategyMetadata, StrategySignal
from .registry import StrategyRegistry
from .strategies import BreakoutStrategy, MeanReversionStrategy, MomentumStrategy, TrendFollowingStrategy
from .orchestration import (AggregatedSignal, AllocationProposal, SignalAggregator, StrategyAllocator,
                            MarketRegime, MarketRegimeDetector, SignalAuditEntry, SignalLogger, StrategyEvaluator,
                            StrategyManager, StrategyRun, StrategySelector, StrategyState, risk_gate)

__all__ = ["Direction", "StrategyConfig", "StrategyError", "StrategyMetadata",
           "StrategySignal", "StrategyRegistry", "MomentumStrategy",
           "TrendFollowingStrategy", "MeanReversionStrategy", "BreakoutStrategy",
           "AggregatedSignal", "AllocationProposal", "SignalAggregator",
           "StrategyAllocator", "StrategyManager", "StrategyRun",
           "StrategySelector", "StrategyState", "risk_gate", "MarketRegime",
           "MarketRegimeDetector", "SignalAuditEntry", "SignalLogger", "StrategyEvaluator",
           "StrategyExecutionPipeline", "StrategyPipelineError"]

from .pipeline import StrategyExecutionPipeline, StrategyPipelineError
