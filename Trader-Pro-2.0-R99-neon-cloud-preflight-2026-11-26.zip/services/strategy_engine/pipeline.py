"""Fail-closed bridge: market data -> strategies -> risk -> pending Paper order.

The pipeline never talks to a broker. It can only stage a pending order after
an independent risk check. The existing OrderService approval path rechecks
risk and is the sole route to the configured Paper broker.
"""
from __future__ import annotations

from datetime import datetime, timezone
import math
import uuid
from typing import Any, Callable, Mapping, Sequence

import core
from services.risk_controls import risk_halt_reason
from .models import StrategyConfig, StrategyError
from .orchestration import (MarketRegimeDetector, SignalAggregator,
                            StrategyAllocator, StrategyManager, StrategySelector)


class StrategyPipelineError(RuntimeError):
    def __init__(self, detail: str, status_code: int = 400):
        super().__init__(detail)
        self.detail = detail
        self.status_code = status_code


class StrategyExecutionPipeline:
    """Generate signals, gate them with portfolio risk and stage manual approvals."""

    def __init__(self, *, manager: StrategyManager, state: dict[str, Any], lock: Any,
                 save: Callable[[], None], history: Callable[..., Any],
                 account_reader: Callable[[], dict[str, Any]],
                 positions_reader: Callable[[], list[dict[str, Any]]],
                 bars_reader: Callable[[str], Sequence[float]],
                 orders_today_reader: Callable[[], int], paper_mode: bool,
                 selector: StrategySelector | None = None,
                 aggregator: SignalAggregator | None = None,
                 allocator: StrategyAllocator | None = None,
                 regime_detector: MarketRegimeDetector | None = None, persistence=None,
                 operational_pause_reader: Callable[[], dict[str, Any]] | None = None,
                 system_safety_reader: Callable[[], dict[str, Any]] | None = None):
        self.manager, self.state, self.lock = manager, state, lock
        self.save, self.history = save, history
        self.account_reader, self.positions_reader = account_reader, positions_reader
        self.bars_reader, self.orders_today_reader = bars_reader, orders_today_reader
        self.paper_mode = bool(paper_mode)
        self.selector = selector or StrategySelector()
        self.aggregator = aggregator or SignalAggregator()
        self.allocator = allocator or StrategyAllocator(max_allocation_pct=5.0)
        self.regime_detector = regime_detector or MarketRegimeDetector()
        self.persistence = persistence
        self.operational_pause_reader = operational_pause_reader
        self.system_safety_reader = system_safety_reader

    def _refresh_durable_pause(self) -> None:
        """Refresh the cross-process kill switch; any uncertainty blocks strategy work."""
        if self.operational_pause_reader is None:
            return
        try:
            durable = self.operational_pause_reader()
            if not isinstance(durable, dict) or not isinstance(durable.get("paused"), bool):
                raise ValueError("État durable du coupe-circuit invalide")
            self.state["paused"] = durable["paused"]
            if durable.get("reason"):
                self.state["pause_reason"] = str(durable["reason"])[:2000]
            elif not durable["paused"]:
                self.state.pop("pause_reason", None)
        except Exception as exc:
            self.state["paused"] = True
            self.state["pause_reason"] = "État durable du coupe-circuit indisponible"
            raise StrategyPipelineError(
                f"{self.state['pause_reason']} : génération d'ordres bloquée ({type(exc).__name__})", 423
            ) from None

    def _require_system_ready(self) -> None:
        if self.system_safety_reader is None:
            raise StrategyPipelineError("État global de sécurité non configuré : trading bloqué", 423)
        try:
            safety = self.system_safety_reader()
            if not isinstance(safety, dict) or safety.get("status") != "READY":
                status = safety.get("status", "UNKNOWN") if isinstance(safety, dict) else "UNKNOWN"
                raise ValueError(f"état global {status}")
        except Exception as exc:
            raise StrategyPipelineError(f"État global de sécurité non prêt : {type(exc).__name__}", 423) from None

    def _risk_check_and_stage(self, proposal, *, symbol: str, regime: str, signals: list[dict[str, Any]]) -> dict[str, Any]:
        if not self.paper_mode:
            raise StrategyPipelineError("Exécution Paper indisponible : mode fermé par sécurité", 403)
        amount = 0.0
        with self.lock:
            self._require_system_ready()
            self._refresh_durable_pause()
            if self.state.get("paused"):
                raise StrategyPipelineError(self.state.get("pause_reason") or "Trading en pause : proposition refusée", 423)
            account = self.account_reader()
            halt_reason = risk_halt_reason(self.state, account)
            if halt_reason:
                if halt_reason.startswith("Arrêt d'urgence"):
                    self.state["paused"] = True
                    self.save()
                    self.history("alert", halt_reason)
                    raise StrategyPipelineError(halt_reason, 423)
                raise StrategyPipelineError(halt_reason, 409)
            equity = float(account.get("equity") or 0)
            if not math.isfinite(equity) or equity <= 0:
                raise StrategyPipelineError("Valeur du portefeuille invalide", 409)
            amount = round(equity * proposal.allocation_pct / 100.0, 2)
            if amount < 1:
                raise StrategyPipelineError("Montant calculé inférieur au minimum d'ordre", 409)
            positions = self.positions_reader()
            reserved = sum(float(item.get("amt") or 0) for item in self.state.get("pending", {}).values()
                           if item.get("side") == "buy" and not item.get("why"))
            reason = core.check((symbol, "buy", amount), account, positions,
                                self.state["limits"], self.state.get("blocked", []),
                                reserved, self.orders_today_reader())
            if reason:
                self.history("strategy_risk_block", f"{symbol} : {reason}")
                raise StrategyPipelineError(reason, 409)
            order_id = "strategy-" + uuid.uuid4().hex
            pending_payload = {
                "sym": symbol, "side": "buy", "amt": amount, "why": "",
                "source": "strategy_engine", "risk_checked_at": datetime.now(timezone.utc).isoformat(),
                "risk_status": "PRECHECK_PASSED_RECHECK_REQUIRED",
                "strategies": list(proposal.source_strategies),
            }
            # Persist first. If the configured database is unavailable, fail closed:
            # do not expose a proposal that would disappear after a restart.
            if self.persistence is not None:
                self.persistence.stage(
                    proposal_id=order_id, symbol=symbol, notional=amount,
                    allocation_pct=proposal.allocation_pct, confidence=proposal.confidence,
                    regime=regime, source_strategies=list(proposal.source_strategies),
                    signals=signals, pending_payload=pending_payload)
            self.state.setdefault("pending", {})[order_id] = pending_payload
            self.save()
            self.history("strategy_order_staged",
                         f"{symbol} : proposition Paper {amount:.2f} USD en attente d'approbation",
                         order_id=order_id, strategies=list(proposal.source_strategies))
            return {"order_id": order_id, "symbol": symbol, "side": "buy",
                    "notional": amount, "status": "PENDING_MANUAL_APPROVAL"}

    def run(self, symbols: Sequence[str], *, configs: Mapping[str, StrategyConfig] | None = None) -> dict[str, Any]:
        if not self.paper_mode:
            raise StrategyPipelineError("Pipeline désactivé hors environnement Paper", 403)
        normalized = list(dict.fromkeys(str(s).strip().upper() for s in symbols if str(s).strip()))
        if not normalized or len(normalized) > 10:
            raise StrategyPipelineError("Fournir entre 1 et 10 symboles", 400)
        if any(not __import__("re").fullmatch(r"[A-Z0-9][A-Z0-9._/-]{0,19}", s) for s in normalized):
            raise StrategyPipelineError("Symbole invalide", 400)
        with self.lock:
            self._require_system_ready()
            self._refresh_durable_pause()
            if self.state.get("paused"):
                raise StrategyPipelineError(self.state.get("pause_reason") or "Trading en pause", 423)
            strategy_settings = dict(self.state.get("strategy", {}))
        if not strategy_settings.get("enabled"):
            raise StrategyPipelineError("Active d'abord le moteur de stratégies", 409)
        account_preflight = self.account_reader()
        halt_reason = risk_halt_reason(self.state, account_preflight)
        if halt_reason:
            if halt_reason.startswith("Arrêt d'urgence"):
                with self.lock:
                    self.state["paused"] = True
                    self.save()
                    self.history("alert", halt_reason)
                raise StrategyPipelineError(halt_reason, 423)
            raise StrategyPipelineError(halt_reason, 409)
        active = [sid for sid, state in self.manager.states() if state.value == "ACTIVE"]
        if not active:
            raise StrategyPipelineError("Aucune stratégie active dans le registre", 409)
        try:
            benchmark = self.bars_reader("SPY")
            regime = self.regime_detector.detect(benchmark)
        except Exception as exc:
            raise StrategyPipelineError(f"Benchmark indisponible : {type(exc).__name__}", 503) from exc
        selected = self.selector.select(regime.label, active)
        run_timestamp = datetime.now(timezone.utc)
        output: list[dict[str, Any]] = []
        config_map = configs or {sid: StrategyConfig({}) for sid in active}
        for symbol in normalized:
            try:
                closes = self.bars_reader(symbol)
                if not isinstance(closes, Sequence) or len(closes) < 2:
                    raise StrategyPipelineError(f"Historique insuffisant pour {symbol}", 422)
                run = self.manager.run(symbol, closes, timestamp=run_timestamp,
                                       configs=config_map, selected_ids=selected)
                aggregate = self.aggregator.aggregate(run.signals, symbol=symbol)
                proposal = self.allocator.propose(aggregate)
                item: dict[str, Any] = {
                    "symbol": symbol, "regime": regime.label,
                    "signals": [{"strategy_id": s.strategy_id, "direction": s.direction.value,
                                 "strength": s.strength, "confidence": s.confidence,
                                 "parameters_version": s.parameters_version}
                                for s in run.signals],
                    "strategy_errors": [{"strategy_id": sid, "error": detail}
                                        for sid, detail in run.errors],
                    "aggregate": {"direction": aggregate.direction.value,
                                  "strength": aggregate.strength,
                                  "confidence": aggregate.confidence,
                                  "independent_groups": aggregate.independent_groups},
                    "proposal_status": proposal.status,
                }
                if proposal.allocation_pct > 0:
                    try:
                        item["paper_order"] = self._risk_check_and_stage(proposal, symbol=symbol, regime=regime.label, signals=item["signals"])
                    except StrategyPipelineError as exc:
                        item["risk_rejection"] = exc.detail
                        item["proposal_status"] = "REJECTED_BY_RISK"
                output.append(item)
            except StrategyPipelineError as exc:
                # A symbol-level data/configuration failure must not erase the
                # results of earlier symbols in the same batch. Return an explicit
                # per-symbol rejection so clients can reconcile partial staging.
                output.append({"symbol": symbol, "status": "SYMBOL_REJECTED",
                               "error": exc.detail, "error_code": exc.status_code})
            except Exception as exc:
                output.append({"symbol": symbol, "status": "SYMBOL_ERROR",
                               "error": f"{type(exc).__name__}: {exc}"})
        return {"mode": "PAPER", "execution": "MANUAL_APPROVAL_REQUIRED",
                "regime": regime.label, "selected_strategies": list(selected),
                "results": output}
