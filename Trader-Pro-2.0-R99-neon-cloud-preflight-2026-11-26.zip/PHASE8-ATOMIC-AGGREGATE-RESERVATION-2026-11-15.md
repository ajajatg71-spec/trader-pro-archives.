# Phase 8 — atomic aggregate buy reservations (2026-11-15)

## Finding

The existing pre-trade risk checks read broker open orders before the durable
submission claim. Two independent workers could therefore both evaluate the
same old snapshot and each pass, even though their combined buy commitments
would exceed available cash or the portfolio gross-exposure / single-issuer
position cap.

## Change

- The durable submission claim now receives a conservative aggregate buy
  reservation ceiling derived from cash after the minimum-cash reserve and
  gross-exposure headroom after current positions.
- It also receives a per-symbol reservation ceiling derived from the current
  position and `max_pos`.
- Inside the same PostgreSQL transaction as the durable intent, the repository
  locks the singleton pause row (the common serialization point for all Trader
  Pro submission claims), checks global safety, reads all non-terminal local
  buy intents, merges them with the broker's complete open-buy snapshot by
  broker order ID, and includes the candidate order.
- Duplicate local/broker representations are counted once only when symbol and
  notional agree. A mismatch or unknown local reservation fails closed.
- The claim is rejected and audited if total cash/gross headroom or per-symbol
  headroom would be exceeded. The broker call remains after transaction commit.
- Existing V1 risk checks and the existing broker idempotency key remain in
  place; this is an additional final atomic reservation gate, not a replacement.

## Test environment prepared

- `compose.test.yaml` provides an isolated PostgreSQL 16 container with a tmpfs
  data directory and a dedicated test-only password.
- `scripts/run_postgres_container_tests.sh` and `.ps1` start it, apply Alembic,
  run PostgreSQL integration tests and the full Python suites, then destroy the
  container and its data.
- A real PostgreSQL concurrency integration test races two independent
  repository instances for a 150 USD reservation ceiling with two 100 USD
  claims; expected result is exactly one accepted and one blocked.
- The same integration test checks the durable audit event for the blocked
  claim.

## Local verification in this environment

- Focused repository/service tests: **73 passed**.
- Full pytest: **564 passed, 11 skipped, 177 subtests passed**.
- `python -m unittest discover -q`: **560 passed**.
- `python -m compileall -q .`: passed.

The 11 skipped tests are opt-in PostgreSQL integration tests. Docker/Podman,
PostgreSQL server/client binaries, and the psycopg driver are not installed in
this execution environment, so the new PostgreSQL concurrency test has been
prepared but has NOT been run against a real PostgreSQL server here. Run the
provided Docker script or the PostgreSQL GitHub Actions workflow to obtain that
proof. No Alpaca order was submitted or cancelled; no Live mode was enabled.

## Scope and limitations

This serializes Trader Pro's own durable submission claims. It cannot make
external/manual broker orders atomic with Trader Pro's database; the broker
snapshot is still a point-in-time external input. Any missing, malformed,
truncated, or mismatched broker snapshot blocks approval. Additional atomic
checks for sector/factor exposure and real Paper broker concurrency remain
separate validation work.
