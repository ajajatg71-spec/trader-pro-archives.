# Phase 8 — Broker event lease fencing (2026-11-15)

## Finding

The durable broker-event inbox reclaimed `processing` rows after a stale timeout. A worker retained only the event IDs it had claimed. If its lease expired and another worker reclaimed the same row, the older worker could still mark the row `processed` or `failed` because finalization selected by event ID alone. The reconciliation itself is read-only, but stale finalization could overwrite the newer worker's state and retry schedule.

## Change

- Added nullable `processing_token` (UUID string) to `broker_event_inbox` with an indexed Alembic migration `b8d2f4a6c901`.
- Each batch claim receives a fresh fencing token.
- Success and failure finalization now require both `status='processing'` and the exact token owned by that worker.
- Finalization clears the token when it owns the lease.
- A stale worker whose token has been replaced cannot overwrite the newer lease. Its result reports the number of superseded events.
- Audit records list only rows still owned by the worker.
- The inbox still triggers read-only reconciliation only; no submit, replace, cancel, or automatic order retry was added.

## Regression coverage

Two deterministic tests replace the lease token during reconciliation and verify that the old worker cannot acknowledge or fail the newer worker's lease.

## Verification in the local archive environment

- `pytest -q tests/test_broker_events.py`: 14 passed.
- `pytest -q`: 568 passed, 11 skipped, 187 subtests passed.
- `python -m unittest discover -q`: 564 passed.
- `python -m compileall -q .`: passed.
- `alembic heads`: one head, `b8d2f4a6c901`.

## Limitations

The lease-fencing regression is tested using the local SQLite test harness. It is not a substitute for concurrent PostgreSQL integration testing. The 11 PostgreSQL-dependent tests remain skipped in this environment. No authenticated Alpaca Paper call, order submission, cancellation, or Live operation was performed.

## Next validation

Run the migration and multi-worker lease-reclaim tests against PostgreSQL 16 (preferably with two independent worker processes), then verify the inbox and reconciliation behavior against Alpaca Paper in read-only mode.
