# R65 — Fusion sélective du terminal R36 / paquet R58

Date : 25 novembre 2026

## Décision de fusion
Base conservée : R64. Le ZIP fourni est une branche antérieure R58 enrichie d'un terminal opérateur R36. Les fichiers critiques de cette branche ne remplacent pas les fichiers R64.

## Ajout retenu
- `services/quant_sizing.py` : dimensionnement quantitatif ATR / volatilité, réduction de budget en régime tendu et estimation pré-trade spread + impact.
- `tests/test_quant_sizing.py` : tests de calcul, plafonds, régimes de stress, entrées non finies et TCA.

## Durcissements appliqués à l'algorithme source
- Rejet explicite des valeurs NaN/Infinity, des prix/equity non positifs, des limites incohérentes et d'un ADV invalide.
- Validation des séries ATR et des longueurs OHLC.
- Le résultat porte `research_only=True`.
- Aucun branchement vers `OrderService`, aucune création d'ordre, aucune allocation de capital et aucune activation du mode Live.

## Éléments volontairement non fusionnés
- `services/orders.py`, `db/order_repository.py`, `broker.py`, `services/reconciliation.py` et leurs tests : versions source plus anciennes, qui risquent de retirer les garde-fous R62-R64.
- Terminal React complet : commandes `approve`, `rebalance`, `pause` et bascule d'auto-exécution nécessitent une adaptation explicite aux garde-fous R64 et au mandat sans levier. Non copié.
- Routes analytics de la branche source : dépendances et valeurs de repli de données de marché insuffisamment sûres pour une intégration directe.

## Limites
Le sizing est une estimation de recherche, pas une recommandation d'ordre, une promesse de coût d'exécution ou une preuve de performance. L'intégration UI/API attendra une validation dédiée des données de marché, du mandat instrument et du Risk Governor.

## Provenance
Paquet fourni : `Lololololol.zip`, SHA-256 `fc0e33ef952b021f860f3ffee86839e1d0d1820d718571b0ce1588c64ef8321a`.
Base : R64.
