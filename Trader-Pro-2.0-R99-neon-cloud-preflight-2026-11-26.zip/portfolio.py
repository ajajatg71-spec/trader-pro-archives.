"""Suivi de portefeuille : lots FIFO, gains réalisés/latents nets de frais, impôt estimé, alertes de risque."""
from collections import deque, defaultdict

def fee_for(notional, pct=0.0, minimum=0.0):
    return max(minimum, notional * pct / 100) if notional > 0 else 0.0

def process(fills, pct=0.0, minimum=0.0):
    """fills : [{symbol, side, qty, price, time}]. Renvoie (lots ouverts, ventes réalisées, frais, total acheté)."""
    lots, realized, fees, invested = defaultdict(deque), [], 0.0, 0.0
    for f in sorted(fills, key=lambda x: x["time"]):
        q, p, sym = float(f["qty"]), float(f["price"]), f["symbol"]
        fee = fee_for(q * p, pct, minimum); fees += fee
        if f["side"] == "buy":
            lots[sym].append([q, p + fee / q, f["time"]]); invested += q * p
        else:
            rem, net_price = q, p - fee / q
            while rem > 1e-9 and lots[sym]:
                lot = lots[sym][0]; take = min(rem, lot[0])
                realized.append({"symbol": sym, "qty": take, "pnl": (net_price - lot[1]) * take,
                                 "sold": f["time"][:10], "bought": lot[2][:10]})
                lot[0] -= take; rem -= take
                if lot[0] <= 1e-9: lots[sym].popleft()
    return lots, realized, fees, invested

def by_year(realized):
    d = {}
    for r in realized: d[r["sold"][:4]] = round(d.get(r["sold"][:4], 0) + r["pnl"], 2)
    return d

def summary(lots, realized, fees, invested, prices):
    real = sum(r["pnl"] for r in realized)
    unreal = sum((prices[s] - l[1]) * l[0] for s, q in lots.items() for l in q if s in prices)
    return {"realized": round(real, 2), "unrealized": round(unreal, 2), "fees": round(fees, 2), "invested": round(invested, 2),
            "return_pct": round((real + unreal) / invested * 100, 2) if invested else 0.0, "by_year": by_year(realized)}

def tax(realized, year, rate=31.4, carry=0.0):
    """Estimation PFU (France) : plus-value nette de l'année, moins-values reportées imputées, impôt. Montants dans la devise des fills."""
    net = sum(r["pnl"] for r in realized if r["sold"].startswith(str(year)))
    used = min(carry, max(net, 0.0)); taxable = max(net, 0.0) - used
    return {"net": round(net, 2), "imputé": round(used, 2), "imposable": round(taxable, 2),
            "impôt": round(taxable * rate / 100, 2), "moins_values_restantes": round(carry - used + (-net if net < 0 else 0), 2)}

def drawdown(equity, peak): return (equity - peak) / peak * 100 if peak else 0.0

def risk_alerts(eq, last, peak, pos, L):
    out = []
    if last and (eq - last) / last * 100 < -L["max_daily_loss"]: out.append(f"Perte journalière : {(eq - last) / last * 100:.1f} %")
    dd = drawdown(eq, peak)
    if dd < -L["max_drawdown"]: out.append(f"Drawdown : {dd:.1f} % depuis le plus haut")
    for p in pos:
        w = float(p["market_value"]) / eq * 100 if eq else 0
        if w > L["max_pos"]: out.append(f"Concentration : {p['symbol']} pèse {w:.0f} %")
    return out
