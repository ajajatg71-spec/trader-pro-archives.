"""Trader Pro 1.1 : serveur + tableau de bord. Chaque ordre exige ton accord."""
import hashlib, json, os, secrets, shutil, threading, time, uuid
from contextlib import asynccontextmanager
from types import SimpleNamespace
from dataclasses import asdict
from datetime import datetime, timedelta, timezone
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel, Field
from candle_analysis import analyze_candles, CandleAnalysisError
from research_v1.quant.candles import scan as scan_advanced_candles
import broker, core, scoring, sentiment, thirteen_f, congress, portfolio, notify, auth, store, anomaly, backtest, risklib, security
from services.state import StateService
from services.portfolio import PortfolioService
from services.risk import RiskService
from services.orders import OrderService, OrderServiceError
from services.institutional_risk import InstitutionalRiskEngine
from services.strategy import StrategyService
from services.quantitative import QuantitativeEngine
from services.strategy_engine import (MomentumStrategy, TrendFollowingStrategy, MeanReversionStrategy, BreakoutStrategy, StrategyManager, StrategyExecutionPipeline, StrategyPipelineError)
from services.market_data import (MarketDataService, MarketDataError, ProviderChain,
    require_fresh_daily_bars, validated_daily_closes, validated_daily_bar_series, DailyBars)
from routers.health import router as health_router
from routers.history import create_history_router
from routers.portfolio import create_portfolio_router
from routers.authentication import create_auth_router
from routers.operator import create_operator_router
from routers.orders import create_orders_router
from routers.risk import create_risk_router
from routers.strategy import create_strategy_router
from routers.analytics import create_analytics_router
from routers.dashboard import create_dashboard_router
from routers.research_registry import create_research_registry_router
import requests
from indicators import rsi
from config import BASE, APP_PASSWORD, LIMITS, STRAT, FEE_PCT, FEE_MIN, KEY, SECRET, TOTP_SECRET, SIM
if SIM:
    import sim_broker as broker  # Explicit simulator selection; never contact Alpaca in BROKER=sim.
from db.session import build_engine, build_session_factory
from db.health import check_database
from services.strategy_engine.persistence import StrategyPersistence
from db.order_repository import OrderRepository
from db.hypothesis_registry import HypothesisRegistry
from services.reconciliation import ReconciliationService, ReconciliationError
from research_v1.adapter import (catalog_summary as research_catalog_summary,
    evaluate_rule as evaluate_research_rule, evaluate_universe as evaluate_research_universe,
    RULE_STRATEGIES as RESEARCH_RULE_STRATEGIES,
    UNIVERSE_STRATEGIES as RESEARCH_UNIVERSE_STRATEGIES, ResearchInputError)
from research_v1.backtesting.scoreboard import evaluate_catalog as evaluate_research_catalog
from research_v1.backtesting.portfolio_backtest import simulate_portfolio as simulate_research_portfolio
from research_v1.backtesting.portfolio_scoreboard import (
    evaluate_portfolio_catalog as evaluate_research_portfolio_catalog,
    required_warmup as research_required_warmup,
)

if APP_PASSWORD and len(APP_PASSWORD) < 12:
    raise SystemExit("APP_PASSWORD doit faire au moins 12 caractères.")


def broker_status_snapshot():
    """Return secret-free broker health; never mistake simulator for Alpaca Paper."""
    if not SIM:
        return broker.paper_status()
    checked_at = datetime.now(timezone.utc).isoformat()
    try:
        broker.account()
        clock = broker.clock()
        if not isinstance(clock, dict) or not isinstance(clock.get("is_open"), bool):
            raise ValueError("simulator health check failed")
        return {
            "provider": "simulator", "paper_confirmed": False,
            "connection_health": "healthy", "last_successful_check": checked_at,
            "last_check_at": checked_at, "confirmation_basis": "local_deterministic_simulator",
            "message": "Simulateur déterministe actif; aucune connexion Alpaca.",
        }
    except Exception:
        return {
            "provider": "simulator", "paper_confirmed": False,
            "connection_health": "unavailable", "last_successful_check": None,
            "last_check_at": checked_at, "confirmation_basis": "local_deterministic_simulator",
            "message": "Simulateur indisponible.",
        }
@asynccontextmanager
async def lifespan(application):
    # _start is resolved when the ASGI server enters lifespan, after module initialization.
    _start()
    try:
        yield
    finally:
        _stop_scheduler()


app = FastAPI(
    title="Trader Pro",
    docs_url=None,
    redoc_url=None,
    openapi_url=None,
    lifespan=lifespan,
)


class CandleResearchRequest(BaseModel):
    symbol: str
    limit: int = Field(default=250, ge=20, le=5000)
    atr_period: int = Field(default=14, ge=2, le=100)
    volume_period: int = Field(default=20, ge=2, le=200)


class ResearchRuleDryRunRequest(BaseModel):
    symbol: str
    limit: int = Field(default=500, ge=30, le=5000)
    params: dict = Field(default_factory=dict)
    benchmark_symbol: str | None = None
    position: dict | None = None


class ResearchUniverseDryRunRequest(BaseModel):
    symbols: list[str] = Field(min_length=2, max_length=50)
    equity: float = Field(gt=0)
    limit: int = Field(default=500, ge=30, le=5000)
    params: dict = Field(default_factory=dict)
    positions: dict = Field(default_factory=dict)
    fundamentals: dict = Field(default_factory=dict)


class ResearchPortfolioBacktestRequest(BaseModel):
    symbols: list[str] = Field(min_length=2, max_length=10)
    limit: int = Field(default=1000, ge=160, le=2500)
    params: dict = Field(default_factory=dict)
    fundamentals_by_symbol: dict = Field(default_factory=dict)
    initial_cash: float = Field(default=100000.0, gt=0, le=1000000000)
    fee: float = Field(default=0.0005, ge=0.0, le=0.01)
    slippage: float = Field(default=0.0005, ge=0.0, le=0.01)
    benchmark_symbol: str = "SPY"
    warmup: int = Field(default=60, ge=30, le=500)


class ResearchPortfolioScoreboardRequest(BaseModel):
    symbols: list[str] = Field(min_length=3, max_length=10)
    limit: int = Field(default=2000, ge=500, le=2500)
    params_by_strategy: dict = Field(default_factory=dict)
    fundamentals_by_symbol: dict = Field(default_factory=dict)
    initial_cash: float = Field(default=100000.0, gt=0, le=1000000000)
    fee: float = Field(default=0.0005, ge=0.0, le=0.01)
    slippage: float = Field(default=0.0005, ge=0.0, le=0.01)
    benchmark_symbol: str = "SPY"
    warmup: int = Field(default=60, ge=30, le=500)
    test_window: int = Field(default=126, ge=20, le=252)
    min_oos_bars: int = Field(default=756, ge=252, le=1500)
    min_folds: int = Field(default=6, ge=3, le=20)


class ResearchScoreboardRequest(BaseModel):
    symbols: list[str] = Field(min_length=3, max_length=10)
    limit: int = Field(default=1000, ge=160, le=2500)
    split: float = Field(default=0.6, ge=0.5, le=0.8)
    fee: float = Field(default=0.0005, ge=0.0, le=0.01)
    slippage: float = Field(default=0.0005, ge=0.0, le=0.01)
    benchmark_symbol: str = "SPY"
    warmup: int = Field(default=60, ge=30, le=252)
app.include_router(health_router)
basic, LOCK, FAILS = HTTPBasic(auto_error=False), threading.RLock(), {}
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIST = os.path.join(ROOT_DIR, "frontend", "dist")
FRONTEND_INDEX = os.path.join(FRONTEND_DIST, "index.html")
PAGE = open(FRONTEND_INDEX if os.path.isfile(FRONTEND_INDEX) else os.path.join(ROOT_DIR, "page.html"), encoding="utf-8").read()
LOGIN = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "login.html"), encoding="utf-8").read()

# ---------- état et historique complet (service indépendant des routes) ----------
STATE_DIR = os.path.abspath(os.getenv("TRADER_STATE_DIR", "."))
os.makedirs(STATE_DIR, exist_ok=True)
STATE_SERVICE = StateService(
    LIMITS, STRAT, secret=KEY,
    state_path=os.path.join(STATE_DIR, "state.json"),
    history_path=os.path.join(STATE_DIR, "history.jsonl"),
    backup_dir=os.path.join(STATE_DIR, "backups"),
    lock=LOCK,
)
ST = STATE_SERVICE.load()

def save():
    STATE_SERVICE.save(ST)

def hist(kind, msg, **kw):
    STATE_SERVICE.append_history(kind, msg, **kw)

def tail(n):
    return STATE_SERVICE.tail(n)

# ---------- sécurité ----------
def guard_basic(request: Request, c: HTTPBasicCredentials = Depends(basic)):
    ip = security.client_ip(request)
    now = time.time()
    FAILS[ip] = [t for t in FAILS.get(ip, []) if now - t < 600]
    if len(FAILS[ip]) >= 5: raise HTTPException(429, "Trop d’essais, réessaie dans 10 minutes")
    if c is None: raise HTTPException(401, "Identifiants requis", headers={"WWW-Authenticate": "Basic"})
    if not (APP_PASSWORD and secrets.compare_digest(c.password.encode(), APP_PASSWORD.encode())):
        FAILS[ip].append(now); hist("auth", f"Accès refusé depuis {ip}")
        raise HTTPException(401, "Accès refusé", headers={"WWW-Authenticate": "Basic"})
    if not security.is_https(request): raise HTTPException(400, "HTTPS requis")
    if request.method != "GET" and request.headers.get("x-trader") != "1": raise HTTPException(403, "Requête refusée")

SKEY = hashlib.sha256(f"{APP_PASSWORD}|{TOTP_SECRET}|session".encode()).digest()

def client_ip(request):
    return security.client_ip(request)

def guard(request: Request):
    """Session par cookie signé (HttpOnly, Secure, SameSite=Strict) + en-tête anti-CSRF sur les écritures."""
    if not security.is_https(request): raise HTTPException(400, "HTTPS requis")
    if not APP_PASSWORD or not auth.check_token(SKEY, request.cookies.get("sess", ""), float(ST.get("revoke_before", 0))):
        raise HTTPException(401, "Connexion requise")
    if request.method != "GET" and request.headers.get("x-trader") != "1": raise HTTPException(403, "Requête refusée")

app.include_router(create_history_router(guard, tail))
app.include_router(create_dashboard_router(
    guard_dependency=guard, page_html=PAGE, broker=broker, state=ST,
    history_reader=tail, state_lock=LOCK, state_saver=save, history_writer=hist,
    limits=LIMITS, base_url=BASE, simulation=SIM, core_module=core,
    congress_module=congress, thirteen_f_module=thirteen_f,
))

@app.middleware("http")
async def secure_headers(request, call_next):
    r = await call_next(request)
    if request.method != "GET": hist("access", f"{request.method} {request.url.path} → {r.status_code}", ip=client_ip(request))
    r.headers.update({"Cache-Control": "no-store", "X-Frame-Options": "DENY", "X-Content-Type-Options": "nosniff",
        "Strict-Transport-Security": "max-age=31536000",
        "Content-Security-Policy": "default-src 'none'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; worker-src 'self'; manifest-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"})
    return r

@app.exception_handler(broker.BrokerError)
async def broker_error(request, e):
    hist("error", str(e)); return JSONResponse({"detail": str(e)}, status_code=502)

# ---------- logique ----------
def propose(orders, a, pos, clear=True):
    used = 0.0
    if clear: ST["pending"] = {}
    for sym, side, amt in orders:
        why = core.check((sym, side, amt), a, pos, ST["limits"], ST["blocked"], used)
        ST["pending"][uuid.uuid4().hex] = {"sym": sym, "side": side, "amt": amt, "why": why}
        if not why and side == "buy": used += amt
    save()

def create_plan(budget):
    if not ST["targets"]: raise HTTPException(400, "Ajoute d’abord des cibles")
    a, pos, L = broker.account(), broker.positions(), ST["limits"]
    amt = core.size(ST["targets"], min(budget, float(a["cash"])), L["buffer"], L["cap"])[0]
    propose([(t, "buy", v) for t, v in amt.items() if v >= 1], a, pos)
    hist("plan", f"Plan d’achat de {budget:.0f} $", orders=ST["pending"]); return {"ok": True}

def create_rebalance():
    if not ST["targets"]: raise HTTPException(400, "Ajoute d’abord des cibles")
    a, pos, L = broker.account(), broker.positions(), ST["limits"]
    o = core.rebalance(ST["targets"], pos, float(a["equity"]), L["buffer"], L["band"])
    propose(o, a, pos); hist("plan", f"Rééquilibrage : {len(o)} ordre(s)", orders=ST["pending"]); return {"n": len(o)}

def n_today():
    d = time.strftime("%Y-%m-%d")
    return sum(1 for r in tail(500) if r["kind"] == "order" and r["t"].startswith(d))


# PostgreSQL is opt-in in local development. Once DATABASE_URL is supplied,
# startup and strategy proposal staging fail closed if the database/schema is unavailable.
DATABASE_URL = os.getenv("DATABASE_URL", "").strip()
DB_ENGINE = build_engine(DATABASE_URL) if DATABASE_URL else None
DB_SESSION_FACTORY = build_session_factory(DB_ENGINE) if DB_ENGINE is not None else None
DB_PERSISTENCE = StrategyPersistence(DB_SESSION_FACTORY) if DB_SESSION_FACTORY is not None else None
DB_ORDER_REPOSITORY = OrderRepository(DB_SESSION_FACTORY) if DB_SESSION_FACTORY is not None else None
DB_HYPOTHESIS_REGISTRY = HypothesisRegistry(DB_SESSION_FACTORY) if DB_SESSION_FACTORY is not None else None
# Restore the durable operational pause before accepting requests. A database
# read failure aborts startup rather than silently clearing an emergency stop.
if DB_ORDER_REPOSITORY is not None:
    _durable_pause = DB_ORDER_REPOSITORY.get_operational_pause()
    ST["paused"] = bool(_durable_pause["paused"])
    if _durable_pause.get("reason"):
        ST["pause_reason"] = _durable_pause["reason"]

def persist_strategy_order_status(order_id, status, **details):
    if DB_PERSISTENCE is not None:
        DB_PERSISTENCE.update_status(order_id, status, **details)

LIQUIDITY_READER = None
if not SIM and KEY and SECRET:
    from services.providers.alpaca_liquidity import AlpacaLiquiditySnapshot
    LIQUIDITY_READER = AlpacaLiquiditySnapshot(KEY, SECRET)

ORDER_SERVICE = OrderService(
    state=ST, lock=LOCK, save=save, history=hist,
    account_reader=broker.account, positions_reader=broker.positions,
    orders_reader=broker.orders, order_submitter=broker.order,
    order_canceller=broker.cancel, daily_loss=core.daily_loss,
    order_checker=core.check, orders_today_reader=n_today, status_writer=persist_strategy_order_status,
    order_persistence=DB_ORDER_REPOSITORY,
    risk_engine=InstitutionalRiskEngine(),
    risk_decision_writer=(DB_ORDER_REPOSITORY.record_risk_decision if DB_ORDER_REPOSITORY is not None else None),
    operational_pause_writer=(DB_ORDER_REPOSITORY.set_operational_pause if DB_ORDER_REPOSITORY is not None else None),
    operational_pause_reader=(DB_ORDER_REPOSITORY.get_operational_pause if DB_ORDER_REPOSITORY is not None else None),
    liquidity_reader=LIQUIDITY_READER,
    system_safety_reader=(DB_ORDER_REPOSITORY.get_system_safety_state if DB_ORDER_REPOSITORY is not None
                          else lambda: {"status": "DEGRADED", "reason": "PostgreSQL indisponible"}),
    instrument_reader=broker.asset_metadata if not SIM else (lambda symbol: {
        "symbol": str(symbol).upper(), "asset_class": "us_equity", "active": True, "tradable": True}),
)


def do_approve(oid):
    try:
        return ORDER_SERVICE.approve(oid)
    except OrderServiceError as exc:
        raise HTTPException(exc.status_code, exc.detail) from exc

def reject_order(oid):
    return ORDER_SERVICE.reject(oid)

def cancel_order(oid):
    return ORDER_SERVICE.cancel(oid)

def toggle_pause():
    return ORDER_SERVICE.toggle_pause()

app.include_router(create_orders_router(
    guard_dependency=guard,
    orders_reader=ORDER_SERVICE.list_orders,
    plan_creator=create_plan,
    rebalance_creator=create_rebalance,
    approval_handler=do_approve,
    rejection_handler=reject_order,
    cancellation_handler=cancel_order,
    pause_handler=toggle_pause,
))

# ---------- phase 2 / 3 : intelligence et décision ----------
def inst_counts():
    agg = {}
    for v in ST["inst"].values():
        for t, c in v["counts"].items():
            a = agg.setdefault(t, {"new": 0, "up": 0, "down": 0, "sold": 0})
            for k in a: a[k] += c.get(k, 0)
    return agg

# Wrap the configured daily-bars reader in the same provider boundary used for
# future failover. In SIM this is explicitly labelled as simulation; no second
# real provider is implied or configured here.
_market_data_readers = [("simulation" if SIM else "alpaca", broker.bars3)]
# Twelve Data is an optional, independent secondary source. It is activated only
# when the operator explicitly supplies its key; no undocumented public feed is used.
_ohlcv_reader = None
if not SIM and os.getenv("TWELVEDATA_API_KEY", "").strip():
    from services.providers.twelvedata import TwelveDataDailyBars
    _market_data_readers.append(("twelvedata", TwelveDataDailyBars()))
    # OHLCV is a separate opt-in reader: the legacy ProviderChain contract
    # remains close/volume-only and cannot silently discard candle geometry.
    _ohlcv_reader = TwelveDataDailyBars(include_ohlc=True)
MARKET_DATA_PROVIDER_CHAIN = ProviderChain(_market_data_readers)
MARKET_DATA_SERVICE = MarketDataService(MARKET_DATA_PROVIDER_CHAIN, broker.news,
                                        ohlcv_reader=_ohlcv_reader,
                                        ttl_seconds=60, max_entries=256)
QUANTITATIVE_ENGINE = QuantitativeEngine()

@app.get("/api/market-data/providers")
def market_data_provider_diagnostics(request: Request, _=Depends(guard)):
    """Authenticated, secret-free operational view of daily-bar providers."""
    snapshot = MARKET_DATA_PROVIDER_CHAIN.health_snapshot()
    providers = {}
    for name, values in snapshot["providers"].items():
        providers[name] = {
            **values,
            "last_attempt_at": values["last_attempt_at"].isoformat() if values["last_attempt_at"] else None,
            "last_success_at": values["last_success_at"].isoformat() if values["last_success_at"] else None,
        }
    return {
        "configured_provider_count": len(providers),
        "providers": providers,
        "last_selected_source": snapshot["last_selected_source"],
        "last_selection_at": snapshot["last_selection_at"].isoformat() if snapshot["last_selection_at"] else None,
        "note": ("Source secondaire Twelve Data configurée mais non encore validée sur données réelles." if "twelvedata" in providers else "Aucune source secondaire réelle configurée; définir TWELVEDATA_API_KEY pour activer Twelve Data."),
    }


def analyze(syms):
    held, inst, out = {p["symbol"] for p in broker.positions()}, inst_counts(), []
    for s in syms:
        try:
            bars_data = MARKET_DATA_SERVICE.daily_bars(s, 250)
            # Live/Paper market data must be timestamped and fresh. The local
            # deterministic simulator has no exchange clock and is explicitly exempt.
            if not SIM:
                require_fresh_daily_bars(bars_data, calendar_name="XNYS")
            news_data = MARKET_DATA_SERVICE.news(s, 15)
            closes, vols, heads = list(bars_data.closes), list(bars_data.volumes), list(news_data.headlines)
        except MarketDataError as e:
            out.append({"symbol": s, "action": "erreur", "score": None, "why": [str(e)]}); continue
        sig = {"tech": scoring.tech_signal(closes), "news": sentiment.score(heads),
               "inst": scoring.inst_signal(s, inst), "congress": ST["congress"].get(s)}
        try:
            quant = QUANTITATIVE_ENGINE.evaluate(closes, sig, held=s in held)
        except ValueError as e:
            out.append({"symbol": s, "action": "erreur", "score": None, "why": [str(e)]}); continue
        if quant.score is None:
            out.append({"symbol": s, "action": "garder", "score": None, "why": list(quant.reasons)}); continue
        act, why = quant.action, list(quant.reasons)
        flags = anomaly.unusual(closes, vols); why = why + ["⚠ " + x for x in flags]
        out.append({"symbol": s, "action": act, "score": quant.score, "why": why, "signals": sig, "flags": flags, "vol": quant.snapshot.daily_volatility, "price": closes[-1]})
        hist("decision", f"{s} : {act} ({comb[0]})", why=why, signals=sig)
    return out


# ---------- phase 4 : performance, impôts, alertes, planificateur ----------
PORTFOLIO_SERVICE = PortfolioService(broker.fills, broker.positions, FEE_PCT, FEE_MIN)

app.include_router(create_portfolio_router(
    guard,
    PORTFOLIO_SERVICE.summary,
    PORTFOLIO_SERVICE.realized,
    PORTFOLIO_SERVICE.tax,
))

# Strategy Engine -> validated market data -> portfolio risk -> pending order.
# Pending orders can only reach the broker through OrderService.approve(), which
# performs a second live risk check. No direct broker dependency exists here.
STRATEGY_MANAGER = StrategyManager(audit_logger=lambda event, detail: hist(event, detail))
for _strategy in (MomentumStrategy(), TrendFollowingStrategy(), MeanReversionStrategy(), BreakoutStrategy()):
    STRATEGY_MANAGER.register(_strategy)
    STRATEGY_MANAGER.activate(_strategy.get_metadata().strategy_id)


def strategy_market_closes(symbol):
    data = MARKET_DATA_SERVICE.daily_bars(symbol, 250)
    require_fresh_daily_bars(data, calendar_name="XNYS", require_timestamps=not SIM)
    return data.closes


STRATEGY_PIPELINE = StrategyExecutionPipeline(
    manager=STRATEGY_MANAGER, state=ST, lock=LOCK, save=save, history=hist,
    account_reader=broker.account, positions_reader=broker.positions,
    bars_reader=strategy_market_closes, orders_today_reader=n_today,
    paper_mode=(SIM or "paper-api" in BASE), persistence=DB_PERSISTENCE,
    operational_pause_reader=(DB_ORDER_REPOSITORY.get_operational_pause if DB_ORDER_REPOSITORY is not None else None),
    system_safety_reader=(DB_ORDER_REPOSITORY.get_system_safety_state if DB_ORDER_REPOSITORY is not None else None),
)

def _research_ohlcv(symbol: str, limit: int):
    """Fetch OHLCV only through the validated market-data boundary."""
    data = MARKET_DATA_SERVICE.daily_ohlcv(symbol, limit)
    legacy = DailyBars(data.symbol, data.closes, data.volumes, data.fetched_at,
                       source=data.source, timestamps=data.timestamps)
    require_fresh_daily_bars(legacy, calendar_name="XNYS", require_timestamps=True)
    return data


@app.post("/api/research/candles/analysis")
def research_candle_analysis(payload: CandleResearchRequest, _=Depends(guard)):
    """Read-only OHLCV candle study; no strategy activation and no broker orders."""
    try:
        data = _research_ohlcv(payload.symbol, payload.limit)
        bars = [
            {"open": o, "high": h, "low": low, "close": c, "volume": v,
             **({"timestamp": stamp} if data.timestamps else {})}
            for o, h, low, c, v, stamp in zip(
                data.opens, data.highs, data.lows, data.closes, data.volumes,
                data.timestamps or (None,) * data.count)
        ]
        result = analyze_candles(bars, atr_period=payload.atr_period,
                                 volume_period=payload.volume_period)
        # Réutilise le détecteur avancé existant (36 figures), sans dupliquer
        # ses règles ni introduire de dépendance vers le broker ou l'exécution.
        advanced_bars = tuple(SimpleNamespace(o=o, h=h, l=low, c=c, v=v)
                              for o, h, low, c, v in zip(
                                  data.opens, data.highs, data.lows,
                                  data.closes, data.volumes))
        advanced_patterns = scan_advanced_candles(advanced_bars, lookback=5)
        return {"symbol": data.symbol, "timeframe": "1day", "source": data.source,
                "fetched_at": data.fetched_at, "mode": "CANDLE_RESEARCH_ONLY",
                "execution": "NONE", "orders_created": 0,
                "strategies_activated": 0, "profitability_guaranteed": False,
                "analysis": asdict(result),
                "advanced_patterns": advanced_patterns,
                "advanced_pattern_count": len(advanced_patterns),
                "advanced_pattern_catalog_size": 36,
                "advanced_scan_lookback": 5}
    except MarketDataError as exc:
        raise HTTPException(503, str(exc)) from exc
    except CandleAnalysisError as exc:
        raise HTTPException(422, str(exc)) from exc


@app.get("/api/research/strategies/catalog")
def research_strategy_catalog(_=Depends(guard)):
    """List the isolated V1 research catalogue; no strategy is activated."""
    return {**research_catalog_summary(), "execution": "DRY_RUN_ONLY",
            "orders_created": 0, "profitability_claim": False}


@app.post("/api/research/strategies/{kind}/dry-run")
def research_strategy_dry_run(kind: str, payload: ResearchRuleDryRunRequest, _=Depends(guard)):
    if kind not in RESEARCH_RULE_STRATEGIES:
        raise HTTPException(400, "Cette route accepte uniquement les 43 stratégies par titre")
    try:
        bars = _research_ohlcv(payload.symbol, payload.limit)
        benchmark = _research_ohlcv(payload.benchmark_symbol, payload.limit) if payload.benchmark_symbol else None
        return evaluate_research_rule(kind, payload.symbol, bars, params=payload.params,
                                      position=payload.position, benchmark=benchmark)
    except MarketDataError as exc:
        raise HTTPException(503, str(exc)) from exc
    except ResearchInputError as exc:
        raise HTTPException(400, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc


@app.post("/api/research/strategies/scoreboard")
def research_strategy_scoreboard(payload: ResearchScoreboardRequest, _=Depends(guard)):
    """Evaluate the 43 per-symbol rules OOS; this never activates or prunes strategies."""
    symbols = list(dict.fromkeys(str(x).strip().upper() for x in payload.symbols))
    if len(symbols) != len(payload.symbols):
        raise HTTPException(400, "L'univers contient des symboles dupliqués")
    try:
        bars = {symbol: _research_ohlcv(symbol, payload.limit) for symbol in symbols}
        benchmark = _research_ohlcv(payload.benchmark_symbol, payload.limit)
        from research_v1.adapter import to_research_bars
        data = {symbol: to_research_bars(item) for symbol, item in bars.items()}
        benchmark_bars = to_research_bars(benchmark)
        benches = {symbol: benchmark_bars for symbol in symbols}
        report = evaluate_research_catalog(data, benches=benches, split=payload.split,
            fee=payload.fee, slip=payload.slippage, warmup=payload.warmup)
        return {**report, "mode": "HISTORICAL_OOS_RESEARCH",
                "execution": "NONE", "strategies_activated": 0,
                "portfolio_strategies_included": False,
                "profitability_guaranteed": False}
    except MarketDataError as exc:
        raise HTTPException(503, str(exc)) from exc
    except ResearchInputError as exc:
        raise HTTPException(400, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc


@app.post("/api/research/portfolio-strategies/{kind}/backtest")
def research_portfolio_strategy_backtest(kind: str, payload: ResearchPortfolioBacktestRequest, _=Depends(guard)):
    """Historical multi-asset simulation only; no broker, order, or strategy activation."""
    if kind not in RESEARCH_UNIVERSE_STRATEGIES:
        raise HTTPException(400, "Type de stratégie de portefeuille inconnu")
    symbols = list(dict.fromkeys(str(x).strip().upper() for x in payload.symbols))
    if len(symbols) != len(payload.symbols):
        raise HTTPException(400, "L'univers contient des symboles dupliqués")
    try:
        raw = {symbol: _research_ohlcv(symbol, payload.limit) for symbol in symbols}
        benchmark = _research_ohlcv(payload.benchmark_symbol, payload.limit)
        from research_v1.adapter import to_research_bars
        data = {symbol: to_research_bars(item) for symbol, item in raw.items()}
        bench = to_research_bars(benchmark)
        benches = {symbol: bench for symbol in symbols}
        effective_warmup = max(payload.warmup, research_required_warmup(kind, payload.params))
        result = simulate_research_portfolio(kind, data, params=payload.params,
            fundamentals=payload.fundamentals_by_symbol or None,
            benchmarks=benches, initial_cash=payload.initial_cash, fee=payload.fee,
            slip=payload.slippage, warmup=effective_warmup)
        return {**result, "requested_warmup": payload.warmup,
                "effective_warmup": effective_warmup,
                "execution": "HISTORICAL_SIMULATION_ONLY",
                "strategies_activated": 0, "profitability_guaranteed": False}
    except MarketDataError as exc:
        raise HTTPException(503, str(exc)) from exc
    except ResearchInputError as exc:
        raise HTTPException(400, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc


@app.post("/api/research/portfolio-strategies/scoreboard")
def research_portfolio_strategy_scoreboard(payload: ResearchPortfolioScoreboardRequest, _=Depends(guard)):
    """Walk-forward OOS research scoreboard for all seven portfolio strategies; no activation or orders."""
    symbols = list(dict.fromkeys(str(x).strip().upper() for x in payload.symbols))
    if len(symbols) != len(payload.symbols):
        raise HTTPException(400, "L'univers contient des symboles dupliqués")
    if not isinstance(payload.params_by_strategy, dict):
        raise HTTPException(422, "params_by_strategy doit être un objet")
    try:
        raw = {symbol: _research_ohlcv(symbol, payload.limit) for symbol in symbols}
        benchmark = _research_ohlcv(payload.benchmark_symbol, payload.limit)
        from research_v1.adapter import to_research_bars
        data = {symbol: to_research_bars(item) for symbol, item in raw.items()}
        benchmark_bars = to_research_bars(benchmark)
        benches = {symbol: benchmark_bars for symbol in symbols}
        report = evaluate_research_portfolio_catalog(
            data, benchmarks=benches, fundamentals_by_symbol=payload.fundamentals_by_symbol or None,
            params_by_strategy=payload.params_by_strategy, initial_cash=payload.initial_cash,
            fee=payload.fee, slip=payload.slippage,
            warmup=payload.warmup, test_window=payload.test_window,
            min_oos_bars=payload.min_oos_bars, min_folds=payload.min_folds)
        return {**report, "benchmark_symbol": payload.benchmark_symbol.upper(),
                "data_source": "validated_daily_ohlcv", "profitability_guaranteed": False}
    except MarketDataError as exc:
        raise HTTPException(503, str(exc)) from exc
    except ResearchInputError as exc:
        raise HTTPException(400, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc


@app.post("/api/research/portfolio-strategies/{kind}/dry-run")
def research_portfolio_strategy_dry_run(kind: str, payload: ResearchUniverseDryRunRequest, _=Depends(guard)):
    if kind not in RESEARCH_UNIVERSE_STRATEGIES:
        raise HTTPException(400, "Type de stratégie de portefeuille inconnu")
    symbols = list(dict.fromkeys(str(x).strip().upper() for x in payload.symbols))
    if len(symbols) != len(payload.symbols):
        raise HTTPException(400, "L'univers contient des symboles dupliqués")
    try:
        bars = {symbol: _research_ohlcv(symbol, payload.limit) for symbol in symbols}
        return evaluate_research_universe(kind, bars, params=payload.params,
            positions=payload.positions, equity=payload.equity, fundamentals=payload.fundamentals)
    except MarketDataError as exc:
        raise HTTPException(503, str(exc)) from exc
    except ResearchInputError as exc:
        raise HTTPException(400, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc


STRATEGY_SERVICE = StrategyService(
    state=ST, lock=LOCK, save=save, history=hist,
    paper_mode=("paper-api" in BASE),
)

app.include_router(create_strategy_router(
    guard_dependency=guard,
    signal_analyzer=analyze,
    strategy_service=STRATEGY_SERVICE,
    pipeline_runner=STRATEGY_PIPELINE.run,
))

def notify_once(key, msg):
    day = time.strftime("%Y-%m-%d")
    if ST["alerted"].get(key) != day:
        ST["alerted"][key] = day; save(); hist("alert", msg); notify.send("⚠️ " + msg)

def monitor_basic():
    a = broker.account(); eq = float(a["equity"]); ST["peak"] = max(float(ST.get("peak") or 0), eq)
    for m in portfolio.risk_alerts(eq, float(a.get("last_equity") or 0), ST["peak"], broker.positions(), ST["limits"]):
        notify_once(m.split(" :")[0], m)
        if m.startswith(("Perte", "Drawdown")) and not ST["paused"]:
            ST["paused"] = True; save(); hist("alert", "ARRÊT D’URGENCE automatique : " + m); notify.send("🛑 Arrêt d’urgence : " + m)

def finish(label):
    """Notifie les propositions ; exécute seul uniquement sur le compte paper et si l'option est active."""
    n = sum(1 for o in ST["pending"].values() if not o["why"]); sent = 0
    if ST["strategy"]["auto_execute"] and "paper-api" in BASE:
        for oid, o in list(ST["pending"].items()):
            if not o["why"]:
                try: do_approve(oid); sent += 1
                except HTTPException: pass
    hist("schedule", f"{label} : {n} proposition(s), {sent} exécutée(s) automatiquement")
    if n: notify.send(f"📊 {label} : {n} proposition(s)" + (f", {sent} exécutée(s) (paper)" if sent else " à valider dans le tableau de bord"))

def scan(S):
    rows, a, pos = analyze(S["watchlist"]), broker.account(), broker.positions()
    held, orders = {p["symbol"]: float(p["market_value"]) for p in pos}, []
    L = ST["limits"]; bearish = L["regime_filter"] >= 1 and risklib.regime(cbars("SPY")) == "baissier"
    for r in rows:
        if r["action"] == "acheter":
            amt = risklib.vol_size(float(a["equity"]), r.get("price") or 0, r.get("vol"), L["risk_per_trade"], L["stop_k"], L["max_pos"])
            amt = min(float(S["trade_amount"]), amt) if amt else float(S["trade_amount"])
            if bearish: hist("risk", f"Achat {r['symbol']} ignoré : marché baissier")
            elif (r.get("price") or 0) < L["min_price"]: hist("risk", f"Achat {r['symbol']} ignoré : prix sous {L['min_price']:g} $")
            else: orders.append((r["symbol"], "buy", round(amt, 2)))
        elif r["action"] == "vendre" and r["symbol"] in held: orders.append((r["symbol"], "sell", round(held[r["symbol"]], 2)))
    with LOCK: propose(orders, a, pos, clear=False)
    finish("Analyse planifiée")

def rebalance_job():
    a, pos, L = broker.account(), broker.positions(), ST["limits"]
    o = core.rebalance(ST["targets"], pos, float(a["equity"]), L["buffer"], L["band"])
    with LOCK: propose(o, a, pos, clear=False)
    finish("Rééquilibrage planifié")

SCHEDULER_STOP = threading.Event()
SCHEDULER_LOCK = threading.Lock()
SCHEDULER_THREAD = None


def scheduler():
    while not SCHEDULER_STOP.wait(60):
        try:
            BEAT["t"] = time.time(); maybe_backup()
            S = ST["strategy"]
            if KEY or SIM: monitor()
            if not S["enabled"]: continue
            if not broker.clock()["is_open"] or ST["paused"]: continue
            now = time.time()
            if S["watchlist"] and now - ST["last"].get("scan", 0) >= S["scan_minutes"] * 60:
                ST["last"]["scan"] = now; save(); scan(S)
            if ST["targets"] and now - ST["last"].get("rebal", 0) >= S["rebalance_days"] * 86400:
                ST["last"]["rebal"] = now; save(); rebalance_job()
        except Exception as e:
            hist("error", f"Planificateur : {e}")


def _start_scheduler():
    global SCHEDULER_THREAD
    with SCHEDULER_LOCK:
        if SCHEDULER_THREAD is not None and SCHEDULER_THREAD.is_alive():
            return
        SCHEDULER_STOP.clear()
        SCHEDULER_THREAD = threading.Thread(target=scheduler, name="trader-pro-scheduler", daemon=True)
        SCHEDULER_THREAD.start()


def _stop_scheduler():
    global SCHEDULER_THREAD
    with SCHEDULER_LOCK:
        thread = SCHEDULER_THREAD
        if thread is None:
            return
        SCHEDULER_STOP.set()
    if thread is not threading.current_thread():
        thread.join(timeout=5)
    with SCHEDULER_LOCK:
        if SCHEDULER_THREAD is thread and not thread.is_alive():
            SCHEDULER_THREAD = None


def _start():
    if DB_ENGINE is not None:
        readiness = check_database(DB_ENGINE)
        if not readiness["reachable"]:
            raise RuntimeError("DATABASE_URL est configurée mais PostgreSQL est inaccessible")
        # Do not auto-create schema: migrations must be applied explicitly with Alembic.
        if DB_PERSISTENCE is None:
            raise RuntimeError("Persistance PostgreSQL indisponible")
        restored = DB_PERSISTENCE.restore_pending()
        with LOCK:
            # With PostgreSQL enabled, its lifecycle state is authoritative for
            # strategy-generated proposals; discard stale JSON copies first.
            pending_state = ST.setdefault("pending", {})
            for oid in [key for key, value in pending_state.items()
                        if value.get("source") == "strategy_engine"]:
                pending_state.pop(oid, None)
            pending_state.update(restored)
            save()
        hist("database", f"PostgreSQL prêt ; {len(restored)} proposition(s) Paper restaurée(s)")
    _start_scheduler()


@app.post("/api/reconciliation/run")
def run_paper_reconciliation(_=Depends(guard)):
    """Manual, authenticated Paper reconciliation; it never submits or retries orders."""
    if DB_ORDER_REPOSITORY is None:
        raise HTTPException(503, "Persistance PostgreSQL non configurée")
    try:
        opening_cash = os.getenv("PAPER_OPENING_CASH")
        report = ReconciliationService(DB_ORDER_REPOSITORY, broker, DB_PERSISTENCE).run(
            opening_cash=opening_cash,
            cash_tolerance=os.getenv("PAPER_RECONCILIATION_CASH_TOLERANCE", "0.05"),
            quantity_tolerance=os.getenv("PAPER_RECONCILIATION_QTY_TOLERANCE", "0.00001"),
        )
        financial = report.get("financial_reconciliation", {})
        if financial.get("status") == "mismatch":
            with LOCK:
                ST["paused"] = True
                save()
            hist("critical", "Arrêt d'urgence : écart financier courtier / grand livre Paper", report=financial)
    except ReconciliationError as exc:
        hist("reconciliation_error", str(exc))
        raise HTTPException(502, str(exc)) from exc
    hist("reconciliation", "Réconciliation Paper terminée", report=report)
    return report


@app.get("/api/system/database")
def database_status(_=Depends(guard)):
    if DB_ENGINE is None:
        return {"configured": False, "reachable": False, "mode": "JSON_ONLY",
                "note": "Configurer DATABASE_URL et appliquer les migrations Alembic pour activer la persistance."}
    result = check_database(DB_ENGINE)
    result["mode"] = "POSTGRESQL"
    if result["reachable"]:
        result.update(DB_PERSISTENCE.health())
    return result

# ---------- phases 5 et 6 : connexion, santé, pages du tableau de bord ----------
BEAT = {"t": time.time(), "bk": 0.0}
app.state.beat = BEAT

app.include_router(create_analytics_router(
    guard_dependency=guard,
    broker=broker,
    state=ST,
    history_reader=tail,
    history_writer=hist,
    beat=BEAT,
    totp_enabled=bool(TOTP_SECRET),
    mode="simulation" if SIM else "paper" if "paper-api" in BASE else "RÉEL",
    sentiment=sentiment,
    thirteen_f=thirteen_f,
    backtest=backtest,
    risklib=risklib,
    broker_status_reader=broker_status_snapshot,
))

def maybe_backup():
    if time.time() - BEAT["bk"] >= 86400:
        BEAT["bk"] = time.time(); store.backup(
            [STATE_SERVICE.state_path, STATE_SERVICE.history_path],
            backup_dir=STATE_SERVICE.backup_dir,
        ); hist("backup", "Sauvegarde automatique")

app.include_router(create_auth_router(
    guard_dependency=guard,
    app_password=APP_PASSWORD,
    totp_secret=TOTP_SECRET,
    session_key=SKEY,
    failures=FAILS,
    client_ip=client_ip,
    history_writer=hist,
    notifier=notify.send,
    token_factory=auth.make_token,
    state=ST,
    state_lock=LOCK,
    save_state=save,
    login_page_renderer=lambda: HTMLResponse(LOGIN),
    totp_verifier=auth.verify_totp,
))

# Safety-state transitions require a separate, out-of-band operator identity
# and mandatory TOTP. The ordinary application password is never sufficient.
OPERATOR_PASSWORD = os.getenv("TRADER_OPERATOR_PASSWORD", "")
OPERATOR_TOTP_SECRET = os.getenv("TRADER_OPERATOR_TOTP_SECRET", "")
app.include_router(create_operator_router(
    repository=DB_ORDER_REPOSITORY,
    operator_password=OPERATOR_PASSWORD,
    operator_totp_secret=OPERATOR_TOTP_SECRET,
    totp_verifier=auth.verify_totp,
    totp_counter_verifier=auth.matching_totp_counter,
    history_writer=hist,
    client_ip=client_ip,
))

# ---------- mesures de risque avancées ----------
def cbars(sym):
    """Return validated close-only history for legacy V1 signal consumers."""
    return list(validated_daily_closes(
        MARKET_DATA_SERVICE, sym, limit=250, calendar_name="XNYS",
        require_timestamps=not SIM,
    ))


def risk_bars(sym):
    """Preserve validated exchange timestamps for portfolio-risk alignment."""
    return validated_daily_bar_series(
        MARKET_DATA_SERVICE, sym, limit=250, calendar_name="XNYS",
        require_timestamps=not SIM,
    )


RISK_SERVICE = RiskService(
    account_reader=broker.account,
    positions_reader=broker.positions,
    state_reader=lambda: ST,
    market_bars_reader=cbars,
    orders_today_reader=n_today,
    broker_error_type=broker.BrokerError,
    market_history_reader=risk_bars,
)

def risk_snapshot():
    return RISK_SERVICE.snapshot()

app.include_router(create_risk_router(guard, risk_snapshot))

# Research registration is durable only when PostgreSQL is configured; fail closed otherwise.
class _UnavailableHypothesisRegistry:
    def preregister(self, **kwargs):
        raise HTTPException(503, "Persistance PostgreSQL indisponible : registre de recherche désactivé")
    def list_families(self, limit=50):
        raise HTTPException(503, "Persistance PostgreSQL indisponible : registre de recherche désactivé")

app.include_router(create_research_registry_router(
    guard, DB_HYPOTHESIS_REGISTRY or _UnavailableHypothesisRegistry()))

def enforce_stops(pos):
    L, held, orders, today, pend = ST["limits"], set(), [], time.strftime("%Y-%m-%d"), {(o["sym"], o["side"]) for o in ST["pending"].values()}
    for p in pos:
        s, px, entry = p["symbol"], float(p["current_price"]), float(p["avg_entry_price"])
        held.add(s); ST["highs"][s] = hi = max(ST["highs"].get(s, 0.0), px, entry)
        why = risklib.stops(entry, px, hi, L)
        if why and (s, "sell") not in pend and ST["alerted"].get("stop:" + s) != today:
            orders.append((s, "sell", round(float(p["market_value"]), 2))); notify_once("stop:" + s, f"{s} : {why} atteint ({px:.2f} $)")
    for s in list(ST["highs"]):
        if s not in held: del ST["highs"][s]
    if orders:
        a = broker.account()
        with LOCK: propose(orders, a, pos, clear=False)
        finish("Protection (stops)")
    save()

def monitor():
    monitor_basic()
    a, pos, L = broker.account(), broker.positions(), ST["limits"]
    eq, wk = float(a["equity"]), time.strftime("%G-%V")
    if ST.get("week", {}).get("id") != wk: ST["week"] = {"id": wk, "eq": eq}; save()
    w0 = ST["week"]["eq"]
    if w0 and (eq - w0) / w0 * 100 < -L["max_weekly_loss"] and not ST["paused"]:
        ST["paused"] = True; save(); hist("alert", "ARRÊT D’URGENCE : perte hebdomadaire maximale atteinte")
        notify.send("🛑 Perte hebdomadaire maximale atteinte : trading en pause")
    enforce_stops(pos)


# Phase 10: serve the React PWA build when it exists. Until the frontend is
# compiled, the proven legacy dashboard remains the safe fallback. Static
# assets are served separately; authenticated API responses are never cached.
if os.path.isfile(FRONTEND_INDEX):
    assets_dir = os.path.join(FRONTEND_DIST, "assets")
    if os.path.isdir(assets_dir):
        app.mount("/assets", StaticFiles(directory=assets_dir), name="frontend-assets")
    @app.get("/manifest.webmanifest", include_in_schema=False)
    def frontend_manifest():
        return FileResponse(os.path.join(FRONTEND_DIST, "manifest.webmanifest"), media_type="application/manifest+json")
    @app.get("/sw.js", include_in_schema=False)
    def frontend_service_worker():
        return FileResponse(os.path.join(FRONTEND_DIST, "sw.js"), media_type="application/javascript", headers={"Cache-Control": "no-cache"})
    @app.get("/offline.html", include_in_schema=False)
    def frontend_offline():
        return FileResponse(os.path.join(FRONTEND_DIST, "offline.html"), media_type="text/html; charset=utf-8")
    @app.get("/icon-192.png", include_in_schema=False)
    def frontend_icon_192():
        return FileResponse(os.path.join(FRONTEND_DIST, "icon-192.png"), media_type="image/png")
    @app.get("/icon-512.png", include_in_schema=False)
    def frontend_icon_512():
        return FileResponse(os.path.join(FRONTEND_DIST, "icon-512.png"), media_type="image/png")
