# Trader Pro 2.0 — R49

## Objectif
Réduire les changements excessifs de paramètres entre fenêtres Walk-Forward.

## Modifications
- Ajout de `parameter_switch_penalty` (défaut 0,10 ; plage autorisée 0 à 10).
- Mesure de distance normalisée entre deux configurations, sur la grille de candidats fournie : valeurs numériques ramenées à l'étendue observée ; catégories et clés absentes traitées comme changements.
- À partir de la deuxième fenêtre, le score de sélection devient : score de validation moins pénalité de distance par rapport aux paramètres sélectionnés à la fenêtre précédente.
- Le rapport expose le score brut, la distance, la pénalité et le score ajusté pour chaque candidat éligible et la configuration retenue.
- La première fenêtre n'est pas pénalisée, car aucune configuration précédente n'existe.
- Ajout de tests pour la distance normalisée et le rejet des pénalités invalides.

## Validation locale
- `BROKER=sim pytest -q` : **801 passed, 11 skipped, 202 subtests passed**.
- `BROKER=sim python -m unittest discover -q` : **719 tests OK**.
- `python -m compileall -q .` : code retour 0.
- `node --check frontend/public/sw.js` : code retour 0.
- 2 fichiers JSON : parsing valide.
- Archive ZIP : intégrité vérifiée après création.

## Limites
- La pénalité est un régularisateur de continuité, pas une preuve de robustesse statistique. Sa valeur doit être calibrée sans utiliser les fenêtres OOS finales.
- Elle ne simule pas encore un portefeuille continu et ne transporte pas les positions entre fenêtres.
- Le système ne génère pas automatiquement de nouveaux candidats.
- Les résultats dépendent des données, du traitement des événements de marché et des hypothèses de coûts.
- PostgreSQL/Neon et Alpaca Paper n'ont pas été validés dans ce lot.
- Aucun accès broker, ordre, activation ou capital autorisé ; aucune rentabilité n'est démontrée.
