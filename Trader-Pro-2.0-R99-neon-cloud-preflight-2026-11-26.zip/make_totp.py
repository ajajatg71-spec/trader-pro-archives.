"""Génère un secret TOTP. Saisis-le à la main dans une appli d'authentification, puis mets-le dans TOTP_SECRET."""
import base64, os
s = base64.b32encode(os.urandom(20)).decode().rstrip("=")
print("TOTP_SECRET =", s)
print("Dans l'appli d'authentification : ajouter un compte > saisir une clé > type basé sur l'heure.")
