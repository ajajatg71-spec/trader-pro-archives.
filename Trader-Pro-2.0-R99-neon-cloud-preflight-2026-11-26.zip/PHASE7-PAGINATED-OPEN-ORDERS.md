# Phase 7 — pagination des ordres ouverts et couverture de réconciliation

## Changement

Le connecteur Alpaca `broker.orders(status, limit)` traite désormais `limit` comme un plafond total et récupère les pages successives par `page_token`, avec une taille maximale de 500 éléments par requête.

Garde-fous :
- limite totale autorisée : 1 à 10 000 ordres ;
- plafond de 20 pages ;
- chaque élément doit être un objet muni d'un identifiant broker ;
- identifiants répétés entre pages refusés ;
- payload non-listé refusé ;
- si le plafond de pages est atteint avant une page incomplète, la lecture échoue plutôt que de retourner un snapshot partiel comme complet.

Le processus d'activation du kill switch demande maintenant jusqu'à 10 000 ordres ouverts. À la limite, le rapport signale explicitement que le snapshot peut être tronqué. Les annulations demeurent des demandes, jamais des confirmations d'état terminal.

Le service de réconciliation accepte également un plafond d'ordres jusqu'à 10 000 et conserve le drapeau `truncated_order_snapshot` lorsque la limite est atteinte. Les absences dans un snapshot potentiellement tronqué ne justifient jamais une nouvelle soumission.

## Tests ajoutés

- récupération de plusieurs pages et passage du dernier ID comme `page_token` ;
- rejet des identifiants dupliqués entre pages ;
- rejet d'un payload de page invalide ;
- rejet d'une limite non autorisée ;
- vérification que le kill switch demande le snapshot étendu.

## Validation locale

- `python -m pytest -q` : 433 passed, 6 skipped, 88 subtests passed.
- `python -m unittest discover -q` : 429 tests passed.
- `python -m compileall -q .` : réussi.
- migration Alembic SQLite : réussie jusqu'à `f3b8c2d91a64` (head).
- import FastAPI en simulation : 35 routes.
- import FastAPI avec configuration Alpaca Paper fictive : 35 routes.

## Limites non levées

Aucun appel réseau authentifié Alpaca Paper n'a été exécuté. Les tests de pagination sont simulés. Les six tests PostgreSQL sont ignorés car aucune instance PostgreSQL n'est configurée. Une limite de 10 000 ordres reste un plafond explicite : si elle est atteinte, le système doit traiter le snapshot comme possiblement incomplet et exiger une investigation/réconciliation supplémentaire.
