# Trade Pro 7 — rapport de fusion

Date : 21 novembre 2026

## Sources intégrées

- Base principale : Trader Pro 2.0 R5 OHLCV.
- Source secondaire : `App-Creator (1).zip`, uniquement pour les évolutions compatibles et utiles.

## Stratégie de fusion

R5 est conservée comme base car elle contient les ajouts OHLCV et l'analyse des chandeliers, ainsi que les corrections de sécurité de sélection du courtier. Les éléments de la seconde archive n'ont pas été copiés aveuglément : certaines parties étaient plus anciennes ou incompatibles.

Éléments repris de la seconde archive :

- Connecteur Alpaca Paper renforcé : vérification de compte authentifié, statut de compte et drapeaux de blocage, validation stricte de l'hôte Paper, refus des redirections, politique de retry différenciée, traitement fail-closed des mutations dont le résultat est incertain, rapprochement par `client_order_id` sans renvoi automatique aveugle.
- État de santé du courtier exposé sans secret dans `/api/health`, avec distinction explicite entre simulateur local et compte Alpaca Paper réellement confirmé.
- Tests de sécurité du connecteur Paper repris et adaptés à la politique explicite `BROKER=sim` / `BROKER=alpaca` de R5.

Éléments volontairement non repris :

- La configuration secondaire qui basculait implicitement en simulation si les clés étaient absentes, même lorsque `BROKER=alpaca` était demandé. La politique explicite et fail-closed de R5 est conservée.
- L'ancien code de marché qui supprimait le contrat OHLCV complet et son adaptateur Twelve Data.
- Les anciens fichiers frontend qui dépendaient d'un préfixe de déploiement Replit non présent dans le frontend R5.
- Les fichiers d'état, historiques, sauvegardes et caches issus de l'espace App-Creator. Ils ne sont pas fusionnés dans un paquet source afin de ne pas embarquer de données d'exécution ou d'historique potentiellement privées.

## Vérifications effectuées sur Trade Pro 7

- `python -m pytest -q -rs` : **663 passed, 11 skipped, 202 subtests passed**, zéro échec.
- `python -m compileall -q .` : réussi.
- `node --check frontend/public/sw.js` : réussi.
- Import FastAPI avec `BROKER=sim` et mot de passe de test : réussi.
- Vérification de l'état du simulateur : `provider=simulator`, `paper_confirmed=false`, `connection_health=healthy`.
- Routes `/health`, `/api/health` et `/login` présentes.

## Limites non certifiées

- Les 11 tests PostgreSQL restent ignorés sans base jetable explicitement configurée.
- Aucun test réel Neon/PostgreSQL, restauration de sauvegarde, ni compte Alpaca Paper réel n'a été exécuté pendant cette fusion.
- Aucun ordre réel ou Paper n'a été envoyé pendant les tests.
- Le build TypeScript/Vite et les tests navigateur ne sont pas certifiés ici faute d'installation npm reproductible.
- La disponibilité réelle des données OHLCV dépend de la configuration et des réponses du fournisseur ; le moteur d'analyse des chandeliers n'est pas une garantie de prédiction.
- Le mode Live reste hors périmètre et ne doit pas être activé.

## Politique de sécurité

La sélection du courtier de R5 est conservée : simulation par défaut, Alpaca uniquement par choix explicite `BROKER=alpaca`, et valeurs inconnues refusées au démarrage. L'environnement Alpaca autorisé reste Paper uniquement. Les secrets doivent être fournis par variables d'environnement et ne doivent jamais être ajoutés au dépôt ou à l'archive.
