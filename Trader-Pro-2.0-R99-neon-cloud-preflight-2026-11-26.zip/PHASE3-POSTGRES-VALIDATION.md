# Phase 3 — PostgreSQL integration validation

## What is prepared

- PostgreSQL 16 local service in `compose.yaml`.
- `.env.example` with separate application, `_test`, and `_restore` database URLs; no real credentials are included.
- `tests/test_postgres_integration.py`: seven opt-in PostgreSQL-only checks covering schema/precision/constraints, transaction rollback, concurrent unique client IDs, durable kill-switch persistence and audit, concurrent pause transitions, atomic paused-order claim, and the race between a new order claim and pause activation.
- `scripts/verify_postgres.sh`: migration, PostgreSQL integration suite, custom-format backup, dump validation, and restore into a separate empty database. It converts SQLAlchemy `postgresql+psycopg://` URLs to libpq URIs and refuses a non-empty restore target.
- `.github/workflows/postgres-integration.yml`: disposable PostgreSQL 16 service on GitHub Actions for push, pull request, and manual runs. It executes the PostgreSQL checks, backup/restore, full pytest/unittest suites, and compileall.

## Execution status in this ChatGPT runtime

**Not executed against PostgreSQL.** The runtime has no Docker/Podman, PostgreSQL server/client binaries (`postgres`, `psql`, `pg_dump`, `pg_restore`), no installed `psycopg` driver, and outbound package download failed due DNS/network unavailability. The seven PostgreSQL integration tests are therefore skipped locally. The workflow is prepared but cannot run until the project is pushed to a GitHub repository with Actions enabled.

Do not close Phase 3 until the PostgreSQL workflow completes successfully. Never point these variables at a production or live-money database.

## Local execution

1. Copy `.env.example` to `.env` and set a long random password.
2. Start PostgreSQL: `docker compose up -d postgres`.
3. Create separate empty databases `trader_pro_test` and `trader_pro_restore`.
4. Install `requirements-dev.txt` and PostgreSQL client tools.
5. Export variables from `.env` and run `bash scripts/verify_postgres.sh`.

The restore database must be empty. The script refuses to overwrite an existing public schema.

## CI execution

The PostgreSQL GitHub Actions workflow uses a disposable PostgreSQL 16 service and CI-only credentials. It runs the same verification script; no repository secrets are needed for this workflow.

## Correctif Windows — comparaison complète après restauration (21 novembre 2026)

Les scripts PowerShell `verify_postgres.ps1` et `run_postgres_full_validation.ps1` vérifiaient auparavant seulement la présence de quatre tables après restauration, alors que le chemin Bash comparait déjà l'ensemble des tables publiques, leurs nombres de lignes et la révision Alembic. Les deux scripts Windows appellent désormais le vérificateur commun `scripts/verify_postgres_restore.py` en lecture seule. Un test de contrat empêche le retour à la vérification partielle des quatre tables.

Ce correctif est vérifié par tests statiques Python ; il n'est pas présenté comme une exécution réelle sous Windows ou PostgreSQL. Le test de restauration réel reste à lancer sur PostgreSQL jetable.
