# Trader Pro 2.0 — R6 : modèle d'allocation multi-stratégies (23 novembre 2026)

## Objet

Ajout d'un aperçu d'allocation théorique dans `research_v1/backtesting/portfolio_scoreboard.py`. Cette étape prolonge le scoreboard walk-forward des sept stratégies de portefeuille ; elle ne crée aucun lien avec l'activation des stratégies, `OrderService` ou le courtier.

## Méthode

- Les seules candidates prises en compte sont les stratégies effectivement évaluées et classées `prometteuse` par le scoreboard OOS.
- Le score de pondération est `Sharpe OOS positif / volatilité OOS`.
- Le poids théorique est plafonné à 25 % par stratégie et à 80 % investi au total ; le reliquat reste en liquidités.
- Le modèle reste bloqué à 100 % de liquidités tant que les quatre contrôles ne sont pas explicitement validés : exposition par actif, régimes de marché, concentration sectorielle et liquidité.
- Il reste également bloqué si le scoreboard relève une paire de candidates dont la corrélation absolue est au moins égale à 0,75.
- Une métrique Sharpe/volatilité absente, non finie ou non positive n'est pas utilisée.

## Séparation stricte

Même si toutes les portes de revue sont validées dans un scénario de test, le résultat porte le statut `MODEL_PREVIEW_ONLY`, avec `capital_authorized=false`, `strategies_activated=0` et `orders_created=0`. Il s'agit d'un outil de recherche pour examiner des poids, pas d'une autorisation de placement d'ordres. Le `selection_preview` existant demeure à 100 % de liquidités.

## Tests et vérifications

- Tests ciblés portefeuille / scoreboard : 22 réussis.
- Suite complète : 718 réussis, 11 ignorés, 202 sous-tests réussis.
- `python -m compileall -q .` : réussi.
- `node --check frontend/public/sw.js` : réussi.
- Deux avertissements de dépréciation FastAPI `on_event` persistent.

## Limites restantes

- Les données utilisées par les tests sont synthétiques ; aucune performance réelle n'est établie.
- Les contrôles de régime, d'exposition sectorielle et de liquidité ne sont pas encore validés sur données de marché réelles. Par conséquent, le chemin normal reste bloqué à 100 % de liquidités.
- PostgreSQL/Neon réel, Alpaca Paper authentifié, flux réels synchronisés et build/typecheck React/Vite ne sont pas validés ici.
- Aucun ordre Paper ou Live n'a été soumis. Live reste verrouillé.
