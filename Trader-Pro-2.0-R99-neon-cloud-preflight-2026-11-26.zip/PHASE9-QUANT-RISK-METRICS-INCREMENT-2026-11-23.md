# Trader Pro 2.0 — incrément R42 : métriques de risque quantitatif

Date : 23 novembre 2026  
Base : R40 (candidat local), sans modification des règles de trading, de l'exécution broker ou du mode Live.

## Amélioration

Le tableau de bord de recherche du catalogue multi-actifs expose désormais, pour chaque courbe OOS :
- **Sortino annualisé**, avec rendement minimum acceptable quotidien fixé à zéro ;
- **Calmar**, CAGR divisé par la valeur absolue du drawdown maximal ;
- **durée maximale du drawdown**, en observations, de l'ancien sommet jusqu'à la récupération (ou jusqu'à la dernière barre si non récupéré).

La fonction de métriques refuse maintenant les courbes contenant des valeurs non finies ou non positives. Les métriques sont ajoutées aux résultats de chaque stratégie et aux lignes des fenêtres de comparaison lorsqu'elles sont produites.

## Validation exécutée

- Tests ciblés du scoreboard : **15 passed**.
- Suite complète `BROKER=sim pytest -q` : **788 passed, 11 skipped, 202 subtests passed**.
- `python -m compileall -q .` : OK.
- `node --check frontend/public/sw.js` : OK.
- JSON du manifeste PWA : valide.
- `bash -n scripts/verify_postgres.sh` : OK.

## Limites

- Ces métriques enrichissent l'analyse du risque mais ne prouvent pas une rentabilité future et ne changent pas le verdict automatique de sélection.
- Les fenêtres dites walk-forward restent des segments descriptifs d'une trajectoire continue ; les paramètres restent figés sur l'ensemble de l'OOS.
- Aucun test PostgreSQL/Neon réel ni restauration externe n'a été exécuté dans cet environnement.
- Aucun accès Alpaca Paper, aucun ordre Paper ou Live, aucun build Docker/Vite distant n'a été exécuté.
- Les 11 tests ignorés restent à valider avec le service PostgreSQL dédié.
- Aucune stratégie n'est activée ; aucun capital n'est autorisé ; Live reste verrouillé.

## Décision

R42 améliore la mesure du risque à la baisse et de la persistance des pertes. C'est un incrément de recherche et de qualité logicielle, pas une certification de performance ni une autorisation de trading.
