# Trader Pro 2.0 — R97
## Continuité de développement indépendante de Replit et précontrôle Neon renforcé

Date : 26 novembre 2026  
Base : R96, évolution additive  
Cible Neon autorisée : `trader_pro_test` uniquement  
Tête Alembic attendue : `f19a6c3d8b42`

## 1. Objectif

Préparer une méthode de travail pendant l'indisponibilité temporaire de Replit, tout en poursuivant les validations R95/R96 sans créer une deuxième application concurrente.

## 2. Changements R97

- Renforcement de `scripts/verify_neon_sqlalchemy_readonly.py` : l'URL doit viser un hôte `*.neon.tech`, la base exacte `trader_pro_test`, et imposer `sslmode=require`, `verify-ca` ou `verify-full`.
- Ajout de tests ciblés pour refuser les hôtes non-Neon et les connexions sans TLS.
- Ajout de `scripts/run_neon_readonly_preflight.ps1` : saisie masquée de l'URL Neon, variable d'environnement limitée au processus, suppression de la variable après exécution, aucune écriture ni migration.
- Ajout de l'option `-RunNeonReadOnly` à `scripts/prepare_windows_validation.ps1`.
- Documentation `REPLIT-INDEPENDENT-WORKFLOW-R97.md` décrivant le parcours Windows local et l'alternative GitHub Actions.
- Correction d'une indentation incohérente dans le script PowerShell de validation PostgreSQL complète.

Aucun changement de schéma, aucune migration, aucun appel d'écriture à Neon, aucun ordre Alpaca.

## 3. Tests locaux réellement exécutés

| Validation | Résultat |
|---|---:|
| Tests ciblés précontrôle Neon | 8 réussis |
| Suite Pytest | 1 012 réussis, 11 ignorés, 205 sous-tests réussis |
| Unittest | 849 réussis |
| Compileall | Réussi |

Les 11 tests PostgreSQL restent ignorés dans ce runner car aucun serveur PostgreSQL, Docker ou Podman n'est installé. Ils ne sont pas déclarés réussis.

## 4. État des trois chantiers externes

### PostgreSQL réel

Le projet contient déjà un environnement PostgreSQL 16 jetable (`compose.test.yaml`), un parcours Windows (`scripts/prepare_windows_validation.ps1 -RunPostgres`) et un workflow GitHub Actions (`.github/workflows/postgres-integration.yml`) qui réalise migrations, tests PostgreSQL, suite complète et backup/restore.

Ces tests n'ont pas pu être exécutés ici : pas de Docker/Podman ni de binaire PostgreSQL dans le runner. Ne jamais rediriger ces tests destructifs vers Neon.

### SQLAlchemy direct vers Neon

Le précontrôle R97 est testé unitairement, mais n'a pas encore été exécuté contre Neon depuis Python/SQLAlchemy : le runner n'a pas le pilote `psycopg` et l'accès réseau requis. Le nouveau parcours Windows permet de le faire depuis le PC du propriétaire sans révéler l'URL dans le terminal ni la stocker dans un fichier.

Le schéma Neon précédemment vérifié reste à la tête `f19a6c3d8b42`, avec 17 tables et le trigger append-only activé. Les 15 révisions corporate actions restent enregistrées.

### Alpaca Paper

Dernière lecture disponible : compte Paper `ACTIVE`, cash/equity 100 000 USD, zéro position et zéro ordre. L'horloge du marché était fermée et la cotation F retournée n'était pas une cotation fraîche exploitable pour un test d'ordre. Aucun ordre n'a été soumis. Le cycle ordre → fill → réconciliation reste ouvert.

Un ordre Paper réel doit être lancé uniquement pendant une séance ouverte, avec une cotation IEX fraîche, le mécanisme d'annulation et une autorisation explicite. Aucun endpoint Live n'est autorisé.

## 5. Alternative Replit

Le chemin immédiat est le PC Windows : Python 3.11/3.12 + PowerShell, puis le script de préparation local. Docker Desktop fournit un PostgreSQL 16 éphémère pour les 11 tests et le cycle backup/restore. Le précontrôle Neon se lance ensuite en lecture seule avec saisie masquée de l'URL.

Le chemin cloud est GitHub Actions. Le workflow PostgreSQL est déjà présent, mais il faut un dépôt GitHub privé contrôlé et accessible. Dans cette session, le compte GitHub connecté ne retourne aucun dépôt accessible et aucun outil de création de dépôt n'est disponible ; aucun push ou lancement CI n'a été effectué.

R97 ne synchronise pas automatiquement le workspace Replit. L'archive est un paquet de continuité autonome ; il faudra comparer et réintégrer les changements dans le projet Replit lorsque son accès sera rétabli.

## 6. Sécurité et état opérationnel

- `system_safety_state` reste `RECONCILING`.
- Trading Live non autorisé.
- Aucun ordre Paper créé pendant R97.
- Aucun changement Neon pendant R97.
- `neondb` et `trader_pro_restore` non modifiées.
- Aucun secret ajouté à l'archive.
- Aucune archive historique supprimée.

**Conclusion :** R97 améliore la portabilité et sécurise le chemin de précontrôle SQLAlchemy. Il ne clôt pas les tests PostgreSQL réels, la connexion SQLAlchemy à Neon ni le cycle d'exécution Paper. Trader Pro 2.0 n'est pas déclaré opérationnel.
