# Trader Pro 2.0 — R74 : transport de la provenance fournisseur

Date : 2026-11-26  
Base : R73 (`Trader-Pro-2.0-R73-ajustement-provenance-2026-11-26.zip`)

## Modifications

- `ProviderChain` conserve désormais le mode d'ajustement déclaré par le lecteur fournisseur et le transporte jusqu'au service de marché.
- Le contrat étendu reste compatible avec les lecteurs historiques : en l'absence de déclaration, le mode reste `unknown`.
- `MarketDataService.daily_bars` valide et stocke la provenance reçue dans `DailyBars`.
- `MarketDataService.daily_ohlcv` récupère et valide également la déclaration du lecteur OHLCV.
- Le lecteur Alpaca `bars3` déclare `split`, cohérent avec le paramètre `adjustment=split` réellement envoyé à l'API dans `_historical_daily_bars`.
- Twelve Data demeure `unknown` ; aucune hypothèse n'est faite sur son ajustement.
- Les erreurs de provenance invalide sont rejetées, sans exposer de secrets.

## Compatibilité

Les anciens lecteurs qui retournent deux ou trois valeurs continuent de fonctionner. Leur provenance est volontairement inconnue, ce qui évite d'élever implicitement des données historiques au rang de données vérifiées.

## Validation

- Tests ciblés marché + Twelve Data : 68 réussis, 28 sous-tests réussis.
- Suite complète : 900 réussis, 11 ignorés, 202 sous-tests réussis.
- Les tests PostgreSQL ignorés ne constituent pas une validation Neon.
- Aucun ordre envoyé ; Live reste désactivé.

## Limites

- La déclaration `split` identifie le paramètre de requête Alpaca, pas une preuve d'ajustement dividendes.
- Twelve Data reste inconnu tant qu'une déclaration vérifiable n'est pas disponible.
- Pas de calcul de rendement total ni de validation de corporate actions effectives dans cet incrément.
- Aucun déploiement Replit, test Neon réel ou session Alpaca Paper authentifiée revendiqué.
