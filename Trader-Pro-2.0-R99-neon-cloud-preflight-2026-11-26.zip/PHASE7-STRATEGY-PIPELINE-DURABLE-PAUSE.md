# Phase 7 — durable kill-switch gate for strategy generation

Date: 11 November 2026

## Change

The strategy pipeline previously consulted only process-local `state['paused']` before running strategies and staging a proposed order. This left a cross-worker gap: a worker could continue generating/staging proposals after another worker had activated the durable PostgreSQL kill switch.

The pipeline now accepts `operational_pause_reader`, injected by the application from `OrderRepository.get_operational_pause()` whenever database persistence is configured. It refreshes the authoritative durable state under the pipeline lock both:

- before starting a strategy run; and
- immediately before staging each proposed order.

A durable paused state updates local state and blocks with status 423. A malformed result or read failure forces local paused state and blocks strategy generation/staging (fail-closed). The in-memory-only path remains available for isolated unit tests and deployments without configured durable persistence; this is not equivalent to multi-worker production safety.

## Regression tests

- A durable pause activated by another worker blocks a new strategy run even when local memory says unpaused.
- A durable pause read failure forces local pause and blocks the run.
- No strategy proposal is persisted in either blocked case.

## Local validation

- `pytest`: 415 passed, 5 skipped, 88 subtests passed.
- `unittest discover`: 411 tests passed.
- `compileall`: passed.
- Alembic SQLite migration: passed through `f3b8c2d91a64` (single head).
- FastAPI import: 35 routes in simulation and non-simulation modes.
- With a freshly migrated SQLite database configured, the strategy pipeline receives the durable pause reader and reads the seeded state.

## Limitations

- PostgreSQL server-level locking/concurrency tests remain skipped because no PostgreSQL server is configured in this environment.
- This closes the stale-local-state gap for strategy proposal generation and staging; it does not provide a distributed lock held across the entire broker network submission. The broker-side race/atomicity question remains open.
- No authenticated Alpaca request or external Paper order was executed.
- Live trading remains disabled.
