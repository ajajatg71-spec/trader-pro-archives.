# Phase 10 — React/PWA increment 7 (R28)

Date: 2026-11-23
Base: R27 archive, preserved as the prior candidate.

## Change

Hardened the dashboard refresh lifecycle against connectivity changes during asynchronous API calls:

- If the browser is already offline, no financial API requests are started and all displayed account/risk/order data are cleared.
- Connectivity is checked again after the dashboard API requests and after the health request, before committing fetched financial data to React state.
- If connectivity drops mid-refresh, the refresh fails closed, clears account/risk/orders/health and removes the last-updated timestamp.
- Existing same-origin credentials, `cache: no-store`, CSRF header, API cache exclusions and read-only order display are preserved.

Added two regression tests for pre-fetch offline blocking and mid-request offline races.

## Validation

- Full suite: **761 passed, 11 skipped, 202 subtests passed**.
- Run mode: `BROKER=sim`; no real broker order was submitted.
- 11 skipped tests require an external PostgreSQL environment.
- Python `compileall`: passed.
- Service worker `node --check`: passed.
- PWA manifest JSON parse: passed.
- React/TypeScript/Vite production build: **not certified**. `npm install --ignore-scripts --no-audit --no-fund --prefer-offline` timed out. A global `tsc --noEmit` attempt failed because React, React DOM, Lucide and Vite type declarations are not installed; this is an environment/dependency failure, not a clean typecheck. No Vite build is claimed.

## Remaining blockers

- Install dependencies reproducibly and commit a lockfile, then run `npm ci`, `npm run typecheck`, and `npm run build`.
- Validate actual browser/mobile behavior and FastAPI session/CSRF integration.
- Validate PostgreSQL/Neon and Alpaca Paper against real authorized test environments.
- Live remains disabled; no automatic strategy activation or capital allocation is authorized.
