# Déploiement Docker — Trader Pro 2.0 (candidat)

Cette procédure prépare un déploiement **Paper uniquement**. Elle ne constitue pas une certification de production.

## 1. Préparer les secrets

```bash
cp .env.example .env
```

Remplacer chaque valeur `REPLACE_...` par un secret unique et fort. `POSTGRES_PASSWORD` doit correspondre au mot de passe inclus dans `DATABASE_URL` ; URL-encoder les caractères réservés. Les deux secrets TOTP doivent être Base32 et distincts. Les clés Alpaca doivent provenir du compte Paper. Ne jamais partager `.env`, l'ajouter à Git ou l'inclure dans une archive.

Vérifier la configuration sans afficher les secrets :

```bash
docker compose config --quiet
```

Le prévol doit réussir avant de démarrer l'application. Il refuse le simulateur et tout endpoint Alpaca autre que Paper.

## 2. Construire et préparer PostgreSQL

```bash
docker compose build app
# Le prévol s'exécute dans le conteneur afin de lire les variables du fichier .env
# injectées par Compose (le script Python local ne charge pas .env automatiquement).
docker compose run --rm --no-deps app python scripts/deployment_preflight.py
docker compose up -d postgres
docker compose ps
```

Attendre l'état `healthy` de PostgreSQL. Appliquer les migrations explicitement :

```bash
docker compose run --rm --no-deps app alembic upgrade head
```

Les migrations ne sont volontairement pas lancées automatiquement au démarrage de l'API.

## 3. Démarrer l'application

```bash
docker compose up -d app
docker compose ps
docker compose logs --tail=100 app
```

L'application écoute uniquement sur `127.0.0.1:${APP_PORT:-8000}`. Placer un reverse proxy HTTPS correctement configuré devant elle avant tout accès distant. Ne pas exposer directement le port de l'API à Internet. Si un proxy est utilisé, définir `TRUSTED_PROXY_IPS` avec ses adresses exactes.

Le conteneur applicatif utilise un système de fichiers racine en lecture seule, supprime toutes les capabilities Linux, fonctionne sans root et conserve les données uniquement dans le volume `trader_pro_state`.

## 4. Vérifier sans envoyer d'ordre

```bash
curl --fail http://127.0.0.1:8000/health
python scripts/verify_postgres_readonly.py
python scripts/verify_alpaca_paper_readonly.py
```

Le second script exige les variables de validation décrites dans son aide/documentation ; il ne doit viser qu'une base de validation autorisée. Le vérificateur Alpaca est en lecture seule. Ne lancer aucun workflow d'ordre Paper sans autorisation explicite.

## 5. Sauvegarde et restauration

La sauvegarde PostgreSQL utilise `scripts/backup_postgres.sh`. Pour tester la chaîne complète, utiliser exclusivement deux bases locales jetables distinctes terminant respectivement par `_test` et `_restore`, avec `TRADER_PRO_TEST_DATABASE_DISPOSABLE=YES`, puis exécuter `scripts/verify_postgres.sh`. Ne jamais utiliser la base Neon persistante pour les tests destructifs.

## Limites connues

- Le build Docker exige `frontend/package-lock.json`. Il n'est pas encore présent dans cette archive. Solution préparée : lancer `bash scripts/prepare_frontend_build.sh` depuis un environnement avec accès au registre npm, ou exécuter le workflow GitHub Actions `Frontend and Docker build validation`. Le workflow génère le vrai lockfile à partir du `package.json`, exécute `npm ci`, le typecheck, le build Vite et le build Docker, puis conserve le lockfile comme artefact à examiner et à intégrer au dépôt. Le workflow ne dépend pas d'un cache npm basé sur un lockfile absent.
- PostgreSQL réel, sauvegarde/restauration réelle, Neon et Alpaca Paper doivent être validés dans leur environnement respectif.
- Ce déploiement n'autorise pas le mode Live et ne garantit aucune performance financière.
