# Trader Pro 2.0 — R12 : comparaison multi-actifs et par régime

Date : 23 novembre 2026  
Base : R11, archive `Trader-Pro-2.0-consolide-candidat-2026-11-23-r11.zip`.

## Travail ajouté

- Ajout de `evaluate_multi_asset_regimes()` dans `research_v1/validation/candle_confluence.py`.
- Entrée sous forme de mapping symbole -> historique OHLCV ; validation individuelle des historiques via l'évaluateur R11.
- Comparaison par actif, figure, horizon et filtre de confluence.
- Classification du régime à la date du signal via `detect_regime()` existant : SMA50/SMA200, ADX et percentile de volatilité.
- Indicateurs et régime calculés sur le seul historique disponible à la clôture du signal ; entrée simulée à l'ouverture suivante ; coûts aller-retour conservés.
- Résultats développement/holdout séparés chronologiquement pour chaque actif.
- Aucun regroupement des observations entre actifs, aucune activation stratégique et aucun ordre.

## Vérifications exécutées

- Tests ciblés chandeliers/confluences : 5 passed.
- Suite complète : **729 passed, 11 skipped, 202 subtests passed**.
- Compilation Python ciblée réussie.
- Deux avertissements FastAPI `on_event` déprécié ; aucun échec.
- Les 11 tests ignorés sont les validations PostgreSQL nécessitant une base de données réelle.

## Limites

- Aucun jeu de données de marché multi-actifs réel n'a été fourni/exécuté dans cette validation ; les tests sont des tests logiciels synthétiques.
- Les étiquettes de régime sont descriptives et déterminées par les seuils du détecteur existant ; elles ne sont pas une vérité économique.
- Les échantillons par actif/régime/figure peuvent être faibles. Le rapport indique le nombre d'observations et un seuil minimal, sans transformer ce seuil en preuve statistique.
- Pas de correction des comparaisons multiples, de test de significativité, ni de validation externe indépendante.
- Recherche seule : aucune modification de stratégie active, aucun ordre.
- PostgreSQL/Neon réel et Alpaca Paper réel restent à valider. Live reste verrouillé.

## Suite recommandée

Ajouter un protocole de contrôle des biais : déduplication/gestion des signaux chevauchants, purge/embargo autour de la frontière développement-holdout, correction des comparaisons multiples et comparaison à un benchmark cohérent par actif et régime. Ensuite seulement, exécuter sur des historiques réels multi-actifs horodatés.
