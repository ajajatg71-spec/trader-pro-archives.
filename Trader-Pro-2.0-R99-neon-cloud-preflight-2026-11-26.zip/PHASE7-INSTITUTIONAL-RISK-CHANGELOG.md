# Phase 7 — Institutional Risk Management (initial delivery)

## Scope delivered

- Added `InstitutionalRiskEngine` as a deterministic, fail-closed policy layer.
- Added portfolio metrics: gross/net exposure (long-only model), cash percentage, largest position concentration, position count, reserved gross exposure, and peak-to-equity drawdown.
- Added hard pre-trade checks for order size as a percentage of equity, per-position concentration, gross exposure including already-open buy reservations, maximum number of positions, and minimum cash reserve.
- Added optional stop-distance risk-budget enforcement when a strategy/order explicitly supplies both entry and stop prices. No stop price is fabricated.
- Added risk-based position sizing capped by the configured maximum position percentage.
- Integrated the policy as a second independent gate in `OrderService.approve`, after the existing V1 order checker and before persistence/broker submission. Risk rejection is logged and the broker is not called.
- Added institutional metrics to the existing risk snapshot endpoint. Existing V1 calculations and alert behavior are retained.

## Safety boundaries

- Long-only exposure model; short selling and leverage are not enabled by this layer.
- Existing daily, weekly, drawdown, pause, and broker-block controls remain in place.
- Sell-side quantity validation remains with the existing V1 order checker.
- Missing/invalid financial inputs fail closed.
- Live mode was not enabled and no live order was sent.

## Validation

- `python -m pytest -q`: 352 passed, 3 skipped, 76 subtests passed.
- `python -m unittest discover -q`: 348 passed.
- `python -m compileall -q .`: passed.
- FastAPI simulation-mode import: passed; 35 routes registered; institutional risk gate injected into `OrderService`.
- The three skipped tests are opt-in PostgreSQL integration tests. PostgreSQL server validation and external Alpaca Paper credentials remain deferred as requested; this delivery does not claim either was tested.

## Remaining Phase 7 work

- Sector and issuer classification with concentration limits backed by trusted metadata.
- Correlation-aware concentration and factor exposure limits.
- Historical VaR/CVaR policy thresholds, scenario stress limits, and liquidity/market-impact constraints integrated into pre-trade decisions.
- Durable risk decision/event audit and operational kill-switch verification.
- Full Paper-account validation when credentials and external database are available.

## Phase 7 — second hardening delivery

- Added issuer and sector aggregation using explicit `state.risk_metadata` mappings (`SYMBOL: {sector, issuer}`). No sector/issuer is guessed or inferred. When a cap below 100% is configured, missing classification blocks the portfolio snapshot and new buy approval.
- Added issuer and sector concentration limits (`max_sector_pct`, `max_issuer_pct`) to both portfolio diagnostics and the pre-trade gate. Exposure includes existing positions plus the proposed buy.
- Connected the risk snapshot's existing historical VaR 95%, CVaR 95%, and worst configured stress scenario to the institutional portfolio snapshot.
- Added optional thresholds `max_var95_pct`, `max_cvar95_pct`, and `max_stress_loss_pct`. A configured threshold fails closed if its metric is unavailable or malformed.
- The risk service stores the latest computed market-risk snapshot in shared application state with an `as_of` timestamp. Pre-trade approval rejects missing or stale snapshots; default maximum age is 900 seconds and can be configured with `market_risk_max_age_seconds`.
- When market data are unavailable, the previous cached market-risk snapshot is cleared so an old VaR/CVaR value cannot authorize a new order.
- Added regression tests for classification coverage, sector aggregation, issuer concentration, VaR/CVaR breaches, invalid metrics, and stale/fresh market-risk snapshots.

### Safety and limitations

- Metadata must be provided by a trusted instrument reference source or reviewed configuration. The engine does not fabricate sector or issuer values.
- VaR/CVaR remain historical estimates from the existing V1 risk formulas; they are not forecasts or guarantees. Their limits are opt-in and must be calibrated by the operator.
- The stress loss percentage is derived from the existing beta-scaled -10%, -20%, and -30% market shocks; it does not replace scenario design or liquidity/market-impact analysis.
- Correlation-aware limits, factor exposure caps, liquidity/market-impact constraints, and durable kill-switch audit remain open.
- Live mode remains disabled. No external broker order was sent.

## Third hardening increment — correlation and factor concentration

- Added opt-in `max_avg_correlation` and `min_effective_n` controls using the existing V1 correlation and effective-number calculations.
- The timestamped market-risk snapshot now carries average pairwise correlation and effective number of holdings; active controls reject missing, invalid, or stale measurements.
- Added portfolio-weighted factor exposure reporting and opt-in per-factor absolute exposure caps using reviewed `risk_metadata[*].factor_loadings`.
- Pre-trade approval evaluates the candidate order against the proposed factor exposure, not only the current portfolio.
- Missing factor loadings fail closed when factor caps are enabled.
- No external factor data provider or automatic classification taxonomy was added; operators must supply trusted, consistently estimated metadata.
- Live execution remains disabled; these controls are additive and do not modify V1 formulas.

## Fourth hardening increment — durable pre-trade decision audit

- Added an append-only `risk_decision` audit record for both approved and blocked pre-trade decisions, correlated to the client order ID.
- Blocked decisions additionally create a durable `risk_events` row; approved decisions are clearly recorded as approvals, not as broker executions.
- The decision record is written before the broker side effect. When PostgreSQL persistence is configured and the audit write fails, order submission fails closed.
- Added regression tests for approved/blocked audit records, correlation IDs, and broker non-submission when audit persistence fails.
- The repository callback is wired only when `DATABASE_URL` is configured. This ZIP's local simulation test did not configure a database, so live database persistence is not claimed as exercised.

### Remaining Phase 7 work

- Trusted liquidity data and pre-trade liquidity / market-impact constraints.
- Durable operational pause / emergency kill-switch audit and restart-state verification.
- PostgreSQL-backed end-to-end validation and Paper-account validation with external credentials.

## Fifth hardening increment — liquidity and market-impact gates

- Added opt-in ADV participation, quoted spread, and square-root market-impact screening limits to the institutional pre-trade buy gate.
- Each control fails closed when required trusted metadata is absent or invalid; crossed quotes are rejected.
- No liquidity data are inferred. Existing V1 formulas and sell-side quantity validation remain unchanged.
- Added regression coverage for threshold breaches and missing/invalid liquidity inputs.
- The current package does not yet connect or freshness-validate a live quote/ADV source; metadata provenance and Paper calibration remain open.
- Validation: 376 pytest passed, 3 opt-in PostgreSQL tests skipped, 76 subtests passed; 372 unittest passed; compileall passed; simulation-mode FastAPI import passed with 35 routes.

### Incrément 6 — coupe-circuit opérationnel durable

- Ajout de `risk_control_state`, singleton SQL pour conserver l'état pause/reprise, le motif, l'acteur et l'horodatage.
- Les transitions pause/reprise et leur événement d'audit sont écrits dans une même transaction.
- La pause manuelle n'est appliquée en mémoire qu'après confirmation de l'écriture durable ; une erreur DB laisse l'état précédent intact.
- Les arrêts d'urgence déclenchés par les seuils de perte/drawdown utilisent le même mécanisme.
- Au démarrage, l'application recharge l'état persistant avant de servir les requêtes ; une erreur de lecture DB interrompt le démarrage au lieu d'effacer silencieusement un arrêt.
- Migration Alembic `d4c8a71e2f90`, puis migration de fusion `e8a19c42d7b1` pour réunir les deux branches Alembic préexistantes (snapshots de positions et coupe-circuit).
- Tests ajoutés : persistance après recréation du repository, audit pause/reprise, validation acteur, ordre écriture/état mémoire, échec DB fail-closed, arrêt automatique persistant.
- Limite : la validation de migration a été exécutée sur SQLite temporaire ; aucun serveur PostgreSQL externe n'a été utilisé dans cet incrément.

### Incrément 7 — fraîcheur des données de liquidité

- Les limites de participation, spread et impact exigent désormais `risk_metadata[SYMBOL].as_of` (epoch secondes).
- Âge maximal configurable avec `liquidity_max_age_seconds`, 120 secondes par défaut ; horodatage absent/invalide, trop ancien ou futur entraîne un refus.
- Deux tests supplémentaires couvrent les métadonnées périmées et l'absence d'horodatage.
- Cette vérification ne remplace pas l'intégration d'un fournisseur vérifié : l'horodatage est une déclaration de la source et ne constitue pas une preuve cryptographique de provenance.

### Increment 6 — Alpaca/IEX liquidity feed integration
- Added an isolated Alpaca market-data adapter for latest IEX bid/ask and recent daily bars; no order endpoints are used.
- ADV proxy uses close × volume, up to 20 completed-session observations, including zero-volume sessions, with a minimum of 10. Source and quote timestamp are returned explicitly.
- OrderService refreshes liquidity metadata immediately before institutional risk approval whenever a buy-side liquidity limit is enabled; absent provider or provider failure blocks before broker submission and is audit-tagged as `LIQUIDITY_DATA`.
- Provider-derived liquidity fields replace prior market-derived fields while sector/factor reference metadata is retained.
- Institutional risk now requires a non-empty source identifier whenever liquidity limits are active.
- No impact coefficient is invented; the impact limit remains fail-closed unless a separately calibrated coefficient is supplied.
- External API connectivity and Paper execution remain unverified; adapter tests use mocked responses.

### Increment 8 — contrôle de fraîcheur à la frontière Alpaca/IEX
- L'adaptateur vérifie désormais lui-même l'âge de la cotation bid/ask avant même de télécharger l'historique quotidien ; valeur par défaut : 120 secondes, configurable.
- Les cotations horodatées dans le futur (au-delà de la tolérance de 5 secondes) et les cotations périmées sont rejetées à la frontière fournisseur.
- L'horloge injectée doit être timezone-aware ; une horloge invalide bloque le flux.
- Deux tests ajoutés : cotation trop ancienne et cotation future. Ils vérifient également qu'aucun second appel HTTP n'est réalisé après rejet.
- Validation locale : 394 tests pytest réussis, 3 tests PostgreSQL ignorés, 76 sous-tests ; 390 tests unittest réussis ; compilation Python réussie.
- Limites inchangées : appels externes Alpaca non exécutés, données IEX non consolidées, pas de test Paper réel ni PostgreSQL externe.


### Liquidity ADV integrity follow-up
- Excluded in-progress current-UTC-day bars from dollar ADV so partial session volume cannot distort participation estimates.
- Future calendar-session bars are rejected.
- `adv_as_of` now identifies the latest completed session actually eligible for ADV, not merely the latest timestamp returned by the provider.
- Added regression coverage for partial-day exclusion and minimum completed-history enforcement.

### Increment 9 — résilience réseau du flux Alpaca/IEX
- Ajout de reprises bornées pour HTTP 429, 500, 502, 503, 504, timeouts et erreurs de connexion.
- Maximum configurable de 0 à 3 reprises (2 par défaut), avec temporisation exponentielle plafonnée à 2 secondes.
- Respect de `Retry-After` numérique ou HTTP-date, plafonné à 2 secondes afin de borner le temps passé dans le contrôle pré-trade.
- Les erreurs client non transitoires (par exemple HTTP 400/401/403) ne sont pas rejouées ; après épuisement des tentatives, le flux échoue et le contrôle pré-trade reste fail-closed.
- Tests couvrant limitation 429, timeout transitoire et bornes de configuration.
- Validation locale : 403 pytest réussis, 3 tests PostgreSQL ignorés, 76 sous-tests ; 399 unittest réussis ; compileall réussi ; import FastAPI simulation réussi avec 35 routes.
- Aucun appel externe Alpaca, aucune connexion PostgreSQL réelle et aucun ordre Paper n'ont été exécutés.

### Incrément 10 — intégrité de l'ADV pour les séances sans volume
- Correction d'un biais : les séances complètes avec volume nul sont désormais conservées comme observations à zéro dans le calcul de l'ADV, au lieu d'être exclues.
- L'ADV représente donc les 20 dernières séances complètes disponibles (ou au minimum 10), et non les 20 séances avec volume strictement positif.
- Un historique composé uniquement de volumes nuls reste refusé car son ADV est nul et ne peut pas servir à autoriser un ordre.
- Ajout de deux tests : inclusion des jours à volume nul dans la moyenne et refus d'un ADV entièrement nul.
- Validation locale : 405 tests pytest réussis, 3 tests PostgreSQL ignorés, 76 sous-tests ; 401 tests unittest réussis ; compilation Python réussie.
- Les données IEX restent un proxy partiel, non consolidé. Aucune calibration d'impact ni connexion Paper externe n'est revendiquée.

## 11 November 2026 — PostgreSQL kill-switch concurrency hardening

- Operational pause updates now acquire the singleton `risk_control_state(id=1)` row with `SELECT ... FOR UPDATE`, serializing concurrent pause/resume transitions on PostgreSQL.
- Runtime updates no longer recreate a missing singleton row. The migration owns singleton initialization; a missing row is an integrity incident and the update fails closed. Reads already reported the missing state as paused.
- Added an opt-in PostgreSQL concurrency integration test asserting every concurrent transition produces an audit event.
- Corrected the PostgreSQL uniqueness test so only the expected duplicate-fill `IntegrityError` can satisfy it; unrelated setup failures can no longer pass the test accidentally. Test data cleanup removes dependent fills before parent orders.
- Local suite: 410 pytest passed, 5 PostgreSQL-only skips, 88 subtests; 406 unittest passed; compileall and PostgreSQL shell-script syntax checks passed.
- PostgreSQL execution remains unverified: this environment has no PostgreSQL server/client, Docker/Podman runtime, or psycopg driver. No claim of live concurrency validation is made.

## 11 November 2026 — durable kill-switch recheck on every approval

- `OrderService.approve()` now reads the durable PostgreSQL pause singleton immediately before risk checks and broker submission, rather than relying solely on the process-local state restored at startup.
- A pause activated by another worker/process is therefore observed at the next order approval. A failed read, malformed response, or unavailable durable state forces the local process into paused state and blocks the order with HTTP-compatible status 423.
- The app injects the durable pause reader from `OrderRepository` whenever database persistence is configured.
- Added tests for cross-process pause visibility, database read failure, and malformed pause state.
- Local suite: 413 pytest passed, 5 PostgreSQL-only skips, 88 subtests; 409 unittest passed.

## 11 November 2026 — durable kill-switch gate for strategy pipeline

- The strategy pipeline now accepts and reads the durable pause state before strategy generation and again before each proposal is staged.
- The FastAPI app injects the same repository-backed pause reader used by manual order approval.
- A pause set by another worker is now reflected before signal generation; a read error or malformed state forces local pause and returns a fail-closed 423 response.
- Added regression tests confirming no proposal is persisted when the durable state is paused or unavailable.
- Local suite: 415 pytest passed, 5 PostgreSQL-only skips, 88 subtests; 411 unittest passed; compileall passed; SQLite Alembic migration reached `f3b8c2d91a64`.
- PostgreSQL concurrency, real provider connectivity, and external Paper trading remain unverified. No distributed lock is yet held across the full broker submission call.

## Atomic durable pause gate for order claims

- Added `stage_order_if_trading_enabled`: locks the singleton durable pause row and creates the `submitting` order intent in one transaction.
- The pause writer and order-claim method now serialize against the same PostgreSQL row lock. A pause committed first prevents a new broker submission claim.
- `OrderService.approve` uses the atomic claim when supported; pause denial maps to 423 and never reaches the broker. Approved risk audit is written only after the claim succeeds.
- Added SQLite repository/service tests and an opt-in PostgreSQL integration test. SQLite does not implement `SELECT FOR UPDATE`; PostgreSQL lock behavior remains unverified until the opt-in tests run against a real server.
- An order claimed before the pause is considered in-flight and must be reconciled; the pause cannot retract a broker request already dispatched.

## 2026-11-12 — récupération prudente des soumissions abandonnées
- Ajout du reclassement transactionnel des intentions `submitting` anciennes vers `submission_unknown` lors de la réconciliation.
- Ajout d'un audit corrélé avec la décision explicite `automatic_resubmission=false`.
- Aucun ordre manquant du snapshot broker n'est relancé automatiquement; il reste à réconcilier manuellement.
- Tests locaux: 422 pytest passés, 6 ignorés (PostgreSQL non configuré), 88 sous-tests; unittest 418 réussis.
- Voir `PHASE7-STALE-SUBMISSION-RECOVERY.md`.

## Kill switch open-order cancellation (2026-11-12)

- Activating the durable pause now snapshots broker-open orders and requests cancellation by broker order ID after the pause has committed.
- Each request is durably audited before the external side effect; local orders move to `pending_cancel` and are not marked terminal until broker reconciliation confirms the final status.
- Failed requests and broker snapshot failures are reported without re-enabling trading. Durable pause read failures fail closed.
- A 500-order snapshot is flagged as potentially truncated; pagination/drain-loop validation remains outstanding.
- Validation: `python -m pytest -q` — 428 passed, 6 skipped, 88 subtests; `python -m unittest discover -q` — 424 passed; `compileall` passed; SQLite Alembic upgrade reached `f3b8c2d91a64`; FastAPI import succeeded in simulation and non-simulation modes (35 routes each).
- Not validated: real PostgreSQL concurrency, authenticated Alpaca Paper cancellation, and broker-side final cancellation outcomes.

## 2026-11-12 — partial-fill and late-fill reconciliation

- Broker cumulative `filled_qty` is now validated against requested `qty` and status semantics before any reconciliation snapshot is persisted.
- Fill activity side must match the parent broker order; inconsistent fills are rejected rather than ingested.
- Reconciliation reports per-order broker-vs-ledger filled-quantity checks. Any mismatch is warned and prevents optional financial reconciliation from claiming a complete fill ledger.
- Recently terminal orders are retained for seven days in the reconciliation query so late fill activities after cancellation can still be ingested idempotently.
- Regression tests cover multiple partial fills during cancel, missing/late fill activities, invalid side, inconsistent `filled` quantity, and financial reconciliation fail-closed behavior.
- Validation: 439 pytest passed, 6 PostgreSQL-only skips, 88 subtests; 435 unittest passed; compileall passed; SQLite Alembic reached `f3b8c2d91a64`; FastAPI imports succeeded with 35 routes in both simulation and non-simulation configurations.
- Real PostgreSQL concurrency, authenticated Alpaca Paper reconciliation, and external broker cancellation outcomes remain unverified.
- See `PHASE7-PARTIAL-FILL-RECONCILIATION.md`.
