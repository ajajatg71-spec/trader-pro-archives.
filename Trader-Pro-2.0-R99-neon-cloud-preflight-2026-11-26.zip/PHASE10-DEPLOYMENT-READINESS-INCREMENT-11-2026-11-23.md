# Trader Pro 2.0 — Durcissement livraison R32 — 23/11/2026

## Changements
- Docker utilise maintenant `npm ci` et exige `frontend/package-lock.json` au lieu de résoudre des dépendances variables avec `npm install`.
- Ajout de `.dockerignore` pour exclure les fichiers `.env`, les secrets, états financiers locaux, bases SQLite, sauvegardes, caches, archives et builds frontend locaux du contexte Docker.
- Documentation de déploiement mise à jour : génération/validation du lockfile, build propre et garde-fous de contexte.
- Tests de contrat ajoutés pour vérifier le verrouillage npm et les exclusions Docker.

## Tests réellement exécutés
- `BROKER=sim pytest -q` : **774 passed, 11 skipped, 202 subtests passed**.
- `python -m compileall -q .` : réussi.
- `node --check frontend/public/sw.js` : réussi.
- Parsing JSON du manifeste PWA : réussi.

## Blocage explicite
`frontend/package-lock.json` est absent. Le Dockerfile exige désormais ce fichier et `npm ci` ; par conséquent, le build Docker échouera proprement jusqu'à génération/validation du lockfile dans un environnement disposant du registre npm. Aucune installation npm complète ni compilation React n'a été exécutée.

## Autres validations externes non effectuées
- Docker/Podman indisponible dans l'environnement d'exécution ; image non construite ni démarrée.
- PostgreSQL/Neon réel et test de restauration non exécutés.
- Alpaca Paper réel non connecté ; aucun ordre soumis.
- HTTPS, cookies/session et navigateur distant non testés.

## Décision
R32 améliore la sécurité du contexte Docker et la reproductibilité attendue, mais n'est pas une version certifiée prête pour production. Live reste verrouillé.
