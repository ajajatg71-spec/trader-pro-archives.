# Phase 9 — Backtesting audit and hardening (2026-11-15)

## Scope
Independent review of `backtest.py` and `tests/test_backtest.py` from the latest available Phase 8 read-only hardening archive. This is a code-level/local validation only; it is not evidence of market-data quality or live/Paper trading performance.

## Findings corrected

1. **Unsafe inputs were accepted.** Invalid/zero/non-finite prices, non-positive starting capital, negative or >=100% fee/slippage, invalid sizing bounds, invalid stop settings and malformed cooldowns could produce nonsensical results or arithmetic errors. The engine now rejects these inputs explicitly.
2. **Optimization split was unchecked.** `optimize()` could accept a split leaving no meaningful train or test window, and an unknown strategy could fail with a raw key error. It now requires a finite split strictly between 0 and 1, at least two prices in each partition, and a known strategy.
3. **Metric inputs were weakly guarded.** `evaluate()` now checks matching equity/position lengths, finite positive equity, valid slice bounds and a positive integer annualization factor.
4. **Walk-forward aggregate metrics were misleading.** The aggregate OOS equity curve previously supplied an all-zero position vector and an empty trade list, so aggregate exposure and completed-trade statistics always reported zero even when fold-level strategies traded. The stitched OOS position series and completed trades are now carried into aggregate metrics. A regression test covers strategy exposure/trades and buy-and-hold exposure.

## Behaviors confirmed by existing tests and code inspection

- Signals are calculated using data through bar *i* and orders are executed at the next bar's close.
- OOS `run()` windows begin with fresh cash and flat exposure; prior positions are not carried into the test window.
- Walk-forward parameter selection uses only the training slice preceding each test fold; test windows are chronologically ordered and non-overlapping by default.
- Fees and slippage are applied to both entry and exit legs.

## Remaining limitations — not certified for institutional release

- Close-only execution model; no OHLC intrabar stop execution, opening gaps, queue position, partial fills, market impact, spread model or latency model.
- End-of-window open positions are marked to market, not force-liquidated; completed-trade count and trade bootstrap omit those still-open positions.
- Bootstrap resamples individual trades independently (IID); it does not preserve serial dependence, volatility clustering or regime changes. A block/stationary bootstrap and confidence intervals remain desirable.
- Long-only model; no short borrow, financing, margin, dividends, corporate actions, delistings or point-in-time universe/survivorship controls are established here.
- Correctness still depends on upstream timestamps, adjusted/raw price consistency, exchange calendars, missing-bar handling and point-in-time data integrity.
- No independent research-grade out-of-sample study across multiple assets, regimes and untouched final holdout has been performed.

## Local verification on 2026-11-15

- `python -m pytest -q`: **532 passed, 10 skipped, 115 subtests passed**.
- `python -m unittest discover -q`: **528 passed**.
- `python -m compileall -q .`: passed.
- The 10 skipped tests include PostgreSQL integration tests; they are not counted as successful PostgreSQL validation.

## Decision
Phase 9 remains **in preparation / partial**. This hardening improves input integrity and aggregate OOS reporting but does not close Phase 9. Phase 8 also remains open pending real PostgreSQL and authenticated Alpaca Paper validation. Live trading remains disabled.

## Follow-up correction — first out-of-sample bar costs (2026-11-15)

A second review found a boundary-accounting defect not covered by the original tests: `optimize()` and `walk_forward()` evaluated OOS metrics starting at the first test close. When the signal formed at the final training close caused an entry at that first test close, the initial entry fee/slippage was already reflected in equity but excluded from the measured OOS return because that first test equity point became the metric baseline.

Correction:
- OOS evaluation now includes the final training close as the return anchor (`start_index - 1`) and the first test close as the first OOS return interval.
- Walk-forward stitching compounds the first test-bar return for every fold, including entry costs.
- Exposure is calculated over actual OOS bars, not the added pre-test anchor observation.
- Added regression tests with flat prices and a 1% fee, proving that the first OOS entry is reflected as a -1% return in optimization and every walk-forward fold/aggregate.

Updated local verification after this correction:
- Backtest tests: **39 passed, 31 subtests passed**.
- Full pytest: **534 passed, 10 skipped, 115 subtests passed**.
- Unittest discovery: **530 passed**.
- `compileall`: passed.

The 10 skipped tests remain PostgreSQL integration tests. No real PostgreSQL or Alpaca Paper validation was performed.

## Follow-up hardening — block bootstrap and input validation (2026-11-15)

The trade bootstrap accepted invalid sample counts and malformed returns, and only supported IID resampling. It now validates the input sequence, finite returns strictly greater than -100%, positive integer sample count, integer seed and valid block size. `block_size=1` preserves the IID method; `block_size>1` uses circular contiguous blocks and labels the result `circular_block`. The output now reports sample count, method and block size. Deterministic regression tests cover invalid inputs and repeatability.

This block bootstrap preserves some local ordering but does not establish stationarity, solve regime shifts, or replace a final untouched holdout. It is a diagnostic sensitivity tool, not proof of strategy robustness.

Updated local verification:
- Backtest tests: **45 passed, 43 subtests passed**.
- Full pytest: **540 passed, 10 skipped, 127 subtests passed**.
- Unittest discovery: **536 passed**.
- `compileall`: passed.


## Follow-up hardening — bootstrap numeric overflow (2026-11-15)

A boundary test with five individually finite but extreme trade returns showed that direct multiplication could overflow the compounded bootstrap equity and silently return `inf` percentiles. Compounding now uses logarithmic growth and explicitly raises `OverflowError` when the reported percentage cannot be represented as a finite float. A regression test reproduces and guards the case.

Updated local verification: backtest tests **45 passed, 43 subtests**; full pytest **540 passed, 10 skipped, 127 subtests**; unittest discovery **536 passed**; `compileall` passed. PostgreSQL tests remain skipped and no external broker checks were run.

## Follow-up hardening — strict result and strategy contracts (2026-11-15)

A further interface audit found that `evaluate()` trusted caller-provided position and trade records too much: missing trade lists could raise incidental `KeyError`, invalid position values could distort exposure, and malformed/out-of-range trade records could silently corrupt win-rate counts or crash later. The evaluator now requires an explicit list of trade records, validates each position as 0/1, validates each trade as an in-range `(index, return)` pair with finite return strictly greater than -100%, and raises actionable `ValueError`s.

The built-in `bh`, `sma`, `rsi` and `tech` strategies now validate their parameter dictionaries before execution, including SMA ordering, RSI bounds and threshold ordering, and finite positive technical threshold. Custom test strategies remain extensible and are not forced into built-in parameter schemas.

Regression coverage verifies malformed results are rejected and every built-in parameter grid still executes.

Updated local verification:
- Backtest tests: **49 passed, 93 subtests passed**.
- Full pytest: **544 passed, 10 skipped, 177 subtests passed**.
- Unittest discovery: **540 passed**.
- `python -m compileall -q .`: passed.

These are local code tests only. PostgreSQL integration remains unexecuted in this environment; no authenticated Alpaca Paper request or order was made.


## Follow-up implementation — OHLC intrabar execution model (2026-11-15)

A separate `run_ohlc()` engine has been added without changing the existing close-only `run()` contract. It validates aligned OHLC series and candle consistency; calculates signals at the close and executes strategy orders at the next open; evaluates protective stops against opening gaps and intrabar ranges; fills gap-through stops at the opening price rather than the stale stop level; and applies a conservative stop-first rule when a candle touches both stop and take-profit levels. Trailing highs are updated only after the current candle's stop check, avoiding an invented intrabar path. Stop cooldown is supported. Open positions at the end remain marked to market, not forcibly liquidated.

Regression tests cover next-open execution, gap-through stop fills, intrabar stop fills, ambiguous stop/target bars, malformed OHLC data, and cooldown. This is a first OHLC execution model, not a full market simulator: it still omits intrabar sequencing beyond the conservative policy, volume/liquidity, partial fills, spread/market impact/latency, corporate actions, and portfolio-level constraints. It requires trusted OHLC inputs.

Updated local verification after OHLC addition: backtest tests **56 passed, 93 subtests passed**; full pytest **551 passed, 10 skipped, 177 subtests passed**; unittest discovery **547 passed**; `python -m compileall -q .` passed. The 10 skipped tests remain PostgreSQL integration tests. No real PostgreSQL connection or Alpaca Paper API request was performed.

## Follow-up hardening — OHLC position sizing parity (2026-11-15)

A review of the new OHLC path found that it always invested all available cash, while the established close-only engine supports volatility-based sizing. `run_ohlc()` now accepts the same optional `sizing={risk, k, max_frac}` contract, validates it, preserves uninvested cash, and estimates volatility only from closes available before the entry bar. When fewer than five historical returns are available, it uses `max_frac`, matching the documented close-only fallback. The legacy `run()` signature and behavior are unchanged.

Regression coverage verifies both the short-history fallback and the pre-entry volatility sizing calculation, plus invalid sizing rejection. This does not yet implement portfolio-level multi-asset allocation or dynamic liquidity/volume constraints.

Updated local verification: backtest tests **59 passed, 93 subtests passed**; full pytest **554 passed, 10 skipped, 177 subtests passed**; unittest discovery **550 passed**; `python -m compileall -q .` passed. The 10 skipped tests remain PostgreSQL integration tests. No real PostgreSQL connection or Alpaca Paper API request was performed.
