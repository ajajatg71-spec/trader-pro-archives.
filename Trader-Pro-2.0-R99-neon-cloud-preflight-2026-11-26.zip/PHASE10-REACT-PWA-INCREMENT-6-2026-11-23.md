# Trader Pro 2.0 — Phase 10 React/PWA increment 6 (R27)

Date: 2026-11-23  
Base: R26

## Delivered

- Added a manual PWA installation guide for browsers that do not expose `beforeinstallprompt`, including iOS/iPadOS Safari steps and generic browser-menu guidance.
- Detects standalone display mode so the install affordance is hidden after the app is installed.
- Replaced the misleading static “Session sécurisée” label with a truthful online/offline indicator.
- Footer now explicitly reports offline state and masked financial data rather than implying broker connectivity.
- Added reduced-motion CSS support and mobile layout refinements for the connection and install controls.
- Research registry now detects connectivity, avoids network refresh while offline, and disables preregistration while offline.
- No trading, order, pause, rebalance, strategy activation or portfolio mutation controls were added.

## Validation

- Full Python suite with `BROKER=sim`: **759 passed, 11 skipped, 202 subtests passed**.
- Frontend contract tests: **17 passed**.
- `python -m compileall -q .`: passed.
- `node --check frontend/public/sw.js`: passed.
- TypeScript TSX syntax transpilation for `main.tsx` and `ResearchRegistry.tsx`: passed using the globally available TypeScript transpiler.
- Full TypeScript typecheck and Vite production build: **not verified** because npm dependencies are not installed; offline npm installation failed because `@types/react` was not present in the local npm cache. No compiled `dist` output is claimed.
- ZIP integrity: verified separately.
- No browser-device test, Lighthouse audit, Neon test, Alpaca Paper API test, or live order was performed.

## Security and deployment notes

- Service worker behavior remains network-only for navigation and excludes API/authenticated content from cache.
- Account/risk/orders/health remain cleared from memory on `offline`.
- Research preregistration is disabled while offline.
- Do not deploy R27 as the production frontend until dependencies are installed, `npm run typecheck` and `npm run build` pass, and real-browser tests validate session, CSRF, logout, offline/online transitions and mobile layouts.
- Live trading remains locked.
