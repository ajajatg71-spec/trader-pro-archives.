# Trader Pro 2.0 — continuation phase 10 / increment 2 (2026-11-18)

## Changes

- Improved the React dashboard's institutional-risk visibility: it now displays `institutional.status` and includes institutional breaches alongside portfolio risk alerts. These values are read from the existing `/api/risk` response; no risk formulas were changed.
- Corrected the risk panel label from “Perte quotidienne” to “Variation quotidienne”, matching the V1 `core.daily_loss` contract (percentage return, negative means loss).
- Made the health/liveness request optional: a degraded `/health` response no longer causes the otherwise valid account, positions, orders and risk payloads to be discarded by a single `Promise.all` failure.
- Hardened the PWA offline behavior. The service worker no longer caches `/` or authenticated dashboard HTML; it caches only the generic offline page, manifest and icons. It explicitly excludes API requests, cross-origin requests and non-GET requests.
- Added a generic offline page that contains no account or portfolio data, and exposed it through a conditional FastAPI static route when a compiled PWA exists.

## Verification

- `python -m compileall -q .`: passed.
- `python -m pytest -q -rs`: **614 passed, 11 skipped, 202 subtests passed**, 0 failures.
- `node --check frontend/public/sw.js`: passed.
- Conditional PWA static-route smoke test with a temporary `frontend/dist`: `/manifest.webmanifest`, `/sw.js`, `/offline.html`, `/icon-192.png`, and `/icon-512.png` all returned HTTP 200; unauthenticated `/` redirected to `/login` (307). Temporary build fixture removed afterwards.
- The npm package install timed out; offline installation confirms required packages are not cached. Consequently `npm run typecheck`, `npm run build`, real-browser rendering, HTTPS integration and installability are still unverified. No `frontend/dist` is shipped.

## Phase 8 review

A further source review confirmed that broker-event processing uses a per-claim token for acknowledgement/failure updates, so a superseded worker cannot acknowledge another worker's lease. Broker notifications trigger full reconciliation only; they do not submit or retry orders. Fill ingestion is keyed by unique broker fill ID, uses Decimal normalization and checks cumulative broker `filled_qty` against the durable ledger. No further code change was justified by this review.

## Boundaries / not done

- No actual Neon/PostgreSQL connection, migration against the user's database, restore drill, or PostgreSQL integration run.
- No authenticated Alpaca Paper read-only request in this environment and no Paper or Live order submitted.
- No frontend npm build or browser test because dependency installation could not complete.
- No deployment; Live remains disabled.

## Next

1. Build the React frontend in a network-enabled Node environment and run typecheck/build.
2. Run HTTPS browser integration against FastAPI using a non-production test account.
3. Execute PostgreSQL integration tests only against a disposable database, never the user's Neon validation or production database.
4. Run Alpaca Paper read-only verification using secrets stored in the user's secure environment; any order test remains separately gated by explicit approval.
