# Décision d'architecture — mandat de trading utilisateur

Date : 23 novembre 2026  
Statut : décision utilisateur confirmée, à appliquer à l'architecture et aux validations

## Décisions retenues

1. **Autonomie complète dans les limites de risque** : une fois le mode d'exécution autorisé et validé, le système peut sélectionner, dimensionner, envoyer et gérer automatiquement les ordres sans demander une confirmation individuelle pour chaque transaction.
2. **Capital disponible uniquement** : aucune marge, aucun emprunt, aucun financement par crédit et aucune exposition supérieure aux liquidités réellement disponibles.

## Conséquences architecturales obligatoires

- Le Strategy Engine et l'allocateur adaptatif proposent des décisions; ils ne peuvent pas contourner les contrôles.
- Le Risk Governor est l'autorité finale pour chaque ordre : limites par ordre/jour/semaine, pertes, drawdown, exposition, concentration, liquidité, qualité/fraîcheur des données et kill switch.
- Un contrôle de financement indépendant vérifie que le notionnel de l'ordre est intégralement couvert par le cash disponible confirmé par le broker. L'« buying power » incluant une marge n'est pas une preuve de cash disponible.
- Si le cash disponible est absent, périmé, incohérent ou impossible à distinguer de la capacité d'emprunt, l'ordre est bloqué (fail-closed).
- Les ordres qui dépassent le cash disponible sont rejetés ou réduits par le moteur de risque; aucune marge ou dette ne peut combler l'écart.
- Le contrôle est appliqué au pré-trade, puis à la réconciliation post-trade; les réservations de cash et les ordres en attente doivent être déduits pour éviter les doubles dépenses.
- Le mode autonome ne donne pas au moteur de recherche le droit d'activer une stratégie ni de modifier les limites de risque. L'approbation de stratégie, la configuration des limites et l'activation du mode Live restent des étapes distinctes.

## Séparation autonomie / autorisation d'exécution

Cette décision fixe le comportement cible, mais **n'active pas l'exécution réelle**. Simulation reste sans ordre broker; Paper doit être validé avec PostgreSQL/Neon et Alpaca Paper; Live reste verrouillé jusqu'aux validations techniques, opérationnelles et de sécurité, puis une activation distincte et explicite. Les credentials absents ou un état de compte non vérifiable ne déclenchent jamais un basculement silencieux.

## Implémentation initiale

`trading_mandate.py` formalise le mandat par défaut et expose un contrôle de couverture cash pur, testable et fail-closed. Il s'agit d'une brique de politique; elle n'est pas encore branchée à tous les chemins d'ordres du broker. Cette intégration effective et les tests de concurrence/réservation de cash restent requis avant Paper/Live.

## Paramètres de référence

- `autonomy = full_within_risk_limits`
- `allow_margin = false`
- `allow_borrowed_funds = false`
- `require_risk_governor = true`
- `fail_closed_on_unknown_buying_power = true`

Aucune valeur ne doit permettre à l'autonomie de neutraliser le Risk Governor, le kill switch ou les plafonds utilisateur.
