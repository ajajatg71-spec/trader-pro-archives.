# Phase 8 — signed short-position snapshots and numeric preflight (2026-11-16)

A cross-layer audit found a mismatch: `ReconciliationService` accepted finite negative position quantities, which are valid for short positions, but `OrderRepository.record_reconciliation_snapshot()` rejected every negative quantity. The repository now persists signed quantities and signed market values while rejecting zero/non-finite quantities, non-finite market values, invalid average entry prices, and non-finite unrealized P/L. Decimal values are retained for SQL Numeric columns; audit JSON stores decimal strings to remain JSON-serializable.

The reconciliation boundary now validates account equity/cash/buying-power and position market value/optional price/P&L fields before stale-submission recovery or any local mutation. This prevents malformed numeric snapshots from partially changing local order state before snapshot persistence fails.

Regression coverage:
- Valid short position with negative quantity and market value is persisted.
- NaN market value is rejected before stale-order recovery or account snapshot writes.
- Infinite account equity is rejected before stale-order recovery or account snapshot writes.

Verification on this archive:
- `python -m pytest -q`: **585 passed, 11 skipped, 194 subtests passed**.
- `python -m unittest discover -q`: **581 passed**.
- `python -m compileall -q .`: passed.
- `alembic heads`: one head, `b8d2f4a6c901`.
- Full Alembic upgrade to head and `alembic current`: succeeded on a disposable SQLite database.

The 11 skipped tests are opt-in PostgreSQL integration tests. This runtime still has no Docker/Podman or PostgreSQL server/client, and no authenticated Alpaca Paper credentials. Therefore real PostgreSQL and Alpaca Paper remain unvalidated. No broker order was submitted or cancelled; Live remains disabled. Phase 8 remains open.
