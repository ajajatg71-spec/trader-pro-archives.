# Phase 3 — Broker ↔ PostgreSQL ↔ Paper reconciliation

Date: 11 November 2026

## Implemented

- Manual authenticated endpoint `POST /api/reconciliation/run`; no scheduler submits or retries orders.
- Conservative reconciliation of local open/uncertain orders against broker orders by `client_order_id`, with fallback to a previously stored `broker_order_id`.
- Identity checks reject a mismatch in symbol, side, or broker order ID before any reconciliation snapshot is written.
- Alpaca FILL activities now retain the unique activity ID and broker order ID required for exact fill mapping.
- Simulated broker fills expose the same identifiers, enabling a real adapter-level integration test.
- Fill ingestion is idempotent by broker activity ID. Unmatched fills are reported and never guessed.
- Account and position snapshots are stored atomically with a shared capture timestamp.
- Strategy proposals are closed from the pending-restore set when their broker order is confirmed.
- Existing durable order intents block a second submission. An absent order in a possibly truncated broker snapshot remains unresolved; it is never auto-retried.
- Truncation of order and fill snapshots is explicitly reported.
- `BROKER=sim` now selects `sim_broker` in the application rather than only changing the dashboard label.

## Verification

- `python -m compileall -q .`: passed.
- `python -m pytest -q`: 323 passed, 72 subtests passed.
- `python -m unittest discover -q`: 319 passed.
- Alembic SQLite upgrade → downgrade base → upgrade head: passed.
- End-to-end integration with the project's actual `sim_broker`: one order matched, status `filled`, one fill persisted, one account snapshot and one position snapshot persisted, no warnings.
- `BROKER=sim` application import: broker module is `sim_broker`; 35 FastAPI routes including the reconciliation endpoint.
- ZIP integrity: verified after packaging.

## Not yet verified

- No Docker executable or PostgreSQL client/server is available in this environment. A real PostgreSQL 16 migration/transaction/concurrency/restore test remains outstanding.
- No external Alpaca Paper credentials or live Paper account were queried. The Alpaca adapter normalization was implemented but not validated against a live account response.
- No automatic retry exists by design. `submission_unknown`, missing remote orders, truncated snapshots, and unmatched fills require a fresh complete broker snapshot and operator review.
- Position snapshots are historical observations; they are not a substitute for a broker-versus-ledger quantity/cash/equity variance policy. That comparison is the next hardening item.

## Safety

- Paper only. Live trading remains disabled.
- Reconciliation never creates, resubmits, or cancels orders.
- A broker record not found is not treated as a rejection.
