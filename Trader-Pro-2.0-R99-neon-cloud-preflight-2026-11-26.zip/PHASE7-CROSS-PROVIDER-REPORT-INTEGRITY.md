# Phase 7 — Intégrité des rapports de comparaison inter-fournisseurs

Date : 11 novembre 2026

## Défaut détecté

La garde vérifiait les types et la cohérence élémentaire des champs, mais elle faisait encore confiance aux verdicts booléens `within_tolerance` et `within_volume_tolerance`. Un rapport construit par un appelant pouvait donc associer un écart important à un verdict favorable. Le taux de recouvrement pouvait aussi être modifié sans modifier les comptages.

## Correction

- Le rapport mémorise les seuils de clôture et de volume réellement utilisés.
- La garde vérifie que les verdicts correspondent aux mesures et aux seuils.
- Elle recalcule le recouvrement attendu à partir des bougies communes et exclusives, puis rejette tout écart incohérent.
- Les seuils doivent être finis et positifs ou nuls.
- Les contrôles ne sélectionnent, ne moyennent et ne remplacent aucun cours.

## Validation locale

- `python -m pytest -q tests/test_market_data_service.py` : 50 tests réussis, 24 sous-tests réussis.
- `python -m pytest -q` : 409 tests réussis, 3 ignorés, 88 sous-tests réussis.
- Les 3 tests ignorés sont les intégrations PostgreSQL opt-in ; aucun serveur PostgreSQL de test n'est configuré.

## Limites non levées

- Aucun appel authentifié Alpaca ou Twelve Data n'a été effectué.
- L'indépendance, la couverture des symboles, les règles d'ajustement des actions et les périmètres de volumes restent à qualifier avec les comptes réels.
- Le flux Alpaca/IEX est partiel et ne constitue pas un volume consolidé de marché.
- La comparaison reste opt-in et n'est pas branchée au chemin de passage d'ordre.
- Paper trading réel et PostgreSQL réel restent à valider avant clôture de la phase 7.
