# Phase 8 — Execution Engine & broker reconciliation

## Initial implementation checkpoint

**Status: IN PROGRESS. This is not a phase closure or production-readiness certification.**

Phase 7 remains open for real PostgreSQL and Alpaca Paper validation. Phase 8 engineering can proceed on isolated execution-lifecycle work, but automated Paper operation remains gated until the preceding risk/database validations are complete. Live trading remains disabled.

## Existing execution/reconciliation foundation verified in the source tree

- `services/orders.py` coordinates pre-trade checks, durable order-intent staging, broker submission, and uncertain-submission handling.
- `broker.py` restricts the configured broker URL to the official HTTPS Alpaca Paper endpoint and uses stable `client_order_id` values.
- `services/reconciliation.py` fetches broker orders, fills, account and positions before local reconciliation; ingests fills idempotently; flags partial-fill mismatches; and never automatically retries missing/uncertain orders.
- `db/order_repository.py` persists order status, fill ledger, account/position snapshots, and cancellation audit events.

These are source-level capabilities and automated local tests; they do not prove connectivity to a live PostgreSQL instance or Alpaca Paper account.

## Changes in this checkpoint

`OrderService.cancel()` now:

1. Resolves the local order correlation from the durable reconciliation snapshot before issuing the external cancellation request.
2. Refuses to call the broker if the durable local order snapshot is unavailable.
3. Records a failed cancellation request without changing the order to a terminal state.
4. Records a successful cancellation request as `pending_cancel` through `record_order_cancel_event`; it does not claim that the order is canceled.
5. Returns an explicit gateway/service error if the broker request or required durable audit fails, so the caller cannot mistake an unconfirmed outcome for a completed cancellation.
6. Leaves the final `canceled` / `filled` outcome to a subsequent broker reconciliation, because a fill can race with a cancellation request.

## Verification performed

- `python -m pytest -q`: **450 passed, 7 skipped, 88 subtests passed**.
- `python -m unittest discover -q`: **446 tests passed**.
- `python -m compileall -q .`: passed.
- The 7 skipped tests are opt-in PostgreSQL integration tests; no real PostgreSQL validation is claimed.
- No authenticated Alpaca Paper request or order was submitted in this checkpoint.

## Remaining Phase 8 work

1. Build a dedicated execution adapter/interface and formal order lifecycle transition policy, without bypassing the Phase 7 risk gate or durable order claim.
2. Add end-to-end tests for submit → broker acknowledgement → partial fill → cancel race → final reconciliation, including restart/recovery cases.
3. Validate broker pagination, activity ingestion and reconciliation against Alpaca Paper with a real Paper account and PostgreSQL.
4. Add operational reporting for unresolved submissions, unmatched fills, quantity discrepancies and cancellation uncertainty.

## Safety constraints

- No automatic resubmission when the broker outcome is unknown.
- Stable client order IDs remain mandatory for idempotency.
- Cancellation request is not equivalent to cancellation confirmation.
- Paper-only endpoint guard remains in force; no Live endpoint or credentials are enabled.
- Do not enable autonomous Paper execution until Phase 7's real-environment gates are passed and explicitly reviewed.

## Second implementation checkpoint — lifecycle transition policy

Added `services/order_lifecycle.py`, an explicit fail-closed order status transition policy. `ReconciliationService` now rejects stale/invalid status regressions before updating the durable order or synchronizing strategy status. Broker-confirmed cancellation/fill races remain supported. Nine tests cover the policy and its reconciliation integration.

Verification: pytest **459 passed, 7 skipped, 88 subtests**; unittest **455 passed**; compileall and YAML parsing passed. PostgreSQL-only integration tests remain skipped and Alpaca Paper was not contacted. See `PHASE8-ORDER-LIFECYCLE-POLICY.md`.

## Phase 8 continuation — operator execution-health summary

- Added `services/execution_health.py`, a read-only classifier for unresolved submissions, broker-missing orders, pending cancellations/replacements, open partial fills, fill-ledger mismatches, rejected lifecycle transitions, and incomplete broker snapshots.
- `ReconciliationService.run()` now includes an `execution_health` section with `healthy` / `warning` / `critical`, exception counts, operator actions, and an explicit `automatic_retry_permitted: false` invariant.
- The classifier uses broker-observed status for pending-action visibility while lifecycle transition validation remains responsible for preventing stale snapshots from overwriting newer local state.
- Added five focused tests for unknown submissions, pending cancellation, fill mismatch, healthy terminal orders, and truncated snapshots.
- Local validation: pytest 465 passed, 7 PostgreSQL-only skipped, 88 subtests passed; unittest 461 passed; compileall and YAML parsing passed. These are local tests, not real PostgreSQL or Alpaca Paper validation.

## Phase 8 continuation — durable broker event inbox

- Added `BrokerEventRecord` and Alembic migration `91c7d3e5a2b4` for a durable, idempotent event inbox.
- Added `services/broker_events.py`: allowlisted event payload storage, exact replay deduplication, conflicting-ID rejection, batch reconciliation trigger, durable failure state, and stale processing lease recovery.
- Broker events never directly overwrite order state and never submit/retry/cancel orders; a full broker reconciliation is required before acknowledging a batch.
- New tests cover allowlisting, duplicate/collision behavior, malformed envelopes, successful batch processing, failed reconciliation, stale-lease recovery, and invalid limits.
- Validation: pytest 472 passed, 7 PostgreSQL-only skipped, 88 subtests passed; unittest 468 passed; compileall passed; full Alembic SQLite upgrade to head passed.
- Not yet wired to an Alpaca websocket/webhook receiver or Phase 11 worker. No PostgreSQL server or authenticated Alpaca Paper stream was used.
