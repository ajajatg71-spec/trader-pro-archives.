"""Stockage fiable : écriture atomique, sauvegardes automatiques avec rotation, restauration si fichier corrompu."""
import glob, json, os, shutil, time

def load_json(path, default, backup_dir="backups"):
    for p in [path] + sorted(glob.glob(os.path.join(backup_dir, "*", os.path.basename(path))), reverse=True):
        try:
            with open(p, encoding="utf-8") as f: return json.load(f)
        except Exception: continue
    return default

def save_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=1, ensure_ascii=False); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)

def backup(files, backup_dir="backups", keep=14, now=None):
    d = os.path.join(backup_dir, time.strftime("%Y%m%d-%H%M", time.localtime(now)))
    os.makedirs(d, exist_ok=True)
    for f in files:
        if os.path.exists(f): shutil.copy2(f, d)
    for old in sorted(glob.glob(os.path.join(backup_dir, "*")))[:-keep]: shutil.rmtree(old, ignore_errors=True)
    return d
