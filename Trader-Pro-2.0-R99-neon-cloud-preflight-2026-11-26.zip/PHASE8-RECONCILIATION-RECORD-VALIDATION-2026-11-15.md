# Phase 8 — validation stricte des enregistrements de réconciliation (2026-11-15)

## Constat

L'audit précédent rejetait déjà les éléments non-dictionnaires dans les listes d'ordres, d'exécutions et de positions. Il restait cependant possible qu'un dictionnaire incomplet soit accepté : un ordre pouvait ne pas contenir son statut, et une position pouvait ne pas avoir de quantité exploitable. Ces données pouvaient ensuite être persistées comme snapshot, ce qui affaiblissait la valeur probante d'une réconciliation.

## Correction

Avant toute récupération de soumission obsolète ou écriture en base, `ReconciliationService.run()` valide désormais :

- chaque ordre : `id`, `client_order_id`, `symbol`, `side` et `status` non vides ; `side` doit être `buy` ou `sell` ;
- chaque position : symbole et quantité présents ; quantité Decimal finie et non nulle ; un seul enregistrement par symbole.

Toute violation interrompt la réconciliation avant l'enregistrement du snapshot, des fills ou des preuves de réconciliation. Les contrôles numériques existants sur les quantités d'ordre et d'exécution restent en place.

## Tests ajoutés

- ordre dictionnaire mais incomplet : rejet avant toute écriture ;
- positions avec quantité `NaN`, quantité nulle ou symbole dupliqué : rejet avant toute écriture.

## Vérifications locales

- `python -m pytest -q` : **579 passed, 11 skipped, 194 subtests passed** ;
- `python -m unittest discover -q` : **575 passed** ;
- `python -m compileall -q .` : réussi ;
- `alembic heads` : tête unique `b8d2f4a6c901` ;
- chaîne complète `alembic upgrade head` puis `alembic current` sur SQLite temporaire : réussite, tête `b8d2f4a6c901`.

## Limites et sécurité

Les 11 tests PostgreSQL restent ignorés car ce runtime ne fournit ni Docker/Podman ni `psql`. Ce passage SQLite ne certifie pas les verrous, transactions concurrentes, sauvegardes/restaurations ou reprises PostgreSQL. Aucun secret Alpaca Paper n'est disponible ici ; aucun appel authentifié au courtier n'a été effectué. Aucun ordre Paper n'a été soumis ou annulé. Le mode Live reste désactivé.

La phase 8 reste ouverte jusqu'à exécution documentée des validations PostgreSQL réelles et de la vérification Alpaca Paper en lecture seule.
