# Trader Pro 2.0 — Phase 2 OrderService

## Changes
- Added `services/orders.py` with injected state, lock, persistence, history, broker, and V1 risk-check dependencies.
- Moved order listing, approval, rejection, cancellation, and pause toggling orchestration out of `app.py`.
- Kept `core.check`, `core.daily_loss`, broker submission, and the pending-order ID as the broker `client_order_id` unchanged.
- Kept FastAPI exception translation in `app.py`; the service raises transport-neutral `OrderServiceError` values.
- Added service tests for approval, pause, daily-loss emergency halt, risk rejection, missing orders, cancellation, and state transitions.

## Verification
- `python -m pytest -q`: 148 passed.
- `python -m unittest discover -s tests -q`: 148 passed.
- `python -m compileall -q .`: passed.
- `BROKER=sim` application import: passed; 31 routes registered, including all order lifecycle routes and `/api/risk`.
- Six financial V1 modules (`core.py`, `scoring.py`, `risklib.py`, `portfolio.py`, `indicators.py`, `backtest.py`) compare byte-for-byte identical to the original archive.
- Tests use mocks/simulation. No Alpaca Paper or Live account was connected; no broker order was submitted.

## Scope and limitations
- Phase 2 remains in progress. `StrategyService`, configuration cleanup, final app assembly review, and integration coverage remain outstanding.
- The service preserves the existing V1 execution flow; it does not add broker reconciliation or guarantee recovery from an ambiguous network timeout. Those controls require a separate, explicitly tested execution/reconciliation step.
- Live mode remains disabled.
