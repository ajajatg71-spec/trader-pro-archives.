# Decision R63 — Protection des transitions d'ordres

## Décision
Le dépôt local d'un statut d'ordre applique désormais la politique centralisée
`services.order_lifecycle.evaluate_transition` avant toute mutation.

## Comportement
- Une transition autorisée est enregistrée normalement.
- Un statut broker obsolète ou incompatible est ignoré sans écraser l'état local.
- Chaque transition ignorée produit un audit `order_status_ignored` avec l'état
  courant, le statut entrant, la raison et l'identifiant broker éventuel.
- La course annulation/remplissage reste permise : `pending_cancel -> filled`
  et `canceled -> filled` restent des transitions acceptées quand le broker
  confirme le remplissage.
- Aucun ordre n'est renvoyé au broker par cette protection.

## Validation
- `test_order_repository.py`, `test_reconciliation.py`,
  `test_order_service.py`, `test_order_lifecycle.py` : 134 passed,
  13 subtests passed.
- `test_broker_events.py`, `test_broker_event_worker.py` : 25 passed,
  4 subtests passed.
- Suite complète non exécutée dans ce jalon.

## Limites opérationnelles
Cette modification est un candidat local. Elle ne prouve ni la validation
PostgreSQL/Neon ni une réconciliation réelle Alpaca Paper. Aucun ordre réel
n'a été envoyé. Le mode Live reste verrouillé.
