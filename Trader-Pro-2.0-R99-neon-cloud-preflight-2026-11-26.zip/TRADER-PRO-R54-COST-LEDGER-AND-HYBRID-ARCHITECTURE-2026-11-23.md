# Trader Pro 2.0 — R54 : comptabilisation des coûts et décision d'architecture hybride

Date : 23 novembre 2026  
Base : R53 (`Trader-Pro-2.0-consolide-candidat-2026-11-23-r53.zip`)  
Décision produit retenue : modèle C hybride adaptatif + portefeuille multi-stratégies ; profil de risque dynamique.

## Décision d'architecture

Le modèle C impose une séparation stricte en couches :

1. **Research / Strategy Discovery** : recherche et comparaison de stratégies ; aucun droit d'allocation ni d'accès broker.
2. **Strategy Approval Registry** : provenance, résultats vérifiables, validation humaine et version approuvée ; une candidate ne devient pas active par simple classement.
3. **Regime & Strategy Selector** : sélection parmi les stratégies approuvées à partir d'informations disponibles à la date de décision ; possibilité de ne sélectionner aucune stratégie.
4. **Portfolio Allocator** : combine les signaux approuvés, calcule des poids cibles et des transitions ; contraintes long-only par défaut, limites par actif/secteur, turnover et liquidité.
5. **Dynamic Risk Governor** : autorité finale indépendante ; peut réduire les poids, refuser les ordres, imposer le cash ou déclencher le kill switch. Le profil dynamique peut adapter le budget de risque dans une enveloppe préautorisée, mais ne peut jamais élargir seul les limites dures.
6. **Execution & Reconciliation** : seule couche autorisée à communiquer avec le courtier ; Paper uniquement jusqu'à validation distincte. Live reste verrouillé.

Le sélecteur et l'allocateur ne doivent pas être fusionnés avec le moteur de recherche. Le risque est un veto final et non un simple score d'optimisation.

## Incrément R54 réellement livré

Dans `research_v1/backtesting/portfolio_backtest.py` :

- Comptabilisation explicite des frais sur chaque exécution d'achat et de vente.
- Estimation du coût de slippage par rapport au prix d'ouverture de référence de la barre.
- Conservation des frais et du slippage dans chaque ligne de fill (`fees`, `slippage_cost`).
- Mise à jour des compteurs cumulatifs `PortfolioState.cumulative_fees` et `cumulative_slippage` lors des simulations segmentées.
- Ajout d'un objet `costs` au résultat avec coûts du segment et cumuls persistés.
- Le coût est compté une seule fois à l'exécution ; la reprise segmentée conserve les totaux.

## Tests

- Tests ciblés backtest/state : **17 passed**.
- Suite complète `BROKER=sim pytest -q` : **809 passed, 11 skipped, 202 subtests passed**.
- Les 11 tests ignorés exigent une base PostgreSQL externe jetable ; ils ne sont pas comptés comme réussis.

## Ce que R54 ne prétend pas livrer

- Pas encore de sélecteur adaptatif de stratégies approuvées.
- Pas encore d'allocateur de portefeuille multi-stratégies branché à l'exécution.
- Pas encore de profil dynamique de risque calibré ou validé ; aucune limite chiffrée n'est inventée dans cette étape.
- Pas encore de walk-forward portefeuille continu multi-stratégies ni de benchmark passif continu segmenté.
- Le slippage est ici un coût de simulation relatif à l'ouverture de la barre, pas une mesure de slippage réel du courtier.
- PostgreSQL/Neon réel, build frontend et Alpaca Paper authentifié restent à valider.
- Aucun ordre broker soumis ; aucun capital alloué ; Live verrouillé.

## Prochaine séquence sans doublon

R55 : formaliser le contrat de décision/allocation multi-stratégies (poids cibles, budget de risque, version des stratégies approuvées, timestamp des signaux, raisons de rejet) comme objet pur et sérialisable ; tester les contraintes et le veto du Risk Governor avant de le brancher au broker.

R56 : brancher ce contrat au portefeuille de recherche en simulation uniquement, avec attribution des contributions et tests de non-régression. Ensuite seulement, construire le walk-forward continu et comparer à des benchmarks cohérents.
