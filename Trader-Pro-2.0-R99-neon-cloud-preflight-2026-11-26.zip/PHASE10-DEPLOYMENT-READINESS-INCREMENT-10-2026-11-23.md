# Trader Pro 2.0 — Durcissement pré-déploiement R31 — 23/11/2026

## Changements
- Le précontrôle exige maintenant explicitement `ALPACA_BASE_URL` : l'endpoint Paper ne peut plus être implicitement supposé.
- `SEC_USER_AGENT` devient obligatoire au précontrôle.
- `TRUSTED_PROXY_IPS` est analysé comme liste d'IP/CIDR ; les entrées invalides, jokers et plages trop larges sont refusés.
- Ajout de tests ciblant ces cas limites.

## Validation exécutée
- `BROKER=sim pytest -q` : **772 passed, 11 skipped, 202 subtests passed**.
- `python -m compileall -q scripts tests` : réussi.
- Archive vérifiée par `unzip -t`.

## Limites toujours ouvertes
- Aucun moteur Docker/Podman disponible dans cet environnement : image non construite ni démarrée.
- Pas de dépendances npm/lockfile certifié : build React de production non exécuté.
- Pas de connexion réelle Neon/PostgreSQL, pas de restauration PostgreSQL démontrée.
- Pas de connexion Alpaca Paper, pas de déploiement HTTPS distant ni test navigateur réel.
- Les 11 tests ignorés dépendent d'environnements/services externes.
- Aucun ordre n'a été envoyé ; mode Live reste hors périmètre.

## Décision
R31 est un candidat plus strict côté précontrôle de production, pas une version certifiée prête à exploiter. Le feu vert reste conditionné aux tests d'infrastructure et de courtier réels.
