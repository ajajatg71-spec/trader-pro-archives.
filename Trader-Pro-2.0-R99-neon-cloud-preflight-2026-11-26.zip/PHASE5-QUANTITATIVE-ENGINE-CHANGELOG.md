# Phase 5 — Quantitative Engine (initial implementation)

## Implemented
- Added `services/quantitative.py` as a dedicated orchestration boundary for the existing quantitative calculations.
- Added immutable snapshots for RSI, MACD, SMA, technical signal, daily volatility, historical VaR and CVaR.
- Added a unified evaluation result containing the existing V1 weighted score, data coverage, action and explanatory reasons.
- Integrated the service into the market-analysis path without changing the original formulas, weights, thresholds, sizing or risk rules.
- Kept `indicators.py`, `scoring.py` and `risklib.py` as the source of truth for validated calculations.
- Added deterministic parity tests against the original functions over multiple history lengths, plus invalid-input and immutability tests.

## Not yet complete
- No new factor research, parameter optimization, portfolio covariance engine or strategy-specific quant models are claimed.
- No walk-forward/OOS validation is claimed here; this belongs to the later backtesting phase.
- No live or paper broker orders were sent.

## Extension — performance and path-risk diagnostics

- Added cumulative return, peak-to-trough maximum drawdown, best/worst daily return, and annualized historical volatility to the immutable snapshot.
- Annualized volatility uses the explicit 252-trading-session convention and remains unavailable when the existing V1 daily-volatility function has insufficient observations.
- Added finite/range validation for recognized normalized scoring factors (`scoring.W`): values must be finite and within [-1, 1]. Unknown factors remain ignored by the existing V1 score combiner.
- The V1 RSI/MACD/SMA, technical score, score weights, coverage, decision thresholds, VaR/CVaR and risk rules were not modified.
- Added tests for drawdown, cumulative return, daily extremes, annualization and malformed signals.
- Removed embedded duplicate source snapshots from the distributable archive to avoid Python test-module import collisions; canonical source and tests remain at repository root.

## Validation in this Linux environment

- `python -m pytest -q`: 229 passed, 40 subtests passed.
- `python -m unittest discover -q`: 225 tests passed.
- `python -m compileall -q .`: passed.
- `BROKER=sim APP_PASSWORD=... python -c 'import app'`: import passed; 32 FastAPI routes registered.
- No broker credentials, real market feed, PostgreSQL server or Windows runtime were available/used in this validation.

## Extension multi-actifs — 10 novembre 2026

- Ajout de `MultiAssetSnapshot` immuable et de `QuantitativeEngine.multi_asset_snapshot`.
- Calculs exposés : matrice de corrélation, matrice de covariance journalière, corrélation moyenne, bêta de chaque actif face au benchmark, série de rendements pondérés du portefeuille, rendement cumulé composé, volatilité journalière/annualisée, VaR/CVaR historiques et nombre effectif de positions.
- Contrats de sécurité : mêmes longueurs et même calendrier chronologique requis pour chaque série ; alignement des dates à effectuer en amont ; poids explicites strictement positifs et somme égale à 1 ; validation des cours finis et positifs. Aucune troncature silencieuse des séries.
- Les fonctions V1 de `risklib.py` sont réutilisées pour les rendements, corrélations, bêtas, VaR/CVaR et concentration ; aucune formule historique n'a été modifiée.
- Tests ajoutés pour corrélation parfaite/inverse/nulle, covariance, bêta, volatilité pondérée, VaR/CVaR, calendrier incohérent, poids invalides et immutabilité.
- Limite : le service ne reçoit pas encore les timestamps des barres ; il impose donc l'alignement en amont et ne peut pas le prouver lui-même. La covariance est une covariance d'échantillon journalière, non annualisée.


## Extension — concentration, expositions et stress tests

- `multi_asset_snapshot` expose désormais l'indice HHI de concentration, le poids de la plus grande ligne, les expositions sectorielles (classification fournie par l'appelant) et les contributions de chaque actif à la variance du portefeuille (décomposition de type Euler).
- Ajout de scénarios de baisse de marché paramétrables. Les pertes sont estimées linéairement à partir des poids et des bêtas historiques ; lorsqu'un bêta est indisponible, la fonction V1 `risklib.stress` applique son hypothèse par défaut de bêta 1. Ce sont des sensibilités indicatives, pas des prévisions ni des pertes maximales garanties.
- Les secteurs doivent couvrir exactement les actifs et les chocs doivent être finis, strictement positifs et inférieurs ou égaux à 100 %. Les chocs par défaut sont -10 %, -20 % et -30 %.
- Tests ajoutés : agrégation sectorielle, HHI, poids maximal, somme des contributions au risque, stress bêta-ajusté et rejets d'entrées incorrectes.
- Aucun changement dans `risklib.py` ou dans les formules V1.

## Extension — attribution factorielle OLS (10 novembre 2026)

- Ajout de `FactorAttributionSnapshot` et `QuantitativeEngine.factor_attribution` pour estimer l'alpha quotidien, l'alpha annualisé en convention arithmétique 252 séances, les expositions (loadings) à un ou plusieurs facteurs, le R² et la volatilité résiduelle.
- Régression des rendements quotidiens de l'actif sur des séries de facteurs fournies par l'appelant, avec constante et moindres carrés ordinaires.
- Contrôles : facteurs non vides, nommés, numériques, finis, de même longueur que les rendements de l'actif ; nombre d'observations supérieur au nombre de coefficients ; rejet des matrices singulières/colinéaires et des rendements constants (R² indéfini).
- Résolution du système par élimination de Gauss avec pivot partiel ; aucune dépendance statistique supplémentaire ni régularisation silencieuse.
- Tests synthétiques mono-facteur et bi-facteur vérifiant la récupération des coefficients, ainsi que les cas d'historique insuffisant, séries désalignées, NaN, colinéarité et immutabilité.
- Limites : les facteurs et leurs calendriers sont fournis par l'appelant ; les dates ne sont pas embarquées dans cette API. Les coefficients sont descriptifs, sensibles à la période/aux facteurs choisis, et ne constituent ni une prévision ni une validation causale. L'alpha annualisé est une extrapolation arithmétique, non une performance composée garantie.
- Aucun changement des fonctions ou paramètres V1 dans `risklib.py`, `indicators.py` ou `scoring.py`.

## Validation après attribution factorielle

- `python -m compileall -q .` : réussi.
- `python -m pytest -q` : 241 réussis, 50 sous-tests réussis.
- `python -m unittest discover -q` : 237 tests réussis.
- Import FastAPI avec `BROKER=sim` : réussi, 32 routes.
- Exécution dans l'environnement Linux disponible ; pas de PostgreSQL, de flux marché réel, de compte broker ni d'environnement Windows validé.

## Extension — modèles de performance par stratégie (10 novembre 2026)

- Ajout de `StrategyPerformanceSnapshot` et `QuantitativeEngine.strategy_performance` pour une série de rendements journaliers décimaux : rendement cumulé et annualisé géométrique, volatilité annualisée, Sharpe, Sortino, drawdown maximal, Calmar, taux de périodes positives, profit factor, moyenne et extrêmes.
- Benchmark optionnel strictement aligné : bêta et corrélation réutilisant les fonctions V1 de `risklib.py`. Taux sans risque quotidien configurable, avec zéro par défaut.
- Ajout de `compare_strategy_performance` : calcul comparatif de plusieurs flux de stratégies sur un calendrier commun, avec matrice de corrélation et snapshots individuels. Aucun historique n'est tronqué pour forcer un alignement.
- Validation stricte : rendements finis supérieurs à -100 %, minimum deux périodes, benchmark de même longueur, noms de stratégies non vides et taux sans risque valide.
- Les ratios impossibles à définir sont retournés comme `None` (ex. Sortino sans baisse, Calmar sans drawdown, profit factor sans perte). Annualisation sur 252 séances.
- Tests synthétiques couvrant drawdown, performance composée, taux de réussite, profit factor, Sharpe/Sortino/Calmar, bêta/corrélation benchmark, comparaison multi-stratégies et entrées invalides.
- Limites : les flux de rendement sont fournis par l'appelant et doivent être journaliers, alignés et cohérents en calendrier. Pas encore de calcul depuis les transactions exécutées, frais, slippage, dividendes ou financement ; pas de backtest OOS/walk-forward dans cette extension. Ces indicateurs ne sont pas des prévisions.
- Aucun changement des formules, pondérations ou seuils V1 ; aucun ordre broker n'est envoyé.

## Validation après diagnostics par stratégie

- `python -m compileall -q .` : réussi.
- `python -m pytest -q` : 245 réussis, 54 sous-tests réussis.

## Extension — modèles de signaux par stratégie (10 novembre 2026)

- Ajout de `StrategySignalSnapshot` et `QuantitativeEngine.strategy_signals` pour trois familles de recherche distinctes : momentum, suivi de tendance et retour à la moyenne.
- Momentum : rendement de clôture sur une fenêtre configurable, normalisé par une échelle explicite en pourcentage et borné à [-1, 1].
- Suivi de tendance : écart relatif entre SMA rapide et SMA lente, normalisé par une échelle explicite et borné à [-1, 1].
- Retour à la moyenne : signal contrariant dérivé du RSI de Wilder existant, centré sur 50 et borné à [-1, 1].
- Les périodes et échelles sont configurables et validées. Les historiques insuffisants produisent `None` avec un indicateur de disponibilité explicite ; aucune valeur n'est inventée.
- Les indicateurs V1 sont réutilisés sans modification. Ces signaux sont des diagnostics de recherche, non des ordres, recommandations ou paramètres optimisés.
- Tests ajoutés sur tendance haussière, RSI extrême, échauffement des fenêtres, validation des entrées et sensibilité aux échelles.

## Extension — isolation stricte de la fenêtre hors échantillon du backtest (10 novembre 2026)

- `backtest.run` accepte désormais `start_index` : l'historique antérieur sert uniquement à échauffer les signaux ; positions, exposition, trades et capital restent à plat avant la fenêtre demandée.
- `backtest.optimize` conserve la simulation continue pour la courbe de contexte, mais calcule désormais les métriques OOS, le benchmark OOS et le bootstrap depuis une simulation indépendante démarrant avec le capital initial et sans position héritée de l'apprentissage.
- Correction de l'annualisation CAGR : une série de `n` valeurs d'équité contient `n-1` intervalles de rendement ; le calcul utilise désormais `(n-1)/bpy` années au lieu de `n/bpy`.
- Tests de non-régression : fenêtre OOS à plat, signal d'entrée pré-apprentissage non reporté, validation de `start_index`, CAGR sur 252 intervalles et égalité entre métriques OOS d'`optimize` et simulation indépendante.
- La fonction `run` conserve le comportement historique lorsque `start_index=0`. Le signal de la barre précédente peut être exécuté à la première barre de test, ce qui respecte la convention existante « signal à la clôture, exécution à la clôture suivante ».
- Limites inchangées : backtest long-only, pas de vérification sur flux réels, pas de modèle de liquidité/impact de marché, ni de walk-forward à fenêtres roulantes ; le test holdout unique n'est pas une preuve de robustesse future.

## Durcissement des entrées numériques et des calculs composés — 11 novembre 2026

- Centralisation de la conversion numérique finie pour les séries de cours, rendements, facteurs, pondérations, taux sans risque et chocs de stress.
- Rejet explicite des booléens dans les champs numériques : Python convertit `True`/`False` en `1`/`0`, ce qui pouvait auparavant laisser passer une donnée mal typée.
- Rejet des rendements factoriels inférieurs ou égaux à -100 %, incompatibles avec une série de rendements simples.
- Détection des débordements et sous-flux invalidant le capital composé d'une stratégie ou du portefeuille, au lieu de publier des métriques infinies ou non interprétables.
- Les formules V1 d'indicateurs, de score et de risque ne sont pas modifiées.
- Tests supplémentaires couvrant prix, échelles, pondérations, benchmark, rendements, taux sans risque, facteurs et débordement numérique.

## Validation après durcissement

- `python -m pytest -q` : 335 réussis, 3 ignorés (tests PostgreSQL opt-in), 72 sous-tests réussis.
- `python -m unittest discover -q` : 331 tests réussis.
- `python -m compileall -q .` : réussi.
- PostgreSQL réel, fournisseurs de marché externes et comptes broker non testés dans cet environnement.
