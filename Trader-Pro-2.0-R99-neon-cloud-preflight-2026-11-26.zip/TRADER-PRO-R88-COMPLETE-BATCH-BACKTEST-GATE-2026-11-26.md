# Trader Pro 2.0 — R88 : verrou de lot complet dans le backtest total return

Base : R87.

## Modifications
- Ajout de `evaluate_total_return_history_from_batch`, qui n'accepte que `CorporateActionBatch` validé et complet.
- Le symbole évalué doit appartenir à l'univers demandé ; les événements doivent rester dans la source et le symbole déclarés.
- Le timestamp de récupération n'est jamais substitué à `available_at` des événements.

## Validation
- 4 tests ciblés ajoutés.

## Limites
- La validation de pagination ne garantit pas que le fournisseur ait publié toutes les opérations sur titres ; l'avertissement de disponibilité retardée Alpaca demeure.
