"""add fencing token to broker event processing leases"""
from alembic import op
import sqlalchemy as sa

revision = "b8d2f4a6c901"
down_revision = "a41d9c7e2b60"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("broker_event_inbox", sa.Column("processing_token", sa.String(length=36), nullable=True))
    op.create_index("ix_broker_event_inbox_processing_token", "broker_event_inbox", ["processing_token"])


def downgrade():
    op.drop_index("ix_broker_event_inbox_processing_token", table_name="broker_event_inbox")
    op.drop_column("broker_event_inbox", "processing_token")
