"""persist append-only point-in-time corporate action revisions"""
from alembic import op
import sqlalchemy as sa

revision = "f19a6c3d8b42"
down_revision = "ea21c7b4d903"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "corporate_action_revisions",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("source", sa.String(length=48), nullable=False),
        sa.Column("event_id", sa.String(length=160), nullable=False),
        sa.Column("revision", sa.Integer(), nullable=False),
        sa.Column("recorded_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("status", sa.String(length=16), nullable=False),
        sa.Column("event_payload", sa.JSON(none_as_null=True), nullable=True),
        sa.UniqueConstraint("source", "event_id", "revision", name="uq_corporate_action_revision_identity"),
        sa.CheckConstraint("revision >= 1", name="ck_corporate_action_revision_positive"),
        sa.CheckConstraint("status IN ('active','cancelled')", name="ck_corporate_action_revision_status"),
        sa.CheckConstraint(
            "(status = 'active' AND event_payload IS NOT NULL) OR "
            "(status = 'cancelled' AND event_payload IS NULL)",
            name="ck_corporate_action_revision_payload_status",
        ),
    )
    op.create_index("ix_corporate_action_revisions_recorded_at", "corporate_action_revisions", ["recorded_at"])
    # PostgreSQL-level append-only enforcement. SQLite tests exercise repository
    # semantics; production PostgreSQL additionally rejects direct UPDATE/DELETE.
    if op.get_bind().dialect.name == "postgresql":
        op.execute("""
        CREATE FUNCTION reject_corporate_action_revision_mutation() RETURNS trigger AS $$
        BEGIN
            RAISE EXCEPTION 'corporate_action_revisions is append-only';
        END;
        $$ LANGUAGE plpgsql
        """)
        op.execute("""
        CREATE TRIGGER trg_corporate_action_revisions_append_only
        BEFORE UPDATE OR DELETE ON corporate_action_revisions
        FOR EACH ROW EXECUTE FUNCTION reject_corporate_action_revision_mutation()
        """)


def downgrade():
    if op.get_bind().dialect.name == "postgresql":
        op.execute("DROP TRIGGER IF EXISTS trg_corporate_action_revisions_append_only ON corporate_action_revisions")
        op.execute("DROP FUNCTION IF EXISTS reject_corporate_action_revision_mutation()")
    op.drop_index("ix_corporate_action_revisions_recorded_at", table_name="corporate_action_revisions")
    op.drop_table("corporate_action_revisions")
