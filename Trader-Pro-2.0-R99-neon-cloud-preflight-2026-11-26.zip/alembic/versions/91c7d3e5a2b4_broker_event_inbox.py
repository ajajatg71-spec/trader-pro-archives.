"""add durable broker event inbox for reconciliation triggers"""
from alembic import op
import sqlalchemy as sa

revision = "91c7d3e5a2b4"
down_revision = "f3b8c2d91a64"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "broker_event_inbox",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("event_id", sa.String(length=160), nullable=False, unique=True),
        sa.Column("event_type", sa.String(length=48), nullable=False),
        sa.Column("broker_order_id", sa.String(length=128), nullable=True),
        sa.Column("client_order_id", sa.String(length=128), nullable=True),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("status", sa.String(length=16), nullable=False, server_default="pending"),
        sa.Column("attempts", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("received_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("processing_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("processed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_error", sa.Text(), nullable=True),
        sa.CheckConstraint("status IN ('pending','processing','processed','failed')", name="ck_broker_event_status"),
        sa.CheckConstraint("attempts >= 0", name="ck_broker_event_attempts_nonnegative"),
    )
    op.create_index("ix_broker_event_inbox_event_type", "broker_event_inbox", ["event_type"])
    op.create_index("ix_broker_event_inbox_broker_order_id", "broker_event_inbox", ["broker_order_id"])
    op.create_index("ix_broker_event_inbox_client_order_id", "broker_event_inbox", ["client_order_id"])
    op.create_index("ix_broker_event_inbox_status", "broker_event_inbox", ["status"])


def downgrade():
    op.drop_index("ix_broker_event_inbox_status", table_name="broker_event_inbox")
    op.drop_index("ix_broker_event_inbox_client_order_id", table_name="broker_event_inbox")
    op.drop_index("ix_broker_event_inbox_broker_order_id", table_name="broker_event_inbox")
    op.drop_index("ix_broker_event_inbox_event_type", table_name="broker_event_inbox")
    op.drop_table("broker_event_inbox")
