"""persisted reconciliation evidence"""
from alembic import op
import sqlalchemy as sa

revision = "8d4f2a6c1e90"
down_revision = "7c2d9e4a1b60"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "reconciliation_runs",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("run_id", sa.String(length=64), nullable=False, unique=True),
        sa.Column("source", sa.String(length=24), nullable=False),
        sa.Column("status", sa.String(length=16), nullable=False),
        sa.Column("snapshot_complete", sa.Boolean(), nullable=False),
        sa.Column("unresolved_count", sa.Integer(), nullable=False),
        sa.Column("orders_seen", sa.Integer(), nullable=False),
        sa.Column("fills_seen", sa.Integer(), nullable=False),
        sa.Column("positions_seen", sa.Integer(), nullable=False),
        sa.Column("evidence_hash", sa.String(length=64), nullable=False),
        sa.Column("details", sa.JSON(), nullable=False),
        sa.Column("started_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.CheckConstraint("status IN ('succeeded','inconclusive','failed')", name="ck_reconciliation_run_status"),
        sa.CheckConstraint("unresolved_count >= 0", name="ck_reconciliation_unresolved_nonnegative"),
        sa.CheckConstraint("orders_seen >= 0 AND fills_seen >= 0 AND positions_seen >= 0", name="ck_reconciliation_counts_nonnegative"),
    )
    op.create_index("ix_reconciliation_runs_run_id", "reconciliation_runs", ["run_id"], unique=False)
    op.add_column("system_safety_state", sa.Column("last_reconciliation_run_id", sa.String(length=64), nullable=True))
    with op.batch_alter_table("system_safety_state") as batch_op:
        batch_op.create_foreign_key("fk_safety_last_reconciliation_run", "reconciliation_runs",
                                    ["last_reconciliation_run_id"], ["run_id"], ondelete="RESTRICT")

def downgrade():
    with op.batch_alter_table("system_safety_state") as batch_op:
        batch_op.drop_constraint("fk_safety_last_reconciliation_run", type_="foreignkey")
        batch_op.drop_column("last_reconciliation_run_id")
    op.drop_index("ix_reconciliation_runs_run_id", table_name="reconciliation_runs")
    op.drop_table("reconciliation_runs")
