"""persist operational pause / emergency kill switch"""
from alembic import op
import sqlalchemy as sa

revision = "d4c8a71e2f90"
down_revision = "b21f6a9d3c10"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "risk_control_state",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("paused", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("reason", sa.Text(), nullable=True),
        sa.Column("actor", sa.String(length=64), nullable=False, server_default="system"),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("CURRENT_TIMESTAMP")),
    )


def downgrade():
    op.drop_table("risk_control_state")
