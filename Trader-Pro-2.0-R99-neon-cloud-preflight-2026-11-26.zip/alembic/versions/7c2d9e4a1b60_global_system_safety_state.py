"""durable global trading safety state"""
from alembic import op
import sqlalchemy as sa

revision = "7c2d9e4a1b60"
down_revision = "a72c9e41b5d0"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "system_safety_state",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("status", sa.String(length=16), nullable=False),
        sa.Column("reason", sa.Text(), nullable=True),
        sa.Column("actor", sa.String(length=64), nullable=False),
        sa.Column("generation", sa.Integer(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.CheckConstraint("status IN ('READY','DEGRADED','RECONCILING','HALTED')", name="ck_system_safety_status"),
        sa.CheckConstraint("generation >= 1", name="ck_system_safety_generation"),
    )
    op.bulk_insert(sa.table("system_safety_state", sa.column("id", sa.Integer()),
        sa.column("status", sa.String()), sa.column("reason", sa.Text()),
        sa.column("actor", sa.String()), sa.column("generation", sa.Integer())),
        [{"id": 1, "status": "RECONCILING", "reason": "Validation initiale requise",
          "actor": "migration", "generation": 1}])

def downgrade():
    op.drop_table("system_safety_state")
