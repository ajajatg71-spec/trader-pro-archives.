"""persist operator login throttling and TOTP replay protection"""
from alembic import op
import sqlalchemy as sa
revision = "a41d9c7e2b60"
down_revision = "9e5b7c2d4a61"
branch_labels = None
depends_on = None
def upgrade():
    op.create_table("operator_auth_attempts", sa.Column("client_key", sa.String(64), primary_key=True), sa.Column("window_started_at", sa.DateTime(timezone=True), nullable=False), sa.Column("attempts", sa.Integer(), nullable=False, server_default="0"), sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()), sa.CheckConstraint("attempts >= 0", name="ck_operator_auth_attempts_nonnegative"))
    op.create_table("operator_totp_state", sa.Column("id", sa.Integer(), primary_key=True), sa.Column("last_accepted_counter", sa.Integer(), nullable=False, server_default="-1"), sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()), sa.CheckConstraint("id = 1", name="ck_operator_totp_state_singleton"), sa.CheckConstraint("last_accepted_counter >= -1", name="ck_operator_totp_counter_nonnegative"))
    op.execute(sa.text("INSERT INTO operator_totp_state (id, last_accepted_counter) VALUES (1, -1)"))
def downgrade():
    op.drop_table("operator_totp_state")
    op.drop_table("operator_auth_attempts")
