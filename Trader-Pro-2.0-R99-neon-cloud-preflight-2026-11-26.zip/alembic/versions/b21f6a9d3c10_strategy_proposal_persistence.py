"""persist strategy proposals and their lifecycle"""
from alembic import op
import sqlalchemy as sa

revision = "b21f6a9d3c10"
down_revision = "43a044e7e6b0"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "strategy_proposals",
        sa.Column("proposal_id", sa.String(length=128), nullable=False),
        sa.Column("symbol", sa.String(length=16), nullable=False),
        sa.Column("side", sa.String(length=8), nullable=False),
        sa.Column("notional", sa.Numeric(24, 8), nullable=False),
        sa.Column("allocation_pct", sa.Numeric(12, 8), nullable=False),
        sa.Column("confidence", sa.Numeric(8, 6), nullable=False),
        sa.Column("regime", sa.String(length=24), nullable=False),
        sa.Column("source_strategies", sa.JSON(), nullable=False),
        sa.Column("signals", sa.JSON(), nullable=False),
        sa.Column("pending_payload", sa.JSON(), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("risk_reason", sa.Text(), nullable=True),
        sa.Column("broker_order_id", sa.String(length=128), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("CURRENT_TIMESTAMP"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("CURRENT_TIMESTAMP"), nullable=False),
        sa.CheckConstraint("side IN ('buy','sell')", name="ck_strategy_proposals_side"),
        sa.CheckConstraint("notional > 0", name="ck_strategy_proposals_notional_positive"),
        sa.CheckConstraint("allocation_pct >= 0 AND allocation_pct <= 100", name="ck_strategy_proposals_allocation_range"),
        sa.CheckConstraint("confidence >= 0 AND confidence <= 1", name="ck_strategy_proposals_confidence_range"),
        sa.PrimaryKeyConstraint("proposal_id"),
    )
    op.create_index("ix_strategy_proposals_symbol", "strategy_proposals", ["symbol"])
    op.create_index("ix_strategy_proposals_status", "strategy_proposals", ["status"])


def downgrade():
    op.drop_index("ix_strategy_proposals_status", table_name="strategy_proposals")
    op.drop_index("ix_strategy_proposals_symbol", table_name="strategy_proposals")
    op.drop_table("strategy_proposals")
