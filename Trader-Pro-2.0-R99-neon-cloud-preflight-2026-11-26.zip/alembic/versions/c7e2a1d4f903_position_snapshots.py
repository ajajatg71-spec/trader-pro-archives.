"""persist broker position snapshots for reconciliation"""
from alembic import op
import sqlalchemy as sa

revision = "c7e2a1d4f903"
down_revision = "b21f6a9d3c10"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "position_snapshots",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("captured_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("symbol", sa.String(length=16), nullable=False),
        sa.Column("quantity", sa.Numeric(24, 10), nullable=False),
        sa.Column("market_value", sa.Numeric(24, 8), nullable=False),
        sa.Column("average_entry_price", sa.Numeric(24, 8), nullable=True),
        sa.Column("unrealized_pl", sa.Numeric(24, 8), nullable=True),
        sa.Column("source", sa.String(length=24), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_position_snapshots_captured_at", "position_snapshots", ["captured_at"])
    op.create_index("ix_position_snapshots_symbol", "position_snapshots", ["symbol"])
    op.create_index("ix_position_snapshots_time_symbol", "position_snapshots", ["captured_at", "symbol"])


def downgrade():
    op.drop_index("ix_position_snapshots_time_symbol", table_name="position_snapshots")
    op.drop_index("ix_position_snapshots_symbol", table_name="position_snapshots")
    op.drop_index("ix_position_snapshots_captured_at", table_name="position_snapshots")
    op.drop_table("position_snapshots")
