"""persist preregistered research hypothesis families"""
from alembic import op
import sqlalchemy as sa
revision = "d91a7c3e5b20"
down_revision = "b8d2f4a6c901"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table("research_hypothesis_families",
        sa.Column("family_id", sa.String(64), primary_key=True),
        sa.Column("study", sa.String(120), nullable=False),
        sa.Column("protocol_version", sa.String(64), nullable=False),
        sa.Column("manifest", sa.JSON(), nullable=False),
        sa.Column("expected_ids", sa.JSON(), nullable=False),
        sa.Column("status", sa.String(24), nullable=False, server_default="PRE_REGISTERED"),
        sa.Column("p_values", sa.JSON(), nullable=True),
        sa.Column("adjusted_results", sa.JSON(), nullable=True),
        sa.Column("selection_authorized", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("results_locked_at", sa.DateTime(timezone=True), nullable=True),
        sa.CheckConstraint("status IN ('PRE_REGISTERED','RESULTS_LOCKED')", name="ck_research_hypothesis_status"),
        sa.CheckConstraint("selection_authorized = false", name="ck_research_hypothesis_no_auto_selection"))
    op.create_index("ix_research_hypothesis_families_status", "research_hypothesis_families", ["status"])

def downgrade():
    op.drop_index("ix_research_hypothesis_families_status", table_name="research_hypothesis_families")
    op.drop_table("research_hypothesis_families")
