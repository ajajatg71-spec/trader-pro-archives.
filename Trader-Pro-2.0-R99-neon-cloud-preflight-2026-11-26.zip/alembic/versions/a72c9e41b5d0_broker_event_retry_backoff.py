"""add retry scheduling and dead-letter state to broker event inbox"""
from alembic import op
import sqlalchemy as sa

revision = "a72c9e41b5d0"
down_revision = "91c7d3e5a2b4"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("broker_event_inbox", sa.Column("next_attempt_at", sa.DateTime(timezone=True), nullable=True))
    op.create_index("ix_broker_event_inbox_next_attempt_at", "broker_event_inbox", ["next_attempt_at"])
    with op.batch_alter_table("broker_event_inbox") as batch_op:
        batch_op.drop_constraint("ck_broker_event_status", type_="check")
        batch_op.create_check_constraint("ck_broker_event_status",
            "status IN ('pending','processing','processed','failed','dead_letter')")


def downgrade():
    with op.batch_alter_table("broker_event_inbox") as batch_op:
        batch_op.drop_constraint("ck_broker_event_status", type_="check")
        batch_op.create_check_constraint("ck_broker_event_status",
            "status IN ('pending','processing','processed','failed')")
    op.drop_index("ix_broker_event_inbox_next_attempt_at", table_name="broker_event_inbox")
    op.drop_column("broker_event_inbox", "next_attempt_at")
