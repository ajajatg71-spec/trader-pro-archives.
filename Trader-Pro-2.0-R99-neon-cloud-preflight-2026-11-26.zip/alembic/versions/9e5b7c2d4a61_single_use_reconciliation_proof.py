"""make persisted reconciliation proofs single-use"""
from alembic import op
import sqlalchemy as sa

revision = "9e5b7c2d4a61"
down_revision = "8d4f2a6c1e90"
branch_labels = None
depends_on = None

def upgrade():
    op.add_column("reconciliation_runs", sa.Column("consumed_at", sa.DateTime(timezone=True), nullable=True))

def downgrade():
    op.drop_column("reconciliation_runs", "consumed_at")
