"""seed the durable operational kill switch singleton"""
from alembic import op
import sqlalchemy as sa

revision = "f3b8c2d91a64"
down_revision = "e8a19c42d7b1"
branch_labels = None
depends_on = None


def upgrade():
    state = sa.table(
        "risk_control_state",
        sa.column("id", sa.Integer),
        sa.column("paused", sa.Boolean),
        sa.column("reason", sa.Text),
        sa.column("actor", sa.String(64)),
    )
    op.bulk_insert(state, [{"id": 1, "paused": False, "reason": None, "actor": "system"}])


def downgrade():
    op.execute(sa.text("DELETE FROM risk_control_state WHERE id = 1 AND actor = 'system' AND paused = false"))
