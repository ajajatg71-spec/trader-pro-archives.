"""store backend research execution provenance on locked hypothesis families"""
from alembic import op
import sqlalchemy as sa

revision = "ea21c7b4d903"
down_revision = "d91a7c3e5b20"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("research_hypothesis_families",
                  sa.Column("execution_provenance", sa.JSON(), nullable=True))


def downgrade():
    op.drop_column("research_hypothesis_families", "execution_provenance")
