"""merge position snapshots and durable kill switch migration heads"""
revision = "e8a19c42d7b1"
down_revision = ("c7e2a1d4f903", "d4c8a71e2f90")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
