# Phase 7 — ADV zero-volume integrity validation

## Finding
The previous ADV implementation omitted completed daily bars whose reported volume was zero. That omission could overstate dollar liquidity for illiquid, halted, or otherwise inactive instruments.

## Change
- Count every valid completed daily session as an ADV observation, including `close × 0 = 0`.
- Use up to the latest 20 completed observations, with a minimum of 10.
- Reject an all-zero ADV because a zero denominator outcome cannot support a buy-side liquidity approval.
- Preserve current-session exclusion, duplicate-session rejection, timestamp checks, quote freshness, retry bounds, and fail-closed behavior.
- No V1 portfolio, signal, sizing, or risk formulas were changed.

## Validation evidence
- `python -m pytest -q`: **405 passed, 3 skipped, 76 subtests passed**.
- `python -m unittest discover -q`: **401 tests passed**.
- `python -m compileall -q .`: passed.
- `DATABASE_URL=sqlite:///temporary-file alembic upgrade head`: passed; current revision `e8a19c42d7b1` (single merge head).
- `BROKER=sim` FastAPI import: passed; 35 routes.
- Non-simulation import with dummy Alpaca credentials: passed; 35 routes. No network request was made.

## Not verified
- Three PostgreSQL integration tests remain skipped because `TRADER_PRO_TEST_DATABASE_URL` is not configured; no PostgreSQL server was exercised.
- No real Alpaca request or broker Paper order was sent. Alpaca adapter tests use mocked HTTP responses.
- IEX volume is not consolidated-market volume. The close-times-volume ADV remains an IEX proxy and must not be represented as consolidated liquidity.
- No square-root market-impact coefficient was calibrated. Impact cap must remain disabled or fail closed until calibrated from verified execution data.
- Phase 7 remains open; this increment does not authorize Live trading.
