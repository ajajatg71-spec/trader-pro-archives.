# Trader Pro 2.0 — environnement de validation réel (PostgreSQL + Alpaca Paper)

Date: 2026-11-12

## Objectif et séparation des environnements

- PostgreSQL 16 est utilisé pour les migrations, les verrous `SELECT FOR UPDATE`, les transactions concurrentes, les contraintes et les sauvegardes/restaurations.
- Alpaca Paper est utilisé séparément pour vérifier l'authentification, le compte, les actifs, la création d'une intention d'ordre, la recherche par `client_order_id` et l'annulation confirmée.
- Aucun test n'utilise le endpoint Live. Le connecteur refuse toute URL autre que `https://paper-api.alpaca.markets`.
- Le test d'ordre Paper est manuel et opt-in. Il récupère une cotation IEX de Ford (F), crée un seul ordre limite DAY d'une action à 1 % sous le bid observé, puis demande son annulation et attend le statut `canceled`. Le prix est non marketable au moment de la cotation, mais le test ne garantit pas qu'un ordre ne puisse jamais être exécuté si le marché baisse rapidement avant l'annulation.
- Le script échoue si l'annulation n'est pas confirmée ou si une quantité a été exécutée. Il affiche alors l'identifiant broker à vérifier manuellement.

## PostgreSQL local avec Docker Compose

1. Installer Docker Desktop / Docker Engine et Compose.
2. `cp .env.example .env` (Windows PowerShell: `Copy-Item .env.example .env`).
3. Remplacer `POSTGRES_PASSWORD` et les mots de passe des URL par un mot de passe aléatoire fort. Ne jamais partager ni committer `.env`.
4. Démarrer: `docker compose up -d postgres`.
5. Créer deux bases jetables distinctes `trader_pro_test` et `trader_pro_restore` dans le conteneur.
6. Installer `pip install -r requirements-dev.txt` et les outils PostgreSQL client `psql`, `pg_dump`, `pg_restore`.
7. Charger les variables `.env` dans le shell puis exécuter `bash scripts/verify_postgres.sh`.

Le script vérifie les suffixes `_test` et `_restore`, convertit les URLs SQLAlchemy `postgresql+psycopg://` vers une URI libpq, refuse toute base de restauration contenant déjà des tables publiques, applique Alembic, exécute les tests PostgreSQL, crée un dump custom, vérifie son intégrité et restaure vers la base vide séparée.

## PostgreSQL CI (environnement réel jetable)

`.github/workflows/postgres-integration.yml` démarre un service PostgreSQL 16 dans GitHub Actions sur push, pull request et déclenchement manuel. Il installe le pilote psycopg et les outils PostgreSQL, crée une base `_restore`, puis lance `scripts/verify_postgres.sh`, la suite complète pytest/unittest et compileall.

Le workflow est prêt dans le code mais ne peut pas être exécuté depuis cet environnement de conversation : aucun dépôt GitHub n'est connecté ici. Il s'exécutera après ajout du code au dépôt et push.

## Alpaca Paper — test lecture seule

Créer un compte Paper dans le tableau de bord Alpaca et générer une paire de clés Paper dédiée. Ne jamais utiliser les clés Live. Exporter:

```bash
export BROKER=alpaca
export ALPACA_BASE_URL=https://paper-api.alpaca.markets
export APCA_API_KEY_ID='PAPER_KEY_ID'
export APCA_API_SECRET_KEY='PAPER_SECRET_KEY'
python scripts/verify_alpaca_paper_readonly.py
```

Ce contrôle lit le compte, les positions, l'horloge du marché et cinq barres SPY. Il n'envoie ni ne modifie ni n'annule aucun ordre.

## Alpaca Paper — test d'ordre explicite

Après le test lecture seule, seulement si le compte est bien Paper et si l'utilisateur accepte un ordre simulé, définir la confirmation exacte:

```bash
export TRADER_PRO_ENABLE_PAPER_ORDER_TEST=YES_I_CONFIRM_PAPER_ONLY
python scripts/verify_alpaca_paper_orders.py
```

Le script exige que le marché soit ouvert et que le quote IEX ait moins de 120 secondes, récupère le bid de F, soumet un ordre limite d'une action à 1 % sous ce bid, vérifie le `client_order_id`, récupère l'ordre par cet identifiant, demande l'annulation, puis interroge le broker jusqu'à 30 secondes. Il ne marque le test réussi que si le statut terminal est `canceled` et `filled_qty` est zéro. En cas d'état inconnu, l'ordre doit être vérifié dans le tableau de bord Paper.

Ne pas exécuter simultanément ce smoke test et un autre système utilisant le même compte Paper.

## GitHub Actions pour Alpaca Paper

`.github/workflows/alpaca-paper-smoke.yml` est strictement `workflow_dispatch`. Dans les paramètres GitHub, créer l'environnement `alpaca-paper`, puis y ajouter les secrets `APCA_PAPER_API_KEY_ID` et `APCA_PAPER_API_SECRET_KEY` avec les clés Paper uniquement. Lancer manuellement le workflow et saisir exactement `PAPER_ONLY_ONE_LIMIT_ORDER`.

## Limites de ce run de développement

L'environnement d'exécution ChatGPT actuel n'a ni Docker/Podman, ni PostgreSQL server/client (`postgres`, `psql`, `pg_dump`, `pg_restore`), ni le pilote `psycopg`, et ne peut pas télécharger de paquets (résolution DNS indisponible). Aucun secret Alpaca n'est configuré. Les workflows CI et les scripts de validation réelle sont donc préparés, mais les tests PostgreSQL et Alpaca Paper ne sont pas déclarés réussis tant qu'ils n'ont pas été exécutés dans l'environnement local ou GitHub Actions.

### Sécurité de nettoyage du smoke test Paper

Après acceptation d'un ordre, toute erreur ultérieure déclenche une tentative
d'annulation de rattrapage. Le script ne considère le test réussi que si Alpaca
confirme `canceled` avec `filled_qty=0`. En cas de statut rempli/partiellement
rempli ou d'annulation non confirmée, le script signale l'identifiant de l'ordre
pour contrôle manuel. Cela réduit le risque de laisser un ordre de test actif,
sans pouvoir garantir l'annulation en cas d'indisponibilité du broker.

## Parcours Windows automatisé

Le script `scripts/prepare_windows_validation.ps1` crée `.venv`, installe les dépendances, lance la suite locale et, avec `-RunPostgres`, délègue à `scripts/run_postgres_container_tests.ps1` pour un PostgreSQL 16 jetable. Voir `WINDOWS-REAL-VALIDATION.md`.

Si Docker local est indisponible, le workflow `.github/workflows/postgres-integration.yml` est le chemin CI recommandé; il fournit un service PostgreSQL 16 réel, puis vérifie migrations, intégration, backup et restore. Le workflow Windows est séparé. Ces workflows doivent être déclenchés dans un dépôt GitHub; leur présence dans l'archive ne prouve pas leur exécution.
