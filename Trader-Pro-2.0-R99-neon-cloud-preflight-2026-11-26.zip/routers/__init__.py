"""FastAPI route modules for Trader Pro 2.0."""
