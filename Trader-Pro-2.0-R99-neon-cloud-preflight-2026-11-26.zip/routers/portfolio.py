"""Read-only portfolio reporting routes, wired through injected services."""
from fastapi import APIRouter, Depends, HTTPException


def create_portfolio_router(guard_dependency, portfolio_summary, realized_reader, tax_calculator):
    router = APIRouter(tags=["portfolio"])

    @router.get("/api/performance")
    def performance(_=Depends(guard_dependency)):
        return portfolio_summary()

    @router.get("/api/tax")
    def tax_view(year: int, carry: float = 0.0, rate: float = 31.4, _=Depends(guard_dependency)):
        if not 2000 <= year <= 2100 or carry < 0 or not 0 <= rate <= 100:
            raise HTTPException(400, "Paramètres invalides")
        return tax_calculator(realized_reader(), year, rate, carry)

    return router
