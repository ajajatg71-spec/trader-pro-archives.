"""Authentication endpoints wired through injected application services."""
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import secrets
import time


class LoginRequest(BaseModel):
    password: str = ""
    code: str = ""


def create_auth_router(
    *,
    guard_dependency,
    app_password: str,
    totp_secret: str,
    session_key: bytes,
    failures: dict,
    client_ip,
    history_writer,
    notifier,
    token_factory,
    state: dict,
    state_lock,
    save_state,
    login_page_renderer,
    totp_verifier,
):
    """Create login/logout routes without importing the legacy app module."""
    router = APIRouter(tags=["authentication"])

    @router.get("/login")
    def login_page():
        # The composition root may attach the existing HTML page renderer.
        return login_page_renderer()

    @router.post("/api/login")
    def login(body: LoginRequest, request: Request):
        if request.headers.get("x-trader") != "1":
            raise HTTPException(403, "Requête refusée")
        ip, now = client_ip(request), time.time()
        failures[ip] = [stamp for stamp in failures.get(ip, []) if now - stamp < 600]
        if len(failures[ip]) >= 5:
            raise HTTPException(429, "Trop d’essais, réessaie dans 10 minutes")
        valid = bool(app_password) and secrets.compare_digest(
            body.password.encode(), app_password.encode()
        )
        if valid and totp_secret:
            valid = totp_verifier(totp_secret, body.code)
        if not valid:
            failures[ip].append(now)
            history_writer("auth", f"Connexion refusée depuis {ip}")
            notifier(f"🔐 Connexion refusée depuis {ip}")
            raise HTTPException(401, "Identifiants incorrects")
        history_writer("auth", f"Connexion réussie depuis {ip}")
        response = JSONResponse({"ok": True})
        response.set_cookie(
            "sess", token_factory(session_key, now=now), max_age=43200,
            httponly=True, secure=True, samesite="strict"
        )
        return response

    @router.post("/api/logout")
    def logout(_=Depends(guard_dependency)):
        response = JSONResponse({"ok": True})
        response.delete_cookie("sess")
        return response

    @router.post("/api/logout_all")
    def logout_all(_=Depends(guard_dependency)):
        with state_lock:
            state["revoke_before"] = time.time()
            save_state()
        history_writer("auth", "Toutes les sessions ont été révoquées")
        return {"ok": True}

    return router

