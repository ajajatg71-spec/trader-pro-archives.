"""Explicit operator-only controls for the durable global safety state.

The operator identity is provisioned out-of-band through environment secrets.
It is deliberately separate from the ordinary application password/session.
"""
from __future__ import annotations

import secrets
import hashlib
from datetime import datetime, timezone
from typing import Any, Callable

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel, Field

import security
from db.order_repository import OrderRepositoryError


class SafetyTransitionRequest(BaseModel):
    status: str = Field(pattern="^(READY|DEGRADED|RECONCILING|HALTED)$")
    reason: str | None = Field(default=None, max_length=2000)
    reconciliation_run_id: str | None = Field(default=None, max_length=64)


def create_operator_router(*, repository: Any, operator_password: str,
                           operator_totp_secret: str, totp_verifier: Callable,
                           history_writer: Callable, client_ip: Callable,
                           failures: dict | None = None, lock=None,
                           totp_counter_verifier: Callable | None = None):
    router = APIRouter(prefix="/api/operator", tags=["operator"])
    basic = HTTPBasic(auto_error=False)
    if repository is not None and not all(hasattr(repository, name) for name in ("operator_auth_is_rate_limited", "record_operator_auth_failure", "consume_operator_totp_counter")):
        raise RuntimeError("Les contrôles opérateur persistants PostgreSQL sont obligatoires")
    if totp_counter_verifier is None:
        raise RuntimeError("Vérificateur TOTP avec compteur obligatoire")

    def require_operator(request: Request,
                         credentials: HTTPBasicCredentials | None = Depends(basic)):
        if repository is None:
            raise HTTPException(503, "PostgreSQL indisponible : commandes opérateur désactivées")
        if not operator_password or len(operator_password) < 20 or not operator_totp_secret:
            raise HTTPException(503, "Identifiants opérateur non configurés")
        if not security.is_https(request):
            raise HTTPException(400, "HTTPS requis")
        ip, now = client_ip(request), datetime.now(timezone.utc)
        client_key = hashlib.sha256(ip.encode("utf-8")).hexdigest()
        try:
            if repository.operator_auth_is_rate_limited(client_key, now=now, limit=5, window_seconds=600):
                raise HTTPException(429, "Trop d'échecs d'authentification opérateur")
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(503, "Protection anti-abus indisponible") from exc
        password_ok = bool(credentials and secrets.compare_digest(
            credentials.username.encode(), b"operator") and
            secrets.compare_digest(credentials.password.encode(), operator_password.encode()))
        code = request.headers.get("x-operator-totp", "")
        matched_counter = totp_counter_verifier(operator_totp_secret, code) if code else None
        if not (password_ok and matched_counter is not None):
            try:
                repository.record_operator_auth_failure(client_key, now=now, window_seconds=600)
            except Exception as exc:
                raise HTTPException(503, "Échec de l'enregistrement de sécurité") from exc
            history_writer("operator_auth", f"Accès opérateur refusé depuis {ip}")
            raise HTTPException(401, "Authentification opérateur invalide",
                                headers={"WWW-Authenticate": "Basic"})
        if request.headers.get("x-trader") != "1":
            raise HTTPException(403, "Requête refusée")
        # Read-only GETs do not consume a one-time code. State-changing operator
        # actions consume the monotonic TOTP counter, preserving replay protection.
        if request.method != "GET":
            try:
                if not repository.consume_operator_totp_counter(int(matched_counter)):
                    history_writer("operator_auth_replay", "Code TOTP opérateur déjà utilisé")
                    raise HTTPException(401, "Code TOTP déjà utilisé")
            except HTTPException:
                raise
            except Exception as exc:
                raise HTTPException(503, "Protection anti-rejeu TOTP indisponible") from exc
        return "operator"

    @router.get("/system-safety")
    def read_system_safety(_actor=Depends(require_operator)):
        try:
            return repository.get_system_safety_state()
        except Exception as exc:
            raise HTTPException(503, "État de sécurité indisponible") from exc

    @router.post("/system-safety")
    def transition_system_safety(body: SafetyTransitionRequest,
                                 actor=Depends(require_operator)):
        try:
            result = repository.transition_system_safety_state(
                status=body.status, reason=body.reason, actor=actor,
                reconciliation_run_id=body.reconciliation_run_id)
            history_writer("operator_safety", f"Transition opérateur vers {body.status}")
            return result
        except OrderRepositoryError as exc:
            raise HTTPException(409, str(exc)) from exc
        except Exception as exc:
            raise HTTPException(503, "Transition de sécurité impossible") from exc

    return router
