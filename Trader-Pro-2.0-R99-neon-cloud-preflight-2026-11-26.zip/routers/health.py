"""Public liveness endpoint, isolated from the legacy application module."""
import time
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

router = APIRouter(tags=["health"])


@router.get("/health")
def health(request: Request):
    beat = request.app.state.beat
    age = time.time() - beat["t"]
    return JSONResponse({"ok": age < 180, "beat_age_s": int(age)}, status_code=200 if age < 180 else 503)
