"""History API router, wired to application services by the composition root."""
from fastapi import APIRouter, Depends


def create_history_router(guard_dependency, history_reader):
    """Build the history router without importing the legacy app module.

    Dependencies are injected by app.py, keeping authentication and storage
    ownership in the composition root until those concerns are migrated.
    """
    router = APIRouter(tags=["history"])

    @router.get("/api/history")
    def history(n: int = 200, _=Depends(guard_dependency)):
        return history_reader(min(max(n, 1), 5000))

    return router
