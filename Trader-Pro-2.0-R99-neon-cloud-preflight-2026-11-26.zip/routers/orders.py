"""Order lifecycle API routes, wired to legacy domain services by dependency injection."""
from fastapi import APIRouter, Depends, HTTPException


def create_orders_router(
    *,
    guard_dependency,
    orders_reader,
    plan_creator,
    rebalance_creator,
    approval_handler,
    rejection_handler,
    cancellation_handler,
    pause_handler,
):
    """Create order routes while keeping broker/state ownership outside this router."""
    router = APIRouter(tags=["orders"])

    @router.get("/api/orders")
    def list_orders(_=Depends(guard_dependency)):
        return orders_reader()

    @router.post("/api/plan")
    def plan(budget: float, _=Depends(guard_dependency)):
        if not 0 < budget <= 1e7:
            raise HTTPException(400, "Budget invalide")
        return plan_creator(budget)

    @router.post("/api/rebalance")
    def rebalance(_=Depends(guard_dependency)):
        return rebalance_creator()

    @router.post("/api/approve/{oid}")
    def approve(oid: str, _=Depends(guard_dependency)):
        return approval_handler(oid)

    @router.post("/api/reject/{oid}")
    def reject(oid: str, _=Depends(guard_dependency)):
        return rejection_handler(oid)

    @router.post("/api/cancel/{oid}")
    def cancel(oid: str, _=Depends(guard_dependency)):
        return cancellation_handler(oid)

    @router.post("/api/pause")
    def pause(_=Depends(guard_dependency)):
        return pause_handler()

    return router
