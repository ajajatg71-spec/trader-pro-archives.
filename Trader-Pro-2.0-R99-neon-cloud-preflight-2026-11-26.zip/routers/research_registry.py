"""Authenticated endpoints for immutable research hypothesis registration."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from db.hypothesis_registry import HypothesisRegistryError

class PreregisterPayload(BaseModel):
    study: str = Field(min_length=1, max_length=120)
    universe: list[str] = Field(min_length=1, max_length=500)
    hypotheses: list[str] = Field(min_length=1, max_length=1000)
    protocol_version: str = Field(min_length=1, max_length=64)
    metadata: dict = Field(default_factory=dict)


def create_research_registry_router(guard_dependency, registry):
    router = APIRouter(prefix="/api/research/registry", tags=["research"])
    @router.post("/families", status_code=201)
    def preregister(payload: PreregisterPayload, _=Depends(guard_dependency)):
        try:
            return registry.preregister(**payload.model_dump())
        except (ValueError, HypothesisRegistryError) as exc:
            raise HTTPException(422, str(exc)) from exc
    @router.get("/families")
    def list_families(limit: int = 50, _=Depends(guard_dependency)):
        if limit < 1 or limit > 200:
            raise HTTPException(422, "limit doit être compris entre 1 et 200")
        return {"items": registry.list_families(limit)}
    return router
