"""Read-only analytics endpoints assembled through injected application services."""
from __future__ import annotations

import shutil
import time
from typing import Any, Callable

from fastapi import APIRouter, Depends, HTTPException


def create_analytics_router(*, guard_dependency: Callable[..., Any], broker: Any,
                            state: dict, history_reader: Callable[[int], list], history_writer: Callable[..., Any],
                            beat: dict, totp_enabled: bool, mode: str,
                            sentiment: Any, thirteen_f: Any, backtest: Any,
                            risklib: Any, broker_status_reader: Callable[[], dict[str, Any]] | None = None) -> APIRouter:
    router = APIRouter(tags=["analytics"])

    @router.get("/api/health")
    def health_detail(_=Depends(guard_dependency)):
        if broker_status_reader is not None:
            try:
                status = broker_status_reader()
                if not isinstance(status, dict):
                    raise ValueError("statut courtier invalide")
            except Exception:
                status = {
                    "provider": "unknown",
                    "paper_confirmed": False,
                    "connection_health": "unavailable",
                    "last_successful_check": None,
                    "last_check_at": None,
                    "confirmation_basis": None,
                    "message": "État du courtier indisponible.",
                }
            api_ok = (
                status.get("connection_health") == "healthy"
                and (
                    status.get("provider") == "simulator"
                    or (
                        status.get("provider") == "alpaca_paper"
                        and status.get("paper_confirmed") is True
                    )
                )
            )
        else:
            try:
                broker.clock()
                api_ok = True
            except Exception:
                api_ok = False
            status = {}
        return {"broker_ok": api_ok, **status, "paused": state["paused"],
                "beat_age_s": int(time.time() - beat["t"]),
                "disk_free_mb": shutil.disk_usage(".").free // 2**20,
                "mode": mode, "totp": totp_enabled}

    @router.get("/api/equity")
    def equity_curve(period: str = "1M", _=Depends(guard_dependency)):
        if period not in ("1W", "1M", "3M", "1A"):
            raise HTTPException(400, "Période invalide")
        return [{"t": t, "v": v} for t, v in broker.equity_curve(period) if v is not None]

    @router.get("/api/decisions")
    def decisions(n: int = 100, _=Depends(guard_dependency)):
        return [r for r in history_reader(1000) if r["kind"] == "decision"][:min(max(n, 1), 500)]

    @router.get("/api/opportunities")
    def opportunities(_=Depends(guard_dependency)):
        seen, out = set(), []
        for row in history_reader(2000):
            if row["kind"] != "decision":
                continue
            symbol = row["msg"].split(" :")[0]
            if symbol in seen:
                continue
            seen.add(symbol)
            if " : acheter" in row["msg"]:
                out.append(row)
        return out

    @router.get("/api/calendar")
    def calendar(_=Depends(guard_dependency)):
        result = {}
        for row in history_reader(3000):
            if row["kind"] in ("order", "cancel", "reject", "block"):
                result.setdefault(row["t"][:10], []).append(f"{row['t'][11:16]} {row['msg']}")
        return result

    @router.get("/api/news")
    def news(symbols: str, _=Depends(guard_dependency)):
        result = []
        for symbol in [x.strip().upper() for x in symbols.replace(",", " ").split()][:5]:
            result += [{"symbol": symbol, "headline": headline,
                        "score": sentiment.score([headline])}
                       for headline in broker.news(symbol, 8)]
        return result

    @router.get("/api/compare")
    def compare(_=Depends(guard_dependency)):
        return thirteen_f.compare(state["inst"])

    @router.get("/api/backtest")
    def backtest_view(symbol: str, strategy: str = "sma", split: float = 0.6,
                      fee: float = 0.05, slip: float = 0.05,
                      realistic: int = 0, _=Depends(guard_dependency)):
        if strategy not in backtest.STRATS:
            raise HTTPException(400, "Stratégie inconnue")
        if not (0.3 <= split <= 0.9 and 0 <= fee <= 5 and 0 <= slip <= 5):
            raise HTTPException(400, "Paramètres hors limites")
        closes = broker.closes_long(symbol.strip().upper()[:10])
        if len(closes) < 300:
            raise HTTPException(400, "Historique insuffisant (300 jours minimum)")
        limits = state["limits"]
        rules = {k: limits[k] for k in ("stop_loss_pct", "trailing_pct", "take_profit_pct")} if realistic else None
        sizing = {"risk": limits["risk_per_trade"], "k": limits["stop_k"],
                  "max_frac": limits["max_pos"] / 100} if realistic else None
        result = backtest.optimize(closes, strategy, split, fee / 100, slip / 100,
                                   rules=rules, sizing=sizing)
        history_writer("backtest", f"{symbol.upper()} {strategy} : test {result['test']['return_pct']} % (Sharpe {result['test']['sharpe']})", params=result["params"], overfit=result["overfit"])
        return result

    return router
