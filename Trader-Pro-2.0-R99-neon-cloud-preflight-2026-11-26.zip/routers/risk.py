"""Read-only risk reporting endpoints; risk calculations stay in injected services."""
from fastapi import APIRouter, Depends


def create_risk_router(guard_dependency, risk_reader):
    router = APIRouter(tags=["risk"])

    @router.get("/api/risk")
    def risk_snapshot(_=Depends(guard_dependency)):
        return risk_reader()

    return router
