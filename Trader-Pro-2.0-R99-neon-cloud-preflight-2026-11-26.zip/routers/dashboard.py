"""Dashboard, account-state and configuration/import endpoints."""
from __future__ import annotations

from typing import Any, Callable

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from pydantic import BaseModel


class DashboardConfig(BaseModel):
    targets: str = ""
    blocked: str = ""
    limits: dict = {}


class TextPayload(BaseModel):
    text: str = ""


def _parse_targets(value: str) -> list[tuple[str, float]]:
    result = []
    for line in value.splitlines():
        parts = line.replace(",", ".").split()
        if len(parts) >= 2:
            try:
                amount = float(parts[1])
                if amount > 0:
                    result.append((parts[0].upper()[:10], amount))
            except ValueError:
                continue
    return result


def create_dashboard_router(*, guard_dependency: Callable[..., Any],
                            page_html: str,
                            broker: Any, state: dict, history_reader: Callable[[int], list],
                            state_lock: Any, state_saver: Callable[[], None],
                            history_writer: Callable[..., Any], limits: dict,
                            base_url: str, simulation: bool, core_module: Any, congress_module: Any,
                            thirteen_f_module: Any) -> APIRouter:
    router = APIRouter(tags=["dashboard"])

    @router.get("/", response_class=HTMLResponse)
    def page(request: Request):
        try:
            guard_dependency(request)
        except HTTPException:
            return RedirectResponse("/login")
        return page_html

    @router.get("/api/state")
    def account_state(_=Depends(guard_dependency)):
        account = broker.account()
        mode = "simulation" if simulation else "paper" if "paper-api" in base_url else "RÉEL"
        return {"mode": mode, "clock": broker.clock()["is_open"],
                "acct": {k: account[k] for k in ("equity", "cash")},
                "daily": round(core_module.daily_loss(account), 2),
                "pos": [{"symbol": p["symbol"], "value": p["market_value"],
                         "pl": p["unrealized_pl"]} for p in broker.positions()],
                "log": [f"{r['t'][5:16]} [{r['kind']}] {r['msg']}" for r in history_reader(50)],
                **state}

    @router.post("/api/config")
    def update_config(config: DashboardConfig, _=Depends(guard_dependency)):
        new_limits = {}
        for key, value in config.limits.items():
            if key in limits:
                try:
                    new_limits[key] = float(value)
                except (TypeError, ValueError):
                    raise HTTPException(400, f"Valeur invalide : {key}")
                if not 0 <= new_limits[key] <= 1e7:
                    raise HTTPException(400, f"Valeur hors limites : {key}")
        with state_lock:
            state["targets"] = _parse_targets(config.targets)
            state["blocked"] = [x.upper() for x in config.blocked.replace(",", " ").split()]
            state["limits"].update(new_limits)
            state_saver()
        history_writer("config", "Réglages modifiés", targets=state["targets"], limits=state["limits"])
        return {"ok": True}

    @router.post("/api/follow")
    def follow(cik: str, _=Depends(guard_dependency)):
        if not cik.isdigit():
            raise HTTPException(400, "CIK invalide")
        try:
            current, previous = thirteen_f_module.latest_two(cik)
        except Exception as exc:
            history_writer("error", f"13F {cik} : {exc}")
            raise HTTPException(502, f"Récupération 13F impossible : {exc}") from exc
        diff, counts = thirteen_f_module.diff(previous, current), {}
        for key, column in (("new", "new"), ("sold", "sold"),
                            ("increased", "up"), ("decreased", "down")):
            for row in diff[key]:
                ticker = thirteen_f_module.to_ticker(row[1])
                if ticker:
                    counts.setdefault(ticker, {})[column] = 1
        weights = [(thirteen_f_module.to_ticker(name) or name, round(weight, 2))
                   for name, weight in thirteen_f_module.weights(current, 10)]
        state["inst"][cik] = {"counts": counts, "weights": weights,
                              "new": [row[1] for row in diff["new"]],
                              "sold": [row[1] for row in diff["sold"]]}
        state_saver()
        history_writer("13f", f"13F suivi : CIK {cik}", new=len(diff["new"]), sold=len(diff["sold"]))
        return {"weights": weights, "new": [row[1] for row in diff["new"]],
                "sold": [row[1] for row in diff["sold"]]}

    @router.post("/api/congress")
    def congress_load(payload: TextPayload, _=Depends(guard_dependency)):
        rows = congress_module.parse(payload.text[:300000])
        with state_lock:
            state["congress"] = congress_module.net(rows)
            state_saver()
        history_writer("congress", f"{len(rows)} transaction(s) du Congrès chargée(s)")
        return {"n": len(rows)}

    return router
