"""Strategy configuration and signal endpoints."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from services.strategy import StrategyService, StrategyServiceError


class StrategyConfig(BaseModel):
    enabled: bool = False
    auto_execute: bool = False
    watchlist: str = ""
    scan_minutes: int = 60
    rebalance_days: int = 7
    trade_amount: float = 500.0


def create_strategy_router(guard_dependency, signal_analyzer, strategy_service: StrategyService, pipeline_runner=None):
    router = APIRouter(tags=["strategy"])

    @router.get("/api/signals")
    def signals(symbols: str, _=Depends(guard_dependency)):
        normalized = [s.strip().upper() for s in symbols.replace(",", " ").split()][:10]
        return signal_analyzer(normalized)

    @router.post("/api/strategy/run")
    def run_strategy(symbols: str, _=Depends(guard_dependency)):
        if pipeline_runner is None:
            raise HTTPException(503, "Pipeline de stratégies indisponible")
        normalized = [s.strip().upper() for s in symbols.replace(",", " ").split() if s.strip()]
        try:
            return pipeline_runner(normalized)
        except Exception as exc:
            status = getattr(exc, "status_code", 500)
            detail = getattr(exc, "detail", "Erreur du pipeline de stratégies")
            raise HTTPException(status, detail) from exc

    @router.post("/api/strategy")
    def strategy(config: StrategyConfig, _=Depends(guard_dependency)):
        try:
            return strategy_service.update(config)
        except StrategyServiceError as exc:
            raise HTTPException(exc.status_code, exc.detail) from exc

    return router
