# Trader Pro 2.0 — R45

## Amélioration
Le tableau de recherche multi-actifs calcule désormais, pour chaque stratégie évaluée :
- l'excès de rendement médian entre fenêtres walk-forward (`median_fold_excess_pct`) ;
- le pire excès de rendement observé sur une fenêtre (`worst_fold_excess_pct`).

Le verdict « prometteuse » exige désormais aussi que la fenêtre médiane surperforme le benchmark équipondéré. Une performance agrégée positive ne suffit donc plus si la fenêtre médiane est négative ou nulle. Le pire résultat de fenêtre est exposé pour l'analyse, sans seuil arbitraire supplémentaire.

Les paramètres de stratégie restent figés sur la période OOS : cette évolution améliore le diagnostic de stabilité mais ne constitue pas encore une optimisation/réoptimisation walk-forward.

## Tests
- `BROKER=sim pytest -q` : 793 passed, 11 skipped, 202 subtests passed.
- `python -m unittest discover -q` : 711 tests OK.
- `python -m compileall -q .` : OK.
- `node --check frontend/public/sw.js` : OK.
- JSON manifest : OK.

## Limites non levées
- 11 tests PostgreSQL restent ignorés faute de base PostgreSQL externe configurée.
- Aucun test réel Neon/PostgreSQL ni Alpaca Paper exécuté dans cette validation.
- Aucune mesure de rentabilité réelle ; aucun ordre créé ; aucune stratégie activée ; Live reste verrouillé.
- Le test walk-forward actuel utilise des paramètres figés et des fenêtres de reporting sur un portefeuille continu ; il ne réoptimise pas les paramètres dans chaque fenêtre.
