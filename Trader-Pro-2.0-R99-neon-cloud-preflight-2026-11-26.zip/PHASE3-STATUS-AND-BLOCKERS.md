# Phase 3 — PostgreSQL / SQLAlchemy / Alembic status

## Implemented in the current worktree
- SQLAlchemy 2.x models and fixed-precision financial columns.
- Unique client and broker order identifiers; fill-to-order foreign key.
- Session/engine factory with explicit DATABASE_URL.
- Alembic initial migration; `DATABASE_URL` now overrides the development ini URL.
- Database connectivity probe that does not silently downgrade to JSON/SQLite.
- PostgreSQL backup script using custom-format `pg_dump`, archive-list verification and SHA-256.

## Remaining release gates (not complete)
- A reachable PostgreSQL instance and credentials are required to run the migration against PostgreSQL.
- PostgreSQL driver `psycopg` is not installed in this runtime.
- Need PostgreSQL integration tests for constraints, transaction rollback, concurrent writes, and migration upgrade/downgrade.
- Need an actual backup and isolated restore test against PostgreSQL.
- Need a reviewed, idempotent import of legacy JSON state, followed by record counts and financial reconciliation.
- Strategy proposal persistence is now wired through `StrategyPersistence`: proposals, signals, regime, pre-risk metadata and lifecycle statuses are stored transactionally; pending proposals are restored from PostgreSQL at startup. The existing OrderService records SUBMITTING before broker submission and SUBMITTED after the response, using the stable client order ID for recovery/idempotency.
- The app uses PostgreSQL as the authoritative source for strategy-generated pending proposals when `DATABASE_URL` is configured; if PostgreSQL/schema is unavailable, startup or proposal staging fails closed. Legacy non-strategy state remains JSON-backed pending a separate migration/reconciliation.
- Need to wire and reconcile the remaining portfolio/account snapshots, fills and general order lifecycle before JSON can cease being authoritative.

The new strategy-proposal migration has been exercised through Alembic upgrade, downgrade to the prior revision, and upgrade again on temporary SQLite. Repository lifecycle and restart restoration are covered by unit tests. This is useful migration/repository evidence, but it is not a PostgreSQL integration test.

Therefore Phase 3 remains **in progress / externally blocked**, not closed. SQLite tests are useful unit tests but are not evidence of PostgreSQL compatibility.

## Deferred user-side validation
The user will install/run Docker Desktop and PostgreSQL later on Windows. Until then, PostgreSQL migrations, integration constraints, backup/restore, and data migration reconciliation remain unverified. The local Docker Compose setup is prepared but Phase 3 is not closed.

- Financial ledger reconciliation now compares fill-derived quantities and cash against broker snapshots when a verified `PAPER_OPENING_CASH` baseline is configured; incomplete fill history is inconclusive and confirmed mismatch pauses trading.
