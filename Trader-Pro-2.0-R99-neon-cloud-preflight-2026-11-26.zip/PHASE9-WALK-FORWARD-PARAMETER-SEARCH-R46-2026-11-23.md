# Phase 9 — recherche chronologique de paramètres (R46)

Date : 23 novembre 2026

## Ajout

`research_v1/backtesting/walk_forward.py` ajoute `run_walk_forward_parameter_search`.
Pour chaque fenêtre, le moteur :
1. simule chaque jeu de paramètres uniquement sur le préfixe d'entraînement ;
2. classe les candidats avec un objectif déterministe basé sur le Sharpe, le drawdown
   et le CAGR d'entraînement ;
3. fige le candidat gagnant ;
4. simule ce candidat sur la fenêtre chronologique suivante, sans utiliser cette
   fenêtre pour le choix des paramètres ;
5. répète le processus en faisant croître le préfixe d'entraînement.

Les paramètres sont validés par le catalogue de stratégies existant. La recherche
est bornée à 100 candidats par appel. Les résultats indiquent explicitement que
les fenêtres de test n'ont pas été utilisées pour la sélection.

## Limites méthodologiques explicites

- Chaque fenêtre OOS repart du capital initial : les résultats sont des diagnostics
  de fenêtres indépendantes, pas un portefeuille continu réoptimisé.
- Les jeux de paramètres doivent être fournis avant le lancement ; le module ne
  fabrique pas automatiquement une grille.
- L'objectif de sélection est une heuristique de recherche, pas un critère de
  rentabilité ou une preuve statistique.
- Le module n'importe aucun broker, ne crée aucun ordre et n'autorise aucun capital.
- Les résultats synthétiques des tests ne sont pas une preuve de performance.

## Tests

La suite complète est passée : 796 passed, 11 skipped, 202 subtests passed.
Les 11 tests ignorés nécessitent un PostgreSQL externe configuré explicitement.
