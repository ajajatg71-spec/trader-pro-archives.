# Trader Pro 2.0 — R91 : registre PostgreSQL durable des opérations sur titres

Base : R90.

## Objectif
Rendre persistantes les révisions point-in-time des opérations sur titres, sans modifier les prix ni autoriser le Live.

## Modifications
- Ajout du modèle SQLAlchemy `CorporateActionRevisionRecord` et de la table `corporate_action_revisions`.
- Ajout de `CorporateActionRepository` : ajout append-only, lecture snapshot `as_of`, reconstruction stricte des événements et comptage des révisions.
- Les identités `(source, event_id, revision)` sont uniques. Une répétition strictement identique est idempotente ; un contenu différent sous la même identité est rejeté.
- Les révisions doivent être contiguës et leur `recorded_at` ne peut pas reculer.
- Verrou transactionnel PostgreSQL par identité d'événement pour sérialiser les écrivains concurrents.
- Trigger PostgreSQL empêchant UPDATE et DELETE directs sur le registre.
- Les annulations sont persistées sans payload d'événement ; les snapshots `as_of` excluent l'événement après la date d'enregistrement de l'annulation.
- Les dates d'annonce restent stockées en ISO avec fuseau dans le payload, afin de préserver leur précision et le point-in-time.

## Tests
- Tests ciblés registre/repository : 19 réussis.
- Suite complète : **991 passed, 11 skipped, 205 subtests passed** (32,12 s). Rapport JUnit : 0 erreur, 0 échec, 11 ignorés. Le runner est resté actif après la sortie du rapport, mais les 1 002 cas ont été comptabilisés.
- `compileall` : réussi.
- `alembic upgrade head` sur base SQLite temporaire vide : réussi, head `f19a6c3d8b42`.
- `history.jsonl` restauré octet pour octet après les tests.

## Validation externe
- Neon projet Trader pro accessible en PostgreSQL 18.7.
- La base `trader_pro_test` contient actuellement zéro table utilisateur ; aucune migration n'a été appliquée à Neon.
- La branche production n'a subi aucune écriture.
- Trigger PostgreSQL et concurrence multi-écrivains restent à vérifier sur une branche Neon de validation.
- Aucun accès Alpaca authentifié utilisé ; aucune récupération réelle d'événements revendiquée.

## Sécurité et limites
- Aucun ordre créé ; Live reste désactivé.
- Aucune donnée de prix modifiée.
- R91 est un candidat local ; pas de certification PostgreSQL/Neon ni Alpaca Paper.
