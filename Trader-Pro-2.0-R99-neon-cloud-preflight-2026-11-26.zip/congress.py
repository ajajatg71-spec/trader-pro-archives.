"""Transactions du Congrès américain : lecture d'un CSV (date,politician,ticker,type,amount) et signal par titre."""
import csv, io

def parse(text):
    rows = []
    for r in csv.DictReader(io.StringIO(text)):
        t = (r.get("type") or "").strip().lower()
        side = 1 if t.startswith(("buy", "purchase")) else -1 if t.startswith(("sale", "sell")) else 0
        if side and (r.get("ticker") or "").strip():
            rows.append((r["ticker"].strip().upper(), side, (r.get("politician") or "").strip(), r.get("date", "")))
    return rows

def net(rows):
    """ticker -> signal de -1 (que des ventes) à +1 (que des achats)."""
    s = {}
    for t, sd, _, _ in rows: s.setdefault(t, []).append(sd)
    return {t: sum(v) / len(v) for t, v in s.items()}
