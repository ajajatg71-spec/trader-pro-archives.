# Phase 7 — Liquidity feed integration validation

## Implemented

- Added `services/providers/alpaca_liquidity.py` with an Alpaca IEX market-data-only adapter for latest bid/ask and recent daily bars.
- The adapter calculates an ADV proxy from close × volume over up to 20 completed daily sessions, including zero-volume sessions (minimum 10), and returns the quote timestamp and `alpaca_iex` source identifier.
- Wired the adapter into `OrderService` only in non-simulation mode when Alpaca credentials are configured.
- Buy-side liquidity limits now trigger a just-in-time data refresh before the institutional risk gate. Missing provider configuration, provider errors, and invalid snapshots block the order before the broker submission call.
- Institutional liquidity controls require explicit source provenance and a fresh timestamp.
- Existing sector/factor metadata is retained when the market-derived liquidity fields are refreshed.
- No market-impact coefficient is fabricated. If the impact cap is enabled without a separately calibrated coefficient, the existing risk engine blocks the order.

## Validation performed in this environment

- `python -m pytest -q`: **392 passed, 3 skipped, 76 subtests passed**.
- `python -m unittest discover -q`: **388 passed**.
- `python -m compileall -q .`: passed.
- `BROKER=sim` app import: passed; 35 routes registered; no live liquidity adapter attached.
- Non-simulation/Paper-configured app import with dummy credentials: passed; 35 routes registered; Alpaca liquidity adapter instantiated. No network request was made.
- Alembic upgrade to head on a fresh temporary SQLite database: passed; single migration head `e8a19c42d7b1`.

## Not verified / remaining

- The three skipped tests are PostgreSQL integration tests. No PostgreSQL server was available for this run.
- No external Alpaca API request or Paper order was performed; provider HTTP tests use mocked responses.
- ADV is an IEX close-times-volume proxy, not consolidated market-wide dollar volume.
- The square-root market-impact coefficient requires independent calibration and trusted instrument metadata; it is intentionally not inferred by the adapter.
- This does not complete Phase 7. PostgreSQL operational restart validation and end-to-end Paper checks remain outstanding.

## Incremental freshness hardening

- The adapter now independently rejects bid/ask quotes older than 120 seconds by default, or timestamped more than five seconds in the future, before requesting daily bars.
- The maximum quote age is configurable and the injected clock must be timezone-aware.
- Two tests cover stale/future quote rejection and assert that the historical-bars HTTP request is not made after rejection.
- Updated local validation: 394 pytest passed, 3 PostgreSQL integration tests skipped, 76 subtests passed; 390 unittest passed; compileall passed.

## Daily-bar integrity hardening

- Each daily bar must now carry a timezone-aware timestamp.
- Daily observations older than 45 calendar days or more than 24 hours in the future are rejected.
- Duplicate daily sessions are rejected rather than double-counted in ADV.
- The snapshot includes `adv_as_of` to expose the newest daily session used in the estimate.
- This remains an IEX-only ADV proxy; 45 calendar days is a conservative freshness bound, not a guarantee of 20 trading sessions or consolidated-market coverage.
- Updated local validation: **397 pytest passed, 3 PostgreSQL integration tests skipped, 76 subtests passed; 393 unittest passed; compileall passed**.

## Zero-volume session integrity follow-up

- Completed sessions with zero reported volume are included as zero-dollar-volume observations in the ADV denominator; excluding them could systematically overstate liquidity for illiquid or halted instruments.
- ADV uses the latest 20 complete observations (minimum 10), regardless of whether their reported volume is zero. An all-zero history is rejected because its ADV is zero.
- Added two regression tests for zero-volume inclusion and all-zero fail-closed behavior.
- Updated local validation: **405 pytest passed, 3 PostgreSQL integration tests skipped, 76 subtests passed; 401 unittest tests passed; compileall passed**.
