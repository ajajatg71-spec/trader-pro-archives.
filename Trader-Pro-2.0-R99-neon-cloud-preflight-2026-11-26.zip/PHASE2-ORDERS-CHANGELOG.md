# Trader Pro 2.0 — Phase 2 orders router

## Scope

Extracted the order API surface into `routers/orders.py` using dependency injection. The router now owns the HTTP endpoints for:

- `GET /api/orders`
- `POST /api/plan`
- `POST /api/rebalance`
- `POST /api/approve/{oid}`
- `POST /api/reject/{oid}`
- `POST /api/cancel/{oid}`
- `POST /api/pause`

Existing domain behavior remains in the application composition layer and is injected into the router. No broker call is performed by the router itself. The original approval logic, including pause checks, account-block checks, daily-loss stop, reserved-cash calculation, risk validation, and idempotent broker order ID, is retained.

## Verification performed

- `python -m compileall -q .`: passed.
- `python -m unittest discover -v`: 126 tests passed.
- `pytest -q`: 126 tests passed.
- Full application import with `BROKER=sim`: passed; 31 routes registered.
- All seven order lifecycle routes present in the full FastAPI app.
- Six calculation modules compared byte-for-byte against the original V1 archive and unchanged: `core.py`, `scoring.py`, `risklib.py`, `portfolio.py`, `indicators.py`, `backtest.py`.

## Safety boundary

No live or paper broker order was sent during these checks. No external broker credentials were used. Live trading remains disabled; this change is a route-structure refactor, not a trading validation or authorization.
