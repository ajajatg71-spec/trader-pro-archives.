# Phase 7 — Kill switch: cancellation requests for broker-open orders

## Change

When the operator activates the durable operational pause, `OrderService.toggle_pause()` now commits the pause first and only then attempts to cancel broker-open orders. It reads at most 500 open orders and accepts only known non-terminal statuses. Orders are canceled by broker order ID, never by the local client ID.

Before each external cancellation call, the repository records an append-only `broker_cancel_requested` audit event. If the order is present in the local ledger, its local status becomes `pending_cancel`. If the broker cancellation request raises an exception, a `broker_cancel_request_failed` event is recorded and the order is not marked canceled.

A successful DELETE response is deliberately not treated as proof of cancellation. The order remains `pending_cancel` until a later broker reconciliation confirms whether cancellation or a fill won the race. The kill switch remains active if the broker snapshot fails, an individual cancellation fails, or the snapshot may be truncated (500 or more results).

When the durable pause cannot be read, the service fails closed and refuses to toggle/resume. When persistence of a requested pause fails, the in-memory process is also forced paused and the request returns an error.

## Tests

- Open broker orders are selected; terminal filled orders are not canceled.
- Durable pause is persisted before cancellation intent and broker call.
- Cancellation uses broker order ID.
- Successful cancellation request remains `pending_cancel`, not `canceled`.
- Cancellation timeout is audited and does not claim final cancellation.
- Broker snapshot failure leaves pause active.
- Durable pause read failure cannot accidentally resume trading.
- Repository audit persists cancellation requests and failures.

## Limits / not yet validated

- SQLite tests do not validate PostgreSQL row locking or concurrent workers.
- No authenticated Alpaca Paper cancellation was sent in this environment.
- The broker adapter currently requests a maximum of 500 open orders; a result count of 500 is reported as potentially truncated. Pagination and a repeated drain/reconcile loop remain to be implemented and tested before production-grade completeness can be claimed.
- An order can fill between the open-order snapshot and cancellation. Only subsequent broker reconciliation can determine the final outcome.
- This is a cancellation-request workflow, not a guarantee that all open orders have been canceled.
