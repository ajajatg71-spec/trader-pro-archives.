# Trader Pro 2.0 — Phase 2 strategy router

## Scope
- Extracted `GET /api/signals` and `POST /api/strategy` into `routers/strategy.py`.
- Added dependency injection for signal analysis, state persistence, locking, and audit logging.
- Preserved the existing symbol normalization and 10-symbol cap, configuration bounds, watchlist cap, and paper-only automatic-execution guard.
- No scoring, sentiment, indicator, portfolio, or risk formulas were changed.

## Validation
- Unit tests cover signal normalization, strategy persistence/audit logging, invalid parameter rejection, and rejection of automatic execution outside Paper mode.
- Full regression suite and application route-registration checks must pass before release.
- No broker orders are submitted by these tests.
