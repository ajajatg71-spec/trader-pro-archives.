# Candle analysis foundation — 2026-11-21

## Added
- New pure `candle_analysis.py` OHLCV analysis module, separate from order execution.
- Strict validation of finite positive OHLC prices, candle geometry, non-negative volume, chronological timezone-aware timestamps, and aligned timestamp presence.
- Candle anatomy: body, upper/lower wick, close location, gap, ATR percentage, relative volume, simple trend context and recent high/low structure.
- Initial transparent pattern heuristics: doji, hammer/hanging-man-like, shooting-star/inverted-hammer-like, marubozu-like, bullish/bearish engulfing, inside/outside bar, morning/evening-star-like.
- Pattern volume confirmation is explicitly a relative-volume observation, not a probability.
- Dedicated tests for pattern recognition, warm-up, malformed OHLC, timestamps and invalid numeric inputs.

## Important limitations
- This is a research foundation, not a complete or predictive candle model. Pattern names that depend on prior trend are deliberately marked context-dependent.
- No signal is connected to the strategy pipeline or broker. No trading thresholds or validated V1 calculations were changed.
- No multi-timeframe alignment, exchange calendar/session segmentation, corporate-action adjustment verification, order-book/spread context, probabilistic calibration, or walk-forward pattern validation is claimed yet.
- Before strategy integration, patterns and context features must be evaluated with point-in-time data, costs, out-of-sample periods and regime-specific statistics.
