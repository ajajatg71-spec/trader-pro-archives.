# Phase 8 — Durable global safety state

## Implemented in this revision

- Added `system_safety_state`, a singleton durable PostgreSQL state with `READY`, `DEGRADED`, `RECONCILING`, and `HALTED`.
- Migration seeds the system in `RECONCILING`, never `READY`; initial trading remains blocked until a complete reconciliation is explicitly attested.
- State transitions are constrained. `HALTED` can only move to `RECONCILING` through an explicit operator actor; it cannot jump directly to `READY`.
- Transition to `READY` now requires a persisted `reconciliation_run_id`, actor `operator`, Paper source, successful status, complete snapshots, zero unresolved discrepancies, a SHA-256 evidence hash, and a proof no older than five minutes. The boolean attestation has been removed.
- Order claim locks the global state row and the durable pause row in the same transaction; missing/non-READY state blocks and is audited.
- Strategy pipeline and order approval both fail closed when the state reader is absent, unavailable, or non-READY. The final order claim repeats the check atomically in PostgreSQL.
- Without configured PostgreSQL, application-level strategy and approval paths remain blocked.

## Important remaining work

- Fine-grained multi-role authorization remains open; the current operator endpoint uses a dedicated operator password plus TOTP.
- Confirm worker outcomes are wired to `DEGRADED`/`RECONCILING`; workers must never auto-promote to `READY`.
- Validate PostgreSQL row-lock behavior with a real PostgreSQL server. SQLite tests do not prove `FOR UPDATE` concurrency semantics.

## Safety note

This is a fail-closed control addition, not a declaration that the trading system is production-certified. Paper and Live broker access are not exercised by these tests.
