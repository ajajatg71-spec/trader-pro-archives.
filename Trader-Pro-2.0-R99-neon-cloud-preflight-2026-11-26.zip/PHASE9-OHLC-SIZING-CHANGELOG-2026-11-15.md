# Phase 9 — OHLC sizing parity (2026-11-15)

- Added optional `sizing` to `run_ohlc()` using the existing `{risk, k, max_frac}` schema.
- Validates sizing with the same helper used by the close-only engine.
- Uses only pre-entry close history for volatility estimation; no future OHLC values enter sizing.
- Preserves uninvested cash and applies the existing short-history `max_frac` fallback.
- Leaves the legacy `run()` path unchanged.
- Tests: short-history fallback, volatility-derived sizing, invalid configuration.

Verification: 59 backtest tests passed (93 subtests); 554 full pytest passed, 10 skipped (PostgreSQL); 550 unittest passed; compileall passed. No real PostgreSQL or Alpaca Paper API calls were made.

## Follow-up — numeric overflow guards (2026-11-15)

Adversarial testing found that individually finite OHLC prices and cash can still produce an infinite position quantity or marked portfolio equity (for example, extremely small prices paired with very large cash). `run_ohlc()` now rejects non-representable entry sizing, cash balances, exit proceeds, trade returns and marked equity with explicit `OverflowError` rather than returning an infinite equity series. Regression tests reproduce both position-quantity and mark-to-market overflow. The legacy close-only `run()` path was not changed.

Verification: 61 backtest tests passed (93 subtests); full pytest **556 passed, 10 skipped, 177 subtests passed**; unittest **552 passed**; `compileall` passed. The ten skipped tests are PostgreSQL integration tests; no PostgreSQL server or Alpaca API was exercised.
