
## 2026-11-15 follow-up — isolated PostgreSQL 16 test container

A second, disposable local test path is now provided in addition to the GitHub
Actions service: `compose.test.yaml` plus `scripts/run_postgres_container_tests.sh`
and `scripts/run_postgres_container_tests.ps1`. The database files live only in
container tmpfs and the runner removes the test container after completion.
The environment creates a separate `_restore` database for backup/restore work.

This runtime has no Docker/Podman executable, PostgreSQL server/client binaries,
or psycopg driver, so it cannot start that environment here. The scripts and
PostgreSQL concurrency test are prepared; they must be run on a Docker-enabled
Windows/Linux host or through the existing PostgreSQL GitHub Actions workflow.
