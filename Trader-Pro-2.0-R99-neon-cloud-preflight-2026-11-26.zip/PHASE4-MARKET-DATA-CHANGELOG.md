# Phase 4 — Market Data Engine (initial implementation)

## Implemented
- Added `MarketDataService` as a provider-independent boundary.
- Symbol normalization and strict symbol validation.
- Daily close/volume series validation: aligned lengths, minimum history, finite positive prices, finite non-negative volumes, and requested maximum length.
- Bounded TTL cache with LRU eviction, thread-safe access, and per-symbol/global invalidation.
- News headline normalization and bounded cache.
- Integrated the engine into the existing analysis path without changing scoring, indicators, sizing, risk, or backtest calculations.
- Added focused unit tests.

## Not yet complete
- Provider pagination and full historical coverage need a dedicated Alpaca adapter and fixture tests.
- No independent second market-data provider or failover.
- No persisted raw bars, corporate-action reconciliation, exchange calendar, intraday feeds, or live feed monitoring.
- Data timestamps are fetch timestamps only; provider bar timestamps are not yet retained. Do not interpret cache freshness as exchange-data freshness.

## Update — provider pagination hardening
- Added bounded Alpaca daily-bar pagination using `next_page_token` for both `bars2` and long-history `closes_long` retrieval.
- Added a maximum page bound, repeated-token detection, chronological timestamp checks, and required close/volume field checks.
- Added deterministic mocked-provider tests for multi-page retrieval, ordering, repeated tokens, and invalid limits.
- The adapter still returns close/volume arrays to preserve existing consumers; provider timestamps are validated but not yet exposed/persisted. Corporate actions beyond Alpaca split adjustment, a second provider, and live feed monitoring remain open.
- No live market-data request or broker order was sent during this work.

## Update — provider timestamps carried into the Market Data Engine
- Added `broker.bars3`, returning Alpaca UTC bar timestamps together with closes and volumes from the same paginated response.
- Switched the application market-data service to the timestamp-aware reader; the simulator explicitly returns no exchange timestamps rather than fabricating them.
- Extended `DailyBars` to retain provider timestamps separately from `fetched_at`.
- Added validation for timestamp count/alignment, timezone awareness, parseability, and strict chronological ordering; legacy two-series readers remain supported.
- Added tests for UTC preservation and rejection of naive/out-of-order timestamps.
- No trading calculations, sizing, risk rules, or execution behavior were changed.


## Update — cross-provider data consistency checks
- Added a read-only comparison utility for two timestamped `DailyBars` histories.
- Matches bars by exact timestamps, reports common/missing coverage, and calculates maximum and mean close-price deviation.
- Exposes a tolerance verdict without silently modifying, averaging, or replacing provider prices.
- Rejects comparisons without timestamps or without overlapping bars.
- Added tests for price divergence, mismatched history coverage, missing timestamps, and no overlap.
- This is a validation primitive only: no second live provider is configured and no live market request was made.


## Session-aware daily-bar freshness (2026-11-10)

- Replaced the temporary four-calendar-day age threshold in the Paper market-data analysis path with the XNYS exchange-session calendar.
- Uses the exchange schedule and actual session close timestamps, including weekends, exchange holidays, DST transitions and early closes; applies a configurable 15-minute publication grace period.
- Requires provider timestamps to map to a valid exchange session, rejects future, naive, duplicate and out-of-order timestamps, and fails closed if the calendar cannot establish the last completed session.
- Added `exchange-calendars` as an explicit runtime dependency. The deterministic local SIM path remains exempt because its synthetic bars intentionally have no exchange timestamps.
- Scope remains US listed equities on XNYS (consistent with the current Alpaca stock adapter); other exchanges/instruments need an explicit calendar mapping before use.

### Contrôle de couverture des séances quotidiennes
- Ajout de `inspect_daily_bar_coverage` et du rapport `DailyBarCoverage` pour détecter les séances XNYS manquantes entre la première et la dernière bougie horodatée.
- Les week-ends et jours fériés sont exclus grâce au calendrier de marché ; les doublons, l'ordre invalide et les horodatages de jours non ouvrés sont rejetés.
- Le diagnostic signale les trous sans rejeter automatiquement l'historique (un arrêt de cotation ou une suspension peut être légitime). Un seuil `max_missing_sessions` permet un contrôle strict à la demande.
- Tests ajoutés : couverture sans faux positif week-end, séance manquante, rejet des dates non ouvrées et doublons.

### Diagnostics des fournisseurs et bascule (2026-11-10)
- `ProviderChain` conserve désormais, en mémoire, les tentatives, succès, échecs, échecs consécutifs, horodatages de dernière tentative/réussite, type d'erreur et latence de chaque fournisseur.
- Le diagnostic indique le dernier fournisseur ayant fourni une réponse valide ; un succès remet le compteur d'échecs consécutifs à zéro.
- `health_snapshot()` renvoie une copie des métriques et n'expose ni messages d'exception, ni URL, ni paramètres susceptibles de contenir des secrets.
- Les métriques sont locales au processus et non persistées ; aucune route HTTP publique n'est ajoutée à ce stade afin de ne pas exposer de détails opérationnels sans contrôle d'accès.
- Tests ajoutés pour le failover, le suivi des échecs et l'absence de fuite de texte sensible.

### Diagnostics fournisseurs exposés (10/11/2026)
- Le lecteur de barres quotidiennes configuré passe désormais par `ProviderChain`, avec un nom explicite (`alpaca` hors simulation, `simulation` en SIM).
- Ajout de `GET /api/market-data/providers`, protégé par la session applicative, exposant les compteurs de tentatives/réussites/échecs, la latence et les derniers horodatages.
- Les diagnostics n'exposent ni messages d'erreur bruts, ni URL, ni identifiants. L'endpoint précise qu'aucun fournisseur secondaire réel n'est configuré.
- Aucun ordre ni calcul financier n'est modifié. La source configurée n'est pas une preuve de connectivité; elle ne sera comptabilisée qu'après une récupération effective.

### Protection contre les pannes répétées des fournisseurs
- Ajout d'un coupe-circuit configurable à `ProviderChain` : ouverture après un seuil d'échecs consécutifs, période de refroidissement, puis sonde de reprise.
- Un fournisseur dont le circuit est ouvert est temporairement ignoré afin d'éviter de répéter des appels connus comme défaillants ; le fournisseur de secours reste essayé.
- Une seule sonde de reprise concurrente est autorisée après le délai ; une réussite referme le circuit et remet à zéro les échecs consécutifs.
- Les diagnostics exposent l'état (`closed`, `open`, `half_open`) et le nombre d'appels ignorés, sans stocker les messages d'erreur sensibles.
- Tests déterministes avec horloge monotone simulée : ouverture, évitement, reprise et validation de configuration.
- Aucun fournisseur secondaire réel n'est ajouté ni prétendu testé dans cette étape.

### Réconciliation inter-fournisseurs — volumes et couverture
- Étendu `compare_daily_bars` pour comparer aussi les volumes sur les seuls horodatages UTC communs.
- Ajout des écarts maximal/moyen de volume, d'un seuil indépendant de tolérance volume et du taux de recouvrement des historiques.
- Renforcement de la validation : volumes absents, désalignés, négatifs ou non finis rejetés.
- Les comparaisons de clôture gardent leur seuil et leur comportement existants ; les métriques volume sont séparées et ne modifient pas automatiquement les cours.
- Tests couvrant volumes nuls, écarts, couverture partielle et paramètres invalides.

### Garde de qualité pour la réconciliation inter-fournisseurs (10/11/2026)
- Ajout de `require_consistent_daily_bars` : validation explicite du nombre de bougies communes, du taux minimal de recouvrement, de la tolérance sur les clôtures et, par défaut, de la tolérance sur les volumes.
- La garde échoue de manière fermée si les données ne satisfont pas les seuils ; les paramètres de recouvrement sont contrôlés (0–100 %) et les comparaisons trop courtes sont refusées.
- La fonction renvoie la comparaison sans modifier, moyenner ou sélectionner les cours. Elle reste opt-in et n'est pas branchée au chemin d'exécution tant qu'un deuxième fournisseur indépendant n'a pas été configuré et vérifié.
- Tests ajoutés pour les cas acceptés, couverture insuffisante, divergence de clôture, divergence de volume et paramètres invalides.

## Adaptateur secondaire Twelve Data (préparation, non validé en production)
- Ajout de `services/providers/twelvedata.py`, adaptateur quotidien indépendant utilisant l'API REST officielle Twelve Data via `requests`.
- Normalisation des dates de séance en `America/New_York`, des clôtures et des volumes ; tri chronologique et rejet des dates dupliquées, historiques courts et valeurs invalides.
- Gestion des erreurs réseau/API sans exposer le message brut, l'URL ou la clé dans les exceptions de diagnostic.
- Activation facultative dans `app.py` uniquement si `TWELVEDATA_API_KEY` est explicitement configurée ; sinon, Alpaca reste seul fournisseur configuré.
- Couverture par tests simulés/mocks : format, fuseau, ordre, erreurs, secrets, valeurs, limite et bascule ProviderChain.
- Limite : aucun appel authentifié réel n'a été réalisé ; les limites de quota, la couverture de symboles et l'accord tarifaire doivent être validés avec le compte opérateur avant usage réel.

## Phase 4 validation environment (2026-11-10)
- Created a dedicated Python 3.13 virtual environment at `/mnt/data/trader-pro-venv` for repeatable local project checks.
- Ran the current Twelve Data adapter build in that environment: 218 pytest tests plus 16 subtests passed; 214 unittest tests passed; `compileall` passed.
- Environment uses preinstalled base-image packages because package-index network access was unavailable; a fully offline-independent dependency installation and live provider credentials remain outstanding.

### Validation renforcée des rapports de cohérence (11/11/2026)
- La garde `require_consistent_daily_bars` valide désormais elle-même les rapports reçus : identités de sources, comptages entiers non négatifs, taux de recouvrement fini (0–100 %), verdicts booléens et métriques d'écart finies/cohérentes.
- Rejet explicite des rapports construits ou altérés par un appelant avec `NaN`, infini, booléens utilisés comme comptages, mesures absentes ou incohérentes. Cela empêche qu'un rapport malformé contourne une garde fail-closed.
- Ajout d'un test prouvant que deux horodatages exprimés dans des fuseaux différents mais représentant le même instant sont correctement rapprochés en UTC.
- Rappel opérationnel : le flux Alpaca configuré est IEX (volume partiel) tandis que la couverture de volume Twelve Data doit être confirmée selon le produit/compte utilisé. La tolérance de volume par défaut ne doit donc pas être interprétée comme un contrôle valide entre ces deux flux avant qualification de leur périmètre. Une comparaison de clôtures seule (`require_volume=False`) reste distincte et ne certifie pas la qualité des volumes.
- Aucun fournisseur n'a été interrogé en direct et la comparaison ne déclenche toujours aucune sélection, moyenne ou substitution automatique de cours.

### Durcissement des rapports de comparaison — seuils et cohérence interne (11/11/2026)
- Le rapport `MarketDataComparison` conserve désormais les seuils exacts de tolérance clôture et volume appliqués lors de son calcul.
- `require_consistent_daily_bars` recalcule la cohérence des verdicts à partir des mesures et des seuils, au lieu de faire confiance à des booléens fournis par l'appelant.
- Le taux de recouvrement est contrôlé par rapport aux comptages `matched/only` ; un rapport dont les métriques ne correspondent pas est rejeté.
- Ajout de tests contre les rapports forgés (écart élevé avec verdict favorable, recouvrement falsifié, comptages incohérents, seuil non fini) et pour la conservation des seuils personnalisés.
- Cette garde reste un outil de qualification opt-in ; aucun deuxième flux réel n'a été authentifié et aucun changement du chemin d'exécution ou des ordres n'a été effectué.
