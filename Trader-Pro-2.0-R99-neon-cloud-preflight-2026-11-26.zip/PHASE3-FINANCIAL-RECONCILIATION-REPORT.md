# Phase 3 — Financial reconciliation report

## Implemented
- Reconstructs signed per-symbol quantities from durable fills and the side of each parent order.
- Reconstructs cash from an explicit opening-cash baseline, fill notional and fees.
- Compares reconstructed cash and quantities with broker account/position snapshots.
- Estimates equity as reconstructed cash plus broker-reported market value of positions, then compares with broker equity.
- Uses Decimal arithmetic and configurable absolute tolerances.
- Writes critical risk/audit events for confirmed discrepancies; the authenticated API route pauses trading on a confirmed mismatch.
- Does not auto-correct balances, positions or orders and never retries/submits orders.

## Fail-closed rules
- Without `PAPER_OPENING_CASH`, financial comparison is `not_run`.
- Truncated, unmatched, invalid, or locally recorded fills absent from the broker activity snapshot make the result `inconclusive`.
- Invalid snapshots and duplicate symbols are inconclusive.
- A confirmed quantity, cash or equity mismatch is `mismatch` and pauses Paper trading through the API route.

## Configuration
- `PAPER_OPENING_CASH`: independently verified opening cash at the start of the complete local fill ledger.
- `PAPER_RECONCILIATION_CASH_TOLERANCE`: default USD 0.05.
- `PAPER_RECONCILIATION_QTY_TOLERANCE`: default 0.00001 shares.

The baseline must match the beginning of the full fill history represented in PostgreSQL. Do not enter the current account cash as opening cash if the ledger already contains older fills.

## Verification boundary
Unit tests and a full deterministic `sim_broker` reconciliation test run on SQLite. This does not certify PostgreSQL server behavior, real Alpaca Paper credentials, provider activity retention, dividends, corporate actions, deposits/withdrawals, or short positions. Those require explicit reconciliation policy and external integration tests.
