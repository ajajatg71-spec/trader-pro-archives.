# Phase 7 — récupération des soumissions abandonnées

## Changement

Le repository expose `recover_stale_submissions(stale_after_seconds=120)`. Lors d'une réconciliation, les intentions restées `submitting` au-delà du délai sont reclassées `submission_unknown` dans une transaction et consignées dans `audit_events`.

Cette opération est volontairement conservative : elle ne soumet, ne rejoue et ne marque jamais automatiquement l'ordre comme rejeté. Le même `client_order_id` doit être recherché auprès du broker. Si l'ordre est absent du snapshot broker, il reste inconnu et non réessayable automatiquement.

Les intentions récentes restent `submitting`. Le délai est configurable au niveau repository, borné entre 1 seconde et 24 heures; la réconciliation utilise 120 secondes par défaut.

## Tests locaux

- `python -m pytest -q`: 422 passed, 6 skipped, 88 subtests passed.
- `python -m unittest discover -q`: 418 tests passed.
- `python -m compileall -q .`: passed.
- Alembic SQLite `upgrade head`: passed, revision `f3b8c2d91a64`.
- La migration crée une seule ligne `risk_control_state`.
- FastAPI import en simulation et hors simulation avec credentials factices: 35 routes chacun.

## Limites

- Les 6 tests PostgreSQL sont ignorés car `TRADER_PRO_TEST_DATABASE_URL` n'est pas configurée.
- Aucun appel broker authentifié ou ordre Paper réel n'a été effectué.
- Une absence d'ordre dans le snapshot distant reste ambiguë (pagination, délai de propagation, rétention). Aucune relance automatique n'est autorisée.
- Le délai de 120 secondes est un seuil opérationnel initial, pas une garantie sur les délais de réponse du broker; il doit être vérifié avec des mesures Paper.
