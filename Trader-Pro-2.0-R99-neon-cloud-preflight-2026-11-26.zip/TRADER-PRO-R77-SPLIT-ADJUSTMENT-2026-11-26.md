# Trader Pro 2.0 — R77 : ajustement historique des splits

Base : R76. La fonction `split_adjusted_closes` applique uniquement les splits sourcés aux clôtures brutes.

## Modifications
- Les clôtures antérieures à l'ex-date sont divisées par le ratio « nouvelles actions / anciennes actions ».
- Plusieurs splits sont composés dans l'ordre des ex-dates.
- Les événements annoncés après `as_of` ne sont pas utilisés.
- Horodatages, cours, fuseau de séance et présence de l'ex-date dans l'historique sont contrôlés.
- Les dividendes sont explicitement refusés par cette fonction ; aucun rendement total n'est revendiqué.

## Tests
- 6 tests ciblés ajoutés. Suite complète : 917 passed, 11 skipped, 205 subtests passed in 25.93s.

## Limites
- La fonction suppose que l'entrée est une série brute et que les événements sont complets et vérifiés.
- Pas de connexion à une source réelle de corporate actions.
