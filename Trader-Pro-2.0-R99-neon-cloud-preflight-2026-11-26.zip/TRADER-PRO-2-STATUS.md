# Trader Pro 2.0 — canonical 12-phase status

Status refreshed on 2026-11-23 from the consolidated Trade Pro 7 source and tests run in this session. A code module or unit test does not, by itself, certify an external service or production deployment.

| Phase | Scope | Evidence in this archive | Status |
|---|---|---|---|
| 1 | Audit, backup, security, regression | V1 safety controls, security/auth modules, tests, Phase 2 report's V1 parity statement | Base present; full original-V1 audit cannot be independently repeated without the original V1 ZIP |
| 2 | Modular FastAPI backend | `routers/`, `services/`, `PHASE2-CLOSURE-REPORT.md`; report records byte-for-byte parity for six V1 calculation modules | Closed for stated software scope |
| 3 | PostgreSQL, SQLAlchemy, Alembic | `db/`, `alembic/`, repository persistence, PostgreSQL harness and tests | Open: no PostgreSQL server/driver/URL in current runtime; PostgreSQL-only tests skipped; real backup/restore and JSON migration not certified |
| 4 | Market Data Engine | `services/market_data.py`, provider adapters, validation/freshness tests | Implemented locally; external provider credentials/data and operational failover not certified |
| 5 | Quantitative Engine | `services/quantitative.py`, V1 parity tests, multi-asset/risk diagnostics, walk-forward report | Implemented locally; timestamp alignment is upstream; no claim of production-grade research validation |
| 6 | Multi-strategy Strategy Engine | four deterministic strategies, registry/pipeline/persistence, integration tests | Advanced locally; Paper and PostgreSQL integration gates remain open; long-only BUY proposal limitations documented |
| 7 | Institutional Risk Management | `services/institutional_risk.py`, durable pause, atomic claim, partial-fill and liquidity checks | Implemented locally; PostgreSQL locking/concurrency not validated against a real server |
| 8 | Execution Engine and broker reconciliation | durable order/fill records, cancellation lifecycle, reconciliation, execution health, Paper smoke harness, durable event inbox with retry backoff/dead-letter, guarded worker, stale-submission recovery and `SUBMISSION_UNKNOWN` protection | In progress; local regression coverage exists, but PostgreSQL concurrency, authenticated Paper lifecycle and deployed worker remain unvalidated |
| 9 | Advanced backtesting and OOS validation | `research_v1/backtesting/portfolio_backtest.py`, `portfolio_scoreboard.py`, mono-titre scoreboard, HAC/Bonferroni corrections, fee-stress tests | Improved locally: 7 portfolio strategies now have continuous multi-asset walk-forward OOS scoring; still requires real authenticated data, survivorship/look-ahead/liquidity/corporate-action review and V1/V2 parity |
| 10 | React/TypeScript web-mobile PWA | `frontend/` React/TypeScript/Vite source, read-only dashboard, PWA manifest/icons/service worker, conditional FastAPI static serving, fail-closed risk UI and stale-data refresh handling | Source delivered in this archive; npm install/typecheck/build, browser integration and mobile installability remain pending |
| 11 | Docker, workers, monitoring, backups | Dockerfile, Compose, backup scripts, GitHub Actions workflows | Infrastructure files present; no deployed environment, actual CI run, worker deployment or restore drill evidenced |
| 12 | Validation, Paper trading, separate Live authorization | Paper-only guards and opt-in scripts | Not reached; no authenticated Alpaca Paper validation; Live must remain disabled |

## Current local verification (2026-11-23)

- `python -m pytest -q`: **702 passed, 11 skipped, 202 subtests passed**, zero failures; 2 FastAPI lifespan deprecation warnings.
- `python -m compileall -q .`: passed.
- `node --check frontend/public/sw.js`: passed.
- Alembic upgrade, downgrade one revision and re-upgrade on a disposable SQLite database: passed; head `a72c9e41b5d0`.
- Compose and GitHub Actions workflow YAML parsing: passed.
- ZIP integrity: passed.

The 11 skipped tests require a dedicated disposable PostgreSQL database and explicit opt-in. This run did not execute real PostgreSQL/Neon migration or restore validation, authenticated Alpaca Paper reads, or browser tests. npm registry DNS resolution failed (`EAI_AGAIN`), so the React build is not certified. No Paper or Live order was sent.

## Critical decisions

1. Keep the validated V1 calculation modules unchanged unless a measured parity test proves a deliberate improvement.
2. Do not enable autonomous Paper order flow until PostgreSQL persistence, broker reconciliation, kill-switch concurrency and Alpaca Paper lifecycle tests pass.
3. Do not enable Live mode. It is outside the present validation scope and requires a separate explicit authorization after all release gates.
4. Keep Phase 10 React/TypeScript PWA separate from the existing HTML dashboard; do not describe the latter as a delivered PWA.
5. Do not claim Phase 3 closure based on SQLite migration tests.

## Increment 2026-11-23 — multi-asset portfolio OOS scoreboard and backtest hardening

- Added authenticated `POST /api/research/portfolio-strategies/scoreboard` for all seven universe strategies.
- The portfolio remains continuous across chronologically segmented OOS windows; parameters are frozen, next-open fills are simulated, and results compare to equal-weight buy-and-hold plus the selected market index.
- Warm-up is derived per strategy; defaults enforce at least 756 OOS sessions across six windows before a `prometteuse` verdict can be considered.
- Bonferroni multiple-testing threshold across the global 50-strategy catalogue (43 per-symbol plus seven portfolio strategies), Newey-West daily paired-excess-return statistic, positive-fold consistency, and a second cost-stress simulation with doubled fees/slippage are included.
- The research-only selection preview always remains 100% cash. The scoreboard includes a Pearson correlation matrix between strategy-level OOS daily returns on common dates; this does not validate underlying asset/sector concentration, liquidity or combined portfolio risk. Any candidate remains unallocated and inactive pending these reviews and Paper gates.
- Added checks for synchronized and timezone-aware strictly increasing bars, nonnegative volumes, normalized symbol duplicates, and explicit benchmark alignment. Corrected a Multi-Factor evidence timestamp and double-counting in displayed trade returns.
- Local verification at that increment: **696 passed, 11 skipped, 202 subtests passed**, compileall passed; 22 focused scoreboard/backtest/API/PIT tests passed. A 1,100-bar pseudo-random synthetic smoke run returned six evaluated strategies and one synthetic candidate; the preview remained 100% cash and `capital_authorized=false`. This is not market-performance evidence.
- No real OHLCV profitability assessment, PostgreSQL/Neon test, Alpaca Paper authentication/order, frontend npm build, browser test, or deployment was completed. Live remains locked; research route cannot submit or stage orders.

## Next engineering sequence

1. Run the portfolio and 43 single-symbol scoreboards on real, authenticated and corporate-action-adjusted historical data across multiple universes; audit survivorship, look-ahead, liquidity, spread and sector concentration.
2. Add a research-only selection policy with an explicit cash fallback and sector/asset/risk caps; it must not feed the broker until all operational gates pass.
3. Complete numeric parity tests of V1/V2 features on identical OHLCV fixtures and attribute performance by asset and market regime.
4. Complete React/TypeScript/PWA build and connect a read-only research dashboard.
5. Run PostgreSQL test/restore concurrency and recovery, then real Alpaca Paper read-only/lifecycle validation; keep any one-order Paper smoke separate and explicitly authorized.

## Increment 2026-11-13 — Phase 8 inbox retry hardening and guarded worker

- Added `next_attempt_at` and capped exponential backoff to prevent immediate retry loops during broker/database outages.
- Added terminal `dead_letter` state after a configurable maximum attempt count (default 8).
- Added `scripts/run_broker_event_worker.py`, a graceful-stop CLI worker. It refuses SIM mode, SQLite, missing credentials and non-Paper Alpaca endpoints. It performs reconciliation only; it never submits orders.
- Added tests for backoff, no immediate retry, dead-letter cutoff and worker environment guards.
- Local verification: see final test counts below; SQLite Alembic upgrade/downgrade/re-upgrade passed.
- The worker has not been deployed. No Alpaca websocket/event receiver is connected yet. No PostgreSQL server or authenticated Alpaca Paper stream/order was used.


## Increment 2026-11-13 — Alpaca Paper WebSocket receiver and periodic reconciliation

- Added `services/alpaca_trade_updates.py` and `scripts/run_alpaca_trade_updates_listener.py` for the documented Paper `trade_updates` stream, stable event IDs, strict Paper endpoint guard, and durable inbox insertion.
- Added independent periodic full reconciliation to `scripts/run_broker_event_worker.py`; notification delivery is no longer the only trigger for broker snapshots. Truncated/incomplete snapshots are rejected.
- Added `websocket-client` runtime dependency.
- Latest local verification: **489 pytest passed, 7 skipped, 88 subtests passed; 485 unittest passed; compileall passed**.
- No authenticated Alpaca connection, PostgreSQL server, actual stream, or deployed worker was available in this runtime.


## Increment 2026-11-14 — Faster recovery after periodic reconciliation failures

- The independent periodic reconciliation in `scripts/run_broker_event_worker.py` now retries failures with capped exponential backoff instead of waiting the full normal interval after each failure.
- Default schedule: immediate at startup; after failures 5s, 10s, 20s, 40s, then 60s capped; after success, normal 300s interval resumes. Bounds are configurable through CLI flags.
- The worker remains read-only for broker reconciliation and cannot submit orders. This does not implement the global system-state machine or certify a trading authorization gate.
- Added `PHASE8-WORKER-RECONCILIATION-RETRY.md` and unit tests for progression, cap, interval ceiling and invalid settings.
- Verification: 492 pytest passed, 7 skipped, 92 subtests; 488 unittest passed; compileall, shell syntax and workflow YAML checks passed.
- Real PostgreSQL and authenticated Alpaca Paper validation remain outstanding.


## Increment 2026-11-15 — durable order-notional validation

- Added shared Decimal-based finite-positive validation to both order-intent persistence entry points.
- Rejects booleans, NaN, infinities, zero/negative and malformed notionals before persistence, including sell-side atomic intents.
- Validates nonblank client IDs and symbols; persists the normalized Decimal.
- Regression tests added for malformed and non-finite inputs.
- Latest local verification: **566 pytest passed, 11 skipped, 187 subtests passed; 562 unittest passed; compileall passed**.
- PostgreSQL 16 concurrency and backup/restore remain unexecuted; Alpaca Paper remains unconnected.


## Increment 2026-11-18 — Phase 10 React/PWA start

- Created a React + TypeScript + Vite responsive frontend with read-only account, positions, risk, open orders and activity panels.
- Added PWA manifest, 192/512 icons and a service worker that never caches API responses.
- Added conditional FastAPI serving of the compiled frontend while preserving the legacy HTML dashboard until `frontend/dist` exists.
- Preserved session-cookie authentication and same-origin API calls; no order execution controls are present.
- Backend regression suite: **614 passed, 11 skipped, 202 subtests passed**. Python compile/import and conditional static-route smoke checks passed.
- npm dependency installation exceeded the available execution window; frontend typecheck/build and real-browser validation remain pending.


## Increment 2026-11-18 — Phase 10 dashboard reliability (Audit 8)

- Risk UI now fails closed for missing/unknown institutional status; zero or missing daily return is no longer colored as a positive result.
- Failed dashboard refresh clears stale account/risk/order values, and an in-flight guard prevents overlapping refresh batches.
- Order panel accurately describes the backend's bounded 20-most-recent-order response rather than implying complete open-order coverage.
- Added three frontend contract tests.
- Latest recovered-copy validation: **624 passed, 11 skipped, 202 subtests passed**; `compileall` passed. Frontend typecheck/build and browser checks remain pending because dependencies are not installed.
- PostgreSQL integration, real Neon read-only verification and Alpaca Paper read-only verification remain outstanding. No broker orders were sent; Live remains locked.


## Increment 2026-11-18 — PostgreSQL backup/restore verification strengthened

- Replaced the restore check that only looked for four table names with `scripts/verify_postgres_restore.py`.
- The new read-only verifier compares every public table name, every table row count, and the Alembic revision between the disposable `_test` source and `_restore` target.
- It rejects remote database hosts before connecting; a negative guard check confirmed the refusal.
- Local verification after the change: shell syntax check, Python compilation, **624 pytest passed, 11 skipped, 202 subtests passed**.
- Actual PostgreSQL migration/backup/restore remains unexecuted in this runtime; the CI workflow must run against its isolated PostgreSQL service to establish that evidence.


## Increment 2026-11-23 — Multi-Factor point-in-time fundamentals

- Portfolio Multi-Factor backtests and the walk-forward scoreboard now require per-symbol historical fundamental snapshots with timezone-aware `available_at` timestamps. The latest snapshot is applied only from its actual public-availability time forward. Static current fundamentals are rejected for historical simulation.
- Without snapshots, the scoreboard returns the strategy row with `evaluated=false` and `blocked_by=point_in_time_fundamentals_missing`; it is not silently treated as a failing or profitable strategy. The Bonferroni family remains the full 50-strategy catalogue; `evaluated_count` is exposed separately.
- The input contract rejects missing symbols, unknown fields, unsorted/duplicate timestamps, naive datetimes, nonnumeric/boolean/nonfinite factors, and empty snapshots. The API returns HTTP 422 when a Multi-Factor backtest lacks the required snapshots.
- Added point-in-time causal tests for fills only after availability and tests for missing/invalid snapshots. Full local suite at that increment: **696 passed, 11 skipped, 202 subtests passed**, 2 FastAPI deprecation warnings; 22 focused tests passed. Compileall and service-worker syntax checks passed.
- Limitation: the caller/provider must supply a verified public publication timestamp and point-in-time values; the runtime does not independently certify third-party data provenance.


## Increment 2026-11-23 — global multiple-testing correction

- The 43 per-symbol rules and seven portfolio strategies belong to one 50-hypothesis research family. Both scoreboards now use the two-sided Bonferroni threshold for all 50 strategies, instead of correcting only within their separate display tables.
- Each response distinguishes the family size (50), the strategy count shown by that scoreboard (43 or 7), and the number actually evaluated (for portfolio strategies, Multi-Factor remains blocked without PIT fundamentals).
- Regression tests confirm the global family size and the corresponding threshold in both scoreboards and HTTP routes.

## Increment 2026-11-23 — single-symbol OOS scoreboard HAC and sample integrity

- The 43-rule scoreboard now evaluates the equal-initial-capital sleeve portfolio across the selected symbols. Strategy verdicts use Newey-West HAC on daily portfolio excess returns versus the equal-capital buy-and-hold benchmark (five lags); the old trade-return t-stat remains descriptive only.
- OOS trade expectancy/count includes only trades with explicit entry and exit indices both at or after the split. Positions carried into OOS still contribute to daily marked-to-market portfolio returns, but are not falsely counted as wholly OOS trades.
- All symbol histories and benchmarks must share exactly the same timezone-aware, strictly increasing timestamps. Missing, unsynchronised or malformed benchmark histories are rejected. Invalid split/alpha/cost settings are rejected.
- Global Bonferroni correction remains across all 50 catalogue hypotheses, not only the 43 visible single-symbol rules.
- Local verification: **702 passed, 11 skipped, 202 subtests passed**; 31 focused research/backtest/API tests passed; `compileall` and service-worker syntax checks passed. Two historical FastAPI lifespan deprecation warnings remain.
- These are software tests only; no real-market profitability inference is made. PostgreSQL/Neon, authenticated Alpaca Paper, React build and browser checks remain open. Live remains locked.

