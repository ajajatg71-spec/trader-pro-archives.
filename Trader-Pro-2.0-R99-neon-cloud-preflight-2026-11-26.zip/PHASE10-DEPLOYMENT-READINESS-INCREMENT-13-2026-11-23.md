# Trader Pro 2.0 — R34 : isolation du stockage runtime
Date : 23 novembre 2026

## Changement de sécurité
L'audit a révélé que R33 attribuait tout `/app` à l'utilisateur non privilégié. Cela permettait au processus applicatif d'écrire aussi dans le code et les dépendances du conteneur. R34 corrige ce point :
- le code et le frontend compilé restent détenus par root et non modifiables par l'utilisateur applicatif ;
- seul `/var/lib/trader-pro` est attribué à UID/GID 10001 ;
- `TRADER_STATE_DIR` dirige `state.json`, `history.jsonl` et `backups/` vers ce répertoire ;
- le service d'état utilise désormais le même répertoire de sauvegarde lors de la récupération ;
- le backup automatique utilise les chemins réels du service d'état ;
- les tests statiques Docker ont été ajustés pour interdire le retour à un `/app` entièrement modifiable.

## Validation exécutée sur l'archive R34
- `BROKER=sim pytest -q` : **778 passed, 11 skipped, 202 subtests passed**.
- `python -m compileall -q .` : réussi.
- `node --check frontend/public/sw.js` : réussi.
- `frontend/public/manifest.webmanifest` : JSON valide.
- Les 11 tests PostgreSQL restent ignorés sans URL de base jetable et consentement explicite.

## Limites
- `npm install --package-lock-only` n'a pas pu finir : le registre npm ne répond pas dans cet environnement. Aucun lockfile n'a été fabriqué.
- Docker/Podman ne sont pas disponibles ici ; aucune image n'a été construite ou démarrée.
- PostgreSQL réel, sauvegarde/restauration, Alpaca Paper et HTTPS distant non validés.
- Deux avertissements FastAPI signalent encore l'usage de `@app.on_event("startup")`.
- Aucun ordre réel envoyé ; Live reste verrouillé.

## Décision
R34 réduit les privilèges du runtime et sépare strictement code et données persistantes. C'est un candidat plus sûr, non un déploiement certifié.
