# Trader Pro 2.0 — R33 : durcissement du conteneur
Date : 23 novembre 2026

## Changement
Le conteneur runtime Python est désormais exécuté avec l'utilisateur non privilégié UID/GID 10001 au lieu de root. Les fichiers du projet et le frontend compilé sont copiés avec le propriétaire runtime approprié. Le répertoire applicatif reste accessible en écriture à cet utilisateur pour préserver le contrat historique `state.json`, `history.jsonl` et `backups/`.

Trois tests de garde Docker ont été ajoutés et le test existant de présence/copie du frontend a été ajusté pour vérifier le `COPY --chown`.

## Résultats exécutés sur R33
- `BROKER=sim pytest -q` : **777 passed, 11 skipped, 202 subtests passed**.
- `python -m compileall -q .` : réussi.
- `node --check frontend/public/sw.js` : réussi.
- JSON de `frontend/public/manifest.webmanifest` : valide.
- Archive ZIP : intégrité vérifiée.

## Limites non levées
- Build React non exécuté : `npm install --package-lock-only` échoue avec `EAI_AGAIN` vers `registry.npmjs.org`; le lockfile n'est pas présent.
- Docker/Podman absents : l'image n'a pas été construite ni démarrée.
- Les 11 tests ignorés n'ont pas été exécutés faute des services/environnements externes requis.
- PostgreSQL réel, restauration, Neon, Alpaca Paper et HTTPS distant non validés.
- Aucun ordre n'a été envoyé. Mode Live verrouillé.

## Décision
R33 améliore la sécurité d'exécution du conteneur, mais reste un candidat de livraison. Ne pas annoncer la production avant les validations manquantes.
