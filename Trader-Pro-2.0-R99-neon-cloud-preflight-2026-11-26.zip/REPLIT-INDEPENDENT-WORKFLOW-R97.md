# Trader Pro 2.0 — continuité sans Replit (R97)

## Objectif

Continuer le développement pendant une indisponibilité de Replit sans créer de copie concurrente ni modifier la base Neon de test. Le ZIP R97 est un paquet source autonome issu de R96. Il ne synchronise pas automatiquement le workspace Replit.

## Parcours recommandé sur Windows 10/11

Prérequis : Python 3.11 ou 3.12, PowerShell et, pour la validation PostgreSQL, Docker Desktop avec Compose v2.

1. Extraire l’archive dans un dossier local, par exemple `C:\Trader-Pro-2.0`.
2. Ouvrir PowerShell dans ce dossier.
3. Préparer l’environnement et lancer les tests hors base :

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\prepare_windows_validation.ps1
```

4. Pour exécuter les tests PostgreSQL réels sur un PostgreSQL 16 jetable, migrations, sauvegarde et restauration incluses :

```powershell
.\scripts\prepare_windows_validation.ps1 -RunPostgres
```

Le script utilise `compose.test.yaml`, publie PostgreSQL uniquement sur `127.0.0.1:55432`, stocke les données de test en mémoire temporaire et détruit le conteneur de test à la fin. Il n’utilise jamais Neon pour les tests destructifs.

## Connexion SQLAlchemy directe à Neon — lecture seule

Après préparation de `.venv`, lancer :

```powershell
.\scripts\run_neon_readonly_preflight.ps1
```

La saisie de l’URL est masquée. L’URL doit viser exclusivement la base `trader_pro_test`, sur un hôte `*.neon.tech`, avec `sslmode=require` ou plus strict. Elle n’est ni affichée ni enregistrée par le script. Le précontrôle exécute `SET TRANSACTION READ ONLY` et n’effectue aucune écriture ou migration. Ne jamais utiliser l’URL de `neondb` ou `trader_pro_restore`.

Le raccourci combiné est :

```powershell
.\scripts\prepare_windows_validation.ps1 -RunNeonReadOnly
```

## Alternative cloud à Replit : GitHub Actions

Le workflow `.github/workflows/postgres-integration.yml` existe déjà dans le projet. Il démarre PostgreSQL 16 éphémère, exécute les migrations, les 11 tests PostgreSQL, la suite complète et un cycle backup/restore. Le workflow `windows-tests.yml` vérifie la compatibilité Windows.

Pour l’utiliser, le code doit être poussé dans un dépôt GitHub privé contrôlé par le propriétaire du projet. Dans cette session, le connecteur GitHub ne retourne actuellement aucun dépôt accessible pour le compte connecté et ne propose pas de création de dépôt ; aucun push ni lancement CI n’a donc été effectué. Ne pas téléverser `.env`, des clés Alpaca, une URL Neon ou un autre secret dans le dépôt.

## Alpaca Paper

Le contrôle lecture seule peut être lancé séparément après configuration locale des clés Paper. Le test d’ordre/annulation reste strictement opt-in, nécessite une confirmation explicite et ne doit jamais utiliser des clés Live. Aucun ordre n’est envoyé par les scripts de préparation Windows ou PostgreSQL.

## Règles de continuité

- Le ZIP R97 est une branche de travail locale issue de R96 ; le projet Replit d’origine reste intact.
- Ne pas importer automatiquement R97 dans Replit à la fin du quota : comparer les changements avant synchronisation.
- Ne pas appliquer de migration à Neon pendant les tests PostgreSQL locaux.
- Ne pas utiliser les tests destructifs sur une base distante.
- Conserver `system_safety_state=RECONCILING` tant que les validations applicatives et broker ne sont pas complètes.
