# Trader Pro 2.0 — R47

## Objet
Correction du calcul hors échantillon dans `research_v1/backtesting/walk_forward.py`.

## Changements
- Le rendement OOS commence désormais à la valeur du portefeuille à la clôture précédant la première séance de test. Le premier jour OOS, y compris son exécution à l'ouverture et son mark-to-market à la clôture, est ainsi comptabilisé.
- Ajout de métriques calculées strictement sur la courbe OOS de chaque fenêtre : rendement total, CAGR annualisé, drawdown maximal, Sharpe, volatilité annualisée et capital initial/final.
- Les fenêtres OOS qui se chevauchent sont désormais refusées (`step_bars` doit être égal à `test_bars`) afin d'éviter de compter plusieurs fois les mêmes séances dans les statistiques agrégées.
- Ajout de tests ciblés sur l'inclusion du premier jour OOS et le refus des fenêtres chevauchantes.

## Validation locale
- `BROKER=sim pytest -q` : **798 passed, 11 skipped, 202 subtests passed**.
- `BROKER=sim python -m unittest discover -q` : **716 tests OK**.
- `python -m compileall -q .` : OK.
- `node --check frontend/public/sw.js` : OK.
- JSON des manifestes : OK.
- Archive ZIP : intégrité contrôlée après création.

## Limites et sécurité
- Les fenêtres restent des diagnostics indépendants qui repartent du capital initial ; ce n'est pas encore une simulation de portefeuille continu avec réoptimisation et transfert des positions entre fenêtres.
- Les résultats dépendent des données historiques et des hypothèses de coûts fournies.
- Aucun accès broker, aucun ordre, aucune activation de stratégie ni autorisation de capital.
- Les 11 tests ignorés nécessitent un PostgreSQL externe. Neon/PostgreSQL réel, Alpaca Paper, build Docker et build frontend TypeScript ne sont pas certifiés par ce lot.
- Aucun résultat ne démontre une rentabilité.

## Compatibilité
R47 est un candidat dérivé de R46. Les archives précédentes ne sont pas écrasées.
