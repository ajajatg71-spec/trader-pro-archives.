# Phase 3 — démarrer PostgreSQL en local

Cette procédure prépare PostgreSQL 16 dans un conteneur Docker avec un volume persistant. Elle ne démarre aucun compte de courtage et ne passe aucun ordre.

## Prérequis
- Docker Desktop installé et démarré (Windows/macOS) ou Docker Engine + Compose (Linux).
- Python et les dépendances du projet installées.

## Démarrage
1. Copier `.env.example` vers `.env`.
2. Remplacer `POSTGRES_PASSWORD` et `APP_PASSWORD` par des mots de passe longs et uniques. Reporter le mot de passe PostgreSQL dans `DATABASE_URL` (encoder les caractères spéciaux URL).
3. Installer les dépendances : `pip install -r requirements.txt`.
4. Démarrer PostgreSQL : `docker compose up -d postgres` (ou `./scripts/start_postgres.sh`).
5. Vérifier : `docker compose ps` et `docker compose exec postgres pg_isready -U trader_pro -d trader_pro`.
6. Appliquer la migration : `alembic upgrade head`.
7. Vérifier l'état : `alembic current`.

## Arrêt et persistance
- Arrêt sans perte des données : `docker compose down`.
- Ne pas exécuter `docker compose down -v` sauf si la suppression définitive de la base est voulue.
- Sauvegarde : `./scripts/backup_postgres.sh` après configuration des variables PostgreSQL requises.

## Portée et limites
Le conteneur PostgreSQL est isolé et son port est publié uniquement sur `127.0.0.1`. La base n'est pas encore la source d'autorité de toutes les données de l'application : les services JSON historiques ne sont pas tous remplacés. La phase 3 ne sera close qu'après tests d'intégration PostgreSQL, migration JSON contrôlée, réconciliation des enregistrements et restauration réelle d'une sauvegarde.


## Tests d'intégration PostgreSQL dédiés

Après avoir démarré le conteneur, crée deux bases jetables séparées :

```bash
docker compose exec -T postgres psql -U trader_pro -d postgres -c "CREATE DATABASE trader_pro_test"
docker compose exec -T postgres psql -U trader_pro -d postgres -c "CREATE DATABASE trader_pro_restore"
set -a; . ./.env; set +a
bash scripts/verify_postgres.sh
```

La base `_restore` doit être vide. Le script refuse de restaurer si elle contient déjà des tables publiques. Ne jamais réutiliser une base de production. Voir `PHASE7-REAL-ENVIRONMENT-TEST-HARNESS.md` pour le workflow GitHub Actions et le contrôle Alpaca Paper séparé.
