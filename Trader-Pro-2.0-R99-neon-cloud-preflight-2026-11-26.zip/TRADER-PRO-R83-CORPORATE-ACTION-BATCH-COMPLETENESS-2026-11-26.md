# Trader Pro 2.0 — R83 : enveloppe de complétude des lots corporate actions

Base : R82.

## Modifications
- Ajout de `CorporateActionBatch`, enveloppe immuable qui conserve l'univers demandé, la période, la date de récupération, la source, le nombre de pages et l'état de pagination.
- Un lot incomplet ou dont les événements débordent de l'univers/source demandés est rejeté.
- La complétude de pagination est déclarée explicitement ; elle n'est jamais supposée à partir du nombre de résultats.

## Validation
- 6 tests ciblés ajoutés ; suite complète à exécuter au jalon R90.

## Limites
- Un lot complet au sens pagination ne garantit pas l'exhaustivité métier du fournisseur.
