# Trader Pro 2.0 — R53
## Phase 9 — Reprise segmentée du simulateur
Date : 23 novembre 2026

### Implémentation
Le simulateur `research_v1/backtesting/portfolio_backtest.py` accepte maintenant :
- `start_index` et `end_index` pour traiter un segment chronologique ;
- un `PortfolioState` ou son dictionnaire sérialisé pour reprendre un portefeuille ;
- la restauration du cash, des positions et des intentions en attente ;
- la conservation du dernier index, timestamp et niveau de capital ;
- la restitution d'un nouvel état versionné après chaque segment.

La stratégie reçoit toujours les données historiques complètes pour calculer ses indicateurs de façon causale, mais la boucle financière ne traite que les barres du segment demandé. Les intentions de la clôture du segment précédent sont exécutées à l'ouverture du premier jour du segment suivant, conformément au contrat temporel existant.

Les appels segmentés omettent volontairement le benchmark passif, car le benchmark historique actuel n'a pas encore son propre état de reprise. Le benchmark reste calculé pour un appel monolithique classique.

### Tests ajoutés
- Équivalence exacte de la courbe de capital monolithique et de deux segments consécutifs.
- Égalité de l'état final : cash, positions, intentions pendantes, fills et transactions clôturées.
- Rejet d'une reprise sans état.
- Rejet d'un index d'état qui ne précède pas immédiatement le segment.

### Résultats
- pytest complet : 808 passed, 11 skipped, 202 subtests passed.
- Tests ciblés état + simulateur : 16 passed.
- compileall : exit 0.
- Archive ZIP : intégrité vérifiée.

### Limites restantes
- Le walk-forward n'utilise pas encore ce mode continu : il reste indépendant par fenêtre et remet le capital à zéro.
- Le changement de paramètres entre segments n'a pas encore de test dédié ; l'API accepte un nouveau `params` mais il faut vérifier les transitions avec positions ouvertes.
- Le benchmark passif n'est pas repris entre segments.
- Les compteurs cumulatifs de frais/slippage de `PortfolioState` sont des champs de schéma, pas encore alimentés par le simulateur.
- Les métriques par segment ne constituent pas encore un rapport OOS continu agrégé.
- Aucun broker, ordre réel, ni allocation de capital n'est autorisé.

### Sécurité
Aucun accès broker. `orders_created=0`. Recherche/backtest uniquement. PostgreSQL/Neon et Alpaca Paper restent à valider séparément. Live reste verrouillé.
