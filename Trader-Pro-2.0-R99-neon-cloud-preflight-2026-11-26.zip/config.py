import os
BASE = os.getenv("ALPACA_BASE_URL", "https://paper-api.alpaca.markets")
KEY = os.getenv("APCA_API_KEY_ID", "")
SECRET = os.getenv("APCA_API_SECRET_KEY", "")
APP_PASSWORD = os.getenv("APP_PASSWORD", "")
LIMITS = {"buffer": 10.0, "cap": 25.0, "max_order": 1500.0,
          "max_pos": 25.0, "min_cash": 10.0, "band": 5.0, "max_daily_loss": 3.0, "max_drawdown": 10.0,
          "max_positions": 12.0, "max_gross": 90.0, "max_order_pct": 25.0, "max_orders_day": 20.0, "max_weekly_loss": 6.0,
          "stop_loss_pct": 8.0, "trailing_pct": 12.0, "take_profit_pct": 0.0, "risk_per_trade": 1.0, "stop_k": 2.0,
          "min_price": 5.0, "regime_filter": 1.0}
STRAT = {"enabled": False, "auto_execute": False, "watchlist": [], "scan_minutes": 60, "rebalance_days": 7, "trade_amount": 500.0}
FEE_PCT = float(os.getenv("FEE_PCT", "0"))   # frais en % du montant (0 = sans commission)
FEE_MIN = float(os.getenv("FEE_MIN", "0"))   # frais minimum par ordre ($)
TOTP_SECRET = os.getenv("TOTP_SECRET", "")   # active la double authentification (voir make_totp.py)
# Fail-safe broker selection: simulation is the default. Alpaca is selected only
# when the operator explicitly opts in with BROKER=alpaca. Unknown values stop
# startup instead of silently selecting a network-connected broker.
BROKER_MODE = os.getenv("BROKER", "sim").strip().lower()
if BROKER_MODE not in {"sim", "alpaca"}:
    raise SystemExit("BROKER invalide : valeurs autorisées 'sim' ou 'alpaca'.")
SIM = BROKER_MODE == "sim"  # Le simulateur reste le choix par défaut, sans clés ni réseau.
