"""User-selected trading mandate; policy declaration only, never an execution switch.

The mandate describes the intended operating policy. Broker execution remains
independently gated by deployment mode, credentials, risk approval and the
explicit live-release process.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class TradingMandate:
    autonomy: str = "full_within_risk_limits"
    allow_margin: bool = False
    allow_borrowed_funds: bool = False
    require_risk_governor: bool = True
    fail_closed_on_unknown_buying_power: bool = True
    allowed_asset_classes: tuple[str, ...] = ("us_equity",)
    allow_options: bool = False
    allow_crypto: bool = False
    allow_forex: bool = False
    allow_futures: bool = False

    def validate(self) -> None:
        if self.autonomy != "full_within_risk_limits":
            raise ValueError("Autonomie non conforme au mandat utilisateur.")
        if self.allow_margin or self.allow_borrowed_funds:
            raise ValueError("Le mandat interdit marge et fonds empruntés.")
        if self.allowed_asset_classes != ("us_equity",):
            raise ValueError("Univers autorisé limité aux actions et ETF classés us_equity par le broker.")
        if any((self.allow_options, self.allow_crypto, self.allow_forex, self.allow_futures)):
            raise ValueError("Options, crypto, Forex et futures sont interdits dans le périmètre initial.")
        if not self.require_risk_governor or not self.fail_closed_on_unknown_buying_power:
            raise ValueError("Le Risk Governor et le contrôle fail-closed sont obligatoires.")

    def order_funding_allowed(self, *, order_notional: float, available_cash: float,
                              buying_power_known: bool = True) -> bool:
        """Allow only orders fully covered by known available cash."""
        self.validate()
        if not buying_power_known:
            return False
        try:
            notional = float(order_notional)
            cash = float(available_cash)
        except (TypeError, ValueError):
            return False
        if not (notional > 0 and cash >= 0):
            return False
        return notional <= cash


    def instrument_allowed(self, *, asset_class: str | None, tradable: bool = True,
                            active: bool = True) -> bool:
        """Fail-closed allowlist for the initial stocks/ETFs universe.

        `asset_class` must come from trusted broker instrument metadata, not
        from a user-provided symbol suffix or strategy label.
        """
        self.validate()
        if not tradable or not active or not isinstance(asset_class, str):
            return False
        normalized = asset_class.strip().lower()
        return normalized in self.allowed_asset_classes


DEFAULT_TRADING_MANDATE = TradingMandate()
DEFAULT_TRADING_MANDATE.validate()
