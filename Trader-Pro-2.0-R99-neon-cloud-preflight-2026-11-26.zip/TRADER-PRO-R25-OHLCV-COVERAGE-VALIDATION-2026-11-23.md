# Trader Pro 2.0 — R25 — Contrôle de couverture OHLCV

Date : 2026-11-23
Base : R24 (candidat local)

## Changement

Ajout de `inspect_ohlcv_daily_bar_coverage` dans `services/market_data.py`.
La fonction réutilise le calendrier boursier déjà utilisé par le contrôle
`DailyBars`, mais accepte désormais `OHLCVDailyBars` et vérifie que chaque
bougie possède un horodatage. Elle rapporte les séances attendues, observées
et manquantes. Un seuil `max_missing_sessions` permet un rejet fail-closed.

Aucune bougie n'est créée, interpolée ou corrigée. Le contrôle reste
explicitement opt-in : les suspensions de cotation, changements de symbole,
jours fériés propres au marché et conventions du fournisseur doivent être
pris en compte par l'appelant via le calendrier approprié.

## Tests

- Tests ciblés OHLCV : 13 réussis.
- Suite complète : 753 réussis, 11 ignorés, 202 sous-tests réussis.
- Les 11 ignorés sont les tests qui nécessitent un PostgreSQL externe.
- Compilation Python (`compileall`) réussie.
- Deux avertissements FastAPI existants liés à `on_event` déprécié.
- Suite exécutée avec `BROKER=sim` ; aucun ordre réel envoyé.

## Limites non levées

- Pas de validation Neon/PostgreSQL réel dans cette exécution.
- Pas de test Alpaca Paper authentifié ni d'ordre Paper soumis.
- Pas de certification du build React/PWA.
- Ce contrôle de couverture ne prouve pas l'exactitude des prix ni la qualité
  fondamentale de la source ; il détecte seulement les séances manquantes
  selon le calendrier fourni.
- Live reste verrouillé.
