# Trader Pro 2.0 — démarrage de l'environnement Windows

Ce parcours prépare un environnement Python isolé et peut lancer PostgreSQL 16 dans un conteneur jetable. Il ne configure aucune clé de courtier et n'envoie aucun ordre.

## Prérequis

- Windows 10/11 64 bits.
- Python 3.11 ou 3.12 (le lanceur `py` est recommandé).
- Connexion Internet pour installer les dépendances Python.
- Pour le test PostgreSQL local : Docker Desktop démarré avec Docker Compose v2.

## Préparer et valider la suite locale

Depuis PowerShell, dans le dossier `trader_pro_resume` :

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\prepare_windows_validation.ps1
```

Le script crée `.venv`, installe `requirements-dev.txt`, compile le projet et exécute pytest et unittest. Les secrets ne sont ni demandés ni écrits.

## Ajouter le vrai PostgreSQL 16

```powershell
.\scripts\prepare_windows_validation.ps1 -RunPostgres
```

Le script démarre le service isolé défini dans `compose.test.yaml`, applique toutes les migrations, exécute les tests d'intégration PostgreSQL puis la suite complète. Le conteneur et son volume temporaire sont supprimés à la fin, même en cas d'échec. Il ne faut pas réutiliser ce compose pour des données réelles.

## Si Docker Desktop n'est pas disponible

Utiliser le workflow GitHub Actions `.github/workflows/postgres-integration.yml` sur un dépôt privé ou public contrôlé. Il démarre un service PostgreSQL 16 jetable et exécute les migrations, tests d'intégration, sauvegarde et restauration. Le workflow Windows `.github/workflows/windows-tests.yml` vérifie séparément la compatibilité Windows.

## Alpaca Paper

Commencer uniquement par le contrôle lecture seule : `.github/workflows/alpaca-paper-readonly.yml` ou `scripts/verify_alpaca_paper_readonly.py`. Il exige des clés Paper, vérifie l'URL officielle Paper et ne soumet/modifie/annule aucun ordre.

Le test d'ordre/annulation est séparé (`alpaca-paper-smoke.yml`) et exige une confirmation textuelle exacte. Il n'est pas exécuté par les scripts de préparation Windows ou PostgreSQL. Ne fournir que des clés Paper dédiées, jamais des clés Live.

## Critères de validation

Ne déclarer PostgreSQL validé qu'après succès des migrations et tests contre PostgreSQL 16 réel, puis vérification de sauvegarde/restauration. Ne déclarer Alpaca Paper validé qu'après un contrôle authentifié réussi. Les tests simulés ou SQLite ne remplacent pas ces preuves.
