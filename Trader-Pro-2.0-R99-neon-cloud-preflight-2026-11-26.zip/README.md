# Trader Pro 2.0 — application complète (source candidate)

Trader Pro 2.0 est une application FastAPI avec moteur de portefeuille, stratégies, gestion du risque, persistance PostgreSQL/Alembic, réconciliation courtier et interface web React/TypeScript en cours de finalisation.

> **État de livraison au 18 novembre 2026 :** le présent paquet contient le code applicatif, les tests, les migrations, les scripts d'exploitation et la source de la PWA. La suite Python passe localement (**624 réussis, 11 ignorés, 202 sous-tests**). Le build React/Vite n'est pas encore certifié : l'accès au registre npm a échoué par résolution DNS dans l'environnement de validation. PostgreSQL réel, Neon et Alpaca Paper restent à valider. Ce paquet est une livraison de code source testée partiellement, pas une application déployée ni une autorisation de trading réel.

## Démarrage local sans courtier (simulation)

Prérequis : Python 3.11+ et pip.

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell : .venv\Scripts\Activate.ps1
pip install -r requirements.txt
pip install -r requirements-dev.txt
```

Lancer le serveur en simulation, sans clés Alpaca (mode par défaut, même si `BROKER` est absent) :

```bash
# Linux/macOS
APP_PASSWORD='change-this-local-password' uvicorn app:app --host 127.0.0.1 --port 8000
# Windows PowerShell
$env:APP_PASSWORD='change-this-local-password'; uvicorn app:app --host 127.0.0.1 --port 8000
```

Ouvrir `http://127.0.0.1:8000` et utiliser le mot de passe local choisi. Les prix du simulateur sont synthétiques : ils servent à vérifier le parcours applicatif, jamais à estimer une performance financière.

## Vérifications locales

```bash
python -m pytest -q -rs
python -m compileall -q .
```

Les tests PostgreSQL qui sont ignorés faute de serveur/URL doivent être exécutés séparément sur une base locale jetable. Ne jamais utiliser la base Neon persistante pour les tests destructifs.

## Interface React / PWA

Prérequis : Node.js 20.19+.

```bash
cd frontend
npm install
npm run typecheck
npm run build
```

Le build produit `frontend/dist`; FastAPI sert alors la PWA compilée. Tant que `dist/index.html` n'existe pas, le serveur conserve l'ancien tableau de bord HTML. L'interface React livrée est volontairement en lecture seule pour les actions de trading. La présence des fichiers source ne signifie pas que le build ou l'installation mobile ont été validés.

## Déploiement Docker

Voir `DEPLOY.md` et `.env.example`. Le service applicatif Compose est configuré pour Alpaca Paper uniquement, avec PostgreSQL sain comme dépendance, volume d'état persistant, système de fichiers racine en lecture seule et écoute locale derrière un reverse proxy HTTPS. Les migrations restent une étape manuelle explicite. Le build Docker exige `frontend/package-lock.json` ; le script `scripts/prepare_frontend_build.sh` et le workflow `.github/workflows/frontend-docker-build.yml` préparent sa génération et sa validation sur un runner disposant d'un accès npm.

## PostgreSQL et Alpaca Paper

PostgreSQL est la cible de persistance durable. Les migrations ne sont pas exécutées automatiquement au démarrage. Suivre `PHASE3-POSTGRES-VALIDATION.md` et `scripts/verify_postgres.sh` uniquement avec deux bases locales jetables distinctes (`*_test` et `*_restore`) et l'opt-in explicite `TRADER_PRO_TEST_DATABASE_DISPOSABLE=YES`.

Les contrôles `scripts/verify_postgres_readonly.py` et `scripts/verify_alpaca_paper_readonly.py` sont des vérifications en lecture seule. Les secrets doivent être injectés dans l'environnement local sécurisé ou dans les secrets d'une CI, jamais ajoutés au dépôt, à l'archive ou au chat. Le workflow Paper avec ordre de test est distinct et nécessite une autorisation explicite avant toute exécution.

## Règles de sécurité non négociables

- Mode Live verrouillé ; ne pas tenter de contourner ce verrou.
- Aucun ordre Paper/Live n'est envoyé par les tests de régression ordinaires.
- Pas de retry aveugle après un état `SUBMISSION_UNKNOWN` : réconcilier d'abord avec le courtier.
- Toute proposition doit repasser par les contrôles de risque et le mécanisme d'approbation existant.
- Ne pas modifier les calculs financiers V1 validés sans test de parité dédié.
- Les performances historiques ou simulées ne garantissent aucune rentabilité future.

Voir `TRADER-PRO-2-STATUS.md`, `DEPLOY.md` et les rapports de phase pour les limites connues et les critères de validation.

## Garde-fous
- Mode réel désactivé : seul l’hôte officiel HTTPS `paper-api.alpaca.markets` est accepté. Aucun commutateur `ALLOW_LIVE` ne permet de l’activer.
- Accès par mot de passe, blocage après 5 échecs, HTTPS exigé, en-têtes de sécurité, protection CSRF. Les en-têtes proxy ne sont reconnus que depuis `TRUSTED_PROXY_IPS`; configure cette variable avec les IP/CIDR exacts du reverse proxy.
- Ordres idempotents (pas de doublon), cash réservé par les ordres en cours, revérification du risque à la validation.
- Perte journalière max (3 % par défaut) : au-delà, arrêt d'urgence automatique.
- Historique complet et horodaté dans history.jsonl (consultable via /api/history).
- Alpaca est en dollars. Outil pédagogique, pas un conseil financier.

## Phases 2 et 3 (intelligence et décision) : ce qui est livré
- indicators.py : RSI, MACD, moyennes mobiles. sentiment.py : tonalité des actualités. scoring.py : score 0-100, couverture des données, décision expliquée (acheter / garder / vendre).
- thirteen_f.py : lecture et comparaison des 13F, récupération SEC (définis SEC_USER_AGENT). `POST /api/follow?cik=1067983`.
- congress.py : `POST /api/congress` avec un CSV (date,politician,ticker,type,amount) que tu fournis.
- `GET /api/signals?symbols=AAPL KO` et section « Signaux » du tableau de bord. Les décisions sont enregistrées avec leurs raisons.
- Le moteur **propose, il n'exécute pas** : chaque ordre passe toujours par ton accord.
- Non testés hors ligne : récupération SEC et données de marché Alpaca (lance smoke_test.py puis /api/follow).

## Phase 4 (gestion du portefeuille) : ce qui est livré
- portfolio.py : lots FIFO, gains réalisés et latents nets de frais, performance en %, frais configurables (FEE_PCT, FEE_MIN). `/api/performance`.
- Impôt estimé selon le PFU français : `/api/tax?year=2026&carry=0&rate=31.4` (31,4 % en 2026 = 12,8 % + 18,6 %, moins-values reportables 10 ans). Les fills Alpaca sont en dollars : la déclaration exige une conversion en euros à la date de chaque opération. Estimation, pas un conseil fiscal.
- Alertes de risque (perte journalière, drawdown depuis le plus haut, concentration) et notifications Telegram (TELEGRAM_TOKEN, TELEGRAM_CHAT_ID). Perte ou drawdown au-delà des limites : arrêt d'urgence automatique.
- Planificateur (section « Stratégie automatique ») : analyse de la watchlist et rééquilibrage à intervalles réguliers, pendant l'ouverture de la bourse. Il **propose** ; l'option « exécuter seul » n'existe que sur le compte paper.
- Non testés hors ligne : les appels Alpaca (historique des exécutions) et Telegram.

## Phases 5 et 6 : ce qui est livré
- Tableau de bord refait : 8 pages (accueil avec courbe interactive, opportunités, investisseurs et comparaison, actualités, calendrier des opérations, décisions de l'algorithme, stratégie, risques), page de connexion.
- Connexion par cookie signé (HttpOnly, Secure, SameSite=Strict), double authentification TOTP (TOTP_SECRET), blocage après 5 échecs, révocation de toutes les sessions, alerte Telegram en cas d'échec.
- Journal d'accès : chaque écriture et chaque connexion est enregistrée. Clés masquées dans les journaux.
- Sauvegarde quotidienne automatique (14 conservées), écriture atomique, restauration si le fichier d'état est corrompu.
- `/health` pour la surveillance, `/api/health` détaillé, détection des mouvements inhabituels (z-score, pic de volume).
- Tests de résistance et de reprise : voir tests/test_resilience.py. Déploiement : voir DEPLOY.md (non réalisé depuis ce chat).

## Moteur de backtest
- `backtest.py` : stratégies (achat-conservation, croisement de moyennes, RSI, score technique), exécution à la clôture **suivante**, frais et glissement.
- Les réglages sont choisis sur la première partie de l'historique et jugés sur la seconde (jamais vue). Un écart important entre les deux est signalé comme sur-ajustement.
- `GET /api/backtest?symbol=AAPL&strategy=sma` et page « Backtest » du tableau de bord. Les prix viennent d'Alpaca (non testé hors ligne). Les performances passées ne prédisent pas les futures.

## Mesures de risque (liste complète)
- **Avant chaque ordre** : tickers interdits, taille max d'ordre ($ et % du portefeuille), position max, nombre max de positions, exposition totale max, cash minimum, ordres max par jour, perte journalière max.
- **Surveillance continue** (chaque minute, serveur allumé) : perte journalière, perte hebdomadaire, recul depuis le plus haut (arrêts d'urgence), concentration, stop-loss fixe, stop suiveur, objectif de gain (propositions de vente, exécutées seules uniquement sur le compte paper si l'option est active).
- **Taille de position** selon la volatilité : on ne risque que `risk_per_trade` % du portefeuille pour un recul de `stop_k` écarts-types journaliers.
- **Filtres d'entrée** : pas d'achat si le marché (SPY) est sous sa moyenne 200 jours (`regime_filter`), ni sous `min_price` $, ni si le RSI dépasse 70.
- **Page Risques** : VaR et CVaR 95 %, volatilité annualisée, corrélation moyenne, nombre effectif de positions, bêta, scénarios de chute du marché (-10, -20, -30 %), stops par position.
- **Limites connues** : les stops sont surveillés par le serveur (pas posés chez le courtier) : serveur éteint = pas de protection ; un stop peut s'exécuter plus bas qu'affiché en cas de saut de cours ; VaR et bêta sont des estimations historiques.

## Mode démo sans clés (simulation par défaut)
Lance le vrai serveur avec un courtier simulé (100 000 $ fictifs, prix synthétiques) : `APP_PASSWORD` suffit, aucune clé Alpaca. L’application sélectionne `BROKER=sim` lorsque la variable `BROKER` est absente. Le mode Alpaca ne s’active qu’avec `BROKER=alpaca` explicite ; toute autre valeur provoque un arrêt au démarrage. Le bandeau affiche « simulation ». Utile pour voir tout le circuit (plan, contrôle du risque, validation, ordres, positions, stops, backtest) avant de brancher Alpaca. Les prix sont inventés : ça ne dit rien sur les marchés.

## Backtest réaliste et robustesse
- `realistic=1` applique au backtest les mêmes stops et la même taille de position que le système réel, avec un délai de réentrée après un stop.
- `mc` : bootstrap des trades de la période test (fourchette 5 %-95 %, probabilité de perte).

## Phase 3 — relational database foundation (in progress)

The SQLAlchemy 2.x models and first Alembic migration are in `db/` and `alembic/`.
The initial schema covers strategy configurations, orders, fills, account snapshots,
audit events, and risk events. Financial quantities use fixed-precision `NUMERIC`
columns; `client_order_id` and broker identifiers are unique to support deduplication.

Set `DATABASE_URL` to a PostgreSQL connection string before connecting the application,
then run `alembic upgrade head`. Example:

```text
DATABASE_URL=postgresql+psycopg://trader_pro:change_me@localhost:5432/trader_pro
```

The relational schema is currently additive and is not yet the live source of truth:
legacy JSON state and existing V1 calculations remain untouched. PostgreSQL deployment,
backup/restore, migration rehearsal, data migration, and repository integration must be
validated before switching application reads or writes to the database.

## Phase 2 — modular FastAPI backend (closed 2026-11-10)

`app.py` is the composition root; HTTP endpoints are grouped under `routers/` and application operations are injected through `services/`. Routers now cover dashboard/state/configuration, authentication, history, orders, portfolio, risk, strategy/signals, health, and analytics/backtesting. Shared environment defaults are centralized in `config.py` and deployment variables are listed in `.env.example`.

Phase 2 regression result: `python -m pytest -q` (160 passed), `python -m unittest discover -s tests -q` (156 passed), compilation passed, and a `BROKER=sim` application import registered 31 routes. The original V1 financial calculation modules were preserved byte-for-byte. See `PHASE2-CLOSURE-REPORT.md` for the scope and boundaries.

### Fournisseur secondaire optionnel (Twelve Data)

La source secondaire Twelve Data est facultative et reste inactive par défaut. Pour la préparer, définir `TWELVEDATA_API_KEY` dans l'environnement du serveur. Au redémarrage, l'adaptateur est ajouté après Alpaca dans la chaîne de secours. Ne jamais placer la clé dans le dépôt, le fichier ZIP partagé ou les journaux. Sans cette variable, Alpaca reste l'unique fournisseur réel configuré. L'activation technique ne vaut pas validation commerciale ou opérationnelle : vérifier les droits d'accès, le quota, les symboles et comparer les historiques avant toute utilisation décisionnelle.


## Environnement de développement isolé

- Linux/macOS : `bash scripts/setup_venv.sh`, puis `source .venv/bin/activate`.
- Windows PowerShell : `./scripts/setup_venv.ps1`, puis ` .venv\Scripts\Activate.ps1`.
- Dépendances de développement (pytest et httpx) : `requirements-dev.txt`.
- Validation locale : `python -m compileall -q .`, `python -m pytest -q`, puis `python -m unittest discover -q`.
- Pour les tests sans compte broker : `BROKER=sim` (Linux/macOS) ou `$env:BROKER='sim'` (PowerShell), avec `APP_PASSWORD` défini.

## Phase 5 — moteur quantitatif (durcissement en cours)

`services/quantitative.py` fournit une façade dédiée pour les indicateurs, le signal technique, le score, la couverture, la décision et les mesures historiques de volatilité/VaR/CVaR. Le snapshot expose aussi le rendement cumulé, le drawdown maximal, les meilleurs/pire rendements journaliers et une volatilité annualisée (convention de 252 séances). La méthode `multi_asset_snapshot` ajoute une matrice de corrélation et de covariance, les bêtas face à un benchmark, les rendements du portefeuille pondérés, sa volatilité/VaR/CVaR historiques et le nombre effectif de positions. Elle expose aussi la concentration HHI, le poids maximal, les expositions sectorielles (classification fournie par l'appelant), les contributions à la variance et des scénarios de baisse bêta-ajustés. Ces stress tests sont des sensibilités linéaires indicatives, pas des prévisions ; si le bêta est indisponible, le calcul reprend l'hypothèse V1 de bêta 1. Les historiques des actifs et du benchmark doivent être préalablement alignés sur les mêmes dates et avoir la même longueur ; les pondérations explicites doivent être positives et totaliser 1. Les facteurs de score connus sont validés dans [-1, 1]. Les calculs RSI/MACD/SMA, les poids et les seuils restent ceux des modules V1 `indicators.py`, `scoring.py` et `risklib.py`. La suite `tests/test_quantitative_engine.py` compare les résultats à ces fonctions de référence et couvre les contrôles multi-actifs. Ces métriques descriptives ne prouvent pas de performance prédictive. Le backtest et le walk-forward sont décrits ci-dessous ; ils restent des validations historiques, pas une preuve de rentabilité future. Voir `PHASE5-QUANTITATIVE-ENGINE-CHANGELOG.md`.

### Attribution factorielle quantitative (phase 5)

Le moteur expose `QuantitativeEngine.factor_attribution(asset_closes, factor_returns)` pour estimer les expositions OLS d'un actif à des facteurs fournis par l'appelant, l'alpha quotidien/annualisé, le R² et la volatilité résiduelle. Les rendements des facteurs doivent être préalablement alignés sur les rendements de l'actif. Le modèle rejette les facteurs colinéaires et les historiques insuffisants ; ses coefficients sont descriptifs et ne constituent pas des prévisions.

### Diagnostics de performance par stratégie (phase 5)

`QuantitativeEngine.strategy_performance(period_returns, benchmark_returns=None, risk_free_daily=0.0)` calcule rendement composé et annualisé, volatilité annualisée, Sharpe, Sortino, drawdown, Calmar, taux de périodes positives et profit factor. Le benchmark facultatif fournit bêta et corrélation. `compare_strategy_performance` compare plusieurs stratégies sur un calendrier commun et produit leur matrice de corrélation. Les séries sont des rendements journaliers décimaux déjà alignés ; aucun historique n'est tronqué automatiquement. Les frais, slippage, dividendes, financement et rapprochement aux transactions réelles ne sont pas encore intégrés. Ces diagnostics ne remplacent pas le backtest hors échantillon de la phase 9.

### Modèles quantitatifs de signaux (phase 5)

Le moteur expose `QuantitativeEngine.strategy_signals()` avec des diagnostics normalisés de momentum, suivi de tendance (SMA rapide/lente) et retour à la moyenne (RSI). Les fenêtres et échelles de normalisation sont configurables. Une fenêtre insuffisante retourne `None` et un état de disponibilité ; aucun ordre n'est généré. Les signaux ne sont ni optimisés ni validés hors échantillon à ce stade.

**Durcissement numérique (11 novembre 2026).** Les entrées booléennes sont désormais rejetées dans les séries numériques, facteurs et pondérations ; les rendements factoriels impossibles (≤ -100 %) sont refusés et les débordements du capital composé déclenchent une erreur explicite. Les calculs V1 restent inchangés. Voir `PHASE5-QUANTITATIVE-ENGINE-CHANGELOG.md`.

### Backtest : isolation de la fenêtre hors échantillon

Le moteur de backtest accepte `start_index` pour échauffer les indicateurs sur l'historique antérieur sans transporter de position ou de capital investi dans la fenêtre OOS. `optimize()` évalue le test sur une simulation indépendante démarrant à plat avec le capital initial ; le benchmark OOS et le bootstrap utilisent la même fenêtre indépendante. Le CAGR annualise les `n-1` intervalles contenus dans `n` observations d'équité. La courbe continue est conservée pour le contexte visuel, elle ne doit pas être confondue avec la simulation OOS isolée. Cette séparation limite les contaminations entre apprentissage et test mais ne remplace pas une validation walk-forward.

### Validation walk-forward

`backtest.walk_forward()` complète le holdout train/test unique par une validation chronologique à fenêtres successives. À chaque pli, les paramètres sont choisis uniquement sur la fenêtre d'apprentissage passée, puis évalués sur le segment suivant, avec capital frais et exposition nulle au début du test. Par défaut, l'apprentissage est expansif ; `expanding=False` limite l'apprentissage à une fenêtre glissante `train_size`. Les tests ne se chevauchent pas (`step` doit être au moins égal à `test_size`). Le résultat expose les métriques de chaque pli, les performances OOS agrégées, le benchmark, la fréquence de sélection des paramètres et le bootstrap des trades OOS. Cette validation reste historique/synthétique selon les données fournies et ne remplace pas un test Paper Trading.


## Phase 6 — Strategy Engine (socle fonctionnel livré, intégration système à valider)

Le package `services/strategy_engine/` fournit un contrat commun, des signaux validés, un registre et quatre stratégies (Momentum, Trend Following, Mean Reversion, Breakout). Il inclut désormais le gestionnaire de cycle de vie avec isolation des erreurs, la sélection par régime, l'agrégation par familles de preuve (Momentum et Trend Following ne comptent pas comme deux confirmations indépendantes), l'allocation indicative plafonnée, l'évaluation comparative et un journal d'audit mémoire borné. Le détecteur de régime réutilise strictement la règle V1 haussier/baissier ; si les données sont insuffisantes, il retourne UNKNOWN et le sélecteur ferme par défaut.

Les allocations sont des propositions uniquement. `risk_gate` exige l'approbation explicite d'un contrôle de risque externe et échoue en mode fermé ; il ne soumet aucun ordre. Le raccordement end-to-end au service Risk Management et à Paper Execution, ainsi que la persistance du journal via PostgreSQL, restent à valider. Aucun mode Live n'est activé. Voir `PHASE6-STRATEGY-ENGINE-CHANGELOG.md`.

## Strategy Engine -> Risk -> Paper (Phase 6 integration)

The authenticated endpoint `POST /api/strategy/run?symbols=AAPL,MSFT` runs the
registered strategy set against validated daily market data. The strategy
configuration must first be enabled through `POST /api/strategy`. Unknown
market regimes fail closed; only BUY proposals can be staged (SELL signals are
informational and no short orders are created).

A BUY proposal is checked against the existing portfolio limits and stored as
`PENDING_MANUAL_APPROVAL`. The pipeline has no broker dependency and never
submits orders. The existing `POST /api/approve/{order_id}` path is the only
execution path: it checks pause state, broker blocks, daily loss, drawdown,
weekly loss, position/exposure/cash/order limits again before the configured
Paper broker is called. A failed second check leaves the proposal unexecuted.

The pipeline is disabled outside SIM or the official Alpaca Paper endpoint.
The simulator may use synthetic timestamp-less data; non-SIM Paper market data
must pass the XNYS freshness check with provider timestamps. PostgreSQL
persistence and real-provider end-to-end validation remain outstanding.

### Phase 3 — persistance des ordres et exécutions
Le dépôt SQL `db.order_repository.OrderRepository` conserve les intentions d'ordres, statuts, fills, snapshots de compte et événements de risque. Lorsque `DATABASE_URL` est configurée, `OrderService` persiste l'intention avant toute soumission. Un timeout courtier produit le statut `submission_unknown` : il faut réconcilier l'ordre avec le courtier avant toute nouvelle tentative. Les migrations doivent être appliquées explicitement avec Alembic ; aucun schéma n'est créé automatiquement au démarrage.

### Paper broker reconciliation

With PostgreSQL configured and Alembic migrations applied, an authenticated operator can run `POST /api/reconciliation/run`. The endpoint reads broker orders, fills, account and positions, then persists matched statuses, idempotent fills, and point-in-time account/position snapshots. It never submits or retries orders. Missing orders and truncated broker snapshots remain unresolved and require review. `BROKER=sim` selects the local simulated broker adapter.

See `PHASE3-BROKER-RECONCILIATION-REPORT.md` for tested scope and outstanding external validation.

## Financial reconciliation (Paper)

Run the authenticated `POST /api/reconciliation/run` endpoint. To activate the cash/position/equity ledger comparison, configure `PAPER_OPENING_CASH` with the independently verified opening cash at the start of the complete local fill history. Optional tolerances: `PAPER_RECONCILIATION_CASH_TOLERANCE` (USD, default 0.05) and `PAPER_RECONCILIATION_QTY_TOLERANCE` (shares, default 0.00001). Incomplete activity history is reported as inconclusive. Confirmed mismatches pause trading; no automatic portfolio repair or order retry occurs. See `PHASE3-FINANCIAL-RECONCILIATION-REPORT.md`.

### Phase 3 — PostgreSQL integration validation (prepared, not yet executed)

The optional PostgreSQL integration suite and non-destructive backup/restore validation are documented in `PHASE3-POSTGRES-VALIDATION.md`. Run `bash scripts/verify_postgres.sh` only with dedicated empty `trader_pro_test` and `trader_pro_restore` databases. Phase 3 remains open until that real PostgreSQL run succeeds.

### Phase 4 — risk consumers use validated market data

Risk-model market closes now pass through the same provider validation and exchange-session freshness gate as strategy signal generation. In Live/Paper mode, missing or stale market timestamps fail closed. The local deterministic simulator is explicitly exempt from real exchange timestamps.

## Phase 7 — Institutional risk controls

The initial institutional risk layer is documented in `PHASE7-INSTITUTIONAL-RISK-CHANGELOG.md`. It adds fail-closed portfolio exposure reporting and a second pre-trade approval gate while preserving the original V1 risk formulas. PostgreSQL and external Alpaca Paper validation remain deferred; see the changelog for exact scope and test results.

## Phase 8 — durable broker event inbox (in progress)

`services/broker_events.py` and Alembic revision `91c7d3e5a2b4` add a durable inbox for broker notifications. Events are deduplicated by a stable caller-supplied ID, stored using an allowlist, and processed by triggering a complete broker reconciliation. Notifications do not directly alter order state and never cause order retries. Failed batches remain retryable; abandoned processing leases can be reclaimed. The inbox is not yet connected to a broker websocket/webhook receiver or a Phase 11 worker. PostgreSQL concurrency and real Alpaca Paper event delivery remain unverified. See `PHASE8-BROKER-EVENT-INBOX.md`.

## Statut canonique du programme Trader Pro 2.0

Le suivi doit utiliser le plan institutionnel à 12 phases défini dans `TRADER-PRO-2-STATUS.md`. Certains titres de phases plus anciens dans ce README décrivent l'historique de V1 et ne correspondent pas à la numérotation canonique du programme 2.0. Le rapport de statut donne les preuves disponibles, les validations externes manquantes et les critères de clôture. Dernière évaluation : 23 novembre 2026.

## Commandes opérateur de sécurité (phase 8)

Les transitions de l'état global (`READY`, `DEGRADED`, `RECONCILING`, `HALTED`)
ne sont pas autorisées par la session normale de l'application. Les routes
`/api/operator/system-safety` exigent une identité HTTP Basic dédiée
(`operator` + `TRADER_OPERATOR_PASSWORD`), un TOTP obligatoire dans
`X-Operator-TOTP`, HTTPS et l'en-tête anti-CSRF `X-Trader: 1`. Le mot de passe
opérateur doit contenir au moins 20 caractères et être différent de
`APP_PASSWORD`. Le secret TOTP doit être distinct de `TOTP_SECRET`.

Exemple de configuration : copier `.env.example`, générer deux secrets
indépendants hors du dépôt, puis les injecter dans l'environnement du serveur.
Ne jamais committer les valeurs réelles. Sans PostgreSQL, sans les deux secrets,
ou sans HTTPS, les routes opérateur échouent en mode fermé. Le rôle `operator`
est attribué côté serveur après authentification ; un champ `actor` envoyé par
le client est ignoré. Le passage à `READY` reste soumis à la preuve Paper
persistée, complète, sans écart et récente vérifiée par `OrderRepository`.

## Trade Pro 7 — paquet fusionné (21 novembre 2026)

Cette archive fusionne la base R5 OHLCV avec les améliorations compatibles du paquet App-Creator, notamment le connecteur Alpaca Paper fail-closed et l'état de santé du courtier. Voir `TRADE-PRO-7-MERGE-REPORT-2026-11-21.md` pour le détail des éléments repris, exclus, tests et limites.

## Recherche multi-stratégies V1 isolée (consolidation du 23 novembre 2026)

Le paquet `research_v1/` réutilise, sous un espace de noms isolé, les moteurs quantitatifs et le catalogue de la branche `refactor-v2` de V1. Il contient 50 types : 43 règles par titre et 7 stratégies d'univers/portefeuille. Ce moteur ne remplace pas `services/strategy_engine/` et n'a aucun accès au courtier.

Routes authentifiées :

- `GET /api/research/strategies/catalog` : inventaire des 50 types.
- `POST /api/research/strategies/{kind}/dry-run` : évalue une règle par titre sur des données OHLCV horodatées. Corps JSON : `{"symbol":"AAPL","limit":500,"params":{},"benchmark_symbol":"SPY"}`. Le benchmark est facultatif pour les règles qui n'en ont pas besoin.
- `POST /api/research/portfolio-strategies/{kind}/dry-run` : évalue une stratégie d'univers sur au moins deux titres synchronisés. Corps JSON : `{"symbols":["AAPL","MSFT"],"equity":100000,"limit":500,"params":{}}`.
- `POST /api/research/portfolio-strategies/{kind}/backtest` : simulation historique multi-actifs, décision à la clôture et exécution à l'ouverture suivante, frais et glissement inclus. Corps JSON : `{"symbols":["AAPL","MSFT","NVDA"],"benchmark_symbol":"SPY","limit":1000,"warmup":60,"initial_cash":100000,"params":{"lookback":252,"top_n":1,"exit_rank":2,"position_pct":0.9,"abs_min":0.0}}`. Cette route ne crée aucun ordre et ne valide pas la rentabilité hors échantillon.
- `POST /api/research/portfolio-strategies/scoreboard` : évalue les sept stratégies d'univers en OOS walk-forward sur 3 à 10 actifs. Exemple : `{"symbols":["AAPL","MSFT","NVDA"],"benchmark_symbol":"SPY","limit":2000,"warmup":60,"test_window":126,"min_oos_bars":756,"min_folds":6,"fee":0.0005,"slippage":0.0005}`. Le moteur garde un portefeuille continu entre les fenêtres, exige des séances synchronisées, compare au buy-and-hold équipondéré et à l'indice choisi, corrige le test multiple au niveau des 50 stratégies du catalogue (Bonferroni + statistique Newey-West) et rejoue les simulations avec frais/glissement doublés. Le warmup est relevé automatiquement par stratégie (ex. 253 séances pour Momentum 12-1).
- `POST /api/research/strategies/scoreboard` : évalue hors échantillon les 43 règles par titre sur 3 à 10 titres. Exemple : `{"symbols":["AAPL","MSFT","NVDA"],"benchmark_symbol":"SPY","limit":1000,"split":0.6,"fee":0.0005,"slippage":0.0005,"warmup":60}`.

Le scoreboard mono-titre applique frais et glissement, compare à l'achat-conservation et corrige le seuil statistique sur la famille globale des 50 stratégies (43 règles individuelles + 7 stratégies de portefeuille), même si chaque tableau n'en affiche qu'une partie. Ses titres sont agrégés comme des lignes équipondérées en capital initial ; le verdict s'appuie sur les rendements journaliers du portefeuille agrégé, nets de l'achat-conservation, avec une statistique Newey-West HAC (5 retards), pas sur l'hypothèse irréaliste d'indépendance des trades. L'espérance et le nombre de trades ne comptent que les positions ouvertes ET clôturées dans l'OOS ; une position reportée depuis l'apprentissage contribue à la valorisation quotidienne OOS, mais n'est pas requalifiée en nouveau trade OOS. Tous les titres et leurs benchmarks doivent partager des timestamps strictement identiques, timezone-aware et croissants. Les paramètres invalides, coûts non finis/négatifs et données désynchronisées sont rejetés. Le moteur parcourt les 7 stratégies d'univers en walk-forward, avec paramètres figés, coûts doublés en scénario de stress et seuil ajusté Bonferroni pour la famille globale de 50 tests ; Multi-Factor n'est effectivement évaluée que lorsque des fondamentaux historiques point-in-time datés sont fournis pour chaque titre. Sans ces snapshots, elle est explicitement non évaluée (pas considérée comme perdante) ; le backtest rejette les fondamentaux statiques. Il mesure aussi les poids quotidiens par titre/liquidités et publie le poids moyen/maximal, les jours exposés, le HHI moyen de concentration et le nombre maximal de positions simultanées. Les expositions par actif sont ainsi mesurées, mais cela ne valide pas encore les secteurs, les facteurs ou la liquidité. Le scoreboard fournit une matrice Pearson de corrélation des rendements OOS entre stratégies, calculée sur leurs dates communes ; cette matrice ne remplace pas l'analyse des risques sous-jacents. Le preview reste toujours à 100 % de liquidités, sans autorisation de capital. Toute candidate exige une revue des expositions réelles et des contrôles de risque avant les validations Paper. Aucun tableau ne produit un verdict « fiable » : « prometteuse » signifie seulement que les critères statistiques et de robustesse n'ont pas invalidé la stratégie sur les données et la période évaluées. Les paramètres doivent être définis avant l'OOS et ne sont jamais optimisés sur la période de test.

Les routes de recherche échouent en mode fermé si les OHLCV complets, horodatés et frais ne sont pas disponibles. Les résultats ne modifient pas les stratégies actives, ne créent aucune proposition d'ordre et ne soumettent aucun ordre. Le service `OrderService` et ses contrôles de risque restent l'unique frontière d'exécution.

Le mode Live demeure verrouillé. La présence d'une stratégie, un backtest positif ou un verdict « prometteuse » ne constitue pas une preuve de rentabilité future.


## Durcissement du risque global de portefeuille — 23 novembre 2026

Le moteur `services.institutional_risk.InstitutionalRiskEngine` contrôle désormais la réserve minimale de liquidités (`min_cash`) au niveau du snapshot global, et pas seulement lors du contrôle pré-transaction. Il publie les HHI sectoriel et émetteur, ainsi que la couverture des classifications disponibles. Les limites facultatives `max_sector_hhi` et `max_issuer_hhi` (bornées entre 0 et 1) déclenchent un blocage en cas de dépassement ou de classification incomplète. Le même calcul prévisionnel est appliqué à une proposition d'achat avant approbation.

Le contrôle VaR/CVaR/stress du snapshot a été dédupliqué : chaque dépassement est désormais signalé une seule fois. Les limites HHI restent désactivées tant qu'elles ne sont pas configurées ; aucune limite par défaut n'est imposée aux comptes existants.

Tests ciblés risques, service de risque, routes et ordres : 87 réussis. Suite complète : 715 réussis, 11 ignorés, 202 sous-tests réussis. PostgreSQL réel, Alpaca Paper et données de marché réelles restent à valider.


## Validation fail-closed de la couverture du risque — incrément R5

Le service `RiskService._advanced()` ne calcule plus VaR/CVaR, corrélation ou bêta à partir d'un sous-ensemble silencieux des positions. Toute position détenue sans au moins 31 clôtures entraîne un état de données indisponibles ; les séries de clôtures doivent également avoir la même longueur que le benchmark SPY. Le snapshot de risque précédent est alors supprimé pour empêcher la réutilisation d'une mesure périmée ou partielle. Le rapport expose la couverture et précise que le lecteur historique ne fournit pas d'horodatages, donc l'alignement exact des séances reste non certifié.

Validation R5 : 41 tests ciblés réussis ; suite complète 715 réussis, 11 ignorés, 202 sous-tests réussis ; compilation Python et syntaxe du service worker validées. PostgreSQL réel, Alpaca Paper et alignement par timestamps réels restent à valider.


## Alignement exact des séances pour le risque — extension R5

Le chemin principal de l'application utilise maintenant `validated_daily_bar_series()` pour conserver les timestamps des barres quotidiennes. `RiskService` compare les timestamps UTC exacts de chaque position détenue à ceux de SPY avant de calculer VaR/CVaR, corrélation et bêta. Une seule séance manquante, décalée ou non horodatée entraîne le refus des métriques et l'effacement du snapshot de risque précédent. L'ancien lecteur close-only reste disponible en compatibilité mais ne certifie que l'égalité des longueurs.

Tests de marché et risque ciblés : 64 passed, 24 subtests passed. Suite complète : 715 passed, 11 skipped, 202 subtests passed. La validation de flux réels synchronisés reste à faire.


En mode simulateur, les barres peuvent être volontairement dépourvues de timestamps de marché. Le service conserve alors la compatibilité du simulateur via le lecteur close-only, avec le statut explicite `not_available_simulation_or_legacy`. Ce chemin ne doit jamais être interprété comme une certification de synchronisation des séances réelles.

## R6 — aperçu d'allocation multi-stratégies (23 novembre 2026)

Le scoreboard OOS publie désormais `allocation_model_preview`, un aperçu théorique pondéré par Sharpe OOS positif / volatilité OOS, plafonné à 25 % par stratégie et 80 % investi. Il est strictement bloqué à 100 % de liquidités tant que les revues d'exposition par actif, de régime, de concentration sectorielle et de liquidité ne sont pas toutes explicitement validées, ou si des candidates sont trop corrélées (|corrélation| >= 0,75). Même dans un scénario où ces contrôles seraient validés, le résultat reste `MODEL_PREVIEW_ONLY`, sans autorisation de capital, activation ni ordre. Le `selection_preview` existant reste à 100 % de liquidités. Détails et limites : `ALLOCATION-MODEL-PREVIEW-R6-2026-11-23.md`.

Validation R6 : tests ciblés portefeuille/scoreboard 22 réussis ; suite complète 718 réussis, 11 ignorés, 202 sous-tests réussis ; `compileall` et vérification syntaxique du service worker réussis. Deux avertissements de dépréciation FastAPI persistent. PostgreSQL/Neon, Alpaca Paper réel, données réelles synchronisées et build React/Vite ne sont pas validés.

## User trading mandate (confirmed)

The target operating policy is full autonomy within hard Risk Governor limits, using available cash only. Margin and borrowed funds are prohibited. Unknown or stale cash availability blocks orders. This mandate does not itself enable broker execution or Live mode; see `DECISION-TRADING-MANDATE-2026-11-23.md` and `trading_mandate.py`.


### Périmètre initial des marchés — R60

Le mandat initial autorise uniquement les actions et ETF (`us_equity`, `us_etf`) après validation de la classification et du statut actif/négociable par des métadonnées broker fiables. Les classes inconnues, options, crypto, Forex et futures sont refusées par défaut. Voir `DECISION-MARKET-UNIVERSE-2026-11-23.md`. Le validateur de mandat est en place ; le raccordement exhaustif à tous les chemins d'ordre reste à réaliser et à vérifier en Alpaca Paper.


### Contrôle broker de l'univers d'instruments — R61

Le service d'approbation exige un lecteur de métadonnées broker. Il bloque si le lecteur manque, si le symbole ne correspond pas, si la classe n'est pas `us_equity`, si l'instrument n'est pas actif ou si `tradable` n'est pas vrai. Pour ne pas inventer une sous-classe ETF absente de la classification Alpaca, actions et ETF sont traités dans la famille fournisseur `us_equity`. La validation réelle via Alpaca Paper reste nécessaire.


### Réservations de trésorerie sur ordres partiellement exécutés — R62

Le contrôle des achats ouverts calcule désormais l'engagement restant lorsque le broker fournit `qty` et `filled_qty` : quantité restante multipliée par `limit_price`, ou prorata du `notional` initial si le prix limite n'est pas fourni. Les ordres partiellement exécutés dont la quantité exécutée est inconnue, incohérente ou supérieure à la quantité initiale bloquent l'approbation. Pour les ordres non partiellement exécutés, le montant nominal reste utilisé, avec `qty × limit_price` comme solution lorsque le nominal est absent. Le contrôle atomique de réservation durable existant est conservé.
