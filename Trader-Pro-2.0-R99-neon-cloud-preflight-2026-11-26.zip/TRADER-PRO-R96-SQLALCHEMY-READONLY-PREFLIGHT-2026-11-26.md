# Trader Pro 2.0 — R96
## Précontrôle SQLAlchemy en lecture seule pour Neon `trader_pro_test`

Date : 26 novembre 2026  
Base : release R95, extension additive sans réécriture  
Cible autorisée : Neon `trader_pro_test` uniquement  
Tête Alembic attendue : `f19a6c3d8b42`

## 1. Objectif

R95 avait validé le schéma Neon et les composants applicatifs localement, mais pas la connexion directe du processus Python/SQLAlchemy à Neon. R96 ajoute un précontrôle exécutable dans un environnement disposant du pilote PostgreSQL et de l'accès réseau.

Nouveau script : `scripts/verify_neon_sqlalchemy_readonly.py`.

## 2. Protections intégrées

- Lit exclusivement `TRADER_PRO_TEST_DATABASE_URL` ; aucun recours implicite à `DATABASE_URL`.
- Refuse toute base autre que le nom exact `trader_pro_test`.
- Refuse tout moteur autre que PostgreSQL.
- Ouvre une transaction et exécute `SET TRANSACTION READ ONLY` avant les requêtes d'inspection.
- Vérifie la base réellement connectée, le mode read-only, la version PostgreSQL, la tête Alembic, les 17 tables requises, le trigger append-only et l'état des contrôles de sécurité.
- Contrôle que le trigger protège bien les opérations `UPDATE` et `DELETE`.
- N'effectue aucune insertion, mise à jour, suppression ou migration.
- Ne journalise jamais l'URL de connexion ni les arguments d'erreur du pilote susceptibles de contenir des secrets.

Commande d'exécution dans un environnement déjà configuré :

```bash
TRADER_PRO_TEST_DATABASE_URL='postgresql://…/trader_pro_test?sslmode=require' \
  python scripts/verify_neon_sqlalchemy_readonly.py
```

Le pilote `psycopg` doit être installé dans l'environnement d'exécution. Le script utilise le mécanisme de normalisation déjà présent dans `db/session.py`.

## 3. Tests R96

- Tests ciblés du garde-fou : 6 réussis.
- Suite complète : 1 010 réussis, 11 ignorés, 205 sous-tests réussis.
- `compileall` sur les nouveaux fichiers : réussi.

Les 11 tests PostgreSQL destructifs restent ignorés : ils exigent un serveur PostgreSQL local jetable. R96 ne modifie pas ce garde-fou.

## 4. Vérifications externes en lecture seule

Contrôles effectués sur Neon `trader_pro_test` :
- Alembic : `f19a6c3d8b42`.
- 17 tables publiques attendues.
- 15 révisions d'événements corporate actions présentes.
- Trigger `trg_corporate_action_revisions_append_only` activé (`tgenabled = O`).
- Définition observée : `BEFORE DELETE OR UPDATE` sur `public.corporate_action_revisions`.

Contrôles Alpaca Paper :
- Compte `ACTIVE`, crypto `ACTIVE`.
- Equity et cash affichés : 100 000 USD chacun.
- Aucune position et aucun ordre retournés.
- Aucun ordre n'a été envoyé pendant R96.

## 5. Limites non levées

Le précontrôle SQLAlchemy est ajouté et testé unitairement, mais **n'a pas encore été exécuté contre Neon** : ce runner ne dispose ni de `psycopg`, ni de binaire PostgreSQL local, ni d'accès réseau sortant. La recherche des applications Replit accessibles et des dépôts GitHub connectés n'a pas retrouvé le projet Trader Pro dans cette session. Il faut exécuter ce script dans l'environnement Replit du projet ou un runner équipé.

Le cycle réel Paper ordre → fill → réconciliation applicative reste également non exécuté. Aucun ordre de test n'a été créé. La réconciliation R95 reste une validation en lecture seule avec zéro ordre/fill.

## 6. État de sécurité

- `system_safety_state` reste `RECONCILING`.
- Trading Live non autorisé.
- Aucune migration ni écriture R96 sur Neon.
- `neondb` et `trader_pro_restore` non modifiées.
- Aucune archive historique supprimée.

**Conclusion :** R96 fournit un outil de précontrôle SQLAlchemy à faible risque et renforce la capacité de validation, mais ne prétend pas avoir clos la connexion directe Neon ni le cycle d'exécution Paper. Trader Pro 2.0 n'est pas déclaré opérationnel.
