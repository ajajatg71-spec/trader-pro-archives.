# Trader Pro 2.0 — R76 : contrat d'événements corporate actions

Base : R75. Cet incrément ajoute un registre d'événements typé et une sélection point-in-time.

## Modifications
- Nouveau module `research_v1/quant/corporate_actions.py`.
- Contrat immuable `CorporateActionEvent` pour splits et dividendes, avec source, identifiant facultatif, ex-date et `available_at` obligatoire avec fuseau.
- Validation stricte des ratios, montants, devises et payloads mutuellement exclusifs.
- `point_in_time_events` exclut les annonces non encore connues et les dates ex-date futures ; aucun backfill de connaissance.
- Aucun prix n'est modifié et aucun événement fournisseur n'est inventé.

## Tests
- 9 tests ciblés ajoutés pour contrats, erreurs et sélection temporelle.
- Suite complète : 911 passed, 11 skipped, 205 subtests passed in 22.70s.

## Limites
- Pas encore de connecteur fournisseur d'événements.
- Pas de transformation split-adjusted ni de calcul de rendement total à ce jalon.
- Les événements doivent provenir d'une source vérifiable avant usage financier.
