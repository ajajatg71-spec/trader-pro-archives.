# Phase 8 — Rejet des snapshots broker mal formés (2026-11-15)

## Constat

L'audit de `services/reconciliation.py` a identifié que les éléments non-dictionnaires présents dans les listes renvoyées par le broker (ordres et exécutions) étaient ignorés avec `continue`. Un snapshot contenant une entrée mal formée pouvait donc être traité comme s'il était complet. Le même risque existait pour les éléments de positions persistés dans le snapshot du compte.

## Correction

La réconciliation valide maintenant la forme de chaque élément des listes `remote_orders`, `remote_fills` et `remote_positions` immédiatement après les quatre lectures broker, avant la récupération des soumissions anciennes et avant toute écriture en base.

Si un élément n'est pas un objet dictionnaire, le traitement échoue avec `ReconciliationError` spécifique. Aucun snapshot de compte/position, aucune mise à jour d'ordre, aucun fill et aucune preuve de réconciliation ne sont écrits dans ce chemin.

Les données de notification `trade_updates` restent un déclencheur uniquement; les snapshots broker complets demeurent la source de vérité de la réconciliation. Aucun ordre n'est soumis, remplacé ou annulé par ce changement.

## Tests ajoutés

- `test_malformed_remote_order_record_aborts_before_any_database_write`
- `test_malformed_remote_fill_record_aborts_before_any_database_write`
- `test_malformed_remote_position_record_aborts_before_any_database_write`

Les trois tests vérifient le refus explicite et l'absence d'écritures partielles.

## Vérification

- Suite ciblée `tests/test_reconciliation.py`: **27 passed**.
- La suite complète doit être relancée avant de figer les résultats consolidés.
- La validation PostgreSQL réelle demeure non exécutée dans l'environnement courant (Docker/Podman, serveur et client PostgreSQL absents).
- Aucune requête authentifiée Alpaca Paper n'a été exécutée; aucun ordre Paper ou Live n'a été soumis.

## Statut

Phase 8 reste ouverte. Les contrôles réels PostgreSQL et Alpaca Paper sont toujours des critères bloquants. Live reste désactivé.
