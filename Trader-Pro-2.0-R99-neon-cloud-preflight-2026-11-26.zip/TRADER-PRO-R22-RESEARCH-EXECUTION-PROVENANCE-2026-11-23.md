# Trader Pro 2.0 — R22 : provenance des exécutions de recherche

Date : 23 novembre 2026  
Base : R21 (`0d70f974ead80871d4a4fea427a18c53475865b533b73281ac667fabac333814`)

## Objectif

Créer le premier contrat backend permettant de rattacher des résultats statistiques à une exécution de recherche identifiable, sans réintroduire une saisie de résultats depuis l'interface.

## Changements

- Ajout de `services/research_execution.py`, sans route HTTP et sans dépendance broker/stratégie.
- L'exécuteur reçoit une famille déjà pré-enregistrée, un snapshot de données et un callable évaluateur côté serveur.
- Il calcule et conserve les empreintes SHA-256 du manifeste/protocole, du snapshot de données, de la version de code et des résultats.
- Chaque exécution reçoit un `run_id`, avec dates de début et de fin et origine `BACKEND_RESEARCH_EXECUTOR`.
- Le registre refuse de verrouiller des résultats sans provenance backend complète.
- Ajout de la colonne `execution_provenance` et migration Alembic `ea21c7b4d903`.
- Le résultat reste immuable ; `selection_authorized` reste toujours faux.
- Aucun lien automatique vers le moteur de stratégies, l'allocation, les propositions ou les ordres.

## Validation locale

- Suite complète avec `BROKER=sim` : **743 passed, 11 skipped, 202 subtests passed**.
- 11 tests ignorés : intégrations nécessitant PostgreSQL externe.
- Compilation Python (`compileall`) : réussie.
- Alembic : une seule tête, `ea21c7b4d903`.
- Aucun appel broker ni ordre envoyé.

## Limites et points non certifiés

- L'évaluateur réel `evaluate_candle_confluence` n'est pas encore raccordé à ce service. Le service constitue le contrat backend et ses tests, pas une intégration de bout en bout.
- Le callable évaluateur doit rester fourni par du code backend de confiance ; aucune route publique ne l'accepte.
- La migration n'a pas été appliquée à une instance PostgreSQL/Neon réelle.
- Le build React, PostgreSQL/Neon réel et Alpaca Paper réel restent non validés.
- Aucune sélection automatique de stratégie, allocation de capital ou exécution Live n'est autorisée.

## Décision

R22 est un candidat technique local. Ne pas le qualifier d'opérationnel. Prochaine étape : concevoir un adaptateur explicite entre les sorties statistiques du moteur de recherche et le contrat d'exécution, avec un test de bout en bout et conservation du caractère recherche uniquement.
