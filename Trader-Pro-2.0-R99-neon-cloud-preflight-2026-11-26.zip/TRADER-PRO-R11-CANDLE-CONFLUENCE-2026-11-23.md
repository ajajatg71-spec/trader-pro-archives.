# Trader Pro 2.0 — R11 : évaluation des confluences chandeliers / indicateurs

Date : 23 novembre 2026  
Base : archive R10 `Trader-Pro-2.0-consolide-candidat-2026-11-23-r10.zip`.

## Travail ajouté

Nouveau module `research_v1/validation/candle_confluence.py` et tests `tests/test_candle_confluence.py`.

Le module compare, pour chaque figure directionnelle détectée :
- chandelier seul (référence) ;
- chandelier + RSI(14) ;
- chandelier + histogramme MACD ;
- chandelier + alignement EMA20/EMA50 et prix ;
- chandelier + volume relatif >= 1,2 ;
- chandelier + RSI et MACD ;
- confluence des quatre filtres RSI, MACD, tendance EMA et volume.

Les indicateurs sont calculés uniquement sur les barres disponibles à la clôture du signal. L'entrée simulée est à l'ouverture suivante et la sortie à la clôture de l'horizon choisi. Les commissions et le glissement sont déduits. Les résultats sont séparés chronologiquement en développement et holdout.

## Vérifications exécutées

- Tests ciblés : 8 passés.
- Suite complète : **727 passed, 11 skipped, 202 subtests passed**.
- 11 tests ignorés : intégrations PostgreSQL qui requièrent un environnement de base de données dédié.
- Deux avertissements de dépréciation FastAPI (`on_event`), sans échec de test.

## Limites et sécurité

- Il s'agit d'un outil de recherche descriptif, pas d'un moteur d'exécution.
- Aucun ordre n'est créé ; aucune stratégie n'est activée automatiquement.
- Les filtres sont des règles heuristiques non optimisées. Le résultat ne prouve ni rentabilité ni avantage statistique.
- Pas de correction des comparaisons multiples, pas de test de significativité, pas encore de validation sur plusieurs marchés / actifs / périodes indépendantes.
- L'intégration API et interface utilisateur n'est pas incluse dans cette incrémentation.
- Les validations réelles PostgreSQL/Neon et Alpaca Paper restent à exécuter. Live reste verrouillé.

## Prochaine étape

Ajouter une couche de comparaison multi-actifs et multi-régimes avec mêmes fenêtres temporelles, frais, benchmark et protocole hors échantillon, puis auditer les biais de sélection et de dépendance des observations avant toute promotion vers les stratégies actives.
