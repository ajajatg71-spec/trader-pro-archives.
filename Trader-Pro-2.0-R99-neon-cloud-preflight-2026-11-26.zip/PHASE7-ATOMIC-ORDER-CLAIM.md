# Phase 7 — atomic durable pause gate for order submission

## Change

`OrderRepository.stage_order_if_trading_enabled()` now locks the singleton
`risk_control_state` row (`SELECT ... FOR UPDATE`) and, in the same database
transaction, verifies that trading is not paused and inserts the durable
`submitting` intent. The pause transition writer locks the same singleton row.
On PostgreSQL this serializes a new submission claim against a committed pause
transition: whichever transaction acquires the row lock and commits first
establishes the ordering.

`OrderService.approve()` uses this atomic method when the production repository
provides it. A denied claim returns HTTP-compatible 423 and does not call the
broker. Missing pause state or database failure remains fail-closed. A duplicate
client order ID remains blocked for reconciliation, preserving idempotency.

The approved risk-decision audit is now written after the atomic claim, so a
pause-denied claim cannot leave a misleading `approved` event.

## Semantics and limitation

This is an atomic **claim boundary**, not a transaction spanning the external
broker API. If a claim commits immediately before an operator activates the
pause, that already-claimed order is in flight and cannot be retroactively
unsent. The pause prevents later claims. In-flight `submitting` or
`submission_unknown` orders must be reconciled with the broker before retrying;
this change does not automatically cancel an order already accepted remotely.

SQLite ignores `SELECT FOR UPDATE`; SQLite tests validate fail-closed behavior
and state transitions, but do not prove PostgreSQL lock serialization. The
PostgreSQL concurrency integration tests remain opt-in and were not executed in
this environment.

## Tests added

- Atomic claim succeeds when the durable pause row is unpaused.
- Repeated client order ID remains idempotently blocked.
- Active pause commits a blocked-claim audit and creates no order intent.
- Missing pause singleton fails closed and creates no intent.
- Order service maps an atomic pause denial to 423 and never calls the broker.
- Phase 6 end-to-end SQLite fixture now seeds the singleton row, matching the
  production migration invariant.

## Validation

See the accompanying validation output for the exact local test totals. Real
PostgreSQL and broker Paper validation remain outstanding.
