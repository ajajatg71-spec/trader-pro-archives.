# Trader Pro 2.0 — R58
Date: 23 novembre 2026
Base: R57 (archive candidate).

## Objectif
Relier les rendements hors-échantillon du scoreboard au simulateur hybride continu, sans générer automatiquement les allocations.

## Réalisation
- Le scoreboard exporte désormais `oos_return_streams`: séries de rendements nets quotidiennes horodatées, sur l'intersection OOS commune de toutes les stratégies effectivement évaluées.
- Les dates de début/fin et le nombre d'observations sont publiés dans `oos_return_streams_metadata`.
- Le nouveau module `hybrid_scoreboard_simulation.py` relie ces séries au simulateur R57.
- Les allocations doivent toujours être fournies explicitement dans un calendrier horodaté. Le pont ne transforme pas le classement en pondérations.
- Le pont refuse les anciens scoreboards sans séries datées, les streams de longueur incohérente et les scoreboards dont la frontière d'exécution n'est pas `NONE`.
- Sortie maintenue en recherche uniquement: aucun accès broker, aucun ordre et aucun capital autorisé.

## Validation
- 40 tests ciblés avant le dernier ajout d'assertions de cohérence du scoreboard: réussis.
- 21 tests ciblés scoreboard + pont après ajout des assertions: réussis.
- Suite complète juste avant le dernier ajout d'assertions: **832 passed, 11 skipped, 202 subtests passed**.
- `compileall`: exit code 0.
- Les tests PostgreSQL externes restent ignorés faute de base de test externe; Neon réel, Alpaca Paper, frontend et déploiement non validés.

## Limites
- Le moteur attend encore une allocation datée externe; aucune politique automatique de rebalancement n'est validée.
- Le common OOS intersection est prudent mais peut réduire l'historique utilisable à cause des warmups différents.
- Les rendements sont nets des coûts du backtest individuel, mais le simulateur hybride facture en plus les coûts de rééquilibrage du portefeuille de stratégies. Les hypothèses doivent être calibrées et contrôlées pour éviter tout double comptage.
- Pas encore de risque agrégé fondé sur les covariances dynamiques des stratégies, ni de stress conjoint multi-régimes.
- Aucun résultat de cette étape ne prouve une rentabilité.

## Conclusion
R58 crée un chemin de données explicite et horodaté entre le scoreboard OOS et le simulateur de portefeuille hybride. L'allocation demeure une décision séparée et contrôlée.
