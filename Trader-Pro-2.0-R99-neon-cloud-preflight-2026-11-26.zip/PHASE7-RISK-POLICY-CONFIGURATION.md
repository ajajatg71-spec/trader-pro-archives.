# Phase 7 — Risk policy configuration

The institutional risk layer is additive to the existing V1 controls. Do not enable thresholds without selecting and documenting a portfolio mandate and a trusted instrument-classification source.

## Optional limits

All percentage limits are expressed as percentages of current account equity.

- `max_sector_pct`: maximum aggregate exposure to one sector.
- `max_issuer_pct`: maximum aggregate exposure to one issuer.
- `max_var95_pct`: maximum historical one-day 95% VaR.
- `max_cvar95_pct`: maximum historical one-day 95% CVaR (expected shortfall estimate).
- `max_stress_loss_pct`: maximum estimated portfolio loss under the existing beta-scaled market shocks.
- `market_risk_max_age_seconds`: maximum age of the computed market-risk snapshot; default 900 seconds.

These thresholds are opt-in. When a threshold is present, missing or malformed market-risk measurements block approval. Stale snapshots block approval. If the market-data service cannot refresh the metrics, it clears the previous snapshot rather than reusing stale values.

## Instrument metadata

Provide reviewed metadata in application state using this shape:

```python
state["risk_metadata"] = {
    "AAPL": {"sector": "Information Technology", "issuer": "Apple Inc."},
    "MSFT": {"sector": "Information Technology", "issuer": "Microsoft Corporation"},
}
```

Use a stable sector taxonomy and canonical issuer names. The same issuer must use the same canonical label across share classes and listings. Do not guess classifications. If a sector or issuer cap below 100% is enabled, missing classification blocks the snapshot and buy approval.

## Important interpretation

VaR and CVaR are historical estimates calculated from observed returns. The stress metric is based on the existing beta-scaled -10%, -20%, and -30% market shocks. Neither is a guarantee against loss. Thresholds should be validated against the account mandate and historical data coverage before use.

Paper mode only. Live execution remains disabled.

## Correlation and diversification controls

- `max_avg_correlation`: maximum average pairwise correlation of held assets, in the range 0 to 1. The metric is calculated from aligned historical daily returns by the existing V1 risk library. If there are not enough valid observations to produce it, an enabled limit blocks new buys.
- `min_effective_n`: minimum effective number of holdings, calculated from normalized portfolio weights using the existing V1 `effective_n` function. This detects concentration that a raw position count can hide. Missing data blocks approval when enabled.

Both controls use the same timestamped market-risk snapshot as VaR/CVaR and are therefore subject to `market_risk_max_age_seconds`.

## Factor exposure controls

Factor caps are configured as absolute portfolio-weighted factor loadings. Example:

```python
state["risk_metadata"] = {
    "AAPL": {"factor_loadings": {"market": 1.15, "growth": 0.70}},
    "MSFT": {"factor_loadings": {"market": 1.05, "growth": 0.55}},
}
state["limits"]["max_factor_exposure"] = {
    "market": 0.80,
    "growth": 0.60,
}
```

For each factor, the engine sums `position_market_value / account_equity * factor_loading`. The absolute value is compared with the configured cap. New buy orders are tested against the proposed portfolio, including the candidate order. Missing loadings fail closed. Factor loadings must come from a reviewed and timestamped attribution process; this phase does not invent a factor taxonomy or fetch factor data automatically. Use consistent factor definitions and estimation windows across symbols. A cap of 0.80 is a loading limit, not 0.80%.

These controls are opt-in and do not change the original V1 return, VaR, correlation, beta, or effective-number formulas.
