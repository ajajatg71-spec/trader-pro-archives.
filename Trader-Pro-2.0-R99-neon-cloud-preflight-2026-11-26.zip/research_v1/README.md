# Moteur de recherche V1 isolé

Ce paquet reprend les modules quantitatifs et le catalogue de 50 stratégies de la branche `refactor-v2` de V1 sous un espace de noms distinct. Il ne remplace pas le moteur de stratégies V2 et n'a aucun accès au courtier.

- 43 stratégies par titre et 7 stratégies de portefeuille.
- Entrée obligatoire : barres OHLCV réelles, alignées et horodatées.
- Sortie : intentions de recherche uniquement (`RESEARCH_DRY_RUN`).
- Aucun ordre n'est créé et aucune stratégie n'est activée.
- Les stratégies d'univers exigent un univers multi-titres synchronisé.

Aucune stratégie n'est considérée rentable par sa seule présence dans le catalogue. Les verdicts nécessitent des données de marché réelles, des frais/glissements réalistes et une validation hors échantillon avec correction des tests multiples.
