"""Walk-forward OOS scoreboard for the seven multi-asset portfolio strategies.

All rule parameters are frozen before the evaluation period. The portfolio is
simulated continuously through the OOS horizon; fold boundaries are reporting
boundaries, not portfolio resets. Costs are charged on every simulated fill.
No broker, order, or activation path is imported here.
"""
from __future__ import annotations

from math import isfinite, sqrt
from datetime import datetime
from statistics import NormalDist, mean, median, stdev

from research_v1.backtesting.portfolio_backtest import simulate_portfolio
from research_v1.backtesting.sector_risk import audit_sector_exposure
from research_v1.strategies.catalog import make
from research_v1.adapter import UNIVERSE_STRATEGIES, RULE_STRATEGIES

TRADING_DAYS = 252
VERDICTS = ("prometteuse", "à surveiller", "non démontrée", "rejetée")
MAX_DRAWDOWN_PCT = -35.0


def required_warmup(kind: str, params: dict | None = None) -> int:
    """Return a causal warm-up that covers the strategy's longest default/input window."""
    strategy = make(kind, f"warmup-{kind}", params or {}, ())
    p = strategy.params
    if kind == "momentum":
        need = 253  # 12-1 momentum plus its 200-session trend filter
    elif kind == "dual_momentum":
        need = int(p["lookback"])
    elif kind == "low_volatility":
        need = max(200, int(p["vol_n"]))
    elif kind == "rs_rotation":
        need = max(200, int(p["rs_n"]))
    elif kind == "multi_factor":
        need = 130
    elif kind == "rebalancing":
        need = 30
    elif kind == "inverse_volatility":
        need = int(p["vol_n"])
    else:
        raise ValueError(f"Stratégie d'univers inconnue : {kind}")
    return max(30, need)


def _curve_metrics(curve: list[float]) -> dict:
    """Risk/return metrics from a positive, chronological marked-to-market equity curve.

    Sortino uses a zero daily minimum acceptable return. Drawdown duration counts
    observations from the prior peak through recovery (or to the final bar).
    These are descriptive research metrics, never a trading authorization.
    """
    empty = {"return_pct": 0.0, "cagr_pct": 0.0, "sharpe": 0.0,
             "sortino": 0.0, "calmar": 0.0, "volatility_pct": 0.0,
             "max_drawdown_pct": 0.0, "max_drawdown_duration_bars": 0}
    if len(curve) < 2 or not isfinite(float(curve[0])) or curve[0] <= 0:
        return empty
    values = [float(value) for value in curve]
    if any(not isfinite(value) or value <= 0 for value in values):
        raise ValueError("La courbe de capital doit contenir uniquement des valeurs positives et finies")
    returns = [values[i] / values[i - 1] - 1 for i in range(1, len(values))]
    avg = mean(returns) if returns else 0.0
    vol = stdev(returns) if len(returns) > 1 else 0.0
    downside = [min(value, 0.0) for value in returns]
    downside_dev = sqrt(sum(value * value for value in downside) / len(downside)) if downside else 0.0
    peak, worst, peak_index = values[0], 0.0, 0
    current_duration = max_duration = 0
    for index, value in enumerate(values):
        if value >= peak:
            peak, peak_index, current_duration = value, index, 0
        else:
            current_duration = index - peak_index
            max_duration = max(max_duration, current_duration)
            worst = min(worst, value / peak - 1)
    years = len(returns) / TRADING_DAYS
    total_return = values[-1] / values[0] - 1
    cagr = ((values[-1] / values[0]) ** (1 / years) - 1) if years > 0 else -1.0
    max_dd_pct = worst * 100
    return {
        "return_pct": round(total_return * 100, 3),
        "cagr_pct": round(cagr * 100, 3),
        "sharpe": round(avg / vol * sqrt(TRADING_DAYS), 3) if vol > 0 else 0.0,
        "sortino": round(avg / downside_dev * sqrt(TRADING_DAYS), 3) if downside_dev > 0 else 0.0,
        "calmar": round(cagr / abs(worst), 3) if worst < 0 else 0.0,
        "volatility_pct": round(vol * sqrt(TRADING_DAYS) * 100, 3),
        "max_drawdown_pct": round(max_dd_pct, 3),
        "max_drawdown_duration_bars": max_duration,
    }


def _hac_t_stat(values: list[float], max_lag: int = 5) -> float:
    """Newey-West HAC t-statistic for mean daily paired excess return."""
    n = len(values)
    if n < 30:
        return 0.0
    avg = mean(values)
    centered = [x - avg for x in values]
    gamma0 = sum(x * x for x in centered) / n
    lag_count = min(max_lag, n - 1)
    long_run = gamma0
    for lag in range(1, lag_count + 1):
        covariance = sum(centered[i] * centered[i - lag] for i in range(lag, n)) / n
        bartlett = 1 - lag / (lag_count + 1)
        long_run += 2 * bartlett * covariance
    variance_mean = max(long_run, 0.0) / n
    if variance_mean <= 1e-18:
        return 0.0
    return avg / sqrt(variance_mean)


def _market_buy_hold_curve(bars: list, n: int, warmup: int, cash: float,
                           fee: float, slip: float) -> list[float]:
    """Buy the market proxy at the same first OOS execution open as the strategy."""
    fill_index = warmup + 1
    if n <= fill_index:
        return [float(cash)] * n
    fill_price = float(bars[fill_index].o) * (1 + slip)
    qty = float(cash) * (1 - fee) / fill_price
    return [float(cash) if i < fill_index else qty * float(bars[i].c) for i in range(n)]


def _market_total_return_buy_hold_curve(market_bars: list, events, *, currency: str,
                                        initial_cash: float, fee: float, slip: float,
                                        warmup: int, price_basis: str = "unknown") -> list[float]:
    """Add sourced corporate-action returns to the existing market buy/hold curve.

    Entry timing and costs remain those of `_market_buy_hold_curve`; after entry,
    the price-only path is scaled by the event-driven total-return index ratio.
    This benchmark is descriptive and does not affect strategy verdicts.
    """
    from research_v1.quant.corporate_actions import dividend_total_return_index
    bars = list(market_bars)
    n = len(bars)
    if n < 2:
        raise ValueError("Historique du benchmark total return insuffisant")
    timestamps = [datetime.fromisoformat(bar.ts) if isinstance(bar.ts, str) else bar.ts
                  for bar in bars]
    total_index = dividend_total_return_index(
        [bar.c for bar in bars], timestamps, events,
        initial_value=100.0, currency=currency, price_basis=price_basis,
    )
    price_curve = _market_buy_hold_curve(bars, n, warmup, initial_cash, fee, slip)
    fill_index = warmup + 1
    if n <= fill_index:
        return price_curve
    base = total_index[fill_index]
    if base <= 0:
        raise ValueError("Base du benchmark total return invalide")
    entry_value = price_curve[fill_index]
    for index in range(fill_index, n):
        price_curve[index] = entry_value * total_index[index] / base
    return price_curve


def _asset_exposure_summary(weights_curve: list[dict[str, float]]) -> dict:
    """Summarize close-to-close OOS capital weights by asset without authorizing allocation."""
    if not weights_curve:
        return {"bars": 0, "assets": {}, "average_invested_pct": 0.0,
                "max_single_asset_weight_pct": 0.0, "average_invested_asset_hhi": 0.0,
                "max_simultaneous_positions": 0}
    symbols = sorted({symbol for row in weights_curve for symbol in row})
    assets = {}
    for symbol in symbols:
        weights = [max(0.0, float(row.get(symbol, 0.0))) for row in weights_curve]
        assets[symbol] = {
            "average_weight_pct": round(mean(weights) * 100, 3),
            "max_weight_pct": round(max(weights, default=0.0) * 100, 3),
            "days_exposed_pct": round(sum(weight > 1e-8 for weight in weights) / len(weights) * 100, 2),
        }
    invested_daily = [sum(max(0.0, float(weight)) for weight in row.values())
                      for row in weights_curve]
    daily_hhi = []
    for row, invested in zip(weights_curve, invested_daily):
        if invested > 1e-8:
            daily_hhi.append(sum((max(0.0, float(weight)) / invested) ** 2
                                 for weight in row.values()))
    return {
        "bars": len(weights_curve),
        "assets": assets,
        "average_invested_pct": round(mean(invested_daily) * 100, 3),
        "max_single_asset_weight_pct": round(max(
            (max((float(weight) for weight in row.values()), default=0.0)
             for row in weights_curve), default=0.0) * 100, 3),
        "average_invested_asset_hhi": round(mean(daily_hhi), 5) if daily_hhi else 0.0,
        "max_simultaneous_positions": max(
            (sum(float(weight) > 1e-8 for weight in row.values())
             for row in weights_curve), default=0),
    }



def _compound_returns(values: list[float]) -> float:
    wealth = 1.0
    for value in values:
        wealth *= 1.0 + value
    return wealth - 1.0


def _market_regime_breakdown(strategy_curve: list[float], benchmark_curve: list[float],
                             market_bars: list, start: int, lookback: int = 63,
                             threshold: float = 0.05) -> dict:
    """Attribute OOS returns to regimes known at the prior close (no look-ahead)."""
    if len(strategy_curve) != len(benchmark_curve) or len(market_bars) != len(strategy_curve):
        raise ValueError("Les courbes de régime doivent être synchronisées")
    buckets = {name: {"strategy_returns": [], "benchmark_returns": []}
               for name in ("risk_on", "sideways", "risk_off")}
    unclassified = 0
    for i in range(max(1, start + 1), len(strategy_curve)):
        known_index = i - 1
        if known_index < lookback:
            unclassified += 1
            continue
        past = float(market_bars[known_index - lookback].c)
        latest = float(market_bars[known_index].c)
        if past <= 0 or latest <= 0:
            unclassified += 1
            continue
        trailing_return = latest / past - 1
        regime = ("risk_on" if trailing_return > threshold else
                  "risk_off" if trailing_return < -threshold else "sideways")
        prev_s, prev_b = strategy_curve[i - 1], benchmark_curve[i - 1]
        if prev_s <= 0 or prev_b <= 0:
            unclassified += 1
            continue
        buckets[regime]["strategy_returns"].append(strategy_curve[i] / prev_s - 1)
        buckets[regime]["benchmark_returns"].append(benchmark_curve[i] / prev_b - 1)

    output = {}
    for name, values in buckets.items():
        sr, br = values["strategy_returns"], values["benchmark_returns"]
        s_total, b_total = _compound_returns(sr), _compound_returns(br)
        output[name] = {
            "observations": len(sr),
            "strategy_return_pct": round(s_total * 100, 3),
            "benchmark_return_pct": round(b_total * 100, 3),
            "excess_return_pct": round((s_total - b_total) * 100, 3),
            "sufficient_sample": len(sr) >= 20,
        }
    return {
        "method": f"market trailing {lookback}-session return, threshold +/-{threshold:.0%}, signal known at prior close",
        "lookback_sessions": lookback,
        "threshold_pct": threshold * 100,
        "classified_observations": sum(row["observations"] for row in output.values()),
        "unclassified_observations": unclassified,
        "regimes": output,
        "all_regimes_sufficiently_sampled": all(row["sufficient_sample"] for row in output.values()),
    }

def _pearson_correlation(left: list[float], right: list[float]) -> float | None:
    """Pearson correlation; return None when either OOS series has no variance."""
    if len(left) != len(right) or len(left) < 3:
        return None
    left_mean, right_mean = mean(left), mean(right)
    left_centered = [x - left_mean for x in left]
    right_centered = [x - right_mean for x in right]
    left_var = sum(x * x for x in left_centered)
    right_var = sum(x * x for x in right_centered)
    denom = sqrt(left_var * right_var)
    if denom <= 1e-18:
        return None
    return round(sum(x * y for x, y in zip(left_centered, right_centered)) / denom, 4)


def _fold_rows(strategy_curve: list[float], equal_curve: list[float],
               test_start: int, test_window: int) -> list[dict]:
    rows = []
    cursor = test_start
    last = len(strategy_curve) - 1
    while cursor < last:
        end = min(cursor + test_window, last)
        if end - cursor < 20:
            break
        s = _curve_metrics(strategy_curve[cursor:end + 1])
        b = _curve_metrics(equal_curve[cursor:end + 1])
        rows.append({
            "start_index": cursor,
            "end_index": end,
            "bars": end - cursor,
            "return_pct": s["return_pct"],
            "benchmark_return_pct": b["return_pct"],
            "excess_return_pct": round(s["return_pct"] - b["return_pct"], 3),
            "sharpe": s["sharpe"],
            "sortino": s["sortino"],
            "calmar": s["calmar"],
            "max_drawdown_pct": s["max_drawdown_pct"],
            "max_drawdown_duration_bars": s["max_drawdown_duration_bars"],
        })
        cursor = end
    return rows


def _verdict(metrics: dict, *, min_oos_bars: int, min_folds: int,
             min_positive_fold_ratio: float, z_threshold: float) -> tuple[str, str]:
    if metrics["oos_bars"] < min_oos_bars or metrics["fold_count"] < min_folds:
        return "non démontrée", (
            f"historique OOS insuffisant : {metrics['oos_bars']} séances et "
            f"{metrics['fold_count']} fenêtres ; minimum requis {min_oos_bars} séances / {min_folds} fenêtres"
        )
    if metrics["oos_return_pct"] <= 0 or metrics["max_drawdown_pct"] < MAX_DRAWDOWN_PCT:
        return "rejetée", "performance OOS négative ou recul maximal supérieur à la limite de risque"
    if metrics["max_single_asset_weight_pct"] > 40.0:
        return "à surveiller", "concentration excessive : un actif dépasse 40 % du portefeuille simulé"
    if metrics["average_invested_asset_hhi"] > 0.50:
        return "à surveiller", "concentration moyenne excessive des positions investies (HHI > 0,50)"
    if metrics["stress_return_pct"] <= 0:
        return "rejetée", "la performance devient négative lorsque les frais et le glissement sont doublés"
    if metrics["sharpe"] <= 0:
        return "rejetée", "Sharpe OOS non positif après coûts"
    if metrics["excess_equal_weight_pct"] <= 0 or metrics["sharpe"] <= metrics["equal_weight_sharpe"]:
        return "à surveiller", "ne surperforme pas le portefeuille passif équipondéré en rendement et en Sharpe"
    if metrics["hac_t_stat"] < z_threshold:
        return "à surveiller", (
            f"surperformance positive mais statistiquement insuffisante après correction des "
            f"{metrics['strategies_tested']} stratégies (t HAC {metrics['hac_t_stat']:.2f} < {z_threshold:.2f})"
        )
    if metrics["positive_fold_ratio"] < min_positive_fold_ratio:
        return "à surveiller", "surperformance trop irrégulière d'une fenêtre walk-forward à l'autre"
    if metrics.get("median_fold_excess_pct", 0.0) <= 0:
        return "à surveiller", "la fenêtre walk-forward médiane ne surperforme pas le benchmark équipondéré"
    if metrics["stress_excess_equal_weight_pct"] <= 0:
        return "à surveiller", "l'avantage sur le benchmark disparaît sous le scénario de coûts doublés"
    return "prometteuse", "résultats OOS positifs, supérieurs au benchmark, robustes aux coûts doublés et statistiquement ajustés"


def build_allocation_model_preview(results: list[dict], risk_review: dict, *,
                                  max_strategy_weight: float = 0.25,
                                  max_invested_weight: float = 0.80) -> dict:
    """Build a fail-closed, research-only allocation preview. Never authorizes capital.

    Weights are inverse-volatility tilted by positive OOS Sharpe, subject to per-sleeve
    and total-investment caps. The preview remains 100% cash until every portfolio
    review gate is explicitly validated and no candidate pair is highly correlated.
    """
    if not 0 < max_strategy_weight <= 1 or not 0 < max_invested_weight <= 1:
        raise ValueError("Les plafonds d'allocation doivent être dans ]0, 1]")
    gates = ("asset_level_exposure_validated", "market_regime_analysis_validated",
             "sector_concentration_validated", "liquidity_validated")
    missing_gates = [gate for gate in gates if risk_review.get(gate) is not True]
    high_corr = risk_review.get("highly_correlated_pairs_abs_ge_0_75") or []
    candidates = [row for row in results if row.get("verdict") == "prometteuse"
                  and row.get("evaluated") is True]
    base = {"mode": "RESEARCH_ONLY", "capital_authorized": False,
            "strategies_activated": 0, "orders_created": 0,
            "max_strategy_weight_pct": round(max_strategy_weight * 100, 2),
            "max_invested_weight_pct": round(max_invested_weight * 100, 2)}
    if missing_gates or high_corr or not candidates:
        reasons = []
        if missing_gates:
            reasons.append("contrôles non validés : " + ", ".join(missing_gates))
        if high_corr:
            reasons.append("corrélations entre candidates >= 0,75")
        if not candidates:
            reasons.append("aucune stratégie OOS prometteuse")
        return {**base, "status": "BLOCKED_CASH_ONLY", "weights_pct": {},
                "cash_pct": 100.0, "blocked_by": reasons}

    scored = []
    for row in candidates:
        try:
            sharpe = float(row["sharpe"])
            volatility = float(row["volatility_pct"])
            if not isfinite(sharpe) or not isfinite(volatility) or sharpe <= 0 or volatility <= 0:
                continue
            scored.append((row["kind"], sharpe / volatility))
        except (KeyError, TypeError, ValueError):
            continue
    if not scored:
        return {**base, "status": "BLOCKED_CASH_ONLY", "weights_pct": {},
                "cash_pct": 100.0, "blocked_by": ["métriques Sharpe/volatilité invalides"]}

    # Iterative proportional allocation with hard sleeve and total-risk-budget caps.
    remaining = min(max_invested_weight, max_strategy_weight * len(scored))
    weights = {kind: 0.0 for kind, _ in scored}
    active = dict(scored)
    while active and remaining > 1e-12:
        total_score = sum(active.values())
        if total_score <= 0:
            break
        capped = []
        for kind, score in active.items():
            proposed = remaining * score / total_score
            room = max_strategy_weight - weights[kind]
            if proposed >= room - 1e-12:
                weights[kind] += room
                remaining -= room
                capped.append(kind)
        if not capped:
            for kind, score in active.items():
                weights[kind] += remaining * score / total_score
            remaining = 0.0
            break
        for kind in capped:
            active.pop(kind, None)
    invested = sum(weights.values())
    return {**base, "status": "MODEL_PREVIEW_ONLY",
            "weights_pct": {kind: round(weight * 100, 3) for kind, weight in weights.items() if weight > 1e-9},
            "cash_pct": round((1 - invested) * 100, 3),
            "blocked_by": [],
            "method": "Sharpe OOS positif / volatilité OOS, plafonds par stratégie et portefeuille",
            "note": "Allocation théorique de recherche ; aucune autorisation de capital ni activation."}


def evaluate_portfolio_catalog(
    bars_by_symbol: dict,
    *,
    benchmarks: dict | None = None,
    fundamentals_by_symbol: dict | None = None,
    sectors_by_symbol: dict[str, str] | None = None,
    params_by_strategy: dict | None = None,
    initial_cash: float = 100_000.0,
    fee: float = 0.0005,
    slip: float = 0.0005,
    warmup: int = 60,
    test_window: int = 126,
    min_oos_bars: int = 756,
    min_folds: int = 6,
    min_positive_fold_ratio: float = 0.60,
    alpha: float = 0.05,
    market_benchmark_corporate_actions: list | tuple | None = None,
    market_benchmark_symbol: str | None = None,
    market_benchmark_currency: str | None = None,
    market_benchmark_price_basis: str | None = None,
) -> dict:
    """Score all seven universe strategies on a continuous, chronological OOS path.

    Parameters are frozen for the entire test. No optimizer or broker is called.
    The result is a research ranking only; it cannot activate strategies.
    """
    if not isinstance(bars_by_symbol, dict) or len(bars_by_symbol) < 2:
        raise ValueError("Au moins deux séries OHLCV sont requises")
    if isinstance(warmup, bool) or not isinstance(warmup, int) or warmup < 30:
        raise ValueError("warmup doit être un entier supérieur ou égal à 30")
    if isinstance(test_window, bool) or not isinstance(test_window, int) or not 20 <= test_window <= 252:
        raise ValueError("test_window doit être un entier entre 20 et 252")
    if not 0 < alpha < 0.5:
        raise ValueError("alpha invalide")
    symbols = sorted(str(s).strip().upper() for s in bars_by_symbol)
    normalized = {str(s).strip().upper(): v for s, v in bars_by_symbol.items()}
    if len(symbols) != len(normalized) or any(not s for s in symbols):
        raise ValueError("Symboles invalides ou dupliqués")
    lengths = {len(normalized[s]) for s in symbols}
    if len(lengths) != 1:
        raise ValueError("Historique multi-actifs non synchronisé")
    n = next(iter(lengths))
    sessions = [tuple(b.ts for b in normalized[s]) for s in symbols]
    if any(s != sessions[0] for s in sessions[1:]):
        raise ValueError("Historique multi-actifs non synchronisé : dates différentes")
    if not benchmarks or any(symbol not in benchmarks for symbol in symbols):
        raise ValueError("Un indice de référence synchronisé est requis pour chaque titre")
    market_bars = benchmarks[symbols[0]]
    if len(market_bars) != n or tuple(b.ts for b in market_bars) != sessions[0]:
        raise ValueError("L'indice de référence doit être synchronisé avec l'univers")
    for symbol in symbols[1:]:
        item = benchmarks[symbol]
        if len(item) != n or tuple(b.ts for b in item) != sessions[0]:
            raise ValueError("Les indices de référence doivent partager les mêmes séances")
    for bar in market_bars:
        if any(not isfinite(float(v)) or float(v) <= 0 for v in (bar.o, bar.h, bar.l, bar.c)):
            raise ValueError("Prix OHLC de l'indice de référence invalide")
        if not isfinite(float(bar.v)) or float(bar.v) < 0:
            raise ValueError("Volume de l'indice de référence invalide")

    use_total_return_benchmark = (market_benchmark_corporate_actions is not None
                                  or market_benchmark_currency is not None
                                  or market_benchmark_symbol is not None
                                  or market_benchmark_price_basis is not None)
    total_return_events = None
    if use_total_return_benchmark:
        if (market_benchmark_corporate_actions is None
                or not isinstance(market_benchmark_currency, str)
                or not isinstance(market_benchmark_symbol, str)
                or not market_benchmark_symbol or market_benchmark_symbol != market_benchmark_symbol.upper()
                or market_benchmark_price_basis != "raw"):
            raise ValueError("Événements, symbole, devise et base de prix raw explicite requis ensemble")
        try:
            total_return_events = tuple(market_benchmark_corporate_actions)
        except TypeError:
            raise ValueError("Collection corporate actions invalide") from None
        from research_v1.quant.corporate_actions import CorporateActionEvent
        if any(not isinstance(event, CorporateActionEvent) or event.symbol != market_benchmark_symbol
               for event in total_return_events):
            raise ValueError("Les événements doivent être validés et correspondre au symbole du benchmark")
        # Validate the complete event series once before evaluating any strategy.
        from research_v1.quant.corporate_actions import dividend_total_return_index
        from datetime import datetime
        market_timestamps = [datetime.fromisoformat(bar.ts) if isinstance(bar.ts, str) else bar.ts
                             for bar in market_bars]
        dividend_total_return_index([bar.c for bar in market_bars], market_timestamps,
                                    total_return_events, currency=market_benchmark_currency, price_basis="raw")

    if fundamentals_by_symbol is not None and not isinstance(fundamentals_by_symbol, dict):
        raise ValueError("fundamentals_by_symbol doit être un objet symbole -> snapshots point-in-time")
    params_by_strategy = params_by_strategy or {}
    if not isinstance(params_by_strategy, dict):
        raise ValueError("params_by_strategy doit être un objet")
    unknown_kinds = sorted(set(params_by_strategy) - set(UNIVERSE_STRATEGIES))
    if unknown_kinds:
        raise ValueError(f"Stratégies inconnues dans params_by_strategy : {', '.join(unknown_kinds)}")
    if any(not isinstance(value, dict) for value in params_by_strategy.values()):
        raise ValueError("Chaque entrée params_by_strategy doit être un objet de paramètres")
    if isinstance(min_oos_bars, bool) or not isinstance(min_oos_bars, int) or min_oos_bars < 1:
        raise ValueError("min_oos_bars doit être un entier positif")
    if isinstance(min_folds, bool) or not isinstance(min_folds, int) or min_folds < 1:
        raise ValueError("min_folds doit être un entier positif")
    if not 0 < min_positive_fold_ratio <= 1:
        raise ValueError("min_positive_fold_ratio doit être dans ]0, 1]")
    strategies_in_scoreboard = len(UNIVERSE_STRATEGIES)
    # Use one family-wise correction across the complete 50-strategy research catalogue.
    strategies_tested = len(UNIVERSE_STRATEGIES) + len(RULE_STRATEGIES)
    z_threshold = NormalDist().inv_cdf(1 - alpha / (2 * strategies_tested))
    results = []
    evaluated_curves = {}

    for kind in sorted(UNIVERSE_STRATEGIES):
        params = dict(params_by_strategy.get(kind) or {})
        if kind == "rebalancing" and "targets" not in params:
            weight = 1.0 / len(symbols)
            params["targets"] = {s: weight for s in symbols}
        effective_warmup = max(warmup, required_warmup(kind, params))
        if kind == "multi_factor" and not fundamentals_by_symbol:
            results.append({"kind": kind, "label": make(kind, f"label-{kind}", params, symbols).label,
                            "verdict": "non démontrée",
                            "reason": "aucune série de fondamentaux historisés point-in-time n'est disponible ; des valeurs statiques introduiraient un biais de regard vers le futur",
                            "effective_warmup": effective_warmup, "oos_bars": 0, "folds": [],
                            "evaluated": False, "blocked_by": "point_in_time_fundamentals_missing"})
            continue
        if n < effective_warmup + 3:
            results.append({"kind": kind, "label": make(kind, f"label-{kind}", params, symbols).label,
                            "verdict": "non démontrée", "reason": f"historique insuffisant : {n} barres, {effective_warmup} requises avant le test",
                            "effective_warmup": effective_warmup, "oos_bars": 0, "folds": [],
                            "evaluated": False, "blocked_by": "insufficient_history"})
            continue

        strategy_fundamentals = fundamentals_by_symbol if kind == "multi_factor" else None
        base = simulate_portfolio(kind, normalized, params=params, fundamentals=strategy_fundamentals,
                                  benchmarks=benchmarks, initial_cash=initial_cash, fee=fee,
                                  slip=slip, warmup=effective_warmup)
        stress = simulate_portfolio(kind, normalized, params=params, fundamentals=strategy_fundamentals,
                                    benchmarks=benchmarks, initial_cash=initial_cash, fee=min(fee * 2, 0.02),
                                    slip=min(slip * 2, 0.02), warmup=effective_warmup,
                                    include_asset_weights=False)
        strategy_curve = [float(x) for x in base["equity_curve"]]
        equal_curve = [float(x) for x in base["benchmark"]["equity_curve"]]
        stress_curve = [float(x) for x in stress["equity_curve"]]
        stress_equal_curve = [float(x) for x in stress["benchmark"]["equity_curve"]]
        market_curve = _market_buy_hold_curve(market_bars, n, effective_warmup,
                                              initial_cash, fee, slip)
        market_total_return_curve = (_market_total_return_buy_hold_curve(
            market_bars, total_return_events, currency=market_benchmark_currency,
            initial_cash=initial_cash, fee=fee, slip=slip, warmup=effective_warmup,
            price_basis=market_benchmark_price_basis)
            if use_total_return_benchmark else None)
        stress_market_curve = _market_buy_hold_curve(market_bars, n, effective_warmup,
                                                     initial_cash, min(fee * 2, 0.02),
                                                     min(slip * 2, 0.02))
        start = effective_warmup
        strategy_oos = strategy_curve[start:]
        equal_oos = equal_curve[start:]
        market_oos = market_curve[start:]
        stress_oos = stress_curve[start:]
        stress_equal_oos = stress_equal_curve[start:]
        asset_exposure = _asset_exposure_summary(base["asset_weights_curve"][start:])
        sector_audit = audit_sector_exposure(base["asset_weights_curve"][start:], sectors_by_symbol)
        regime_breakdown = _market_regime_breakdown(
            strategy_curve, market_curve, market_bars, start, lookback=63, threshold=0.05)
        s_metrics = _curve_metrics(strategy_oos)
        e_metrics = _curve_metrics(equal_oos)
        m_metrics = _curve_metrics(market_oos)
        st_metrics = _curve_metrics(stress_oos)
        st_eq_metrics = _curve_metrics(stress_equal_oos)
        strategy_daily = [strategy_curve[i] / strategy_curve[i - 1] - 1 for i in range(start + 1, n)]
        equal_daily = [equal_curve[i] / equal_curve[i - 1] - 1 for i in range(start + 1, n)]
        paired_excess = [a - b for a, b in zip(strategy_daily, equal_daily)]
        folds = _fold_rows(strategy_curve, equal_curve, start, test_window)
        fold_excess = [float(row["excess_return_pct"]) for row in folds]
        positive_folds = sum(1 for value in fold_excess if value > 0)
        fold_ratio = positive_folds / len(folds) if folds else 0.0
        median_fold_excess = median(fold_excess) if fold_excess else 0.0
        worst_fold_excess = min(fold_excess) if fold_excess else 0.0
        oos_bars = max(0, n - start - 1)
        metrics = {
            "oos_bars": oos_bars,
            "fold_count": len(folds),
            "positive_folds": positive_folds,
            "positive_fold_ratio": round(fold_ratio, 3),
            "median_fold_excess_pct": round(median_fold_excess, 3),
            "worst_fold_excess_pct": round(worst_fold_excess, 3),
            "oos_return_pct": s_metrics["return_pct"],
            "cagr_pct": s_metrics["cagr_pct"],
            "sharpe": s_metrics["sharpe"],
            "sortino": s_metrics["sortino"],
            "calmar": s_metrics["calmar"],
            "max_drawdown_duration_bars": s_metrics["max_drawdown_duration_bars"],
            "volatility_pct": s_metrics["volatility_pct"],
            "max_drawdown_pct": s_metrics["max_drawdown_pct"],
            "equal_weight_return_pct": e_metrics["return_pct"],
            "equal_weight_sharpe": e_metrics["sharpe"],
            "excess_equal_weight_pct": round(s_metrics["return_pct"] - e_metrics["return_pct"], 3),
            "market_return_pct": m_metrics["return_pct"],
            "market_sharpe": m_metrics["sharpe"],
            "excess_market_pct": round(s_metrics["return_pct"] - m_metrics["return_pct"], 3),
            "hac_t_stat": round(_hac_t_stat(paired_excess), 3),
            "stress_return_pct": st_metrics["return_pct"],
            "stress_excess_equal_weight_pct": round(st_metrics["return_pct"] - st_eq_metrics["return_pct"], 3),
            "stress_excess_market_pct": round(st_metrics["return_pct"] - _curve_metrics(stress_market_curve[start:])["return_pct"], 3),
            "trades": base["metrics"]["trades"],
            "exposure_pct": round(mean(base["exposure_curve"][start:]) * 100, 2),
            "strategies_tested": strategies_tested,
            "z_threshold": round(z_threshold, 3),
            "effective_warmup": effective_warmup,
            "average_invested_pct": asset_exposure["average_invested_pct"],
            "max_single_asset_weight_pct": asset_exposure["max_single_asset_weight_pct"],
            "average_invested_asset_hhi": asset_exposure["average_invested_asset_hhi"],
            "max_simultaneous_positions": asset_exposure["max_simultaneous_positions"],
        }
        if market_total_return_curve is not None:
            market_total_metrics = _curve_metrics(market_total_return_curve[start:])
            metrics["market_total_return_pct"] = market_total_metrics["return_pct"]
            metrics["market_total_return_cagr_pct"] = market_total_metrics["cagr_pct"]
            metrics["excess_market_total_return_pct"] = round(
                s_metrics["return_pct"] - market_total_metrics["return_pct"], 3)
        verdict_value, reason = _verdict(metrics, min_oos_bars=min_oos_bars,
                                         min_folds=min_folds,
                                         min_positive_fold_ratio=min_positive_fold_ratio,
                                         z_threshold=z_threshold)
        evaluated_curves[kind] = (strategy_curve, effective_warmup)
        results.append({"kind": kind, "label": make(kind, f"label-{kind}", params, symbols).label,
                        "params": params, **metrics, "asset_exposure": asset_exposure,
                        "market_regime_breakdown": regime_breakdown, "sector_audit": sector_audit,
                        "verdict": verdict_value, "reason": reason, "folds": folds,
                        "evaluated": True})

    results.sort(key=lambda r: (VERDICTS.index(r["verdict"]),
                                -r.get("sharpe", -999),
                                -r.get("excess_equal_weight_pct", -999)))
    candidates = [r["kind"] for r in results if r.get("verdict") == "prometteuse"]
    # Compare strategy-level return streams on their common OOS date intersection.
    # Position weights are measured separately from each strategy's OOS simulation.
    common_start = max((item[1] for item in evaluated_curves.values()), default=n - 1)
    common_series = {
        kind: [curve[i] / curve[i - 1] - 1 for i in range(common_start + 1, n)]
        for kind, (curve, _) in evaluated_curves.items()
    }
    # Explicit dated net OOS returns for downstream research portfolio simulation.
    # The common intersection prevents asynchronous strategy streams and uses
    # only the independently evaluated OOS portion of each frozen-parameter run.
    common_oos_timestamps = list(sessions[0][common_start + 1:n])
    oos_return_streams = {
        kind: [
            {"timestamp": timestamp, "return_pct": round(value * 100.0, 10)}
            for timestamp, value in zip(common_oos_timestamps, values)
        ]
        for kind, values in common_series.items()
    }
    correlation_matrix = {}
    for kind, values in common_series.items():
        correlation_matrix[kind] = {other: (1.0 if kind == other else _pearson_correlation(values, peer))
                                    for other, peer in common_series.items()}
    candidate_pairs = []
    candidate_correlations = {}
    for kind in candidates:
        candidate_correlations[kind] = {other: correlation_matrix.get(kind, {}).get(other)
                                        for other in candidates}
    for idx, left in enumerate(candidates):
        for right in candidates[idx + 1:]:
            corr = candidate_correlations[left][right]
            if corr is not None:
                candidate_pairs.append({"left": left, "right": right, "correlation": corr})
    high_corr = [pair for pair in candidate_pairs if abs(pair["correlation"]) >= 0.75]
    max_candidate_corr = max((abs(pair["correlation"]) for pair in candidate_pairs), default=None)
    portfolio_risk_review = {
        "status": "REVIEW_REQUIRED" if candidates else "NO_OOS_CANDIDATES",
        "candidate_strategies": candidates,
        "common_oos_bars": len(next(iter(common_series.values()))) if common_series else 0,
        "strategy_return_correlation_method": "Pearson on common OOS daily net returns",
        "candidate_correlation_matrix": candidate_correlations,
        "candidate_pairs": candidate_pairs,
        "highly_correlated_pairs_abs_ge_0_75": high_corr,
        "max_abs_candidate_correlation": round(max_candidate_corr, 4) if max_candidate_corr is not None else None,
        "concentration_screen": {
            "max_single_asset_weight_pct": 40.0,
            "max_average_invested_asset_hhi": 0.50,
            "scope": "individual strategy simulated portfolio, not combined live portfolio",
            "passed_by_candidate": {
                row["kind"]: (
                    row.get("max_single_asset_weight_pct", 101.0) <= 40.0
                    and row.get("average_invested_asset_hhi", 1.0) <= 0.50
                )
                for row in results if row.get("kind") in candidates
            },
        },
        "asset_level_exposure_measured": True,
        "market_regime_analysis_measured": True,
        "market_regime_analysis_validated": False,
        "asset_level_exposure_validated": False,
        "candidate_asset_exposure": {
            kind: next((row.get("asset_exposure") for row in results if row.get("kind") == kind), None)
            for kind in candidates
        },
        "asset_level_exposure_reviewed": False,
        "sector_concentration_validated": False,
        "sector_audit_available": sectors_by_symbol is not None,
        "liquidity_validated": False,
        "capital_authorized": False,
        "reason": "Les poids et la concentration des actifs sont désormais mesurés dans l'OOS, mais doivent être revus avec les secteurs, la liquidité, les spreads, les drawdowns et les limites de risque avant toute allocation.",
    }
    selection_preview = {
        "mode": "RESEARCH_ONLY",
        "status": "CANDIDATES_REQUIRE_PORTFOLIO_RISK_REVIEW" if candidates else "NO_ELIGIBLE_STRATEGY_CASH_ONLY",
        "candidate_strategies": candidates,
        "cash_pct": 100.0,
        "capital_authorized": False,
        "strategies_activated": 0,
        "orders_created": 0,
        "reason": ("Des candidates ont passé le filtre OOS mais restent en observation : la corrélation stratégie, les expositions par actif/secteur, les limites de risque et la validation Paper ne sont pas encore autorisées."
                   if candidates else "Aucune stratégie ne franchit tous les critères OOS et de stress ; le repli automatique est de conserver 100 % de liquidités."),
    }
    allocation_model_preview = build_allocation_model_preview(results, portfolio_risk_review)
    return {
        "mode": "WALK_FORWARD_OOS_RESEARCH",
        "symbols": symbols,
        "bars": n,
        "fee": fee,
        "slippage": slip,
        "test_window": test_window,
        "requested_warmup": warmup,
        "minimum_oos_bars": min_oos_bars,
        "minimum_folds": min_folds,
        "multiple_testing": {"method": "Bonferroni two-sided across the full V1 research catalogue",
                             "alpha": alpha, "family_size": strategies_tested,
                             "strategies_in_scoreboard": strategies_in_scoreboard,
                             "tested_count": strategies_in_scoreboard,
                             "evaluated_count": sum(1 for r in results if r.get("evaluated", True)),
                             "z_threshold": round(z_threshold, 3)},
        "results": results,
        "market_total_return_benchmark": ({
            "enabled": True,
            "symbol": market_benchmark_symbol,
            "currency": market_benchmark_currency,
            "corporate_action_events": len(total_return_events),
            "price_basis": market_benchmark_price_basis,
            "dividend_policy": "reinvested_at_ex_date_close",
            "affects_strategy_verdict": False,
            "note": "Benchmark descriptif séparé ; ne modifie ni le classement ni les verdicts de stratégie.",
        } if use_total_return_benchmark else {"enabled": False}),
        "counts": {v: sum(1 for r in results if r["verdict"] == v) for v in VERDICTS},
        "oos_return_streams": oos_return_streams,
        "oos_return_streams_metadata": {
            "method": "common OOS intersection; daily net portfolio returns from frozen-parameter simulations",
            "first_timestamp": common_oos_timestamps[0] if common_oos_timestamps else None,
            "last_timestamp": common_oos_timestamps[-1] if common_oos_timestamps else None,
            "observations": len(common_oos_timestamps),
        },
        "strategy_return_correlation": {
            "method": "Pearson on common OOS daily net returns",
            "common_oos_bars": len(next(iter(common_series.values()))) if common_series else 0,
            "matrix": correlation_matrix,
        },
        "portfolio_risk_review": portfolio_risk_review,
        "selection_preview": selection_preview,
        "allocation_model_preview": allocation_model_preview,
        "execution": "NONE",
        "broker_access": False,
        "orders_created": 0,
        "strategies_activated": 0,
        "profitability_guaranteed": False,
        "caveats": [
            "Les paramètres sont figés avant toute la période évaluée ; aucune optimisation n'est faite sur l'OOS.",
            "Les fenêtres sont des segments chronologiques d'un portefeuille continu, pas des portefeuilles réinitialisés ; le verdict exige aussi une surperformance médiane positive entre fenêtres.",
            "Le t-stat utilise une variance Newey-West avec correction d'autocorrélation ; le seuil Bonferroni couvre les 50 stratégies du catalogue (43 par titre et 7 portefeuille), même si ce tableau n'en affiche que sept.",
            "Le scénario de stress double les frais et le glissement ; il ne modélise pas l'impact de marché ni la liquidité intraday.",
            "L'attribution de régime utilise le rendement de marché des 63 séances précédentes, connu à la clôture précédente ; les sous-échantillons de moins de 20 séances sont signalés comme insuffisants et ne prouvent pas la robustesse du régime.",
            "Multi-Factor n'est évaluée que si chaque actif possède des snapshots fondamentaux disponibles à la date de publication (available_at) ; les fondamentaux statiques sont interdits.",
            "L'horodatage available_at doit provenir d'une source publique vérifiable ; le moteur ne peut pas certifier seul la provenance du fournisseur de données.",
            "Un verdict prometteuse est un signal de recherche, pas une preuve de rentabilité future ni une autorisation de trading.",
        ],
    }
