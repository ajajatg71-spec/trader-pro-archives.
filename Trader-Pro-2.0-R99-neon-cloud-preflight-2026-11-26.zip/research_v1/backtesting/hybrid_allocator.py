"""Research-only hybrid multi-strategy allocator.

This module converts approved strategy research metrics into constrained target
weights. It has no broker, order, account, or production-risk imports. Outputs
are proposals only; human approval and the V2 risk/order path remain mandatory.
"""
from __future__ import annotations

from math import isfinite
from typing import Any, Mapping, Sequence


_REQUIRED = {
    "strategy_id", "expected_return_pct", "volatility_pct",
    "max_drawdown_pct", "confidence", "stability_score", "liquidity_score",
}


def _number(value: Any, name: str, *, minimum: float | None = None,
            maximum: float | None = None) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{name} must be numeric")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{name} must be numeric") from exc
    if not isfinite(result):
        raise ValueError(f"{name} must be finite")
    if minimum is not None and result < minimum:
        raise ValueError(f"{name} is below its permitted range")
    if maximum is not None and result > maximum:
        raise ValueError(f"{name} is above its permitted range")
    return result


def allocate_hybrid_portfolio(
    candidates: Sequence[Mapping[str, Any]],
    *,
    correlations: Mapping[str, Mapping[str, float]] | None = None,
    max_total_exposure: float = 0.90,
    max_strategy_weight: float = 0.35,
    risk_budget_pct: float = 0.12,
    max_drawdown_pct: float = 25.0,
    correlation_penalty: float = 0.50,
) -> dict[str, Any]:
    """Return a deterministic, long-only research allocation proposal.

    Candidate metrics must be computed from validated out-of-sample research.
    expected_return_pct is an estimate, not a forecast or promise. Correlation
    inputs must refer to the same OOS return window. Missing pairwise values are
    treated conservatively as 1.0 (fully correlated).
    """
    total_cap = _number(max_total_exposure, "max_total_exposure", minimum=0.0, maximum=1.0)
    per_cap = _number(max_strategy_weight, "max_strategy_weight", minimum=0.0, maximum=1.0)
    budget = _number(risk_budget_pct, "risk_budget_pct", minimum=0.0, maximum=1.0)
    dd_limit = _number(max_drawdown_pct, "max_drawdown_pct", minimum=0.0, maximum=100.0)
    corr_penalty = _number(correlation_penalty, "correlation_penalty", minimum=0.0, maximum=1.0)
    if not isinstance(candidates, Sequence) or isinstance(candidates, (str, bytes)):
        raise ValueError("candidates must be a sequence")
    if not isinstance(correlations or {}, Mapping):
        raise ValueError("correlations must be a mapping")

    parsed = []
    seen = set()
    rejected = []
    for row in candidates:
        if not isinstance(row, Mapping) or not _REQUIRED.issubset(row):
            raise ValueError("candidate is missing required research metrics")
        sid = row["strategy_id"]
        if not isinstance(sid, str) or not sid.strip() or sid in seen:
            raise ValueError("strategy_id must be unique and non-empty")
        seen.add(sid)
        expected = _number(row["expected_return_pct"], f"{sid}.expected_return_pct")
        vol = _number(row["volatility_pct"], f"{sid}.volatility_pct", minimum=1e-9)
        dd = _number(row["max_drawdown_pct"], f"{sid}.max_drawdown_pct", minimum=0.0, maximum=100.0)
        confidence = _number(row["confidence"], f"{sid}.confidence", minimum=0.0, maximum=1.0)
        stability = _number(row["stability_score"], f"{sid}.stability_score", minimum=0.0, maximum=1.0)
        liquidity = _number(row["liquidity_score"], f"{sid}.liquidity_score", minimum=0.0, maximum=1.0)
        if expected <= 0:
            rejected.append({"strategy_id": sid, "reason": "non_positive_oos_expectancy"})
            continue
        if dd > dd_limit:
            rejected.append({"strategy_id": sid, "reason": "drawdown_limit_exceeded"})
            continue
        # Quality combines multiple independent dimensions; volatility scales
        # the estimated edge. This is a ranking heuristic, not a return forecast.
        quality = confidence * stability * liquidity
        risk_adjusted_edge = (expected / vol) * quality
        if risk_adjusted_edge <= 0:
            rejected.append({"strategy_id": sid, "reason": "insufficient_quality_score"})
            continue
        parsed.append({
            "strategy_id": sid, "expected": expected, "vol": vol,
            "drawdown": dd, "quality": quality, "edge": risk_adjusted_edge,
        })

    if not parsed or total_cap == 0 or per_cap == 0 or budget == 0:
        return {
            "mode": "RESEARCH_ALLOCATION_PROPOSAL",
            "weights": {}, "total_exposure": 0.0, "risk_budget_pct": budget,
            "rejected": rejected, "selected_count": 0,
            "capital_authorized": False, "orders_created": 0, "broker_access": False,
        }

    # Greedy diversification: rank by quality-adjusted edge, then discount
    # candidates correlated with already selected strategies.
    corr = correlations or {}
    remaining = list(parsed)
    selected = []
    while remaining:
        ranked = []
        for item in remaining:
            prior = []
            for chosen in selected:
                raw = (corr.get(item["strategy_id"], {}) or {}).get(chosen["strategy_id"])
                if raw is None:
                    raw = (corr.get(chosen["strategy_id"], {}) or {}).get(item["strategy_id"])
                value = 1.0 if raw is None else _number(
                    raw, "correlation", minimum=-1.0, maximum=1.0
                )
                prior.append(max(0.0, value))
            mean_corr = sum(prior) / len(prior) if prior else 0.0
            adjusted = item["edge"] * (1.0 - corr_penalty * mean_corr)
            ranked.append((adjusted, item["strategy_id"], item, mean_corr))
        ranked.sort(key=lambda x: (-x[0], x[1]))
        score, _, winner, mean_corr = ranked[0]
        if score <= 0:
            break
        winner = dict(winner)
        winner["diversification_score"] = score
        winner["mean_positive_correlation"] = mean_corr
        selected.append(winner)
        remaining.remove(next(x for x in remaining if x["strategy_id"] == winner["strategy_id"]))

    # Quality-adjusted inverse-volatility weights; cap each strategy and total.
    raw_weights = {
        item["strategy_id"]: (item["quality"] / item["vol"])
        for item in selected
    }
    raw_total = sum(raw_weights.values())
    weights = {}
    for item in selected:
        sid = item["strategy_id"]
        proposed = (raw_weights[sid] / raw_total) * total_cap
        weights[sid] = min(per_cap, proposed)

    # Redistribute only into remaining headroom, never exceeding either cap.
    target_total = min(total_cap, sum(min(per_cap, (raw_weights[s["strategy_id"]] / raw_total) * total_cap)
                                      for s in selected))
    for _ in range(len(selected)):
        current = sum(weights.values())
        residual = target_total - current
        if residual <= 1e-12:
            break
        eligible = [s for s in selected if weights[s["strategy_id"]] < per_cap - 1e-12]
        if not eligible:
            break
        denom = sum(raw_weights[s["strategy_id"]] for s in eligible)
        if denom <= 0:
            break
        for s in eligible:
            sid = s["strategy_id"]
            add = residual * raw_weights[sid] / denom
            weights[sid] = min(per_cap, weights[sid] + add)

    # Dynamic risk budget is an upper bound on gross exposure; the allocation
    # never increases it automatically. Unallocated capital remains cash.
    risk_cap = min(total_cap, budget / max(
        sum((weights[s["strategy_id"]] * s["vol"] / 100.0) for s in selected), 1e-12
    ) * total_cap)
    if risk_cap < sum(weights.values()):
        scale = risk_cap / sum(weights.values())
        weights = {sid: weight * scale for sid, weight in weights.items()}

    rounded = {sid: round(weight, 10) for sid, weight in weights.items() if weight > 1e-10}
    return {
        "mode": "RESEARCH_ALLOCATION_PROPOSAL",
        "weights": rounded,
        "total_exposure": round(sum(rounded.values()), 10),
        "risk_budget_pct": budget,
        "risk_cap_exposure": round(risk_cap, 10),
        "selected_count": len(rounded),
        "selection_order": [s["strategy_id"] for s in selected],
        "diagnostics": {
            s["strategy_id"]: {
                "quality_score": round(s["quality"], 6),
                "risk_adjusted_edge": round(s["edge"], 6),
                "mean_positive_correlation": round(s["mean_positive_correlation"], 6),
            } for s in selected
        },
        "rejected": rejected,
        "capital_authorized": False,
        "orders_created": 0,
        "broker_access": False,
    }


def build_hybrid_allocation_from_scoreboard(
    scoreboard: Mapping[str, Any],
    *,
    liquidity_scores: Mapping[str, float],
    max_total_exposure: float = 0.80,
    max_strategy_weight: float = 0.25,
    risk_budget_pct: float = 0.12,
    max_drawdown_pct: float = 25.0,
    correlation_penalty: float = 0.50,
) -> dict[str, Any]:
    """Build a research-only proposal from a portfolio OOS scoreboard.

    Only evaluated ``prometteuse`` rows are eligible. The liquidity score must
    be supplied separately from validated market microstructure evidence; it is
    deliberately not inferred from OHLCV backtest metrics. Confidence is a
    conservative bounded transform of the HAC t-statistic, and stability is
    the positive-fold ratio. The scoreboard correlation matrix is reused only
    when its common OOS observations are present.
    """
    if not isinstance(scoreboard, Mapping):
        raise ValueError("scoreboard must be a mapping")
    if not isinstance(liquidity_scores, Mapping):
        raise ValueError("liquidity_scores must be a mapping")
    results = scoreboard.get("results")
    if not isinstance(results, Sequence) or isinstance(results, (str, bytes)):
        raise ValueError("scoreboard results must be a sequence")
    corr_section = scoreboard.get("strategy_return_correlation") or {}
    if not isinstance(corr_section, Mapping):
        raise ValueError("strategy_return_correlation must be a mapping")
    matrix = corr_section.get("matrix") or {}
    if not isinstance(matrix, Mapping):
        raise ValueError("correlation matrix must be a mapping")

    candidates = []
    rejected = []
    for row in results:
        if not isinstance(row, Mapping):
            raise ValueError("scoreboard result rows must be mappings")
        sid = row.get("kind")
        if row.get("evaluated") is not True or row.get("verdict") != "prometteuse":
            continue
        if not isinstance(sid, str) or not sid.strip():
            raise ValueError("eligible scoreboard row has no strategy kind")
        required = ("cagr_pct", "volatility_pct", "max_drawdown_pct",
                    "hac_t_stat", "positive_fold_ratio")
        if any(key not in row for key in required):
            rejected.append({"strategy_id": sid, "reason": "missing_oos_metric"})
            continue
        if sid not in liquidity_scores:
            rejected.append({"strategy_id": sid, "reason": "validated_liquidity_score_missing"})
            continue
        t_stat = _number(row["hac_t_stat"], f"{sid}.hac_t_stat")
        confidence = min(1.0, max(0.0, t_stat / 3.0))
        candidates.append({
            "strategy_id": sid,
            "expected_return_pct": _number(row["cagr_pct"], f"{sid}.cagr_pct"),
            "volatility_pct": _number(row["volatility_pct"], f"{sid}.volatility_pct"),
            "max_drawdown_pct": abs(_number(row["max_drawdown_pct"], f"{sid}.max_drawdown_pct")),
            "confidence": confidence,
            "stability_score": _number(
                row["positive_fold_ratio"], f"{sid}.positive_fold_ratio", minimum=0.0, maximum=1.0
            ),
            "liquidity_score": _number(
                liquidity_scores[sid], f"{sid}.liquidity_score", minimum=0.0, maximum=1.0
            ),
        })

    eligible_ids = {row["strategy_id"] for row in candidates}
    correlations = {
        sid: {
            other: value
            for other, value in (matrix.get(sid, {}) or {}).items()
            if other in eligible_ids and value is not None
        }
        for sid in eligible_ids
    }
    proposal = allocate_hybrid_portfolio(
        candidates,
        correlations=correlations,
        max_total_exposure=max_total_exposure,
        max_strategy_weight=max_strategy_weight,
        risk_budget_pct=risk_budget_pct,
        max_drawdown_pct=max_drawdown_pct,
        correlation_penalty=correlation_penalty,
    )
    proposal["rejected"] = rejected + proposal["rejected"]
    proposal["source"] = "evaluated_promising_portfolio_oos_scoreboard"
    proposal["liquidity_evidence_required"] = True
    proposal["common_oos_correlation_required"] = True
    proposal["capital_authorized"] = False
    proposal["orders_created"] = 0
    proposal["broker_access"] = False
    return proposal
