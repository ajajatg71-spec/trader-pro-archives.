"""Versioned, strictly validated state container for continuous research portfolios.

This module is deliberately broker-independent. It defines the persistence contract
before the simulator is wired to resume from it.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from math import isfinite
from typing import Any


SCHEMA_VERSION = 1
_ALLOWED_INTENT_KEYS = {
    "strategy", "symbol", "side", "kind", "reason", "weight",
    "confidence", "evidence", "notional", "decision_timestamp",
}


def _finite_number(value: Any, field_name: str, *, minimum: float | None = None) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{field_name} must be a finite number")
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{field_name} must be a finite number") from exc
    if not isfinite(number) or (minimum is not None and number < minimum):
        raise ValueError(f"{field_name} is outside its valid range")
    return number


@dataclass
class PortfolioState:
    """Serializable long-only portfolio state at a completed bar close."""

    universe: list[str]
    cash: float
    positions: dict[str, dict[str, Any]] = field(default_factory=dict)
    pending_intents: list[dict[str, Any]] = field(default_factory=list)
    last_index: int = -1
    last_timestamp: str | None = None
    last_equity: float | None = None
    cumulative_fees: float = 0.0
    cumulative_slippage: float = 0.0
    fills: list[dict[str, Any]] = field(default_factory=list)
    closed_trades: list[dict[str, Any]] = field(default_factory=list)
    schema_version: int = SCHEMA_VERSION

    def validate(self) -> "PortfolioState":
        if self.schema_version != SCHEMA_VERSION:
            raise ValueError("Unsupported portfolio state schema_version")
        if not isinstance(self.universe, list) or not self.universe:
            raise ValueError("universe must be a non-empty list")
        normalized = [str(symbol).strip().upper() for symbol in self.universe]
        if any(not symbol for symbol in normalized) or len(set(normalized)) != len(normalized):
            raise ValueError("universe contains blank or duplicate symbols")
        if normalized != self.universe:
            raise ValueError("universe symbols must be normalized uppercase strings")
        self.cash = _finite_number(self.cash, "cash", minimum=0.0)
        if isinstance(self.last_index, bool) or not isinstance(self.last_index, int) or self.last_index < -1:
            raise ValueError("last_index must be an integer >= -1")
        if self.last_index == -1 and self.last_timestamp is not None:
            raise ValueError("unstarted state cannot have last_timestamp")
        if self.last_index >= 0 and (not isinstance(self.last_timestamp, str) or not self.last_timestamp.strip()):
            raise ValueError("started state requires last_timestamp")
        if self.last_equity is not None:
            self.last_equity = _finite_number(self.last_equity, "last_equity", minimum=0.0)
        self.cumulative_fees = _finite_number(self.cumulative_fees, "cumulative_fees", minimum=0.0)
        self.cumulative_slippage = _finite_number(self.cumulative_slippage, "cumulative_slippage", minimum=0.0)
        if not isinstance(self.positions, dict) or not isinstance(self.pending_intents, list):
            raise ValueError("positions and pending_intents have invalid types")
        for symbol, position in self.positions.items():
            if symbol not in self.universe or not isinstance(position, dict):
                raise ValueError("position symbol or record is invalid")
            if set(position) != {"qty", "avg", "held_since"}:
                raise ValueError("position fields are invalid")
            _finite_number(position["qty"], f"positions.{symbol}.qty", minimum=1e-12)
            _finite_number(position["avg"], f"positions.{symbol}.avg", minimum=1e-12)
            if not isinstance(position["held_since"], str) or not position["held_since"].strip():
                raise ValueError(f"positions.{symbol}.held_since is required")
        for intent in self.pending_intents:
            if not isinstance(intent, dict) or set(intent) - _ALLOWED_INTENT_KEYS:
                raise ValueError("pending intent has invalid fields")
            required = {"strategy", "symbol", "side", "kind", "reason"}
            if not required.issubset(intent):
                raise ValueError("pending intent is missing required fields")
            if intent["symbol"] not in self.universe or intent["side"] not in {"buy", "sell"}:
                raise ValueError("pending intent symbol or side is invalid")
            if not all(isinstance(intent[key], str) and intent[key].strip() for key in required):
                raise ValueError("pending intent text fields must be non-empty")
            for key, default in (("weight", 1.0), ("confidence", 0.5)):
                _finite_number(intent.get(key, default), f"pending_intent.{key}", minimum=0.0)
            if "notional" in intent and intent["notional"] is not None:
                _finite_number(intent["notional"], "pending_intent.notional", minimum=0.0)
            if "evidence" in intent and not isinstance(intent["evidence"], list):
                raise ValueError("pending intent evidence must be a list")
        if not isinstance(self.fills, list) or not isinstance(self.closed_trades, list):
            raise ValueError("fills and closed_trades must be lists")
        if any(not isinstance(row, dict) for row in self.fills + self.closed_trades):
            raise ValueError("fills and closed_trades entries must be objects")
        return self

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "PortfolioState":
        if not isinstance(payload, dict):
            raise ValueError("portfolio state must be an object")
        allowed = set(cls.__dataclass_fields__)
        if set(payload) - allowed:
            raise ValueError("portfolio state contains unknown fields")
        required = {"universe", "cash"}
        if not required.issubset(payload):
            raise ValueError("portfolio state is missing required fields")
        return cls(**payload).validate()
