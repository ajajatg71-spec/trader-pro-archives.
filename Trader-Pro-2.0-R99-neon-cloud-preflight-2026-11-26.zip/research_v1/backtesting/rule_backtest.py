"""Backtest d'une stratégie à règles sur un titre : signal à la clôture de la barre t (données jusqu'à t seulement), exécution à l'OUVERTURE de t+1 avec glissement et frais."""
from research_v1.quant.features import Features
from research_v1.strategies import catalog
from research_v1.strategies.types import Context, SymbolData

def simulate(bars, kind, params=None, bench=None, fee=0.0005, slip=0.0005, warmup=60, cash=10000.0, features=None):
    """Simule la stratégie `kind` (une règle du catalogue) en investissant tout le capital sur la ligne à chaque entrée. Renvoie {eq, pos, trades, closed} :
    eq = capital à chaque clôture, pos = 1 si investi, trades = [(indice de la barre de sortie, rendement)], closed = détail des trades fermés."""
    strat = catalog.make(kind, "bt", params or {}, ["S"])
    if not isinstance(strat, catalog.RuleStrategy): raise ValueError(f"{kind} n'est pas une stratégie à règles par titre")
    n, f = len(bars), features or Features(bars, bench); qty, cash_, entry, pending, eq, ps, trades, closed = 0.0, cash, None, None, [], [], [], []
    for t in range(n):
        if pending == "buy" and qty == 0:
            px = bars[t].o * (1 + slip); qty = cash_ * (1 - fee) / px; entry = {"i": t, "px": px, "ts": bars[t].ts, "cash": cash_}; cash_ = 0.0
        elif pending == "sell" and qty > 0:
            px = bars[t].o * (1 - slip); cash_ = qty * px * (1 - fee); r = cash_ / entry["cash"] - 1; trades.append((t, r)); closed.append({"entry_index": entry["i"], "exit_index": t, "entry_price": entry["px"], "exit_price": px, "return": r, "bars": t - entry["i"]}); qty, entry = 0.0, None
        pending = None; equity = cash_ + qty * bars[t].c; eq.append(equity); ps.append(1 if qty > 0 else 0)
        if warmup <= t < n - 1:
            pos = {"S": {"qty": qty, "avg": entry["px"], "value": qty * bars[t].c, "held_since": entry["ts"], "price": bars[t].c}} if qty > 0 else {}
            out = strat.evaluate(Context(bars[t].ts, {"S": SymbolData("S", bars, None, None, bench, injected=f.at(t))}, pos, equity))
            if qty == 0 and any(i.side == "buy" for i in out): pending = "buy"
            elif qty > 0 and any(i.side == "sell" for i in out): pending = "sell"
    return {"eq": eq, "pos": ps, "trades": trades, "closed": closed}

def buy_and_hold(bars, fee=0.0005, slip=0.0005, warmup=60, cash=10000.0):
    """Référence : achat à l'ouverture de la barre warmup+1 et conservation jusqu'à la fin, mêmes frais et même glissement."""
    n, qty, eq, ps = len(bars), 0.0, [], []
    for t in range(n):
        if t == warmup + 1 and n > warmup + 1: qty = cash * (1 - fee) / (bars[t].o * (1 + slip)); cash = 0.0
        eq.append(cash + qty * bars[t].c); ps.append(1 if qty > 0 else 0)
    return {"eq": eq, "pos": ps, "trades": []}
