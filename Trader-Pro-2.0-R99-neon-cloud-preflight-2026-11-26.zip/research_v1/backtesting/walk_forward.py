"""Chronological parameter search with strictly frozen out-of-sample folds.

Each fold selects parameters using only the prefix ending at train_end. The
selected parameter set is then evaluated on the subsequent test window. Fold
capital is reset deliberately: results are independent fold diagnostics, not
a continuous deployable portfolio or an execution instruction.
"""
from __future__ import annotations

from math import isfinite
from statistics import mean

from research_v1.backtesting.portfolio_backtest import simulate_portfolio
from research_v1.backtesting.portfolio_scoreboard import required_warmup


def _validate_inputs(bars_by_symbol, kind, parameter_sets, *, train_bars, validation_bars,
                     test_bars, step_bars, fee, slippage, initial_cash):
    if not isinstance(bars_by_symbol, dict) or len(bars_by_symbol) < 2:
        raise ValueError("Au moins deux séries OHLCV sont requises")
    if not isinstance(parameter_sets, list) or not parameter_sets:
        raise ValueError("parameter_sets doit être une liste non vide")
    if len(parameter_sets) > 100:
        raise ValueError("Maximum 100 jeux de paramètres par recherche")
    if any(not isinstance(params, dict) for params in parameter_sets):
        raise ValueError("Chaque jeu de paramètres doit être un objet")
    for name, value in (("train_bars", train_bars), ("validation_bars", validation_bars),
                        ("test_bars", test_bars), ("step_bars", step_bars)):
        if isinstance(value, bool) or not isinstance(value, int) or value < 20:
            raise ValueError(f"{name} doit être un entier >= 20")
    if validation_bars >= train_bars:
        raise ValueError("validation_bars doit être inférieur à train_bars")
    if step_bars != test_bars:
        raise ValueError(
            "step_bars doit être égal à test_bars pour éviter le chevauchement "
            "des fenêtres hors échantillon"
        )
    if not isfinite(float(fee)) or not isfinite(float(slippage)) or not 0 <= fee <= .02 or not 0 <= slippage <= .02:
        raise ValueError("Frais et slippage doivent être finis et compris entre 0 et 2 %")
    if not isfinite(float(initial_cash)) or initial_cash <= 0:
        raise ValueError("initial_cash doit être strictement positif")
    # Validate all parameter dictionaries against the actual strategy catalogue.
    from research_v1.strategies.catalog import make
    for params in parameter_sets:
        make(kind, f"walk-forward-validation-{kind}", params, list(bars_by_symbol))
    lengths = {len(series) for series in bars_by_symbol.values()}
    if len(lengths) != 1:
        raise ValueError("Historique non synchronisé : longueurs différentes")
    n = next(iter(lengths))
    if n < train_bars + test_bars + 2:
        raise ValueError("Historique insuffisant pour au moins une fenêtre train/test")
    return n


def _training_score(metrics: dict) -> float:
    """Conservative deterministic objective; computed only on training data."""
    sharpe = float(metrics.get("sharpe", 0.0))
    drawdown = abs(float(metrics.get("max_drawdown_pct", 0.0))) / 100.0
    cagr = float(metrics.get("cagr_pct", 0.0)) / 100.0
    if not all(isfinite(x) for x in (sharpe, drawdown, cagr)):
        return float("-inf")
    # Penalize deep drawdowns and reward risk-adjusted performance, not raw return.
    return sharpe - 2.0 * drawdown + min(max(cagr, -1.0), 1.0) * 0.25


def _parameter_distance(left: dict, right: dict, candidates: list[dict]) -> float:
    """Mean normalized distance across the fixed candidate grid (0..1)."""
    keys = sorted(set(left) | set(right))
    if not keys:
        return 0.0
    distances = []
    for key in keys:
        if key not in left or key not in right:
            distances.append(1.0)
            continue
        a, b = left[key], right[key]
        if isinstance(a, bool) or isinstance(b, bool) or not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
            distances.append(0.0 if a == b else 1.0)
            continue
        values = [
            float(candidate[key]) for candidate in candidates
            if key in candidate and not isinstance(candidate[key], bool)
            and isinstance(candidate[key], (int, float))
        ]
        span = max(values) - min(values) if values else 0.0
        distances.append(0.0 if span <= 0 else min(abs(float(a) - float(b)) / span, 1.0))
    return sum(distances) / len(distances)


def _out_of_sample_metrics(equity_curve: list[float]) -> dict:
    """Measure a fold from the equity immediately before its first test bar."""
    if len(equity_curve) < 2:
        raise ValueError("Une fenêtre hors échantillon doit contenir au moins deux points de capital")
    values = [float(value) for value in equity_curve]
    if any(not isfinite(value) or value <= 0 for value in values):
        raise ValueError("Courbe de capital hors échantillon invalide")
    start, end = values[0], values[-1]
    returns = [right / left - 1.0 for left, right in zip(values, values[1:])]
    peak = start
    max_drawdown = 0.0
    for value in values[1:]:
        peak = max(peak, value)
        max_drawdown = min(max_drawdown, value / peak - 1.0)
    volatility_daily = 0.0
    sharpe = 0.0
    if len(returns) > 1:
        from statistics import pstdev
        volatility_daily = pstdev(returns)
        if volatility_daily > 0:
            sharpe = mean(returns) / volatility_daily * (252 ** 0.5)
    years = len(returns) / 252.0
    cagr = ((end / start) ** (1.0 / years) - 1.0) * 100.0 if years > 0 else 0.0
    return {
        "oos_return_pct": round((end / start - 1.0) * 100.0, 3),
        "oos_cagr_pct": round(cagr, 3),
        "oos_max_drawdown_pct": round(max_drawdown * 100.0, 3),
        "oos_sharpe": round(sharpe, 4),
        "oos_annualized_volatility_pct": round(volatility_daily * (252 ** 0.5) * 100.0, 3),
        "oos_start_equity": round(start, 2),
        "oos_final_equity": round(end, 2),
        "oos_observations": len(returns),
    }


def run_walk_forward_parameter_search(
    kind: str,
    bars_by_symbol: dict,
    parameter_sets: list[dict],
    *,
    train_bars: int = 756,
    validation_bars: int = 30,
    test_bars: int = 126,
    step_bars: int = 126,
    fee: float = 0.0005,
    slippage: float = 0.0005,
    initial_cash: float = 100_000.0,
    parameter_switch_penalty: float = 0.10,
) -> dict:
    """Select on each historical training prefix and evaluate frozen params OOS.

    Candidate parameter sets are scored on a chronological validation tail
    inside each training prefix. The earlier prefix is used only to provide
    causal indicator history. Test bars are never passed to selection. Each
    test fold starts from cash; folds remain independent diagnostics.
    """
    n = _validate_inputs(
        bars_by_symbol, kind, parameter_sets, train_bars=train_bars,
        validation_bars=validation_bars, test_bars=test_bars,
        step_bars=step_bars, fee=fee,
        slippage=slippage, initial_cash=initial_cash,
    )
    if not isfinite(float(parameter_switch_penalty)) or not 0.0 <= parameter_switch_penalty <= 10.0:
        raise ValueError("parameter_switch_penalty doit être fini et compris entre 0 et 10")
    folds = []
    previous_selected_params = None
    fixed_baseline_params = None
    train_end = train_bars - 1
    while train_end + 1 < n:
        test_start = train_end + 1
        test_end = min(test_start + test_bars, n)
        if test_end - test_start < 20:
            break
        validation_start = train_end - validation_bars
        scored = []
        validation_bars_by_symbol = {
            symbol: series[:train_end + 1]
            for symbol, series in bars_by_symbol.items()
        }
        for candidate_index, params in enumerate(parameter_sets):
            warmup = required_warmup(kind, params)
            if validation_start + 1 < warmup + 3:
                raise ValueError(
                    f"Historique antérieur à la validation trop court pour {kind}: "
                    f"{validation_start + 1} observations, {warmup + 3} requises"
                )
            validation = simulate_portfolio(
                kind, validation_bars_by_symbol, params=params,
                initial_cash=initial_cash, fee=fee, slip=slippage,
                warmup=validation_start, include_asset_weights=False,
            )
            validation_curve = validation["equity_curve"][validation_start:train_end + 1]
            validation_metrics = _out_of_sample_metrics(validation_curve)
            score = _training_score({
                "sharpe": validation_metrics["oos_sharpe"],
                "max_drawdown_pct": validation_metrics["oos_max_drawdown_pct"],
                "cagr_pct": validation_metrics["oos_cagr_pct"],
            })
            scored.append({
                "candidate_index": candidate_index,
                "params": dict(params),
                "validation_score": round(score, 8) if isfinite(score) else None,
                "validation_sharpe": validation_metrics["oos_sharpe"],
                "validation_max_drawdown_pct": validation_metrics["oos_max_drawdown_pct"],
                "validation_cagr_pct": validation_metrics["oos_cagr_pct"],
                "validation_return_pct": validation_metrics["oos_return_pct"],
                "validation_observations": validation_metrics["oos_observations"],
            })
        eligible = [row for row in scored if row["validation_score"] is not None]
        if not eligible:
            raise ValueError("Aucun jeu de paramètres avec score de validation valide")
        for row in eligible:
            distance = (
                _parameter_distance(previous_selected_params, row["params"], parameter_sets)
                if previous_selected_params is not None else 0.0
            )
            row["parameter_distance_from_previous"] = round(distance, 6)
            row["switch_penalty"] = round(parameter_switch_penalty * distance, 8)
            row["adjusted_selection_score"] = round(
                row["validation_score"] - row["switch_penalty"], 8
            )
        selected = max(
            eligible,
            key=lambda row: (row["adjusted_selection_score"], -row["candidate_index"]),
        )
        selected_params = selected["params"]
        selected_warmup = required_warmup(kind, selected_params)
        # Freeze the first validation-selected candidate as a non-adaptive
        # comparator. It is never reselected using later validation or test data.
        if fixed_baseline_params is None:
            fixed_baseline_params = dict(selected_params)

        # The full chronological series is supplied for indicator warmup, but
        # the strategy is disabled until the first OOS decision at train_end.
        test = simulate_portfolio(
            kind, bars_by_symbol, params=selected_params,
            initial_cash=initial_cash, fee=fee, slip=slippage,
            warmup=train_end, include_asset_weights=False,
        )
        # Include the close immediately before the first test bar so the first
        # OOS session's open execution and close-to-close P&L are counted.
        oos_curve = test["equity_curve"][train_end:test_end]
        if len(oos_curve) < 2:
            break
        oos_metrics = _out_of_sample_metrics(oos_curve)

        # Evaluate the frozen first-fold parameters over the exact same OOS
        # dates, execution model, costs, and reset-capital convention.
        fixed_test = simulate_portfolio(
            kind, bars_by_symbol, params=fixed_baseline_params,
            initial_cash=initial_cash, fee=fee, slip=slippage,
            warmup=train_end, include_asset_weights=False,
        )
        fixed_curve = fixed_test["equity_curve"][train_end:test_end]
        fixed_metrics = _out_of_sample_metrics(fixed_curve)
        paired_return_difference = round(
            oos_metrics["oos_return_pct"] - fixed_metrics["oos_return_pct"], 3
        )
        folds.append({
            "train_start_index": 0,
            "train_end_index": train_end,
            "test_start_index": test_start,
            "test_end_index_exclusive": test_end,
            "test_bars": len(oos_curve) - 1,
            "selected_candidate_index": selected["candidate_index"],
            "selected_params": selected_params,
            "validation_start_index": validation_start,
            "validation_end_index_exclusive": train_end + 1,
            "selection_score": selected["adjusted_selection_score"],
            "raw_validation_score": selected["validation_score"],
            "parameter_distance_from_previous": selected["parameter_distance_from_previous"],
            "switch_penalty": selected["switch_penalty"],
            "training_candidates": scored,
            **oos_metrics,
            "oos_trades": sum(
                1 for trade in test["closed_trades"]
                if test_start <= trade.get("exit_index", -1) < test_end
            ),
            "warmup_required_for_selected_params": selected_warmup,
            "fixed_baseline_params": dict(fixed_baseline_params),
            "fixed_baseline_oos_return_pct": fixed_metrics["oos_return_pct"],
            "fixed_baseline_oos_sharpe": fixed_metrics["oos_sharpe"],
            "fixed_baseline_oos_max_drawdown_pct": fixed_metrics["oos_max_drawdown_pct"],
            "adaptive_minus_fixed_return_pct_points": paired_return_difference,
            "capital_reset_for_fold": True,
        })
        previous_selected_params = dict(selected_params)
        train_end += step_bars

    returns = [row["oos_return_pct"] for row in folds]
    fixed_returns = [row["fixed_baseline_oos_return_pct"] for row in folds]
    paired_differences = [row["adaptive_minus_fixed_return_pct_points"] for row in folds]
    return {
        "mode": "RESEARCH_WALK_FORWARD_PARAMETER_SEARCH",
        "strategy": kind,
        "fold_count": len(folds),
        "candidate_count": len(parameter_sets),
        "selection_objective": "validation Sharpe - 2 * absolute validation max drawdown + 0.25 * clipped validation CAGR",
        "selection_uses_validation_tail_only": True,
        "validation_bars": validation_bars,
        "parameter_switch_penalty": parameter_switch_penalty,
        "parameter_selection_policy": "validation score minus normalized parameter-distance penalty from previous fold selection",
        "selection_uses_test_data": False,
        "test_windows_used_for_selection": False,
        "fold_capital_policy": "reset_to_initial_cash_each_fold; independent diagnostic folds",
        "mean_oos_return_pct": round(mean(returns), 3) if returns else None,
        "median_oos_return_pct": round(sorted(returns)[len(returns)//2], 3) if returns else None,
        "fixed_baseline_policy": "first_validation_selected_candidate_frozen_for_all_oos_folds",
        "fixed_baseline_params": fixed_baseline_params,
        "fixed_baseline_mean_oos_return_pct": round(mean(fixed_returns), 3) if fixed_returns else None,
        "mean_adaptive_minus_fixed_return_pct_points": round(mean(paired_differences), 3) if paired_differences else None,
        "adaptive_outperformed_fixed_fold_ratio": round(sum(value > 0 for value in paired_differences) / len(paired_differences), 4) if paired_differences else None,
        "positive_oos_fold_ratio": round(sum(value > 0 for value in returns) / len(returns), 4) if returns else None,
        "folds": folds,
        "broker_access": False,
        "orders_created": 0,
        "strategies_activated": 0,
        "capital_authorized": False,
        "limitations": [
            "folds are non-overlapping, independent diagnostics and reset to cash; this is not a continuous live portfolio",
            "candidate parameter sets must be specified before the run",
            "fixed baseline freezes the first validation-selected candidate; it is a paired diagnostic, not a separately optimized benchmark",
            "parameter-switch penalty is a continuity regularizer, not proof of statistical robustness",
            "the validation tail selects among candidates; the earlier prefix supplies indicator history only",
            "results depend on the supplied data, corporate-action treatment and execution-cost assumptions",
            "no statistical profitability claim or broker authorization is produced",
        ],
    }
