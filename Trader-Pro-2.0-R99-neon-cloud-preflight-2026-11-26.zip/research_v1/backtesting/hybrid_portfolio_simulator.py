"""Continuous research-only simulator for dated hybrid strategy allocations.

Weights decided at timestamp t are held over the return interval ending at the
next timestamp. Rebalancing costs are charged on one-way turnover. This module
is deliberately disconnected from brokers and production capital controls.
"""
from __future__ import annotations

from math import isfinite
from typing import Any, Mapping, Sequence


def _finite(value: Any, name: str, minimum: float | None = None) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{name} must be finite numeric")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{name} must be finite numeric") from exc
    if not isfinite(result) or (minimum is not None and result < minimum):
        raise ValueError(f"{name} is outside its valid range")
    return result


def simulate_hybrid_strategy_portfolio(
    returns_by_strategy: Mapping[str, Sequence[Mapping[str, Any]]],
    allocation_schedule: Sequence[Mapping[str, Any]],
    *,
    initial_cash: float = 100_000.0,
    fee_rate: float = 0.0005,
    max_gross_exposure: float = 0.80,
    max_portfolio_drawdown_pct: float = 20.0,
) -> dict[str, Any]:
    """Simulate a continuous, long-only portfolio of strategy return streams.

    Each strategy stream contains ordered ``{"timestamp", "return_pct"}``
    intervals. A schedule row contains ``{"timestamp", "weights"}``; those
    weights become effective for the interval beginning at that timestamp.
    Schedule timestamps must align exactly with the return timeline. Missing
    strategy weights mean zero. Drawdown protection is a research overlay:
    once breached, exposure is held at zero for the rest of this run.
    """
    if not isinstance(returns_by_strategy, Mapping) or not returns_by_strategy:
        raise ValueError("returns_by_strategy must be a non-empty mapping")
    if not isinstance(allocation_schedule, Sequence) or isinstance(allocation_schedule, (str, bytes)) or not allocation_schedule:
        raise ValueError("allocation_schedule must be a non-empty sequence")
    cash0 = _finite(initial_cash, "initial_cash", 1e-9)
    fee = _finite(fee_rate, "fee_rate", 0.0)
    gross_cap = _finite(max_gross_exposure, "max_gross_exposure", 0.0)
    if gross_cap > 1.0:
        raise ValueError("max_gross_exposure cannot exceed 1")
    dd_limit = _finite(max_portfolio_drawdown_pct, "max_portfolio_drawdown_pct", 0.0)
    if dd_limit > 100:
        raise ValueError("max_portfolio_drawdown_pct cannot exceed 100")

    streams = {}
    timeline = None
    for sid, rows in returns_by_strategy.items():
        if not isinstance(sid, str) or not sid.strip() or not isinstance(rows, Sequence) or isinstance(rows, (str, bytes)):
            raise ValueError("strategy streams must be named sequences")
        parsed = []
        for row in rows:
            if not isinstance(row, Mapping) or not isinstance(row.get("timestamp"), str):
                raise ValueError("each return row requires a timestamp")
            parsed.append((row["timestamp"], _finite(row.get("return_pct"), f"{sid}.return_pct") / 100.0))
        dates = [x[0] for x in parsed]
        if not dates or dates != sorted(dates) or len(set(dates)) != len(dates):
            raise ValueError("strategy timestamps must be non-empty, ordered and unique")
        if timeline is None:
            timeline = dates
        elif dates != timeline:
            raise ValueError("all strategy streams must share the same timestamps")
        streams[sid] = dict(parsed)
    assert timeline is not None

    schedule = {}
    for row in allocation_schedule:
        if not isinstance(row, Mapping) or row.get("timestamp") not in timeline:
            raise ValueError("allocation timestamp must match the return timeline")
        ts = row["timestamp"]
        if ts in schedule:
            raise ValueError("allocation timestamps must be unique")
        raw = row.get("weights")
        if not isinstance(raw, Mapping):
            raise ValueError("allocation weights must be a mapping")
        weights = {}
        for sid, weight in raw.items():
            if sid not in streams:
                raise ValueError(f"unknown strategy in allocation: {sid}")
            value = _finite(weight, f"{sid}.weight", 0.0)
            weights[sid] = value
        if sum(weights.values()) > gross_cap + 1e-9:
            raise ValueError("allocation exceeds max_gross_exposure")
        schedule[ts] = weights
    if timeline[0] not in schedule:
        raise ValueError("an initial allocation is required at the first timestamp")

    equity = cash0
    peak = cash0
    previous_weights = {}
    active = {}
    halted = False
    curve, interval_rows = [], []
    total_fees = 0.0
    max_dd = 0.0
    for i, ts in enumerate(timeline):
        if ts in schedule or halted:
            target = {} if halted else schedule[ts]
            old_cash_weight = max(0.0, 1.0 - sum(previous_weights.values()))
            new_cash_weight = max(0.0, 1.0 - sum(target.values()))
            turnover = (sum(abs(target.get(s, 0.0) - previous_weights.get(s, 0.0))
                             for s in streams)
                        + abs(new_cash_weight - old_cash_weight)) / 2.0
            rebalance_fee = equity * turnover * fee
            equity -= rebalance_fee
            total_fees += rebalance_fee
            active = dict(target)
            previous_weights = dict(target)
        else:
            turnover = 0.0
            rebalance_fee = 0.0

        portfolio_return = sum(active.get(s, 0.0) * streams[s][ts] for s in streams)
        start_equity = equity
        equity *= (1.0 + portfolio_return)
        peak = max(peak, equity)
        drawdown = (peak - equity) / peak if peak else 0.0
        max_dd = max(max_dd, drawdown)
        if drawdown * 100.0 >= dd_limit and dd_limit > 0:
            halted = True
        curve.append({"timestamp": ts, "equity": round(equity, 8),
                      "gross_exposure": round(sum(active.values()), 8),
                      "drawdown_pct": round(drawdown * 100.0, 8)})
        interval_rows.append({"timestamp": ts, "portfolio_return_pct": round(portfolio_return * 100.0, 8),
                              "turnover": round(turnover, 8),
                              "rebalance_fee": round(rebalance_fee, 8),
                              "equity_before_return": round(start_equity, 8)})
    final_return = (equity / cash0 - 1.0) * 100.0
    return {
        "mode": "RESEARCH_CONTINUOUS_HYBRID_PORTFOLIO",
        "initial_cash": cash0, "final_equity": round(equity, 8),
        "return_pct": round(final_return, 8),
        "max_drawdown_pct": round(max_dd * 100.0, 8),
        "total_rebalance_fees": round(total_fees, 8),
        "periods": len(timeline), "equity_curve": curve,
        "intervals": interval_rows, "drawdown_halt_triggered": halted,
        "capital_authorized": False, "orders_created": 0, "broker_access": False,
    }
