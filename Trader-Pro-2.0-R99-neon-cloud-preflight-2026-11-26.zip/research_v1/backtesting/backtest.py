"""Moteur de backtest (long seulement) : exécution à la clôture suivante (pas de regard dans le futur), frais, glissement,
règles de risque optionnelles (stops, taille selon la volatilité), séparation apprentissage / test, bootstrap des trades."""
import random
from research_v1.quant.indicators import rsi
from research_v1.risk import risklib
from research_v1.strategies import scoring

def _sma(c, i, n): return sum(c[i - n + 1:i + 1]) / n

def s_bh(c, i, p, pos):
    """Achat-conservation : toujours investi (signal 1)."""
    return 1
def s_sma(c, i, p, pos):
    """Croisement de moyennes mobiles : 1 si la rapide dépasse la lente, sinon 0 ; garde la position tant que l'historique est insuffisant."""
    if i < p["slow"]: return pos
    return 1 if _sma(c, i, p["fast"]) > _sma(c, i, p["slow"]) else 0
def s_rsi(c, i, p, pos):
    """Retour à la moyenne : achète sous le seuil bas du RSI, vend au-dessus du seuil haut, sinon garde la position."""
    r = rsi(c[max(0, i - 120):i + 1], p["n"])
    if r is None: return pos
    return 1 if r < p["low"] else 0 if r > p["high"] else pos
def s_tech(c, i, p, pos):
    """Score technique : achète si le score atteint le seuil, vend s'il passe sous l'opposé du seuil, sinon garde la position."""
    t = scoring.tech_signal(c[max(0, i - 120):i + 1])
    if t is None: return pos
    return 1 if t >= p["buy"] else 0 if t <= -p["buy"] else pos

STRATS = {"bh": s_bh, "sma": s_sma, "rsi": s_rsi, "tech": s_tech}
GRIDS = {"bh": [{}],
         "sma": [{"fast": f, "slow": s} for f in (5, 10, 20, 30) for s in (40, 60, 100, 150) if f < s],
         "rsi": [{"n": 14, "low": l, "high": h} for l in (20, 25, 30, 35) for h in (60, 65, 70, 75)],
         "tech": [{"buy": b} for b in (0.3, 0.4, 0.7)]}

def run(c, name, p, cash=10000.0, fee=0.0, slip=0.0, rules=None, sizing=None):
    """Signal calculé à la clôture i, exécuté à la clôture i+1.
    rules : stop_loss_pct, trailing_pct, take_profit_pct, cooldown (barres sans rachat après un stop).
    sizing : {risk, k, max_frac} -> fraction investie = min(max_frac, risk % / (k x volatilité journalière))."""
    fn, rules, pos, qty, entry_val, want = STRATS[name], rules or {}, 0, 0.0, 0.0, None
    ent_px = hi = 0.0; cool = 0; eq, trades, ps = [], [], []
    for i, px in enumerate(c):
        if want is not None and want != pos:
            if want:
                fill = px * (1 + slip); frac = 1.0
                if sizing:  # volatilité inconnue (historique trop court) : on prend la taille maximale autorisée, jamais 100 %
                    mf, vol = sizing.get("max_frac", 1.0), risklib.daily_vol(c[:i])
                    frac = min(mf, sizing["risk"] / 100 / (sizing["k"] * vol)) if vol else mf
                entry_val = cash * frac; qty = entry_val * (1 - fee) / fill; cash -= entry_val; ent_px, hi = fill, px
            else:
                proceeds = qty * px * (1 - slip) * (1 - fee); cash += proceeds; trades.append((i, proceeds / entry_val - 1)); qty = 0.0
            pos = want
        eq.append(cash + qty * px); ps.append(pos)
        if pos: hi = max(hi, px)
        if pos and rules and risklib.stops(ent_px, px, hi, rules): want, cool = 0, int(rules.get("cooldown", 5))
        else:
            want = fn(c, i, p, pos)
            if cool > 0 and not pos:
                cool -= 1
                if want: want = 0
    return {"eq": eq, "trades": trades, "pos": ps}

def evaluate(res, lo=0, hi=None, bpy=252):
    """Métriques d'une fenêtre [lo, hi) : rendement, CAGR, pire baisse, Sharpe, trades, taux de réussite, exposition."""
    if isinstance(bpy, bool) or not isinstance(bpy, int) or bpy <= 0:
        raise ValueError("bpy doit être un entier strictement positif")
    hi = len(res["eq"]) if hi is None else hi
    eq, ps = res["eq"][lo:hi], res["pos"][lo:hi]
    tr = [r for i, r in res["trades"] if lo <= i < hi]; n = len(eq)
    if n < 2:
        return {"return_pct": 0.0, "cagr_pct": 0.0, "max_dd_pct": 0.0, "sharpe": 0.0, "trades": 0, "win_rate_pct": 0.0, "exposure_pct": 0.0}
    r = [eq[i] / eq[i - 1] - 1 for i in range(1, n)]
    m = sum(r) / len(r); sd = (sum((x - m) ** 2 for x in r) / len(r)) ** .5
    peak, dd = eq[0], 0.0
    for v in eq: peak = max(peak, v); dd = min(dd, v / peak - 1)
    # n equity observations contain n-1 close-to-close return intervals.
    yrs = (n - 1) / bpy
    return {"return_pct": round((eq[-1] / eq[0] - 1) * 100, 2),
            "cagr_pct": round(((eq[-1] / eq[0]) ** (1 / yrs) - 1) * 100, 2) if eq[-1] > 0 else -100.0,
            "max_dd_pct": round(dd * 100, 2), "sharpe": round(m / sd * bpy ** .5, 2) if sd > 0 else 0.0,
            "trades": len(tr), "win_rate_pct": round(sum(t > 0 for t in tr) / len(tr) * 100, 1) if tr else 0.0,
            "exposure_pct": round(sum(ps) / n * 100, 1)}

def bootstrap(trades, n=1000, seed=1):
    """Rééchantillonne les trades du test : fourchette de résultats plausibles et probabilité de perte. None si < 5 trades."""
    if len(trades) < 5: return None
    rnd, out = random.Random(seed), []
    for _ in range(n):
        g = 1.0
        for _ in trades: g *= 1 + rnd.choice(trades)
        out.append(g - 1)
    out.sort(); q = lambda p: round(out[int(p * (n - 1))] * 100, 2)
    return {"p5": q(.05), "p50": q(.5), "p95": q(.95), "prob_loss_pct": round(sum(x < 0 for x in out) / n * 100, 1), "n_trades": len(trades)}

def _down(v, n=200):
    if len(v) <= n: return [round(x, 2) for x in v]
    step = (len(v) - 1) / (n - 1)
    return [round(v[round(i * step)], 2) for i in range(n)]

def optimize(c, name, split=0.6, fee=0.0005, slip=0.0005, cash=10000.0, rules=None, sizing=None):
    """Choisit les réglages sur la partie apprentissage, puis juge sur la partie test (jamais vue)."""
    k = int(len(c) * split); best, bs = None, None
    for p in GRIDS[name]:
        s = evaluate(run(c, name, p, cash, fee, slip, rules, sizing), 0, k)["sharpe"]
        if bs is None or s > bs: best, bs = p, s
    res, bh = run(c, name, best, cash, fee, slip, rules, sizing), run(c, "bh", {}, cash, fee, slip)
    tr, te = evaluate(res, 0, k), evaluate(res, k); m = min(len(c), 200)
    return {"strategy": name, "params": best, "realistic": bool(rules or sizing), "train": tr, "test": te,
            "benchmark_train": evaluate(bh, 0, k), "benchmark_test": evaluate(bh, k),
            "overfit": bool(tr["sharpe"] > 0.3 and te["sharpe"] < 0.5 * tr["sharpe"]),
            "mc": bootstrap([r for i, r in res["trades"] if i >= k]),
            "curve": {"strategy": _down(res["eq"]), "benchmark": _down(bh["eq"]), "split": round(k / (len(c) - 1) * (m - 1))}}


def evaluate_total_return_history(closes, timestamps, events, *, symbol: str, currency: str,
                                  initial_value: float = 100.0,
                                  session_timezone: str = "America/New_York", bpy: int = 252,
                                  price_basis: str = "unknown") -> dict:
    """Evaluate a buy-and-hold total-return history from raw closes and sourced actions.

    This is a separate research utility. It does not alter the strategy `run`
    function, execution assumptions, or broker path.
    """
    from research_v1.quant.corporate_actions import (
        CorporateActionError, CorporateActionEvent, dividend_total_return_index,
    )
    if not isinstance(symbol, str) or not symbol or symbol != symbol.upper():
        raise ValueError("Symbole de rendement total invalide")
    try:
        event_list = tuple(events)
    except TypeError:
        raise ValueError("Collection d'événements invalide") from None
    if any(not isinstance(event, CorporateActionEvent) or event.symbol != symbol
           for event in event_list):
        raise ValueError("Les événements doivent être validés et appartenir au symbole évalué")
    try:
        curve = list(dividend_total_return_index(
            closes, timestamps, event_list, initial_value=initial_value,
            currency=currency, price_basis=price_basis, session_timezone=session_timezone,
        ))
    except CorporateActionError as exc:
        raise ValueError(str(exc)) from exc
    metrics = evaluate({"eq": curve, "pos": [1] * len(curve), "trades": []}, bpy=bpy)
    return {
        "symbol": symbol,
        "mode": "TOTAL_RETURN_RESEARCH",
        "metrics": metrics,
        "total_return_index": curve,
        "price_basis": "raw_closes_plus_sourced_corporate_actions",
        "input_price_basis": price_basis,
        "dividend_policy": "reinvested_at_ex_date_close",
        "currency": currency,
        "corporate_action_events": len(event_list),
        "broker_access": False,
        "orders_created": 0,
    }



def evaluate_total_return_history_from_ledger(closes, timestamps, revisions, *, as_of, symbol: str, currency: str,
                                               initial_value: float = 100.0,
                                               session_timezone: str = "America/New_York", bpy: int = 252,
                                               price_basis: str = "unknown") -> dict:
    """Evaluate total return using only the latest corporate-action revisions known at as_of."""
    from research_v1.quant.corporate_action_ledger import corporate_action_snapshot
    events = corporate_action_snapshot(revisions, as_of=as_of)
    return evaluate_total_return_history(closes, timestamps, events, symbol=symbol, currency=currency,
        initial_value=initial_value, session_timezone=session_timezone, bpy=bpy, price_basis=price_basis)



def evaluate_total_return_history_from_batch(closes, timestamps, batch, *, as_of, symbol: str, currency: str,
                                               initial_value: float = 100.0,
                                               session_timezone: str = "America/New_York", bpy: int = 252,
                                               price_basis: str = "unknown") -> dict:
    """Evaluate only from a complete, source-scoped corporate-action batch."""
    from research_v1.quant.corporate_actions import CorporateActionBatch, CorporateActionError
    if not isinstance(batch, CorporateActionBatch):
        raise ValueError("Un lot CorporateActionBatch validé est requis")
    if symbol not in batch.requested_symbols:
        raise ValueError("Le symbole évalué ne figure pas dans l'univers du lot")
    if any(event.source != batch.source or event.symbol != symbol for event in batch.events):
        raise ValueError("Le lot contient des événements hors source ou hors symbole")
    # Do not treat retrieval time as historical knowledge; event.available_at remains authoritative.
    return evaluate_total_return_history(closes, timestamps, batch.events, symbol=symbol, currency=currency,
        initial_value=initial_value, session_timezone=session_timezone, bpy=bpy, price_basis=price_basis)
