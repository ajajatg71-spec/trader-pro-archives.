"""Tableau de fiabilité : mesure chaque stratégie à règles HORS ÉCHANTILLON (la dernière partie de l'historique, jamais utilisée pour régler quoi que ce soit),
frais et glissement compris, face à l'achat-conservation. Aucun verdict « fiable » n'existe : au mieux « prometteuse ». Teste N stratégies ⇒ seuil statistique corrigé (Bonferroni)."""
import statistics
from datetime import datetime
from research_v1.backtesting import backtest as BT
from research_v1.backtesting import rule_backtest as RB
from research_v1.quant.features import Features
from research_v1.strategies import catalog

VERDICTS = ("prometteuse", "à surveiller", "non démontrée", "rejetée")
MIN_TRADES, MAX_DD = 30, -35.0

def bonferroni_z(m, alpha=0.05):
    """Seuil de significativité (bilatéral) pour une statistique t quand m stratégies sont testées : z tel que P(|Z| > z) = alpha / m."""
    return statistics.NormalDist().inv_cdf(1 - alpha / (2 * max(1, m)))

def t_stat(returns):
    """Statistique t de la moyenne des rendements de trades (0 s'il y a moins de 2 trades ou aucune dispersion)."""
    n = len(returns)
    if n < 2: return 0.0
    m = sum(returns) / n; sd = (sum((x - m) ** 2 for x in returns) / (n - 1)) ** .5
    return m / (sd / n ** .5) if sd > 0 else 0.0

def verdict(a, z):
    """Verdict et raison d'un agrégat hors échantillon : rejetée (espérance ou Sharpe ≤ 0, ou recul pire que -35 %), non démontrée (moins de 30 trades),
    à surveiller (positive mais non distinguable du hasard après correction, ou sous l'achat-conservation), prometteuse (t ≥ seuil corrigé, Sharpe > achat-conservation, dégradation ≤ 50 %)."""
    if a["oos_trades"] < MIN_TRADES: return "non démontrée", f"seulement {a['oos_trades']} trades hors échantillon (minimum {MIN_TRADES})" if a["expectancy_pct"] > 0 else f"{a['oos_trades']} trades hors échantillon, espérance {a['expectancy_pct']:+.2f} %"
    if a["expectancy_pct"] <= 0 or a["test_sharpe"] <= 0: return "rejetée", f"espérance {a['expectancy_pct']:+.2f} % par trade, Sharpe hors échantillon {a['test_sharpe']:.2f}"
    if a["worst_dd_pct"] < MAX_DD: return "rejetée", f"recul maximal {a['worst_dd_pct']:.0f} % hors échantillon"
    if a["t_stat"] < z: return "à surveiller", f"surperformance journalière du portefeuille mais t HAC = {a['t_stat']:.2f} < {z:.2f} (seuil corrigé pour 50 stratégies) : preuve statistique insuffisante"
    if a["test_sharpe"] <= a["bh_sharpe"]: return "à surveiller", f"statistiquement positive mais Sharpe {a['test_sharpe']:.2f} sous l'achat-conservation ({a['bh_sharpe']:.2f})"
    if a["degradation"] is not None and a["degradation"] > 0.5: return "à surveiller", f"Sharpe en baisse de {a['degradation'] * 100:.0f} % entre apprentissage et test"
    return "prometteuse", f"t HAC journalier = {a['t_stat']:.2f} ≥ {z:.2f}, Sharpe portefeuille {a['test_sharpe']:.2f} contre {a['bh_sharpe']:.2f} pour l'achat-conservation"

def _hac_t_stat(returns, max_lag=5):
    """Newey-West HAC t-statistic for average daily portfolio excess return."""
    n = len(returns)
    if n < 30:
        return 0.0
    avg = statistics.fmean(returns)
    centered = [x - avg for x in returns]
    gamma0 = sum(x * x for x in centered) / n
    lag_count = min(max_lag, n - 1)
    long_run = gamma0
    for lag in range(1, lag_count + 1):
        covariance = sum(centered[i] * centered[i - lag] for i in range(lag, n)) / n
        long_run += 2 * (1 - lag / (lag_count + 1)) * covariance
    variance_mean = max(long_run, 0.0) / n
    if variance_mean <= 1e-18:
        return 0.0
    return avg / variance_mean ** 0.5


def _fully_oos_closed_trades(closed, split_index):
    """Count only trades with explicit entry and exit indices fully inside OOS."""
    return [item for item in closed
            if isinstance(item.get("entry_index"), int)
            and isinstance(item.get("exit_index"), int)
            and item["entry_index"] >= split_index
            and item["exit_index"] >= split_index
            and item["exit_index"] >= item["entry_index"]]


def _validate_synchronized_data(data):
    if not isinstance(data, dict) or not data:
        raise ValueError("Un univers non vide de séries OHLCV est requis")
    sessions = []
    lengths = set()
    for symbol, bars in data.items():
        if not bars:
            raise ValueError(f"Historique vide pour {symbol}")
        lengths.add(len(bars))
        parsed = []
        for bar in bars:
            raw = getattr(bar, "ts", None)
            if raw is None:
                raise ValueError("Horodatage OHLCV manquant pour le scoreboard")
            try:
                stamp = datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
            except (TypeError, ValueError) as exc:
                raise ValueError(f"Horodatage OHLCV invalide pour {symbol}") from exc
            if stamp.tzinfo is None or stamp.utcoffset() is None:
                raise ValueError(f"Horodatage OHLCV sans fuseau pour {symbol}")
            if parsed and stamp <= parsed[-1]:
                raise ValueError(f"Horodatages OHLCV non strictement croissants pour {symbol}")
            parsed.append(stamp)
        sessions.append(tuple(parsed))
    if len(lengths) != 1 or any(item != sessions[0] for item in sessions[1:]):
        raise ValueError("Le scoreboard multi-titres exige des historiques synchronisés sur les mêmes dates")
    return next(iter(lengths))


def _validate_synchronized_benchmarks(data, benchmarks):
    if not benchmarks:
        return
    if not isinstance(benchmarks, dict):
        raise ValueError("Les benchmarks doivent être fournis par symbole")
    expected = tuple(datetime.fromisoformat(str(getattr(bar, "ts")).replace("Z", "+00:00"))
                     for bar in next(iter(data.values())))
    for symbol, bars in benchmarks.items():
        if symbol not in data:
            raise ValueError(f"Benchmark fourni pour un symbole absent de l'univers : {symbol}")
        if not bars or len(bars) != len(expected):
            raise ValueError(f"Historique benchmark vide ou incomplet pour {symbol}")
        parsed = []
        for bar in bars:
            raw = getattr(bar, "ts", None)
            if raw is None:
                raise ValueError(f"Horodatage benchmark manquant pour {symbol}")
            try:
                stamp = datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
            except (TypeError, ValueError) as exc:
                raise ValueError(f"Horodatage benchmark invalide pour {symbol}") from exc
            if stamp.tzinfo is None or stamp.utcoffset() is None:
                raise ValueError(f"Horodatage benchmark sans fuseau pour {symbol}")
            if parsed and stamp <= parsed[-1]:
                raise ValueError(f"Horodatages benchmark non strictement croissants pour {symbol}")
            parsed.append(stamp)
        if tuple(parsed) != expected:
            raise ValueError(f"Benchmark non synchronisé avec {symbol}")


def evaluate_kind(kind, data, benches=None, split=0.6, fee=0.0005, slip=0.0005, warmup=60, params=None, features=None, z=1.96):
    """Évalue une règle sur un portefeuille de lignes équipondérées en capital initial.

    La statistique utilisée pour le verdict est un t-stat Newey-West des rendements
    journaliers OOS du portefeuille net de l'achat-conservation. Les trades ne sont
    comptés OOS que si leur entrée ET leur sortie surviennent après le split.
    """
    n = _validate_synchronized_data(data)
    if n < warmup + 100:
        return {"kind": kind, "label": catalog.REGISTRY[kind].label, "symbols": 0,
                "verdict": "non démontrée", "reason": "historique insuffisant", "rows": []}
    split_index = warmup + int((n - warmup) * split)
    simulations, benchmark_sims, rows, oos = {}, {}, [], []

    for sym, bars in data.items():
        f = (features or {}).get(sym) or Features(bars, (benches or {}).get(sym))
        res = RB.simulate(bars, kind, params, (benches or {}).get(sym), fee, slip,
                          warmup, features=f)
        bh = RB.buy_and_hold(bars, fee, slip, warmup)
        training = BT.evaluate(res, warmup, split_index)
        closed_oos = _fully_oos_closed_trades(res.get("closed", []), split_index)
        oos.extend(item["return"] for item in closed_oos)
        test_view = {"eq": res["eq"], "pos": res["pos"],
                     "trades": [(item["exit_index"], item["return"]) for item in closed_oos]}
        test = BT.evaluate(test_view, split_index - 1, n)
        benchmark_test = BT.evaluate(bh, split_index - 1, n)
        simulations[sym] = res
        benchmark_sims[sym] = bh
        rows.append({"symbol": sym, "train": training, "test": test,
                     "bh_test": benchmark_test,
                     "oos_closed_trades": len(closed_oos)})

    symbols = list(simulations)
    # Each symbol receives the same initial sleeve capital. Summing the sleeve
    # equity curves gives a reproducible, non-look-ahead equal-capital portfolio.
    portfolio_eq = [sum(simulations[s]["eq"][i] for s in symbols) for i in range(n)]
    portfolio_pos = [sum(simulations[s]["pos"][i] for s in symbols) / len(symbols)
                     for i in range(n)]
    benchmark_eq = [sum(benchmark_sims[s]["eq"][i] for s in symbols) for i in range(n)]
    benchmark_pos = [sum(benchmark_sims[s]["pos"][i] for s in symbols) / len(symbols)
                     for i in range(n)]
    portfolio_closed_oos = sorted(
        [item for s in symbols for item in _fully_oos_closed_trades(
            simulations[s].get("closed", []), split_index)],
        key=lambda item: item["exit_index"])
    combined_test = BT.evaluate({"eq": portfolio_eq, "pos": portfolio_pos,
                                 "trades": [(x["exit_index"], x["return"]) for x in portfolio_closed_oos]},
                                split_index - 1, n)
    combined_train_trades = sorted(
        [(item["exit_index"], item["return"]) for s in symbols
         for item in simulations[s].get("closed", [])
         if item.get("entry_index", -1) >= warmup and item.get("exit_index", n) < split_index],
        key=lambda item: item[0])
    combined_train = BT.evaluate({"eq": portfolio_eq, "pos": portfolio_pos,
                                  "trades": combined_train_trades}, warmup, split_index)
    combined_benchmark = BT.evaluate({"eq": benchmark_eq, "pos": benchmark_pos,
                                      "trades": []}, split_index - 1, n)

    strategy_daily = [portfolio_eq[i] / portfolio_eq[i - 1] - 1
                      for i in range(split_index, n) if portfolio_eq[i - 1] > 0]
    benchmark_daily = [benchmark_eq[i] / benchmark_eq[i - 1] - 1
                       for i in range(split_index, n) if benchmark_eq[i - 1] > 0]
    paired_excess = [a - b for a, b in zip(strategy_daily, benchmark_daily)]
    wins = [r for r in oos if r > 0]
    losses = [r for r in oos if r <= 0]
    worst_symbol_dd = min(row["test"]["max_dd_pct"] for row in rows)
    a = {
        "oos_trades": len(oos),
        "expectancy_pct": round(sum(oos) / len(oos) * 100, 3) if oos else 0.0,
        "win_rate_pct": round(len(wins) / len(oos) * 100, 1) if oos else 0.0,
        "profit_factor": round(sum(wins) / -sum(losses), 2)
            if losses and sum(losses) < 0 else None,
        "t_stat": round(_hac_t_stat(paired_excess), 3),
        "trade_t_stat": round(t_stat(oos), 2),
        "t_stat_method": "Newey-West HAC on daily equal-capital portfolio excess returns",
        "oos_daily_observations": len(paired_excess),
        "train_sharpe": round(combined_train["sharpe"], 2),
        "test_sharpe": round(combined_test["sharpe"], 2),
        "bh_sharpe": round(combined_benchmark["sharpe"], 2),
        "test_return_pct": round(combined_test["return_pct"], 2),
        "bh_return_pct": round(combined_benchmark["return_pct"], 2),
        "worst_dd_pct": round(min(worst_symbol_dd, combined_test["max_dd_pct"]), 2),
        "worst_single_symbol_dd_pct": round(worst_symbol_dd, 2),
        "portfolio_max_drawdown_pct": round(combined_test["max_dd_pct"], 2),
        "exposure_pct": round(combined_test["exposure_pct"], 1),
    }
    a["degradation"] = round(
        (a["train_sharpe"] - a["test_sharpe"]) / abs(a["train_sharpe"]), 3
    ) if a["train_sharpe"] > 0 else None
    v, why = verdict(a, z)
    return {"kind": kind, "label": catalog.REGISTRY[kind].label,
            "family": catalog.FAMILY.get(kind), "symbols": len(rows), **a,
            "verdict": v, "reason": why, "rows": rows}

def evaluate_catalog(data, benches=None, kinds=None, split=0.6, fee=0.0005, slip=0.0005, warmup=60, alpha=0.05):
    """Évalue les stratégies à règles et classe l'OOS avec contrôle global des 50 tests."""
    from math import isfinite
    from research_v1.strategies import rules
    from research_v1.adapter import UNIVERSE_STRATEGIES

    if not isinstance(split, (int, float)) or not 0 < split < 1:
        raise ValueError("split doit être strictement compris entre 0 et 1")
    if not isinstance(alpha, (int, float)) or not 0 < alpha < 1:
        raise ValueError("alpha doit être strictement compris entre 0 et 1")
    if not isinstance(warmup, int) or isinstance(warmup, bool) or warmup < 0:
        raise ValueError("warmup doit être un entier positif ou nul")
    for label, value in (("fee", fee), ("slip", slip)):
        if not isinstance(value, (int, float)) or not isfinite(value) or value < 0 or value > 0.05:
            raise ValueError(f"{label} doit être un nombre fini entre 0 et 0.05")

    _validate_synchronized_data(data)
    _validate_synchronized_benchmarks(data, benches or {})
    ks = [k for k in (kinds or sorted(rules.SPECS)) if k in rules.SPECS]
    if not ks:
        raise ValueError("Au moins une stratégie à règles connue est requise")
    # Both per-symbol and portfolio scoreboards form one 50-hypothesis research family.
    family_size = len(rules.SPECS) + len(UNIVERSE_STRATEGIES)
    z = bonferroni_z(family_size, alpha)
    feats = {s: Features(b, (benches or {}).get(s)) for s, b in data.items() if len(b) >= warmup + 100}
    res = [evaluate_kind(k, data, benches, split, fee, slip, warmup, None, feats, z) for k in ks]
    res.sort(key=lambda r: (VERDICTS.index(r["verdict"]), -r.get("test_sharpe", -99)))
    return {"tested": len(ks), "family_size": family_size, "alpha": alpha,
            "multiple_testing_method": "Bonferroni two-sided across 43 per-symbol + 7 portfolio strategies",
            "symbols": sorted(feats), "split": split, "fee": fee, "slip": slip,
            "z_threshold": round(z, 2),
            "counts": {v: sum(r["verdict"] == v for r in res) for v in VERDICTS}, "results": res,
            "caveats": ["Aucun verdict ne garantit un résultat futur : « prometteuse » signifie seulement « pas encore invalidée ».", "Le seuil statistique couvre les 50 stratégies du catalogue V1, pas seulement les règles présentées dans ce tableau.", "Les trades de titres corrélés ne sont pas indépendants : la statistique t est optimiste.",
                        "Ces résultats ne valent que pour les titres et la période fournis ; la période de test ne doit jamais servir à régler les paramètres."]}

def rejected_kinds(report):
    """Types de stratégies rejetés par le tableau (à retirer du catalogue actif)."""
    return sorted(r["kind"] for r in report["results"] if r["verdict"] == "rejetée")
