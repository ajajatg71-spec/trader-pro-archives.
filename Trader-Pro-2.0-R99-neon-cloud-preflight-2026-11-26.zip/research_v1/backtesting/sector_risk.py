"""Research-only sector exposure audit; missing classification fails closed."""
from math import isfinite

def audit_sector_exposure(weights_curve, sectors=None, max_sector_pct=35.0):
    if not 0 < max_sector_pct <= 100:
        raise ValueError("Invalid sector limit")
    if sectors is not None and not isinstance(sectors, dict):
        raise ValueError("Invalid sectors")
    sectors = sectors or {}
    peaks = {}
    breaches = 0
    for weights in weights_curve:
        totals = {}
        for symbol, raw in weights.items():
            weight = float(raw)
            if not isfinite(weight) or weight < 0:
                raise ValueError("Invalid asset weight")
            sector = sectors.get(symbol) or "UNKNOWN"
            totals[sector] = totals.get(sector, 0) + weight
        if sum(totals.values()) > 1.000001:
            raise ValueError("Asset exposure exceeds equity")
        for sector, weight in totals.items():
            peaks[sector] = max(peaks.get(sector, 0), weight)
        if totals.get("UNKNOWN", 0) > 0 or any(weight * 100 > max_sector_pct for sector, weight in totals.items() if sector != "UNKNOWN"):
            breaches += 1
    complete = bool(weights_curve) and peaks.get("UNKNOWN", 0) == 0
    return {
        "status": "WITHIN_RESEARCH_LIMITS" if complete and breaches == 0 else "REVIEW_REQUIRED",
        "classification_complete": complete,
        "sector_peak_pct": {k: round(v * 100, 3) for k, v in sorted(peaks.items())},
        "breach_days": breaches,
        "max_sector_pct": max_sector_pct,
        "capital_authorized": False,
        "orders_created": 0,
    }
