"""Fail-closed bridge from the OOS scoreboard to the hybrid simulator."""
from __future__ import annotations

from typing import Any, Mapping, Sequence

from .hybrid_portfolio_simulator import simulate_hybrid_strategy_portfolio


def simulate_hybrid_scoreboard_portfolio(
    scoreboard: Mapping[str, Any],
    allocation_schedule: Sequence[Mapping[str, Any]],
    *,
    initial_cash: float = 100_000.0,
    fee_rate: float = 0.0005,
    max_gross_exposure: float = 0.80,
    max_portfolio_drawdown_pct: float = 20.0,
) -> dict[str, Any]:
    """Simulate a dated strategy allocation using only common OOS return streams.

    This adapter rejects malformed or legacy scoreboards without explicit
    timestamped OOS streams. It never creates weights from scoreboard rankings:
    allocations must be supplied separately by the research/human review layer.
    """
    if not isinstance(scoreboard, Mapping) or scoreboard.get("mode") != "WALK_FORWARD_OOS_RESEARCH":
        raise ValueError("a WALK_FORWARD_OOS_RESEARCH scoreboard is required")
    streams = scoreboard.get("oos_return_streams")
    if not isinstance(streams, Mapping) or not streams:
        raise ValueError("scoreboard has no dated common OOS return streams")
    if scoreboard.get("execution") != "NONE" or scoreboard.get("broker_access") is not False:
        raise ValueError("scoreboard execution boundary is invalid")
    metadata = scoreboard.get("oos_return_streams_metadata")
    if not isinstance(metadata, Mapping):
        raise ValueError("OOS stream metadata is required")
    observations = metadata.get("observations")
    if isinstance(observations, bool) or not isinstance(observations, int) or observations < 1:
        raise ValueError("OOS stream observation count is invalid")
    if any(not isinstance(rows, Sequence) or isinstance(rows, (str, bytes)) or len(rows) != observations
           for rows in streams.values()):
        raise ValueError("OOS streams do not match the declared common observation count")
    result = simulate_hybrid_strategy_portfolio(
        streams, allocation_schedule,
        initial_cash=initial_cash,
        fee_rate=fee_rate,
        max_gross_exposure=max_gross_exposure,
        max_portfolio_drawdown_pct=max_portfolio_drawdown_pct,
    )
    result["source"] = "walk_forward_common_oos_scoreboard"
    result["oos_observations"] = observations
    result["capital_authorized"] = False
    result["orders_created"] = 0
    result["broker_access"] = False
    return result
