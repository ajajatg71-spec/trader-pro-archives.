"""Backtest multi-actifs des stratégies d'univers, sans accès broker.

Décision à la clôture t, exécution à l'ouverture t+1. Les séries d'indicateurs
sont causales et synchronisées. Les achats sont plafonnés par les liquidités.
"""
from __future__ import annotations

from dataclasses import asdict
from datetime import date, datetime
import re
from math import isfinite
from statistics import mean, pstdev

from research_v1.quant.features import Features
from research_v1.strategies.catalog import make
from research_v1.strategies.types import Context, SymbolData, Intent
from research_v1.backtesting.portfolio_state import PortfolioState
from research_v1.adapter import UNIVERSE_STRATEGIES


def _validate(bars_by_symbol, fee, slip, cash, warmup):
    if not isinstance(bars_by_symbol, dict) or len(bars_by_symbol) < 2:
        raise ValueError("Au moins deux séries OHLCV sont requises")
    if not 0 <= fee <= .02 or not 0 <= slip <= .02:
        raise ValueError("Frais et glissement doivent être compris entre 0 et 2 %")
    if not isfinite(cash) or cash <= 0:
        raise ValueError("Capital initial strictement positif requis")
    symbols = sorted(str(s).strip().upper() for s in bars_by_symbol)
    if len(set(symbols)) != len(symbols) or any(not s for s in symbols):
        raise ValueError("Symboles invalides ou dupliqués")
    lengths = {len(bars_by_symbol[s]) for s in bars_by_symbol}
    if len(lengths) != 1:
        raise ValueError("Historique non synchronisé : longueurs différentes")
    if isinstance(warmup, bool) or not isinstance(warmup, int) or warmup < 1:
        raise ValueError("warmup doit être un entier positif")
    n = next(iter(lengths))
    if n < warmup + 3:
        raise ValueError(f"Historique insuffisant : {warmup + 3} barres minimum")
    sessions = [tuple(b.ts for b in bars_by_symbol[s]) for s in bars_by_symbol]
    if any(x != sessions[0] for x in sessions[1:]):
        raise ValueError("Historique non synchronisé : horodatages différents")
    parsed_sessions = []
    for raw_ts in sessions[0]:
        try:
            parsed = datetime.fromisoformat(str(raw_ts).replace("Z", "+00:00"))
        except (TypeError, ValueError) as exc:
            raise ValueError("Horodatage OHLCV invalide") from exc
        if parsed.tzinfo is None or parsed.utcoffset() is None:
            raise ValueError("Horodatage OHLCV sans fuseau horaire")
        parsed_sessions.append(parsed)
    if any(right <= left for left, right in zip(parsed_sessions, parsed_sessions[1:])):
        raise ValueError("Horodatages OHLCV dupliqués ou non croissants")
    for s, bars in bars_by_symbol.items():
        for bar in bars:
            values = (bar.o, bar.h, bar.l, bar.c)
            if any(not isfinite(float(x)) or float(x) <= 0 for x in values):
                raise ValueError(f"Prix OHLC invalide pour {s}")
            if not isfinite(float(bar.v)) or float(bar.v) < 0:
                raise ValueError(f"Volume OHLCV invalide pour {s}")
            o, h, low, close = (float(x) for x in values)
            if h < max(o, close, low) or low > min(o, close, h):
                raise ValueError(f"Bougie OHLC incohérente pour {s}")
    return symbols, n



def _parse_fundamental_as_of(value, symbol):
    """Parse a reporting-period end date; reject ambiguous or future-dated periods."""
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"as_of doit être une date de référence explicite pour {symbol}")
    raw = value.strip()
    # Explicit fiscal-quarter labels are normalized to their period end.
    quarter = re.fullmatch(r"(\d{4})-Q([1-4])", raw, flags=re.IGNORECASE)
    if quarter:
        year, q = int(quarter.group(1)), int(quarter.group(2))
        return date(year, (q - 1) * 3 + 3, (31, 30, 30, 31)[q - 1])
    if re.fullmatch(r"\d{4}", raw):
        return date(int(raw), 12, 31)
    try:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        try:
            return date.fromisoformat(raw)
        except ValueError as exc:
            raise ValueError(f"as_of invalide pour {symbol}; formats acceptés : YYYY, YYYY-Qn, YYYY-MM-DD ou datetime ISO") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(f"as_of datetime sans fuseau horaire pour {symbol}")
    return parsed.date()


def _prepare_point_in_time_fundamentals(fundamentals, symbols, bars_by_symbol, n):
    """Expand public-availability snapshots into a causally aligned daily history."""
    if not isinstance(fundamentals, dict):
        raise ValueError("fundamentals doit être un objet symbole -> liste de snapshots")
    normalized = {}
    for raw_symbol, snapshots in fundamentals.items():
        symbol = str(raw_symbol).strip().upper()
        if not symbol or symbol in normalized:
            raise ValueError("Symboles de fondamentaux invalides ou dupliqués")
        if symbol not in symbols:
            raise ValueError(f"Fondamentaux fournis pour un symbole hors univers : {symbol}")
        if not isinstance(snapshots, list) or not snapshots:
            raise ValueError(f"Snapshots point-in-time manquants pour {symbol}")
        parsed = []
        previous = None
        for record in snapshots:
            if not isinstance(record, dict):
                raise ValueError(f"Snapshot fondamental invalide pour {symbol}")
            allowed = {"available_at", "as_of", "eps", "growth_pct", "margin_pct"}
            if set(record) - allowed or "available_at" not in record:
                raise ValueError(f"Chaque snapshot {symbol} doit contenir available_at et uniquement des champs autorisés")
            try:
                available = datetime.fromisoformat(str(record["available_at"]).replace("Z", "+00:00"))
            except (TypeError, ValueError) as exc:
                raise ValueError(f"available_at invalide pour {symbol}") from exc
            if available.tzinfo is None or available.utcoffset() is None:
                raise ValueError(f"available_at sans fuseau horaire pour {symbol}")
            if previous is not None and available <= previous:
                raise ValueError(f"Snapshots {symbol} non strictement croissants")
            previous = available
            as_of = record.get("as_of", available.isoformat())
            as_of_date = _parse_fundamental_as_of(as_of, symbol)
            if as_of_date > available.date():
                raise ValueError(f"as_of postérieur à available_at pour {symbol} : snapshot non point-in-time")
            clean = {"available_at": available.isoformat(), "as_of": as_of.strip()}
            for field in ("eps", "growth_pct", "margin_pct"):
                raw_value = record.get(field)
                if raw_value is None:
                    clean[field] = None
                else:
                    try:
                        numeric = float(raw_value)
                    except (TypeError, ValueError, OverflowError) as exc:
                        raise ValueError(f"Valeur {field} non numérique pour {symbol}") from exc
                    if isinstance(raw_value, bool) or not isfinite(numeric):
                        raise ValueError(f"Valeur {field} non finie/invalide pour {symbol}")
                    clean[field] = numeric
            if all(clean[field] is None for field in ("eps", "growth_pct", "margin_pct")):
                raise ValueError(f"Snapshot sans facteur exploitable pour {symbol}")
            parsed.append((available, clean))
        normalized[symbol] = parsed
    if set(normalized) != set(symbols):
        missing = sorted(set(symbols) - set(normalized))
        raise ValueError(f"Snapshots point-in-time manquants pour : {', '.join(missing)}")

    history = {}
    for symbol in symbols:
        rows = normalized[symbol]
        cursor = 0
        current = None
        daily = []
        for bar in bars_by_symbol[symbol]:
            session = datetime.fromisoformat(str(bar.ts).replace("Z", "+00:00"))
            while cursor < len(rows) and rows[cursor][0] <= session:
                current = rows[cursor][1]
                cursor += 1
            daily.append(dict(current) if current is not None else None)
        if len(daily) != n:
            raise RuntimeError("Alignement interne des fondamentaux impossible")
        history[symbol] = daily
    return history

def _metrics(equity_curve, daily_returns, trades, exposure, fee, slip):
    if len(equity_curve) < 2:
        return {"return_pct": 0.0, "cagr_pct": 0.0, "max_drawdown_pct": 0.0, "sharpe": 0.0,
                "volatility_pct": 0.0, "trades": trades, "exposure_pct": 0.0}
    start, end = equity_curve[0], equity_curve[-1]
    peak, max_dd = equity_curve[0], 0.0
    for value in equity_curve:
        peak = max(peak, value)
        max_dd = min(max_dd, value / peak - 1)
    mu = mean(daily_returns) if daily_returns else 0.0
    vol = pstdev(daily_returns) if len(daily_returns) > 1 else 0.0
    # Equity observations bracket len(curve)-1 daily return intervals.
    years = len(daily_returns) / 252
    return {"return_pct": round((end / start - 1) * 100, 3),
            "cagr_pct": round(((end / start) ** (1 / years) - 1) * 100, 3) if end > 0 else -100.0,
            "max_drawdown_pct": round(max_dd * 100, 3),
            "sharpe": round(mu / vol * (252 ** .5), 3) if vol else 0.0,
            "volatility_pct": round(vol * (252 ** .5) * 100, 3),
            "trades": trades, "exposure_pct": round(mean(exposure) * 100, 2) if exposure else 0.0,
            "fee_rate": fee, "slippage_rate": slip}


def simulate_portfolio(kind, bars_by_symbol, *, params=None, fundamentals=None, benchmarks=None,
                       initial_cash=100_000.0, fee=0.0005, slip=0.0005, warmup=60,
                       include_asset_weights=True, state=None, start_index=0, end_index=None):
    """Simule une stratégie d'univers sur un portefeuille long-only.

    Les intentions sont émises à la clôture puis exécutées à l'ouverture suivante.
    Les positions sont marquées au marché à chaque clôture. Les ventes passent
    avant les achats; les achats sont réduits si le cash disponible est insuffisant.
    """
    if kind not in UNIVERSE_STRATEGIES:
        raise ValueError("Stratégie d'univers inconnue")
    if not isinstance(include_asset_weights, bool):
        raise ValueError("include_asset_weights doit être booléen")
    bars = {}
    for raw_symbol, series in bars_by_symbol.items():
        symbol = str(raw_symbol).strip().upper()
        if not symbol or symbol in bars:
            raise ValueError("Symboles invalides ou dupliqués après normalisation")
        bars[symbol] = series
    symbols, n = _validate(bars, fee, slip, initial_cash, warmup)
    if kind == "multi_factor":
        if not fundamentals:
            raise ValueError("Multi-Factor exige des snapshots fondamentaux historiques point-in-time (available_at) ; les valeurs statiques sont interdites")
        fundamentals_history = _prepare_point_in_time_fundamentals(fundamentals, symbols, bars, n)
    else:
        if fundamentals:
            raise ValueError("Les snapshots fondamentaux ne sont acceptés que par Multi-Factor")
        fundamentals_history = None
    if isinstance(start_index, bool) or not isinstance(start_index, int) or not 0 <= start_index < n:
        raise ValueError("start_index must be an integer within the data range")
    if end_index is None:
        end_index = n
    if isinstance(end_index, bool) or not isinstance(end_index, int) or not start_index < end_index <= n:
        raise ValueError("end_index must be an integer greater than start_index and <= data length")
    if state is None:
        if start_index != 0:
            raise ValueError("A validated portfolio state is required when start_index > 0")
        portfolio_state = PortfolioState(universe=list(symbols), cash=float(initial_cash)).validate()
    else:
        portfolio_state = PortfolioState.from_dict(state.to_dict() if isinstance(state, PortfolioState) else state)
        if portfolio_state.universe != list(symbols):
            raise ValueError("Portfolio state universe does not match input data")
        if portfolio_state.last_index != start_index - 1:
            raise ValueError("Portfolio state index does not immediately precede start_index")
        if start_index > 0 and portfolio_state.last_timestamp != bars[symbols[0]][start_index - 1].ts:
            raise ValueError("Portfolio state timestamp does not match preceding bar")
    feats = {s: Features(bars[s], (benchmarks or {}).get(s)) for s in symbols}
    strat = make(kind, f"portfolio-backtest-{kind}", dict(params or {}), symbols)
    cash = portfolio_state.cash
    positions = {s: dict(p) for s, p in portfolio_state.positions.items()}
    pending = [Intent(**row) for row in portfolio_state.pending_intents]
    equity_curve, daily_returns, exposure_curve = [], [], []
    asset_weights_curve, cash_weights_curve = [], []
    closed_trades, fills = [], []
    segment_fees = 0.0
    segment_slippage = 0.0
    previous_equity = portfolio_state.last_equity if portfolio_state.last_equity is not None else cash

    for t in range(start_index, end_index):
        # Execute yesterday's close decisions at today's open.
        open_prices = {s: float(bars[s][t].o) for s in symbols}
        sells = [i for i in pending if i.side == "sell"]
        buys = [i for i in pending if i.side == "buy"]
        for intent in sells:
            s = intent.symbol.upper()
            pos = positions.get(s)
            if not pos:
                continue
            px = open_prices[s] * (1 - slip)
            if intent.notional is not None:
                qty = min(pos["qty"], max(0.0, float(intent.notional)) / max(px, 1e-12))
            else:
                qty = pos["qty"]
            if qty <= 0:
                continue
            gross_proceeds = qty * px
            trade_fee = gross_proceeds * fee
            trade_slippage = qty * max(0.0, open_prices[s] - px)
            proceeds = gross_proceeds - trade_fee
            segment_fees += trade_fee
            segment_slippage += trade_slippage
            cash += proceeds
            # avg already includes the buy-side fee because qty is net of that fee.
            # Compare net sale proceeds per share with this all-in entry basis once.
            closed_trades.append({"symbol": s, "entry_price": pos["avg"], "exit_price": px,
                                  "qty": qty, "return_pct": round((px * (1-fee) / pos["avg"] - 1) * 100, 4),
                                  "exit_index": t})
            pos["qty"] -= qty
            if pos["qty"] <= 1e-10:
                positions.pop(s, None)
            fills.append({"index": t, "symbol": s, "side": "sell", "qty": qty, "price": px,
                          "notional": gross_proceeds, "fees": trade_fee, "slippage_cost": trade_slippage})
        # Calculate equity at execution prices before allocating entries.
        equity_at_open = cash + sum(p["qty"] * open_prices[s] for s, p in positions.items())
        for intent in buys:
            s = intent.symbol.upper()
            if s not in bars or s in positions:
                continue
            px = open_prices[s] * (1 + slip)
            target = max(0.0, min(1.0, float(intent.weight))) * equity_at_open
            spend = min(cash, target)
            if intent.notional is not None:
                spend = min(cash, max(0.0, float(intent.notional)))
            if spend <= 1e-8:
                continue
            trade_fee = spend * fee
            qty = (spend - trade_fee) / px
            trade_slippage = qty * max(0.0, px - open_prices[s])
            segment_fees += trade_fee
            segment_slippage += trade_slippage
            cash -= spend
            positions[s] = {"qty": qty, "avg": spend / qty, "held_since": bars[s][t].ts}
            fills.append({"index": t, "symbol": s, "side": "buy", "qty": qty, "price": px,
                          "notional": spend, "fees": trade_fee, "slippage_cost": trade_slippage})
        pending = []

        # Mark to market at close.
        equity = cash + sum(p["qty"] * float(bars[s][t].c) for s, p in positions.items())
        equity_curve.append(equity)
        daily_returns.append(equity / previous_equity - 1 if previous_equity else 0.0)
        previous_equity = equity
        exposure_curve.append((equity - cash) / equity if equity > 0 else 0.0)
        if include_asset_weights:
            if equity > 0:
                asset_weights_curve.append({
                    s: p["qty"] * float(bars[s][t].c) / equity
                    for s, p in positions.items()
                })
                cash_weights_curve.append(cash / equity)
            else:
                asset_weights_curve.append({})
                cash_weights_curve.append(1.0)

        # Decide at close t; the resulting intentions can only fill at t+1 open.
        if warmup <= t < n - 1:
            data = {}
            for s in symbols:
                fund = fundamentals_history[s][t] if fundamentals_history is not None else None
                data[s] = SymbolData(s, bars[s], fundamentals=fund,
                                     bench=(benchmarks or {}).get(s), injected=feats[s].at(t))
            pos_ctx = {s: {"qty": p["qty"], "avg": p["avg"],
                           "value": p["qty"] * float(bars[s][t].c),
                           "held_since": p["held_since"], "price": float(bars[s][t].c)}
                       for s, p in positions.items()}
            pending = strat.evaluate(Context(bars[symbols[0]][t].ts, data, pos_ctx, equity))
            # A defensive contract: strategy output may not reference an unknown symbol.
            if any(i.symbol.upper() not in bars for i in pending):
                raise RuntimeError("La stratégie a émis une intention hors univers")

    metrics = _metrics(equity_curve, daily_returns[1:], len(closed_trades), exposure_curve, fee, slip)
    final_equity = equity_curve[-1]
    portfolio_state.cash = cash
    portfolio_state.positions = {s: dict(p) for s, p in positions.items()}
    portfolio_state.pending_intents = [asdict(intent) for intent in pending]
    portfolio_state.last_index = end_index - 1
    portfolio_state.last_timestamp = bars[symbols[0]][end_index - 1].ts
    portfolio_state.last_equity = final_equity
    portfolio_state.cumulative_fees += segment_fees
    portfolio_state.cumulative_slippage += segment_slippage
    portfolio_state.fills.extend(fills)
    portfolio_state.closed_trades.extend(closed_trades)
    portfolio_state.validate()
    result = {"mode": "RESEARCH_BACKTEST", "strategy": kind, "params": strat.params,
              "symbols": symbols, "bars": end_index - start_index, "warmup": warmup,
              "initial_cash": initial_cash, "final_equity": round(final_equity, 2),
              "cash": round(cash, 2),
              "open_positions": {s: {"qty": round(p["qty"], 8), "avg": round(p["avg"], 6)} for s, p in positions.items()},
              "metrics": metrics, "equity_curve": [round(x, 2) for x in equity_curve],
              "exposure_curve": [round(x, 6) for x in exposure_curve],
              **({"asset_weights_curve": asset_weights_curve,
                  "cash_weights_curve": [round(x, 8) for x in cash_weights_curve]}
                 if include_asset_weights else {}),
              "closed_trades": closed_trades, "fills": fills,
              "portfolio_state": portfolio_state.to_dict(),
              "costs": {"fees": round(segment_fees, 8), "slippage": round(segment_slippage, 8),
                        "cumulative_fees": round(portfolio_state.cumulative_fees, 8),
                        "cumulative_slippage": round(portfolio_state.cumulative_slippage, 8)},
              "broker_access": False, "orders_created": 0}
    # The passive benchmark is meaningful only for a full, fresh run. Segment
    # calls deliberately omit it rather than reporting a misleading reset benchmark.
    if start_index == 0 and end_index == n and state is None:
        benchmark_qty = {}
        benchmark_cash = float(initial_cash)
        benchmark_curve = []
        for t in range(n):
            if t == warmup + 1:
                allocation = initial_cash / len(symbols)
                for symbol in symbols:
                    fill_price = float(bars[symbol][t].o) * (1 + slip)
                    benchmark_qty[symbol] = allocation * (1 - fee) / fill_price
                benchmark_cash = 0.0
            benchmark_curve.append(benchmark_cash + sum(
                qty * float(bars[symbol][t].c) for symbol, qty in benchmark_qty.items()))
        benchmark_returns = [benchmark_curve[i] / benchmark_curve[i-1] - 1
                             for i in range(1, len(benchmark_curve)) if benchmark_curve[i-1] > 0]
        benchmark_metrics = _metrics(benchmark_curve, benchmark_returns, 0,
                                     [1.0 if i >= warmup + 1 else 0.0 for i in range(n)], fee, slip)
        metrics["excess_return_vs_equal_weight_pct"] = round(
            metrics["return_pct"] - benchmark_metrics["return_pct"], 3)
        result["benchmark"] = {"name": "equal_weight_buy_and_hold",
                               "metrics": benchmark_metrics,
                               "equity_curve": [round(x, 2) for x in benchmark_curve]}
    return result
