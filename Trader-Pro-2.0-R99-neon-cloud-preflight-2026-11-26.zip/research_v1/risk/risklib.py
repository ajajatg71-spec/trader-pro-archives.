"""Mesures de risque (fonctions pures) : volatilité, taille de position, VaR/CVaR, corrélation, bêta,
concentration, stops, régime de marché, scénarios de crise, série de pertes."""
import math

def returns(c):
    """Rendements simples entre clôtures successives."""
    return [c[i] / c[i - 1] - 1 for i in range(1, len(c))]

def stdev(v):
    """Écart-type d'échantillon (0 si moins de 2 valeurs)."""
    if len(v) < 2: return 0.0
    m = sum(v) / len(v); return (sum((x - m) ** 2 for x in v) / (len(v) - 1)) ** .5

def daily_vol(closes, n=20):
    """Volatilité journalière sur n jours, ou None si moins de 5 rendements."""
    r = returns(closes)[-n:]
    return stdev(r) if len(r) >= 5 else None

def vol_size(equity, price, vol, risk_pct=1.0, k=2.0, max_pos_pct=25.0):
    """Montant à investir pour ne risquer que risk_pct % du portefeuille si le titre recule de k écarts-types journaliers."""
    if not vol or vol <= 0 or price <= 0: return None
    return round(min(equity * risk_pct / 100 / (k * vol), equity * max_pos_pct / 100), 2)

def inverse_vol_weights(vols):
    """Poids inversement proportionnels à la volatilité."""
    inv = {s: 1 / v for s, v in vols.items() if v and v > 0}; t = sum(inv.values())
    return {s: w / t for s, w in inv.items()} if t else {}

def portfolio_returns(weights, closes):
    """Rendements journaliers d'un portefeuille à poids donnés, sur l'historique commun."""
    n = min(len(closes[s]) for s in weights)
    R = {s: returns(closes[s][-n:]) for s in weights}
    return [sum(weights[s] * R[s][i] for s in weights) for i in range(n - 1)]

def var_cvar(r, level=0.95):
    """Perte journalière historique : (VaR, CVaR) en fraction positive. None si moins de 20 observations."""
    if len(r) < 20: return None
    s = sorted(r); k = int(len(s) * (1 - level))
    return max(-s[k], 0.0), max(-sum(s[:k + 1]) / (k + 1), 0.0)

def corr(a, b):
    """Corrélation de Pearson sur la période commune."""
    n = min(len(a), len(b)); a, b = a[-n:], b[-n:]
    if n < 2: return 0.0
    ma, mb = sum(a) / n, sum(b) / n
    sa, sb = sum((x - ma) ** 2 for x in a) ** .5, sum((x - mb) ** 2 for x in b) ** .5
    return sum((x - ma) * (y - mb) for x, y in zip(a, b)) / (sa * sb) if sa and sb else 0.0

def avg_corr(rets):
    """Corrélation moyenne entre toutes les paires, ou None."""
    ks = list(rets); ps = [corr(rets[a], rets[b]) for i, a in enumerate(ks) for b in ks[i + 1:]]
    return sum(ps) / len(ps) if ps else None

def beta(a, m):
    """Bêta d'un actif par rapport au marché, ou None."""
    n = min(len(a), len(m)); a, m = a[-n:], m[-n:]
    if n < 2: return None
    ma, mm = sum(a) / n, sum(m) / n; vm = sum((x - mm) ** 2 for x in m)
    return sum((x - ma) * (y - mm) for x, y in zip(a, m)) / vm if vm else None

def effective_n(weights):
    """Nombre effectif de positions (inverse de l'indice de concentration HHI)."""
    h = sum(w * w for w in weights); return 1 / h if h else None

def stops(entry, px, high, L):
    """Raison du stop touché, ou '' (stop-loss fixe, stop suiveur, objectif de gain ; 0 = désactivé)."""
    sl, tr, tp = L.get("stop_loss_pct", 0), L.get("trailing_pct", 0), L.get("take_profit_pct", 0)
    if sl > 0 and px <= entry * (1 - sl / 100): return f"stop-loss {sl:g} %"
    if tr > 0 and high > 0 and px <= high * (1 - tr / 100): return f"stop suiveur {tr:g} %"
    if tp > 0 and px >= entry * (1 + tp / 100): return f"objectif de gain {tp:g} %"
    return ""

def stop_price(entry, high, L):
    """Prix du stop actif le plus protecteur (fixe ou suiveur), ou None."""
    c = [entry * (1 - L["stop_loss_pct"] / 100)] if L.get("stop_loss_pct", 0) > 0 else []
    if L.get("trailing_pct", 0) > 0 and high > 0: c.append(high * (1 - L["trailing_pct"] / 100))
    return max(c) if c else None

def regime(spy):
    """'haussier' si la dernière clôture dépasse sa moyenne sur 200 jours, sinon 'baissier' ; None si moins de 200 points."""
    if len(spy) < 200: return None
    return "haussier" if spy[-1] > sum(spy[-200:]) / 200 else "baissier"

def stress(values, shock_pct, betas=None):
    """Perte estimée (négative) si le marché chute de shock_pct %, titre par titre puis total."""
    out = {s: -v * shock_pct / 100 * (betas or {}).get(s, 1.0) for s, v in values.items()}
    return out, sum(out.values())

def loss_streak(trades):
    """Nombre de pertes consécutives les plus récentes."""
    n = 0
    for t in reversed(trades):
        if t < 0: n += 1
        else: break
    return n
