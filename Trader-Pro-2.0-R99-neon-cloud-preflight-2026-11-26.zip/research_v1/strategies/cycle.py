"""Cycle du moteur multi-stratégies : évaluation isolée de chaque stratégie active, stops de protection, dimensionnement selon budget et limites,
arbitrage entre stratégies, suspension automatique, journal de chaque décision. Fonction pure : aucune écriture, aucun ordre envoyé."""
import re
from research_v1.strategies import arbiter
from research_v1.strategies.catalog import make
from research_v1.strategies.types import Context, Intent

DEFAULT_LIMITS = {"max_position_pct": 0.35, "max_positions": 8, "max_drawdown_pct": 15.0, "daily_loss_pct": 4.0, "stop_loss_pct": 8.0, "min_equity_pct": 50.0, "max_errors": 5}
LIMIT_BOUNDS = {"max_position_pct": (0.01, 1.0), "max_positions": (1, 50), "max_drawdown_pct": (1.0, 100.0), "daily_loss_pct": (0.1, 100.0), "stop_loss_pct": (0.0, 50.0), "min_equity_pct": (0.0, 100.0), "max_errors": (1, 100)}
DEFAULT_SETTINGS = {"enabled": False, "auto_execute": False, "cycle_minutes": 15, "conflict_policy": "risk_first", "max_symbol_pct": 25.0, "cooldown_minutes": 60, "max_total_budget_pct": 90.0, "min_notional": 5.0}
SETTING_BOUNDS = {"cycle_minutes": (1, 1440), "max_symbol_pct": (1.0, 100.0), "cooldown_minutes": (0, 10080), "max_total_budget_pct": (1.0, 100.0), "min_notional": (1.0, 100000.0)}

def validate_limits(limits):
    """Limites de risque d'une stratégie complétées par les défauts ; refuse les noms inconnus et les valeurs hors bornes."""
    out = {**DEFAULT_LIMITS}
    for k, v in (limits or {}).items():
        if k not in LIMIT_BOUNDS: raise ValueError(f"Limite inconnue : {k}")
        lo, hi = LIMIT_BOUNDS[k]
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not lo <= v <= hi: raise ValueError(f"{k} doit être un nombre entre {lo} et {hi}")
        out[k] = int(v) if isinstance(DEFAULT_LIMITS[k], int) else float(v)
    return out

def validate_settings(settings):
    """Réglages du moteur complétés par les défauts ; refuse les noms inconnus, les politiques inconnues et les valeurs hors bornes."""
    out = {**DEFAULT_SETTINGS}
    for k, v in (settings or {}).items():
        if k not in DEFAULT_SETTINGS: raise ValueError(f"Réglage inconnu : {k}")
        if k in ("enabled", "auto_execute"):
            if not isinstance(v, bool): raise ValueError(f"{k} doit être vrai ou faux")
        elif k == "conflict_policy":
            if v not in arbiter.POLICIES: raise ValueError(f"conflict_policy doit être l'un de : {', '.join(arbiter.POLICIES)}")
        else:
            lo, hi = SETTING_BOUNDS[k]
            if isinstance(v, bool) or not isinstance(v, (int, float)) or not lo <= v <= hi: raise ValueError(f"{k} doit être un nombre entre {lo} et {hi}")
        out[k] = v
    return out

def validate_universe(universe):
    """Univers d'investissement : 1 à 50 symboles distincts (lettres et points), en majuscules."""
    u = [str(s).strip().upper() for s in universe or []]
    if not u or len(u) > 50 or len(set(u)) != len(u) or not all(re.fullmatch(r"[A-Z.]{1,10}", s) for s in u): raise ValueError("Univers invalide : 1 à 50 symboles distincts (lettres et points)")
    return u

def validate_allocation(equity, defs, max_total_pct):
    """Refuse un total de budgets des stratégies actives supérieur à la part autorisée du capital."""
    total = sum(d["budget"] for d in defs if d["state"] == "active")
    if total > equity * max_total_pct / 100 + 1e-9: raise ValueError(f"Budgets actifs ({total:.0f}) supérieurs à {max_total_pct:.0f} % du capital ({equity * max_total_pct / 100:.0f})")

def check_guards(m, limits, budget):
    """Raison de suspension automatique d'une stratégie, ou None : recul maximal, perte du jour, capital sous le minimum, erreurs consécutives.
    m = {equity, peak, day_start, errors}."""
    if m["peak"] > 0 and (m["equity"] / m["peak"] - 1) * 100 <= -limits["max_drawdown_pct"]: return f"recul de {(m['equity'] / m['peak'] - 1) * 100:.1f} % depuis le plus haut (limite {limits['max_drawdown_pct']} %)"
    if m["day_start"] > 0 and (m["equity"] / m["day_start"] - 1) * 100 <= -limits["daily_loss_pct"]: return f"perte du jour de {(m['equity'] / m['day_start'] - 1) * 100:.1f} % (limite {limits['daily_loss_pct']} %)"
    if budget > 0 and m["equity"] < budget * limits["min_equity_pct"] / 100: return f"capital tombé à {m['equity']:.0f}, sous {limits['min_equity_pct']:.0f} % du budget ({budget:.0f})"
    if m["errors"] >= limits["max_errors"]: return f"{m['errors']} erreurs consécutives"
    return None

_RANK = {"stop": 0, "exit": 1, "rebalance": 2, "entry": 3}

def run_cycle(defs, ledger, data, prices, equity_total, now, meta=None, in_flight=(), recent_sells=(), settings=None, symbol_values=None, order_cap=None):
    """Exécute un cycle. Renvoie {cycle_id, ts, orders, decisions, suspended, errors, equities}.
    Chaque intention produit exactement une décision (outcome : proposed, suppressed, skipped). Les ordres sont tagués par stratégie (attribution).
    order_cap : montant maximal d'un ordre (limite globale de risque)."""
    S, meta, symbol_values = validate_settings(settings), meta if meta is not None else {}, symbol_values or {}
    cycle = "c" + re.sub(r"\D", "", now)[:14]; decisions, sized, suspended, errors, equities = [], [], [], [], {}
    def decide(d, i, outcome, detail="", notional=None, suffix=""):
        rec = {"decision_id": f"{cycle}-{d['name']}-{i.symbol}{suffix}", "cycle_id": cycle, "ts": now, "strategy": d["name"], "symbol": i.symbol, "side": i.side, "kind": i.kind, "reason": i.reason,
               "confidence": i.confidence, "evidence": i.evidence, "outcome": outcome, "detail": detail, "notional": notional}
        decisions.append(rec); return rec
    for d in sorted((x for x in defs if x["state"] == "active"), key=lambda x: (x["priority"], x["name"])):
        name, L = d["name"], {**DEFAULT_LIMITS, **d.get("risk_limits", {})}; m = meta.setdefault(name, {"errors": 0, "peak": d["budget"], "day": None})
        pos = {s: {**p, "price": prices.get(s, p["avg"])} for s, p in ledger.positions(name).items()}
        for p in pos.values(): p["value"] = p["qty"] * p["price"]
        eq = d["budget"] + ledger.realized.get(name, 0.0) + sum((p["price"] - p["avg"]) * p["qty"] for p in pos.values()); equities[name] = round(eq, 2)
        if not m["day"] or m["day"]["date"] != now[:10]: m["day"] = {"date": now[:10], "equity": eq}
        m["peak"] = max(m["peak"], eq)
        why = check_guards({"equity": eq, "peak": m["peak"], "day_start": m["day"]["equity"], "errors": m["errors"]}, L, d["budget"])
        if why: suspended.append({"name": name, "reason": why}); continue
        try:
            raw = list(make(d["kind"], name, d["params"], d["universe"]).evaluate(Context(now, {s: data[s] for s in d["universe"] if s in data}, pos, eq)))
        except Exception as e:
            m["errors"] += 1; errors.append({"strategy": name, "error": f"{type(e).__name__}: {e}"}); continue
        m["errors"] = 0
        if L["stop_loss_pct"] > 0:
            for s, p in pos.items():
                if p["price"] <= p["avg"] * (1 - L["stop_loss_pct"] / 100): raw.append(Intent(name, s, "sell", "stop", f"stop-loss de {L['stop_loss_pct']:g} % atteint ({p['price']:.2f} pour un prix de revient de {p['avg']:.2f})", 1.0, 1.0))
        best, dups = {}, {}
        for i in sorted(raw, key=lambda i: (_RANK.get(i.kind, 9), -i.confidence, i.symbol)):
            if i.symbol in best:
                dups[i.symbol] = dups.get(i.symbol, 0) + 1; decide(d, i, "skipped", "écarté : une intention plus prioritaire existe pour ce titre dans la même stratégie", suffix=f"~{dups[i.symbol]}")
            else: best[i.symbol] = i
        free, count = max(0.0, eq - sum(p["value"] for p in pos.values())), len(pos)
        for s in sorted(best, key=lambda s: (-best[s].confidence, s)):
            i, cur = best[s], pos.get(s, {}).get("value", 0.0)
            if i.side == "sell":
                if cur <= 0: decide(d, i, "skipped", "la stratégie ne détient pas ce titre"); continue
                n = min(i.notional if i.notional is not None else cur * min(1.0, i.weight), cur)
                if n < S["min_notional"] and cur >= S["min_notional"]: n = min(cur, S["min_notional"])
            else:
                if s not in pos and count >= L["max_positions"]: decide(d, i, "skipped", "nombre maximal de positions atteint"); continue
                n = min(i.notional if i.notional is not None else eq * i.weight, free, eq * L["max_position_pct"] - cur)
                if n < S["min_notional"]: decide(d, i, "skipped", "budget ou plafond de position insuffisant"); continue
                free -= n; count += 0 if s in pos else 1
            if n < S["min_notional"]: decide(d, i, "skipped", "montant trop faible"); continue
            rec = decide(d, i, "pending", "", round(n, 2)); sized.append({"decision_id": rec["decision_id"], "strategy": name, "symbol": s, "side": i.side, "kind": i.kind, "notional": round(n, 2), "priority": d["priority"], "reason": i.reason})
    caps = {i["symbol"]: max(0.0, equity_total * S["max_symbol_pct"] / 100 - symbol_values.get(i["symbol"], 0.0)) for i in sized if i["side"] == "buy"}
    orders, suppressed = arbiter.arbitrate(sized, S["conflict_policy"], set(in_flight), set(recent_sells) if S["cooldown_minutes"] else set(), caps, order_cap=order_cap)
    keep = []
    for o in orders:
        if o["notional"] < S["min_notional"]:
            for i in o["decision_ids"]: suppressed[i] = "montant trop faible après plafonnement du titre"
        else: keep.append(o)
    for rec in decisions:
        if rec["outcome"] != "pending": continue
        if rec["decision_id"] in suppressed: rec["outcome"], rec["detail"] = "suppressed", suppressed[rec["decision_id"]]
        else: rec["outcome"], rec["detail"] = "proposed", "ordre proposé"
    for k, o in enumerate(keep): o["order_ref"] = k
    return {"cycle_id": cycle, "ts": now, "orders": keep, "decisions": decisions, "suspended": suspended, "errors": errors, "equities": equities}
