"""Performance d'une stratégie : statistiques de trades fermés et courbe de capital (fonctions pures)."""

def trade_stats(closed):
    """Statistiques des trades fermés : nombre, taux de réussite, profit factor (None s'il n'y a aucune perte), gain et perte moyens, espérance, résultat total."""
    if not closed: return {"trades": 0, "win_rate_pct": 0.0, "profit_factor": None, "avg_win": 0.0, "avg_loss": 0.0, "expectancy": 0.0, "total_pnl": 0.0}
    w, l = [t["pnl"] for t in closed if t["pnl"] > 0], [t["pnl"] for t in closed if t["pnl"] <= 0]
    return {"trades": len(closed), "win_rate_pct": round(len(w) / len(closed) * 100, 1), "profit_factor": round(sum(w) / -sum(l), 3) if l and sum(l) < 0 else None,
            "avg_win": round(sum(w) / len(w), 2) if w else 0.0, "avg_loss": round(sum(l) / len(l), 2) if l else 0.0, "expectancy": round(sum(t["pnl"] for t in closed) / len(closed), 2), "total_pnl": round(sum(t["pnl"] for t in closed), 2)}

def curve_stats(curve):
    """Rendement total et pire recul (%) d'une courbe [{ts, equity}]."""
    if len(curve) < 2: return {"return_pct": 0.0, "max_drawdown_pct": 0.0, "points": len(curve)}
    peak, dd = curve[0]["equity"], 0.0
    for p in curve: peak = max(peak, p["equity"]); dd = min(dd, p["equity"] / peak - 1)
    return {"return_pct": round((curve[-1]["equity"] / curve[0]["equity"] - 1) * 100, 2), "max_drawdown_pct": round(dd * 100, 2), "points": len(curve)}

def update_curve(curve, ts, equity, max_points=2000):
    """Ajoute un point à la courbe (un seul par horodatage) et garde les max_points derniers."""
    if curve and curve[-1]["ts"] == ts: curve[-1]["equity"] = equity
    else: curve.append({"ts": ts, "equity": equity})
    del curve[:-max_points]; return curve
