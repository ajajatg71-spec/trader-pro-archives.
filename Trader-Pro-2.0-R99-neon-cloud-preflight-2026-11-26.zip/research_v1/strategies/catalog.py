"""Catalogue des stratégies : 43 stratégies à règles par titre (rules.py) et 7 stratégies d'univers (classement, rééquilibrage). Toutes sont pures :
elles lisent des données et renvoient des intentions, sans jamais envoyer d'ordre. Une stratégie ne voit que ses propres positions."""
from datetime import datetime
from research_v1.quant import factors as F
from research_v1.strategies import rules
from research_v1.strategies.types import Intent

def _days(a, b):
    try: return (datetime.fromisoformat(b.replace("Z", "+00:00")) - datetime.fromisoformat(a.replace("Z", "+00:00"))).days
    except (ValueError, AttributeError): return 0

class Strategy:
    kind, label, PARAMS = "", "", {}
    def __init__(self, name, params=None, universe=()):
        self.name, self.params, self.universe = name, self.validate_params(params or {}), list(universe)

    @classmethod
    def validate_params(cls, params):
        """Paramètres complétés par les défauts ; refuse les noms inconnus, les types faux, les valeurs hors bornes et les non-entiers pour un paramètre entier."""
        out = {k: v[0] for k, v in cls.PARAMS.items()}
        for k, v in params.items():
            if k not in cls.PARAMS: raise ValueError(f"Paramètre inconnu pour {cls.kind} : {k}")
            d, lo, hi, _ = cls.PARAMS[k]
            if isinstance(d, bool):
                if not isinstance(v, bool): raise ValueError(f"{k} doit être vrai ou faux")
            else:
                if isinstance(v, bool) or not isinstance(v, (int, float)) or not lo <= v <= hi: raise ValueError(f"{k} doit être un nombre entre {lo} et {hi}")
                if isinstance(d, int):
                    if isinstance(v, float) and not v.is_integer(): raise ValueError(f"{k} doit être un entier")
                    v = int(v)
                else: v = float(v)
            out[k] = v
        return out

    @classmethod
    def describe(cls):
        """Fiche du catalogue : type, nom, famille, paramètres (défaut, bornes, rôle)."""
        return {"kind": cls.kind, "label": cls.label, "family": FAMILY.get(cls.kind, "portefeuille"), "params": [{"name": k, "default": d, "min": lo, "max": hi, "description": txt} for k, (d, lo, hi, txt) in cls.PARAMS.items()]}

    def intent(self, symbol, side, kind, reason, d=None, weight=1.0, confidence=0.5, evidence=None, notional=None):
        """Construit une intention avec preuves chiffrées."""
        return Intent(self.name, symbol, side, kind, reason, max(0.0, min(1.0, weight)), max(0.0, min(1.0, confidence)), evidence or [], notional)

    def evaluate(self, ctx):
        """Intentions de la stratégie pour ce cycle (à implémenter)."""
        raise NotImplementedError

class RuleStrategy(Strategy):
    spec = None
    def evaluate(self, ctx):
        """Pour chaque titre : sortie si la règle de sortie, la durée maximale ou le stop ATR se déclenche ; sinon entrée si la règle d'entrée est satisfaite."""
        out, p = [], self.params
        for s in self.universe:
            d = ctx.data.get(s)
            if d is None: continue
            f = d.features
            if f.n < 30: continue
            pos, ts = ctx.positions.get(s), f.bars[f.cursor].ts
            if pos:
                why = self.spec["exit"](f, p, pos) or self._common_exit(f, pos, ctx.now)
                if why: out.append(self.intent(s, "sell", "exit", why, evidence=[{"name": self.kind, "value": 1.0, "as_of": ts, "source": "règle", "rationale": why}]))
            else:
                r = self.spec["entry"](f, p)
                if r: out.append(self.intent(s, "buy", "entry", r[0], weight=p["position_pct"], confidence=r[1], evidence=[{"name": self.kind, "value": round(r[1], 3), "as_of": ts, "source": "règle", "rationale": r[0]}]))
        return out

    def _common_exit(self, f, pos, now):
        p = self.params; held = _days(pos["held_since"], now)
        if p["max_hold_days"] and held >= p["max_hold_days"]: return f"durée maximale atteinte ({held} jours)"
        atr = f.v("atr", 14)
        if p["stop_atr"] and atr and f.close < pos["avg"] - p["stop_atr"] * atr: return f"stop de {p['stop_atr']:g} ATR touché ({pos['avg'] - p['stop_atr'] * atr:.2f})"
        return None

def _rank(scores, reverse=True):
    order = sorted(scores, key=lambda s: (-scores[s] if reverse else scores[s], s)); return {s: i + 1 for i, s in enumerate(order)}

class _Ranking(Strategy):
    """Base des stratégies de classement : détient les top_n du classement, sort quand un titre tombe sous exit_rank ou perd son critère absolu."""
    def score(self, d): raise NotImplementedError
    def qualifies(self, d, sc): return True
    def evaluate(self, ctx):
        """Classe l'univers, achète les meilleurs qualifiés, vend ceux qui sortent du classement ou ne qualifient plus."""
        p, scores, out = self.params, {}, []
        for s in self.universe:
            d = ctx.data.get(s)
            if d is not None and d.features.n >= 30:
                sc = self.score(d)
                if sc is not None: scores[s] = sc
        rank = _rank(scores); ts = next((ctx.data[s].features.bars[ctx.data[s].features.cursor].ts for s in scores), ctx.now)
        for s in self.universe:
            if s not in scores: continue
            sc, ok_ = scores[s], self.qualifies(ctx.data[s], scores[s]); ev = [{"name": self.kind, "value": round(sc, 4), "as_of": ts, "source": "règle", "rationale": f"rang {rank[s]} sur {len(scores)}, score {sc:.4f}"}]
            if s in ctx.positions:
                if rank[s] > p["exit_rank"] or not ok_: out.append(self.intent(s, "sell", "exit", f"{'sorti du classement' if rank[s] > p['exit_rank'] else 'ne remplit plus le critère'} (rang {rank[s]}, score {sc:.4f})", evidence=ev))
            elif rank[s] <= p["top_n"] and ok_: out.append(self.intent(s, "buy", "entry", f"rang {rank[s]} sur {len(scores)} (score {sc:.4f})", weight=p["position_pct"], confidence=max(0.3, 1 - (rank[s] - 1) / max(len(scores), 1)), evidence=ev))
        return out

_RP = {"top_n": (5, 1, 20, "nombre de titres détenus"), "exit_rank": (8, 1, 50, "rang au-delà duquel on vend"), "position_pct": (0.2, 0.01, 1.0, "part du capital par ligne")}

class Momentum(_Ranking):
    kind, label = "momentum", "Momentum 12-1 mois (classement)"
    PARAMS = {**_RP, "min_momentum": (0.0, -0.5, 2.0, "momentum minimal"), "trend_filter": (True, None, None, "exiger cours > moyenne 200 j")}
    def score(self, d):
        f = d.features
        if f.n >= 253: a, b = f.v("close", at=21), f.v("close", at=252); return a / b - 1 if a and b else None
        return f.v("roc", 126) if f.n >= 127 else None
    def qualifies(self, d, sc): return sc >= self.params["min_momentum"] and (not self.params["trend_filter"] or rules._uptrend(d.features))

class DualMomentum(_Ranking):
    kind, label = "dual_momentum", "Momentum dual (absolu et relatif)"
    PARAMS = {"top_n": (1, 1, 10, "nombre de titres détenus"), "exit_rank": (2, 1, 50, "rang de sortie"), "position_pct": (0.9, 0.01, 1.0, "part du capital par ligne"), "lookback": (252, 60, 500, "fenêtre de rendement"), "abs_min": (0.0, -0.5, 1.0, "rendement absolu minimal (sinon liquidités)")}
    def score(self, d): return d.features.v("roc", self.params["lookback"])
    def qualifies(self, d, sc): return sc > self.params["abs_min"]

class LowVolatility(_Ranking):
    kind, label = "low_volatility", "Faible volatilité en tendance"
    PARAMS = {"top_n": (3, 1, 20, "nombre de titres détenus"), "exit_rank": (6, 1, 50, "rang de sortie"), "position_pct": (0.33, 0.01, 1.0, "part du capital par ligne"), "vol_n": (60, 20, 250, "fenêtre de volatilité")}
    def score(self, d):
        v = d.features.v("vol", self.params["vol_n"]); return None if v is None or v <= 0 else -v
    def qualifies(self, d, sc): return rules._uptrend(d.features)

class RSRotation(_Ranking):
    kind, label = "rs_rotation", "Rotation sur la force relative"
    PARAMS = {**_RP, "top_n": (3, 1, 20, "nombre de titres détenus"), "exit_rank": (6, 1, 50, "rang de sortie"), "position_pct": (0.33, 0.01, 1.0, "part du capital par ligne"), "rs_n": (63, 10, 250, "fenêtre"), "min_rs": (0.0, -0.5, 1.0, "surperformance minimale face à l'indice")}
    def score(self, d): return d.features.v("rs_roc", self.params["rs_n"])
    def qualifies(self, d, sc): return sc >= self.params["min_rs"] and rules._uptrend(d.features)

class MultiFactor(Strategy):
    kind, label = "multi_factor", "Multi-facteurs (value, croissance, qualité, momentum)"
    PARAMS = {**_RP, "min_coverage": (0.5, 0.25, 1.0, "part minimale des facteurs disponibles"), "min_score": (0.0, -3.0, 3.0, "score composite minimal")}
    def evaluate(self, ctx):
        """Classe l'univers par score composite (z-scores transversaux) ; achète les meilleurs couverts par assez de facteurs."""
        p, inputs, out = self.params, {}, []
        for s in self.universe:
            d = ctx.data.get(s)
            if d is not None and d.features.n >= 130: inputs[s] = F.raw_inputs([b.c for b in d.bars[:d.features.n]], d.fundamentals)
        if len(inputs) < 2: return out
        sc = F.factor_scores(inputs)
        for s, r in sc.items():
            if r["composite"] is None: continue
            current_bar = ctx.data[s].bars[ctx.data[s].features.cursor]
            ev = [{"name": "multi_factor", "value": r["composite"], "as_of": current_bar.ts, "source": "facteurs", "rationale": f"rang {r['rank']} sur {len(sc)}, couverture {r['coverage']:.0%}, manquants : {', '.join(r['missing']) or 'aucun'}"}]
            if s in ctx.positions:
                if r["rank"] > p["exit_rank"] or r["composite"] < p["min_score"]: out.append(self.intent(s, "sell", "exit", f"sorti du classement multi-facteurs (rang {r['rank']}, score {r['composite']:.2f})", evidence=ev))
            elif r["rank"] <= p["top_n"] and r["composite"] >= p["min_score"] and r["coverage"] >= p["min_coverage"]: out.append(self.intent(s, "buy", "entry", f"rang {r['rank']} sur {len(sc)}, score composite {r['composite']:.2f}", weight=p["position_pct"], confidence=min(1.0, 0.5 + r["composite"] / 4), evidence=ev))
        return out

class Rebalancing(Strategy):
    kind, label = "rebalancing", "Rééquilibrage vers des poids cibles"
    PARAMS = {"band": (5.0, 0.5, 50.0, "écart toléré en points de capital"), "min_trade": (25.0, 1.0, 100000.0, "montant minimal d'un ajustement")}
    @classmethod
    def validate_params(cls, params):
        """Poids cibles (symbole -> poids, somme ≤ 1, chaque poids dans ]0, 1]) plus bande et montant minimal."""
        t = params.get("targets")
        if not isinstance(t, dict) or not t: raise ValueError("targets requis : {symbole: poids}")
        base = super().validate_params({k: v for k, v in params.items() if k != "targets"}); clean = {}
        for s, w in t.items():
            if isinstance(w, bool) or not isinstance(w, (int, float)) or not 0 < w <= 1: raise ValueError(f"poids invalide pour {s}")
            clean[str(s).upper()] = float(w)
        if sum(clean.values()) > 1 + 1e-9: raise ValueError("la somme des poids dépasse 100 %")
        return {**base, "targets": clean}
    def __init__(self, name, params=None, universe=()): super().__init__(name, params, ()); self.universe = sorted(self.params["targets"])
    def evaluate(self, ctx):
        """Achète ou vend l'écart entre la valeur détenue et le poids cible quand il dépasse la bande."""
        p, out = self.params, []
        for s, w in sorted(p["targets"].items()):
            if s not in ctx.data: continue
            cur, tgt = ctx.positions.get(s, {}).get("value", 0.0), ctx.equity * w; drift = (cur - tgt) / ctx.equity * 100
            if abs(drift) >= p["band"] and abs(cur - tgt) >= p["min_trade"]:
                side = "buy" if tgt > cur else "sell"; why = f"poids {cur / ctx.equity * 100:.1f} % pour une cible de {w * 100:.1f} % (écart {drift:+.1f} points)"
                out.append(self.intent(s, side, "rebalance", why, confidence=min(1.0, abs(drift) / 20), notional=abs(cur - tgt), evidence=[{"name": "rebalancing", "value": round(drift, 2), "as_of": ctx.now, "source": "règle", "rationale": why}]))
        return out

class InverseVolatility(Strategy):
    kind, label = "inverse_volatility", "Parité de risque simple (poids ∝ 1/volatilité)"
    PARAMS = {"vol_n": (60, 20, 250, "fenêtre de volatilité"), "invested_pct": (0.9, 0.1, 1.0, "part du capital investie"), "band": (5.0, 0.5, 50.0, "écart toléré en points de capital"), "min_trade": (25.0, 1.0, 100000.0, "montant minimal d'un ajustement")}
    def evaluate(self, ctx):
        """Pondère chaque titre par l'inverse de sa volatilité et rééquilibre quand l'écart dépasse la bande."""
        p, vols, out = self.params, {}, []
        for s in self.universe:
            d = ctx.data.get(s)
            if d is not None and d.features.n >= 30:
                v = d.features.v("vol", p["vol_n"])
                if v and v > 0: vols[s] = v
        if len(vols) < 2: return out
        inv = {s: 1 / v for s, v in vols.items()}; tot = sum(inv.values())
        for s in sorted(vols):
            w = inv[s] / tot * p["invested_pct"]; cur, tgt = ctx.positions.get(s, {}).get("value", 0.0), ctx.equity * w; drift = (cur - tgt) / ctx.equity * 100
            if abs(drift) >= p["band"] and abs(cur - tgt) >= p["min_trade"]:
                why = f"poids cible {w * 100:.1f} % (volatilité {vols[s] * 100:.2f} % par jour), poids actuel {cur / ctx.equity * 100:.1f} %"
                out.append(self.intent(s, "buy" if tgt > cur else "sell", "rebalance", why, confidence=0.5, notional=abs(cur - tgt), evidence=[{"name": "inverse_volatility", "value": round(w, 4), "as_of": ctx.now, "source": "règle", "rationale": why}]))
        return out

def _rule_class(kind, spec): return type("Rule_" + kind, (RuleStrategy,), {"kind": kind, "label": spec["label"], "PARAMS": spec["params"], "spec": spec})

UNIVERSE = (Momentum, DualMomentum, LowVolatility, RSRotation, MultiFactor, Rebalancing, InverseVolatility)
REGISTRY = {c.kind: c for c in UNIVERSE}
REGISTRY.update({k: _rule_class(k, s) for k, s in rules.SPECS.items()})
FAMILY = {**{k: "tendance" for k in ("golden_cross", "ema_cross", "triple_ema", "macd_cross", "supertrend", "aroon_trend", "ichimoku_cloud", "adx_di_cross", "keltner_breakout", "new_high_52w", "rs_leader", "trend_pullback", "donchian_turtle", "trend_following", "breakout")},
          **{k: "retour à la moyenne" for k in ("rsi2", "bollinger_bounce", "stochastic_cross", "cci_reversal", "williams_reversal", "ibs_reversion", "zscore_reversion", "mfi_oversold", "vwap_reversion", "gap_fill", "mean_reversion")},
          **{k: "volatilité et volume" for k in ("volatility", "ttm_squeeze", "nr7_breakout", "inside_bar_breakout", "atr_expansion", "obv_trend", "cmf_trend")},
          **{k: "chandeliers" for k in ("candle_reversal_support", "candle_continuation", "candle_confluence", "engulfing_pullback", "pin_bar_support", "morning_star_trade", "outside_reversal", "doji_confirmation", "kicker_gap", "harami_confirmation")},
          **{k: "classement et portefeuille" for k in ("momentum", "dual_momentum", "low_volatility", "rs_rotation", "multi_factor", "rebalancing", "inverse_volatility")}}

def make(kind, name, params=None, universe=()):
    """Construit une stratégie du catalogue ; ValueError si le type est inconnu ou les paramètres invalides."""
    if kind not in REGISTRY: raise ValueError(f"Type de stratégie inconnu : {kind}")
    return REGISTRY[kind](name, params, universe)

def catalog():
    """Fiches de toutes les stratégies, triées par famille puis par nom."""
    return sorted((c.describe() for c in REGISTRY.values()), key=lambda x: (x["family"], x["kind"]))
