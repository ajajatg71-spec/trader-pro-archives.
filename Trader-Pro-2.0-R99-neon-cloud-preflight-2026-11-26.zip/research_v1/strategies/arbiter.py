"""Arbitrage entre stratégies : une même opportunité ne doit jamais produire d'ordres contradictoires ni d'ordres en double."""

POLICIES = ("risk_first", "priority", "veto")

def arbitrate(intents, policy="risk_first", in_flight=(), cooldown=(), symbol_caps=None, default_cap=None, order_cap=None):
    """intents : dicts dimensionnés {decision_id, strategy, symbol, side, kind, notional, priority, reason}.
    Règles, titre par titre : (1) un ordre déjà en cours sur le titre : tout est ignoré ; (2) achat et vente sur le même titre : un stop de risque gagne toujours,
    sinon selon la politique (risk_first : la vente ; priority : la stratégie la plus prioritaire ; veto : aucun ordre) ; (3) pas d'achat pendant le délai de réflexion après une vente ;
    (4) les achats du titre sont fusionnés en un seul ordre, plafonné par symbol_caps[titre] (ou default_cap) et réparti au prorata ; (5) les ventes aussi, sans plafond de titre ;
    (6) order_cap plafonne le montant de tout ordre (achat ou vente), par exemple pour respecter la limite globale de taille d'ordre.
    Renvoie (ordres, supprimés) ; supprimés = {decision_id: raison}."""
    if policy not in POLICIES: raise ValueError(f"Politique de conflit inconnue : {policy}")
    caps, orders, suppressed, by = symbol_caps or {}, [], {}, {}
    for i in intents: by.setdefault(i["symbol"], []).append(i)
    for sym in sorted(by):
        items = sorted(by[sym], key=lambda i: (i["priority"], i["strategy"], i["decision_id"]))
        if sym in in_flight:
            for i in items: suppressed[i["decision_id"]] = "un ordre est déjà en cours sur ce titre"
            continue
        buys, sells = [i for i in items if i["side"] == "buy"], [i for i in items if i["side"] == "sell"]
        if buys and sells:
            if any(s["kind"] == "stop" for s in sells): drop, why = buys, "conflit : un stop de risque est en cours sur ce titre"
            elif policy == "risk_first": drop, why = buys, f"conflit : {', '.join(sorted({s['strategy'] for s in sells}))} vend ce titre (le risque passe d'abord)"
            elif policy == "priority": drop, why = (sells if items[0]["side"] == "buy" else buys), f"conflit : {items[0]['strategy']} est prioritaire"
            else: drop, why = buys + sells, "conflit : aucun ordre (politique veto)"
            for i in drop: suppressed[i["decision_id"]] = why
            buys, sells = [i for i in buys if i["decision_id"] not in suppressed], [i for i in sells if i["decision_id"] not in suppressed]
        if buys and sym in cooldown:
            for i in buys: suppressed[i["decision_id"]] = "délai de réflexion après une vente récente"
            buys = []
        for side, group in (("buy", buys), ("sell", sells)):
            if not group: continue
            total = sum(i["notional"] for i in group); cap = caps.get(sym, default_cap) if side == "buy" else None
            scale = min(1.0, max(cap, 0.0) / total) if cap is not None and total > 0 else 1.0
            if order_cap is not None and total > 0: scale = min(scale, max(order_cap, 0.0) / total)
            orders.append({"symbol": sym, "side": side, "notional": round(total * scale, 2), "scaled": scale < 1.0,
                           "attribution": [{"strategy": i["strategy"], "notional": round(i["notional"] * scale, 2), "decision_id": i["decision_id"]} for i in group],
                           "decision_ids": [i["decision_id"] for i in group], "kinds": sorted({i["kind"] for i in group}), "reasons": [f"{i['strategy']} : {i['reason']}" for i in group]})
    return orders, suppressed
