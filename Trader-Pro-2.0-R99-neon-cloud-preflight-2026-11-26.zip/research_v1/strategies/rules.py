"""Règles d'entrée et de sortie des stratégies par titre (43 règles). Une règle lit les indicateurs au curseur (Features) et renvoie une raison chiffrée.
Aucune de ces règles n'est « prouvée » : le tableau de fiabilité (backend/backtesting/scoreboard.py) les mesure hors échantillon et écarte celles qui échouent."""
from research_v1.quant import levels as L

COMMON = {"position_pct": (0.2, 0.01, 1.0, "part du capital par ligne"), "max_hold_days": (0, 0, 500, "durée maximale de détention en jours (0 = sans limite)"), "stop_atr": (0.0, 0.0, 10.0, "stop à X ATR sous le prix de revient (0 = sans stop)")}
SPECS = {}

def rule(kind, label, params, entry, exit_=None):
    """Enregistre une règle : libellé, paramètres (défaut, bornes, rôle), fonction d'entrée et fonction de sortie facultative."""
    SPECS[kind] = {"label": label, "params": {**COMMON, **params}, "entry": entry, "exit": exit_ or (lambda f, p, pos: None)}

def ok(*x):
    """Vrai si aucune des valeurs n'est indéfinie."""
    return all(v is not None for v in x)

def cross_up(fa, fb, window=1):
    """Vrai si la série a est au-dessus de b et l'a franchie à la hausse dans les `window` dernières barres."""
    if not ok(fa(0), fb(0)) or fa(0) <= fb(0): return False
    for j in range(window):
        a1, b1, a0, b0 = fa(j + 1), fb(j + 1), fa(j), fb(j)
        if ok(a1, b1, a0, b0) and a1 <= b1 and a0 > b0: return True
    return False

def _uptrend(f, n=200):
    s = f.v("sma", n); return ok(s) and f.close > s

BULL_REV = {"hammer", "inverted_hammer", "dragonfly_doji", "bullish_engulfing", "piercing_line", "bullish_harami", "bullish_harami_cross", "tweezer_bottom", "morning_star", "morning_doji_star", "three_inside_up", "three_outside_up", "bullish_kicker"}
BEAR_REV = {"hanging_man", "shooting_star", "gravestone_doji", "bearish_engulfing", "dark_cloud_cover", "bearish_harami", "bearish_harami_cross", "tweezer_top", "evening_star", "evening_doji_star", "three_inside_down", "three_outside_down", "bearish_kicker", "three_black_crows"}
BULL_CONT = {"three_white_soldiers", "rising_three_methods", "bullish_marubozu"}
DOJIS = {"doji", "long_legged_doji", "dragonfly_doji"}

def pats(f, codes, at=0, min_strength=0.0, context=True):
    """Figures de chandeliers de la liste, à la barre `at`, avec contexte valide (sauf context=False) et force minimale."""
    return [p for p in f.patterns(at=at) if p.code in codes and p.strength >= min_strength and (p.context_ok or not context)]

def bearish_pattern(f):
    """Raison de sortie si une figure baissière avec son contexte apparaît à la barre courante."""
    ps = pats(f, BEAR_REV); return f"figure baissière : {ps[0].name}" if ps else None

def support_touch(f, tol):
    """Niveaux de support touchés par la bougie courante (à ±tol x ATR)."""
    atr = f.v("atr", 14); return L.touching(f.levels(), f.low, f.high, atr, tol, "support") if atr else []

# ----- tendance -----
def _golden_e(f, p):
    a, b = (lambda k: f.v("sma", p["fast"], at=k)), (lambda k: f.v("sma", p["slow"], at=k))
    if p["fast"] < p["slow"] and cross_up(a, b, p["window"]): return f"croisement doré : moyenne {p['fast']} j ({a(0):.2f}) au-dessus de la moyenne {p['slow']} j ({b(0):.2f})", 0.6
def _golden_x(f, p, pos):
    a, b = f.v("sma", p["fast"]), f.v("sma", p["slow"]); return "croisement de la mort : moyenne rapide sous la lente" if ok(a, b) and a < b else None
rule("golden_cross", "Croisement doré (moyenne 50 j au-dessus de la 200 j)", {"fast": (50, 5, 100, "moyenne rapide"), "slow": (200, 50, 400, "moyenne lente"), "window": (3, 1, 10, "fraîcheur du croisement (barres)")}, _golden_e, _golden_x)

def _ema_e(f, p):
    a, b, adx = (lambda k: f.v("ema", p["fast"], at=k)), (lambda k: f.v("ema", p["slow"], at=k)), f.v("adx", 14)
    if p["fast"] < p["slow"] and ok(adx) and adx >= p["adx_min"] and cross_up(a, b, p["window"]): return f"croisement EMA {p['fast']}/{p['slow']} avec ADX {adx:.0f}", 0.55
def _ema_x(f, p, pos):
    a, b = f.v("ema", p["fast"]), f.v("ema", p["slow"]); return "EMA rapide repassée sous l'EMA lente" if ok(a, b) and a < b else None
rule("ema_cross", "Croisement d'EMA filtré par l'ADX", {"fast": (12, 2, 50, "EMA rapide"), "slow": (26, 5, 100, "EMA lente"), "adx_min": (20, 5, 50, "ADX minimal"), "window": (2, 1, 10, "fraîcheur du croisement")}, _ema_e, _ema_x)

def _triple_e(f, p):
    e1, e2, e3, e3p = f.v("ema", 8), f.v("ema", 21), f.v("ema", 55), f.v("ema", 55, at=5)
    if ok(e1, e2, e3, e3p) and f.close > e1 > e2 > e3 and e3 > e3p: return f"EMA 8 > 21 > 55 alignées et EMA 55 en hausse ({e1:.2f} > {e2:.2f} > {e3:.2f})", 0.55
def _triple_x(f, p, pos):
    e = f.v("ema", 21); return "cours sous l'EMA 21" if ok(e) and f.close < e else None
rule("triple_ema", "Triple EMA alignées (8, 21, 55)", {}, _triple_e, _triple_x)

def _macd_e(f, p):
    h0, h1 = f.v("macd_hist"), f.v("macd_hist", at=1)
    if ok(h0, h1) and h1 <= 0 < h0 and (not p["trend_filter"] or _uptrend(f)): return f"histogramme MACD passé au positif ({h1:.3f} puis {h0:.3f})", 0.5
def _macd_x(f, p, pos):
    h = f.v("macd_hist"); return "histogramme MACD négatif" if ok(h) and h < 0 else None
rule("macd_cross", "MACD : croisement de la ligne de signal à la hausse", {"trend_filter": (True, None, None, "exiger cours > moyenne 200 j")}, _macd_e, _macd_x)

def _st_e(f, p):
    d = [f.v("st_dir", p["n"], p["mult"], at=k) for k in range(p["window"] + 1)]
    if d[0] == 1 and any(d[k] == 1 and d[k + 1] == -1 for k in range(p["window"])): return f"Supertrend repassé à la hausse (ATR {p['n']}, facteur {p['mult']})", 0.55
def _st_x(f, p, pos): return "Supertrend repassé à la baisse" if f.v("st_dir", p["n"], p["mult"]) == -1 else None
rule("supertrend", "Supertrend (retournement haussier)", {"n": (10, 2, 50, "période ATR"), "mult": (3.0, 0.5, 10.0, "facteur ATR"), "window": (3, 1, 10, "fraîcheur du retournement")}, _st_e, _st_x)

def _aroon_e(f, p):
    u, d = f.v("aroon_up", p["n"]), f.v("aroon_down", p["n"])
    if ok(u, d) and u >= 70 and d <= 30: return f"Aroon haut {u:.0f}, bas {d:.0f} : nouveaux plus hauts récents", 0.5
def _aroon_x(f, p, pos):
    u, d = f.v("aroon_up", p["n"]), f.v("aroon_down", p["n"]); return "Aroon bas au-dessus de Aroon haut" if ok(u, d) and d > u else None
rule("aroon_trend", "Aroon : tendance haussière récente", {"n": (25, 5, 100, "période")}, _aroon_e, _aroon_x)

def _ichi_e(f, p):
    a, b, t, k = f.v("span_a"), f.v("span_b"), f.v("tenkan"), f.v("kijun")
    if ok(a, b, t, k) and f.close > max(a, b) and t > k and f.close > k and a > b: return f"cours au-dessus du nuage Ichimoku ({max(a, b):.2f}), tenkan {t:.2f} > kijun {k:.2f}", 0.6
def _ichi_x(f, p, pos):
    k = f.v("kijun"); return "cours sous la kijun" if ok(k) and f.close < k else None
rule("ichimoku_cloud", "Ichimoku : cours au-dessus du nuage", {}, _ichi_e, _ichi_x)

def _adxdi_e(f, p):
    a = f.v("adx", p["n"])
    if ok(a) and a >= p["adx_min"] and cross_up(lambda k: f.v("pdi", p["n"], at=k), lambda k: f.v("mdi", p["n"], at=k), p["window"]): return f"+DI passe au-dessus de -DI avec un ADX de {a:.0f}", 0.55
def _adxdi_x(f, p, pos):
    pd, md = f.v("pdi", p["n"]), f.v("mdi", p["n"]); return "-DI au-dessus de +DI" if ok(pd, md) and md > pd else None
rule("adx_di_cross", "Croisement +DI / -DI avec ADX", {"n": (14, 5, 50, "période"), "adx_min": (20, 5, 50, "ADX minimal"), "window": (2, 1, 10, "fraîcheur")}, _adxdi_e, _adxdi_x)

def _kc_e(f, p):
    u, u1, c1 = f.v("kc_up", p["n"], 10, p["mult"]), f.v("kc_up", p["n"], 10, p["mult"], at=1), f.v("close", at=1)
    if ok(u, u1, c1) and f.close > u and c1 <= u1 and (not p["trend_filter"] or _uptrend(f)): return f"cassure du canal de Keltner ({f.close:.2f} > {u:.2f})", 0.55
def _kc_x(f, p, pos):
    m = f.v("kc_mid", p["n"], 10, p["mult"]); return "cours sous le milieu du canal de Keltner" if ok(m) and f.close < m else None
rule("keltner_breakout", "Cassure du canal de Keltner", {"n": (20, 5, 100, "période EMA"), "mult": (2.0, 0.5, 5.0, "facteur ATR"), "trend_filter": (True, None, None, "exiger cours > moyenne 200 j")}, _kc_e, _kc_x)

def _high_e(f, p):
    hi = f.v("close_hi", p["lookback"])
    if ok(hi) and f.close >= hi: return f"nouveau plus haut de clôture sur {p['lookback']} séances ({f.close:.2f})", 0.55
def _high_x(f, p, pos):
    s = f.v("sma", p["exit_ma"]); return f"cours sous la moyenne {p['exit_ma']} j" if ok(s) and f.close < s else None
rule("new_high_52w", "Nouveau plus haut sur 52 semaines", {"lookback": (252, 60, 500, "fenêtre"), "exit_ma": (50, 10, 200, "moyenne de sortie")}, _high_e, _high_x)

def _rs_e(f, p):
    rs, rm, roc = f.v("rs"), f.v("rs_sma", p["rs_ma"]), f.v("rs_roc", p["rs_n"])
    if ok(rs, rm, roc) and rs > rm and roc >= p["min_rs"] and _uptrend(f): return f"force relative en hausse de {roc * 100:.1f} % sur {p['rs_n']} séances et au-dessus de sa moyenne", 0.55
def _rs_x(f, p, pos):
    rs, rm = f.v("rs"), f.v("rs_sma", p["rs_ma"]); return "force relative sous sa moyenne" if ok(rs, rm) and rs < rm else None
rule("rs_leader", "Leader de force relative face à l'indice", {"rs_n": (63, 10, 250, "fenêtre"), "rs_ma": (50, 10, 200, "moyenne de la ligne de force relative"), "min_rs": (0.05, -0.5, 1.0, "surperformance minimale")}, _rs_e, _rs_x)

def _pull_e(f, p):
    e20, e50, r = f.v("ema", 20), f.v("ema", 50), f.v("rsi", 14)
    if ok(e20, e50, r) and _uptrend(f) and e20 > e50 and f.low <= e20 <= f.close and p["rsi_lo"] <= r <= p["rsi_hi"]: return f"repli sur l'EMA 20 dans une tendance haussière (RSI {r:.0f})", 0.55
def _pull_x(f, p, pos):
    e50, r = f.v("ema", 50), f.v("rsi", 14)
    if ok(e50) and f.close < e50: return "cours sous l'EMA 50"
    if ok(r) and r > p["rsi_exit"]: return f"RSI {r:.0f} élevé"
rule("trend_pullback", "Repli sur l'EMA 20 dans une tendance haussière", {"rsi_lo": (40, 20, 60, "RSI minimal"), "rsi_hi": (55, 40, 80, "RSI maximal"), "rsi_exit": (70, 55, 95, "RSI de sortie")}, _pull_e, _pull_x)

def _don_e(f, p):
    hi = f.v("don_hi", p["entry_n"])
    if ok(hi) and f.close > hi: return f"cassure du plus haut {p['entry_n']} séances ({hi:.2f})", 0.55
def _don_x(f, p, pos):
    lo = f.v("don_lo", p["exit_n"]); return f"cassure du plus bas {p['exit_n']} séances ({lo:.2f})" if ok(lo) and f.close < lo else None
rule("donchian_turtle", "Tortues : canal de Donchian 20/10", {"entry_n": (20, 5, 100, "canal d'entrée"), "exit_n": (10, 3, 50, "canal de sortie")}, _don_e, _don_x)

# ----- retour à la moyenne -----
def _rsi2_e(f, p):
    r = f.v("rsi", 2)
    if ok(r) and r < p["rsi_buy"] and _uptrend(f): return f"RSI(2) à {r:.1f} dans une tendance haussière", 0.55
def _rsi2_x(f, p, pos):
    r, s = f.v("rsi", 2), f.v("sma", p["sma_exit"])
    if ok(r) and r > p["rsi_exit"]: return f"RSI(2) remonté à {r:.0f}"
    if ok(s) and f.close > s: return f"cours au-dessus de la moyenne {p['sma_exit']} j"
rule("rsi2", "RSI(2) de Connors", {"rsi_buy": (10, 1, 30, "seuil d'entrée"), "rsi_exit": (70, 50, 95, "seuil de sortie"), "sma_exit": (5, 2, 20, "moyenne de sortie")}, _rsi2_e, _rsi2_x)

def _bb_e(f, p):
    lo, lo1, c1 = f.v("bb_lo"), f.v("bb_lo", at=1), f.v("close", at=1)
    if ok(lo, lo1, c1) and c1 < lo1 and f.close > lo and (not p["trend_filter"] or _uptrend(f)): return f"retour dans les bandes de Bollinger après une clôture sous la bande basse ({lo1:.2f})", 0.55
def _bb_x(f, p, pos):
    m = f.v("bb_mid"); return "cours revenu à la moyenne de Bollinger" if ok(m) and f.close >= m else None
rule("bollinger_bounce", "Rebond sur la bande basse de Bollinger", {"trend_filter": (True, None, None, "exiger cours > moyenne 200 j")}, _bb_e, _bb_x)

def _sto_e(f, p):
    k, d, k1, d1 = f.v("stoch_k"), f.v("stoch_d"), f.v("stoch_k", at=1), f.v("stoch_d", at=1)
    if ok(k, d, k1, d1) and k1 <= d1 and k > d and k1 < p["oversold"]: return f"%K croise %D à la hausse en zone de survente ({k1:.0f} puis {k:.0f})", 0.5
def _sto_x(f, p, pos):
    k = f.v("stoch_k"); return f"%K en surachat ({k:.0f})" if ok(k) and k > p["overbought"] else None
rule("stochastic_cross", "Stochastique : croisement en survente", {"oversold": (25, 5, 50, "seuil de survente"), "overbought": (75, 50, 95, "seuil de surachat")}, _sto_e, _sto_x)

def _cci_e(f, p):
    c0, c1 = f.v("cci"), f.v("cci", at=1)
    if ok(c0, c1) and c1 < -p["level"] <= c0: return f"CCI remonté au-dessus de {-p['level']} ({c1:.0f} puis {c0:.0f})", 0.5
def _cci_x(f, p, pos):
    c = f.v("cci"); return f"CCI au-dessus de {p['exit_level']}" if ok(c) and c > p["exit_level"] else None
rule("cci_reversal", "CCI : sortie de survente", {"level": (100, 50, 300, "seuil"), "exit_level": (50, -100, 200, "seuil de sortie")}, _cci_e, _cci_x)

def _wr_e(f, p):
    w0, w1, s = f.v("willr"), f.v("willr", at=1), f.v("sma", 50)
    if ok(w0, w1, s) and w1 < -80 <= w0 and f.close > s: return f"%R de Williams sorti de survente ({w1:.0f} puis {w0:.0f})", 0.5
def _wr_x(f, p, pos):
    w = f.v("willr"); return "%R de Williams en surachat" if ok(w) and w > -20 else None
rule("williams_reversal", "Williams %R : sortie de survente", {}, _wr_e, _wr_x)

def _ibs_e(f, p):
    i = f.v("ibs")
    if ok(i) and i < p["ibs_buy"] and _uptrend(f): return f"clôture dans le bas de la barre (IBS {i:.2f}) dans une tendance haussière", 0.5
def _ibs_x(f, p, pos):
    i = f.v("ibs"); return f"IBS {i:.2f} élevé" if ok(i) and i > p["ibs_exit"] else None
rule("ibs_reversion", "IBS : clôture dans le bas de la barre", {"ibs_buy": (0.2, 0.02, 0.5, "seuil d'entrée"), "ibs_exit": (0.8, 0.5, 0.98, "seuil de sortie")}, _ibs_e, _ibs_x)

def _z_e(f, p):
    z = f.v("z", p["n"])
    if ok(z) and z < p["z_buy"] and (not p["trend_filter"] or _uptrend(f)): return f"cours à {z:.1f} écarts-types sous sa moyenne {p['n']} j", 0.55
def _z_x(f, p, pos):
    z = f.v("z", p["n"]); return "cours revenu à sa moyenne" if ok(z) and z > 0 else None
rule("zscore_reversion", "Retour à la moyenne (z-score)", {"n": (20, 5, 100, "fenêtre"), "z_buy": (-2.0, -4.0, -0.5, "z-score d'entrée"), "trend_filter": (True, None, None, "exiger cours > moyenne 200 j")}, _z_e, _z_x)

def _mfi_e(f, p):
    m0, m1 = f.v("mfi"), f.v("mfi", at=1)
    if ok(m0, m1) and m0 < p["level"] and m0 > m1 and _uptrend(f): return f"MFI à {m0:.0f} (survente) et en remontée", 0.5
def _mfi_x(f, p, pos):
    m = f.v("mfi"); return f"MFI à {m:.0f}" if ok(m) and m > p["exit_level"] else None
rule("mfi_oversold", "Money Flow Index en survente", {"level": (20, 5, 40, "seuil"), "exit_level": (70, 50, 95, "seuil de sortie")}, _mfi_e, _mfi_x)

def _vw_e(f, p):
    vw, r = f.v("vwap", 20), f.v("rsi", 14)
    if ok(vw, r) and f.close < vw * (1 - p["dev"]) and r < p["rsi_max"] and _uptrend(f): return f"cours {abs(f.close / vw - 1) * 100:.1f} % sous le prix moyen pondéré 20 j (RSI {r:.0f})", 0.5
def _vw_x(f, p, pos):
    vw = f.v("vwap", 20); return "cours revenu au prix moyen pondéré" if ok(vw) and f.close >= vw else None
rule("vwap_reversion", "Retour au prix moyen pondéré (VWAP 20 j)", {"dev": (0.03, 0.005, 0.2, "écart d'entrée"), "rsi_max": (40, 20, 60, "RSI maximal")}, _vw_e, _vw_x)

def _gap_e(f, p):
    g = f.v("gap")
    if ok(g) and g <= -p["gap_pct"] and f.close > f.open: return f"ouverture en gap baissier de {g * 100:.1f} % puis bougie haussière", 0.5
def _gap_x(f, p, pos): return f"objectif de {p['target_pct'] * 100:.0f} % atteint" if f.close >= pos["avg"] * (1 + p["target_pct"]) else None
rule("gap_fill", "Comblement de gap baissier", {"gap_pct": (0.02, 0.005, 0.2, "taille du gap"), "target_pct": (0.02, 0.005, 0.2, "objectif"), "max_hold_days": (5, 0, 500, "durée maximale de détention")}, _gap_e, _gap_x)

# ----- volatilité et volume -----
def _vol_e(f, p):
    prev = [x for x in (f.v("bw_pct", 126, at=k) for k in range(1, p["lookback"] + 1)) if x is not None]; u = f.v("bb_up")
    if prev and ok(u) and min(prev) <= p["squeeze_pct"] and f.close > u: return f"sortie de compression (percentile {min(prev) * 100:.0f} %) avec cassure de la bande haute", 0.55
def _vol_x(f, p, pos):
    m = f.v("bb_mid"); return "cours sous la moyenne de Bollinger" if ok(m) and f.close < m else None
rule("volatility", "Compression puis expansion de volatilité", {"squeeze_pct": (0.15, 0.01, 0.5, "percentile de compression"), "lookback": (5, 1, 30, "séances observées")}, _vol_e, _vol_x)

def _squeeze(f, k): return all(ok(x) for x in (f.v("bb_up", at=k), f.v("kc_up", at=k))) and f.v("bb_up", at=k) < f.v("kc_up", at=k) and f.v("bb_lo", at=k) > f.v("kc_lo", at=k)
def _ttm_e(f, p):
    m = f.v("kc_mid")
    if _squeeze(f, 1) and not _squeeze(f, 0) and ok(m) and f.close > m: return "compression Bollinger/Keltner relâchée à la hausse", 0.55
def _ttm_x(f, p, pos):
    m = f.v("kc_mid"); return "cours sous le milieu de Keltner" if ok(m) and f.close < m else None
rule("ttm_squeeze", "Squeeze Bollinger dans Keltner relâché", {}, _ttm_e, _ttm_x)

def _nr_e(f, p):
    if f.v("nr", p["n"], at=1) is True and ok(f.v("high", at=1)) and f.close > f.v("high", at=1): return f"cassure de la veille, jour à amplitude la plus étroite des {p['n']} dernières séances", 0.5
def _below_ma(n): return lambda f, p, pos: (f"cours sous la moyenne {p['exit_ma']} j" if ok(f.v("sma", p["exit_ma"])) and f.close < f.v("sma", p["exit_ma"]) else None)
rule("nr7_breakout", "NR7 : cassure après le jour le plus étroit", {"n": (7, 4, 20, "fenêtre"), "exit_ma": (10, 3, 50, "moyenne de sortie")}, _nr_e, _below_ma(0))

def _ib_e(f, p):
    h1, l1, h2, l2, s = f.v("high", at=1), f.v("low", at=1), f.v("high", at=2), f.v("low", at=2), f.v("sma", 50)
    if ok(h1, l1, h2, l2, s) and h1 < h2 and l1 > l2 and f.close > h2 and f.close > s: return f"cassure du haut de la barre mère ({h2:.2f}) après une barre intérieure", 0.5
rule("inside_bar_breakout", "Cassure après une barre intérieure", {"exit_ma": (10, 3, 50, "moyenne de sortie")}, _ib_e, _below_ma(0))

def _atrx_e(f, p):
    tr, a1, i, s, rv = f.v("tr"), f.v("atr", 14, at=1), f.v("ibs"), f.v("sma", 50), f.v("relvol", 20)
    if ok(tr, a1, i, s, rv) and tr >= p["mult"] * a1 and i >= 0.75 and f.close > s and rv >= p["relvol_min"]: return f"amplitude {tr / a1:.1f} fois l'ATR, clôture dans le haut de la barre, volume {rv:.1f} fois la moyenne", 0.55
def _atrx_x(f, p, pos):
    e = f.v("ema", 10); return "cours sous l'EMA 10" if ok(e) and f.close < e else None
rule("atr_expansion", "Expansion d'amplitude avec volume", {"mult": (2.0, 1.2, 5.0, "amplitude / ATR"), "relvol_min": (1.2, 0.5, 5.0, "volume relatif minimal")}, _atrx_e, _atrx_x)

def _obv_e(f, p):
    o, om, om5, s = f.v("obv"), f.v("obv_sma", 20), f.v("obv_sma", 20, at=5), f.v("sma", 50)
    if ok(o, om, om5, s) and f.close > s and o > om and om > om5: return "volume cumulé (OBV) au-dessus de sa moyenne et en hausse, cours au-dessus de la moyenne 50 j", 0.5
def _obv_x(f, p, pos):
    o, om = f.v("obv"), f.v("obv_sma", 20); return "OBV sous sa moyenne" if ok(o, om) and o < om else None
rule("obv_trend", "OBV : volume qui confirme la tendance", {}, _obv_e, _obv_x)

def _cmf_e(f, p):
    c, s5, s2 = f.v("cmf", 20), f.v("sma", 50), f.v("sma", 200)
    if ok(c, s5, s2) and c > p["level"] and f.close > s5 and f.close > s2: return f"flux de capitaux (Chaikin) à {c:.2f} dans une tendance haussière", 0.5
def _cmf_x(f, p, pos):
    c = f.v("cmf", 20); return "flux de capitaux négatif" if ok(c) and c < 0 else None
rule("cmf_trend", "Chaikin Money Flow positif en tendance", {"level": (0.10, 0.0, 0.5, "seuil")}, _cmf_e, _cmf_x)

# ----- chandeliers -----
def _crs_e(f, p):
    ps = pats(f, BULL_REV, min_strength=p["min_strength"]); sup = support_touch(f, p["tol_atr"]) if ps else []
    if ps and sup: return f"{ps[0].explanation} ; au contact du support {sup[0]['price']:.2f} ({sup[0]['touches']} contacts)", ps[0].strength
def _crs_x(f, p, pos):
    r = f.v("rsi", 14); return bearish_pattern(f) or (f"RSI {r:.0f} élevé" if ok(r) and r > p["rsi_exit"] else None)
rule("candle_reversal_support", "Figure haussière sur un support", {"min_strength": (0.5, 0.0, 1.0, "force minimale de la figure"), "tol_atr": (0.5, 0.1, 2.0, "tolérance (ATR)"), "rsi_exit": (65, 50, 90, "RSI de sortie")}, _crs_e, _crs_x)

def _cc_e(f, p):
    ps, s5, s2, rv = pats(f, BULL_CONT), f.v("sma", 50), f.v("sma", 200), f.v("relvol", 20)
    if ps and ok(s5, s2, rv) and f.close > s5 > s2 and rv >= p["min_relvol"]: return f"{ps[0].explanation} ; tendance haussière, volume {rv:.1f} fois la moyenne", ps[0].strength
def _cc_x(f, p, pos):
    e = f.v("ema", 20); return bearish_pattern(f) or ("cours sous l'EMA 20" if ok(e) and f.close < e else None)
rule("candle_continuation", "Figure de continuation haussière en tendance", {"min_relvol": (1.0, 0.3, 5.0, "volume relatif minimal")}, _cc_e, _cc_x)

def _conf_e(f, p):
    ps = pats(f, BULL_REV)
    if not ps: return None
    r, k, rv, v = f.v("rsi", 14), f.v("stoch_k"), f.v("relvol", 20), []
    if ok(r) and r < 40: v.append(f"RSI {r:.0f} < 40")
    if ok(k) and k < 30: v.append(f"stochastique {k:.0f} < 30")
    if support_touch(f, 0.5): v.append("au contact d'un support")
    if ok(rv) and rv >= 1.3: v.append(f"volume {rv:.1f}x")
    if _uptrend(f): v.append("au-dessus de la moyenne 200 j")
    if len(v) >= p["min_votes"]: return f"{ps[0].explanation} ; confluence de {len(v)} signaux : " + ", ".join(v), min(1.0, ps[0].strength + 0.1 * len(v))
def _conf_x(f, p, pos):
    r = f.v("rsi", 14); return bearish_pattern(f) or (f"RSI {r:.0f} élevé" if ok(r) and r > 65 else None)
rule("candle_confluence", "Figure haussière confirmée par plusieurs signaux", {"min_votes": (3, 2, 5, "nombre minimal de signaux concordants")}, _conf_e, _conf_x)

def _eng_e(f, p):
    ps, e20, e50 = pats(f, {"bullish_engulfing"}), f.v("ema", 20), f.v("ema", 50)
    if ps and ok(e20, e50) and _uptrend(f) and e20 > e50 and f.low <= e20 * (1 + p["tol"]): return f"{ps[0].explanation} ; au contact de l'EMA 20 dans une tendance haussière", ps[0].strength
def _eng_x(f, p, pos):
    e = f.v("ema", 50); return "avalement baissier" if pats(f, {"bearish_engulfing"}) else ("cours sous l'EMA 50" if ok(e) and f.close < e else None)
rule("engulfing_pullback", "Avalement haussier sur repli en tendance", {"tol": (0.005, 0.0, 0.05, "tolérance autour de l'EMA 20")}, _eng_e, _eng_x)

def _pin_e(f, p):
    ps, ll = pats(f, {"hammer", "dragonfly_doji"}), f.v("ll", 20); rng = f.high - f.low
    if ps and ok(ll) and rng > 0 and (min(f.open, f.close) - f.low) / rng >= p["tail"] and f.low <= ll * 1.002: return f"{ps[0].explanation} ; mèche basse de {(min(f.open, f.close) - f.low) / rng * 100:.0f} % de l'amplitude au plus bas 20 séances", ps[0].strength
def _pin_x(f, p, pos):
    e = f.v("ema", 10); return "cours revenu au-dessus de l'EMA 10" if ok(e) and f.close >= e else None
rule("pin_bar_support", "Marteau à longue mèche sur un plus bas", {"tail": (0.66, 0.5, 0.95, "mèche basse minimale (part de l'amplitude)")}, _pin_e, _pin_x)

def _ms_e(f, p):
    ps = pats(f, {"morning_star", "morning_doji_star"}, min_strength=p["min_strength"])
    if ps: return ps[0].explanation, ps[0].strength
def _ms_x(f, p, pos):
    r = f.v("rsi", 14)
    if f.close < pos["avg"] * (1 - p["stop_pct"]): return f"stop de {p['stop_pct'] * 100:.0f} % sous le prix de revient"
    return bearish_pattern(f) or (f"RSI {r:.0f} élevé" if ok(r) and r > p["rsi_exit"] else None)
rule("morning_star_trade", "Étoile du matin", {"min_strength": (0.4, 0.0, 1.0, "force minimale"), "stop_pct": (0.04, 0.01, 0.2, "stop"), "rsi_exit": (65, 50, 90, "RSI de sortie")}, _ms_e, _ms_x)

def _out_e(f, p):
    h1, l1, c1, c2, c3 = f.v("high", at=1), f.v("low", at=1), f.v("close", at=1), f.v("close", at=2), f.v("close", at=3)
    if ok(h1, l1, c1, c2, c3) and f.high > h1 and f.low < l1 and f.close > h1 and c1 < c2 < c3: return "barre englobante haussière après trois clôtures en baisse", 0.5
def _rsi_x(f, p, pos):
    r = f.v("rsi", 14); return f"RSI {r:.0f} élevé" if ok(r) and r > 65 else None
rule("outside_reversal", "Retournement par barre extérieure", {}, _out_e, _rsi_x)

def _doji_e(f, p):
    ps, h1, e, e5 = pats(f, DOJIS, at=1, context=False), f.v("high", at=1), f.v("ema", 20), f.v("ema", 20, at=5)
    if ps and ok(h1, e, e5) and e < e5 and f.close > h1: return f"{ps[0].explanation} (veille), confirmé par une clôture au-dessus de son plus haut ({h1:.2f})", 0.5
rule("doji_confirmation", "Doji en baisse confirmé par la bougie suivante", {}, _doji_e, _rsi_x)

def _kick_e(f, p):
    ps, rv = pats(f, {"bullish_kicker"}), f.v("relvol", 20)
    if ps and ok(rv) and rv >= p["relvol_min"]: return f"{ps[0].explanation} ; volume {rv:.1f} fois la moyenne", ps[0].strength
def _kick_x(f, p, pos):
    r = f.v("rsi", 14); return bearish_pattern(f) or (f"RSI {r:.0f} élevé" if ok(r) and r > 70 else None)
rule("kicker_gap", "Coup de pied haussier avec volume", {"relvol_min": (1.5, 0.5, 5.0, "volume relatif minimal")}, _kick_e, _kick_x)

def _har_e(f, p):
    ps, h1 = pats(f, {"bullish_harami", "bullish_harami_cross"}, at=1), f.v("high", at=1)
    if ps and ok(h1) and f.close > h1: return f"{ps[0].explanation} (veille), confirmé par une clôture au-dessus de son plus haut ({h1:.2f})", ps[0].strength
rule("harami_confirmation", "Harami haussier confirmé", {}, _har_e, _kick_x)

# ----- stratégies d'origine (versions à base de règles) -----
def _mr_e(f, p):
    r, pb = f.v("rsi", 14), f.v("bb_pctb")
    if ok(r, pb) and r < p["rsi_buy"] and pb <= p["pctb_buy"] and _uptrend(f): return f"survente : RSI {r:.0f}, %B {pb:.2f}, dans une tendance haussière", 0.55
def _mr_x(f, p, pos):
    r, m = f.v("rsi", 14), f.v("bb_mid")
    if ok(r) and r >= p["rsi_exit"]: return f"RSI revenu à {r:.0f}"
    if ok(m) and f.close >= m: return "cours revenu à la moyenne de Bollinger"
rule("mean_reversion", "Retour à la moyenne : survente RSI et Bollinger", {"rsi_buy": (30, 5, 50, "RSI d'entrée"), "pctb_buy": (0.05, -0.5, 0.5, "%B maximal"), "rsi_exit": (55, 30, 90, "RSI de sortie")}, _mr_e, _mr_x)

def _tf_e(f, p):
    a, pd, md, sf, ss = f.v("adx", 14), f.v("pdi", 14), f.v("mdi", 14), f.v("sma", p["fast"]), f.v("sma", p["slow"])
    if ok(a, pd, md, sf, ss) and a >= p["adx_min"] and pd > md and f.close > sf > ss: return f"tendance haussière forte : ADX {a:.0f}, cours > moyenne {p['fast']} j > moyenne {p['slow']} j", min(1.0, a / 50)
def _tf_x(f, p, pos):
    sf, hi, at = f.v("sma", p["fast"]), f.v("close_hi", p["chand_n"]), f.v("atr", 14)
    if ok(sf) and f.close < sf: return f"cours sous la moyenne {p['fast']} j"
    if ok(hi, at) and f.close < hi - p["atr_mult"] * at: return f"stop suiveur touché ({hi - p['atr_mult'] * at:.2f})"
rule("trend_following", "Suivi de tendance (ADX et moyennes mobiles)", {"adx_min": (25, 10, 60, "ADX minimal"), "fast": (50, 10, 100, "moyenne rapide"), "slow": (200, 100, 300, "moyenne lente"), "atr_mult": (3.0, 1.0, 10.0, "stop suiveur en ATR"), "chand_n": (22, 5, 100, "fenêtre du plus haut")}, _tf_e, _tf_x)

def _bo_e(f, p):
    hi, rv = f.v("don_hi", p["n"]), f.v("relvol", 20)
    if ok(hi, rv) and f.close > hi and rv >= p["vol_mult"]: return f"cassure du plus haut {p['n']} séances ({hi:.2f}) avec un volume {rv:.1f} fois la moyenne", min(1.0, rv / 3)
def _bo_x(f, p, pos):
    lo = f.v("don_lo", p["exit_n"]); return f"cassure du bas du canal {p['exit_n']} séances ({lo:.2f})" if ok(lo) and f.close < lo else None
rule("breakout", "Cassure de canal avec volume", {"n": (55, 10, 250, "canal d'entrée"), "exit_n": (20, 5, 100, "canal de sortie"), "vol_mult": (1.5, 0.5, 10.0, "volume relatif minimal")}, _bo_e, _bo_x)
