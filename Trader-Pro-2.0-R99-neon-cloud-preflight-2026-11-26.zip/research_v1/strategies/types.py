"""Types du moteur de stratégies. Convention de poids : pour un achat, fraction du capital de la stratégie à investir sur la ligne ;
pour une vente, fraction de la position détenue par la stratégie."""
from dataclasses import dataclass, field
from research_v1.quant.features import Features

@dataclass(frozen=True)
class Intent:
    strategy: str
    symbol: str
    side: str            # buy | sell
    kind: str            # entry | exit | stop | rebalance
    reason: str
    weight: float = 1.0
    confidence: float = 0.5
    evidence: list = field(default_factory=list)
    notional: float | None = None   # montant explicite (rééquilibrage)

@dataclass
class SymbolData:
    symbol: str
    bars: list
    analysis: dict | None = None     # sortie de signal_engine.analyze_symbol (facultatif)
    fundamentals: dict | None = None
    bench: list | None = None        # barres de l'indice de référence
    injected: object = field(default=None, repr=False)   # Features fourni de l'extérieur (tests, backtest)
    _f: object = field(default=None, repr=False)

    @property
    def price(self): return self.injected.close if self.injected is not None else self.bars[-1].c

    @property
    def features(self):
        if self.injected is not None: return self.injected
        if self._f is None: self._f = Features(self.bars, self.bench)
        return self._f

@dataclass
class Context:
    now: str
    data: dict           # symbole -> SymbolData
    positions: dict      # positions de CETTE stratégie : symbole -> {qty, avg, value, held_since}
    equity: float        # capital courant de la stratégie
