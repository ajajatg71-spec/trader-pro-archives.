"""Registre d'attribution : qui détient quoi. Les exécutions sont attribuées aux stratégies (lots FIFO) ; une stratégie ne peut vendre que ce qu'elle détient."""

class LedgerError(ValueError):
    pass

class Ledger:
    def __init__(self):
        self.lots, self.closed, self.realized, self.seen, self.fills = {}, [], {}, set(), []

    @classmethod
    def from_fills(cls, fills, clamp=True):
        """Reconstruit le registre en rejouant les exécutions dans l'ordre chronologique."""
        lg = cls()
        for f in sorted(fills, key=lambda f: (f["ts"], f["id"])): lg.apply(f, clamp)
        return lg

    def apply(self, fill, clamp=False):
        """Applique une exécution {id, strategy, symbol, side, qty, price, fee, ts}. Idempotent sur id. clamp : une vente excédentaire est ramenée à la quantité détenue."""
        if fill["id"] in self.seen: return False
        key, q, px, fee = (fill["strategy"], fill["symbol"]), float(fill["qty"]), float(fill["price"]), float(fill.get("fee", 0.0))
        if fill["side"] == "buy": self.lots.setdefault(key, []).append([q, px + fee / q, fill["ts"]])
        else:
            lots = self.lots.setdefault(key, []); owned = sum(l[0] for l in lots)
            if q > owned + 1e-9:
                if not clamp: raise LedgerError(f"{fill['strategy']} vend {q} {fill['symbol']} mais n'en détient que {owned}")
                q = owned
            rem, net = q, px - (fee / float(fill["qty"]) if float(fill["qty"]) else 0.0)
            while rem > 1e-12 and lots:
                lot = lots[0]; take = min(rem, lot[0]); pnl = (net - lot[1]) * take
                self.closed.append({"strategy": fill["strategy"], "symbol": fill["symbol"], "qty": take, "pnl": pnl, "pnl_pct": (net / lot[1] - 1) * 100, "opened": lot[2], "closed": fill["ts"]})
                self.realized[fill["strategy"]] = self.realized.get(fill["strategy"], 0.0) + pnl; lot[0] -= take; rem -= take
                if lot[0] <= 1e-12: lots.pop(0)
        self.seen.add(fill["id"]); self.fills.append(fill); return True

    def position(self, strategy, symbol):
        """{qty, avg, cost, held_since} de la stratégie sur ce titre, ou None."""
        lots = self.lots.get((strategy, symbol), []); q = sum(l[0] for l in lots)
        if q <= 1e-9: return None
        cost = sum(l[0] * l[1] for l in lots); return {"qty": q, "avg": cost / q, "cost": cost, "held_since": lots[0][2]}

    def positions(self, strategy):
        """Toutes les positions de la stratégie : symbole -> position."""
        return {s: p for (st, s) in sorted(self.lots) if st == strategy for p in [self.position(st, s)] if p}

    def total_qty(self, symbol):
        """Quantité totale détenue sur ce titre par toutes les stratégies."""
        return sum(l[0] for (st, s), lots in self.lots.items() if s == symbol for l in lots)

    def reconcile(self, broker_qty, tol=1e-4):
        """Écarts entre le registre et les positions du courtier : [{symbol, ledger_qty, broker_qty, diff}] (diff positif = quantité non attribuée)."""
        out = []
        for s in sorted(set(broker_qty) | {s for (_, s) in self.lots}):
            lq, bq = self.total_qty(s), float(broker_qty.get(s, 0.0))
            if abs(bq - lq) > max(tol, 0.001 * max(bq, lq)): out.append({"symbol": s, "ledger_qty": round(lq, 8), "broker_qty": round(bq, 8), "diff": round(bq - lq, 8)})
        return out

def split_fill(fill, attribution):
    """Répartit une exécution entre les stratégies d'un ordre fusionné, au prorata de leurs montants. Renvoie des exécutions attribuées (id suffixé)."""
    tot = sum(a["notional"] for a in attribution)
    if tot <= 0: raise LedgerError("attribution sans montant")
    return [{**fill, "id": f"{fill['id']}:{a['strategy']}", "strategy": a["strategy"], "qty": float(fill["qty"]) * a["notional"] / tot, "fee": float(fill.get("fee", 0.0)) * a["notional"] / tot} for a in attribution]
