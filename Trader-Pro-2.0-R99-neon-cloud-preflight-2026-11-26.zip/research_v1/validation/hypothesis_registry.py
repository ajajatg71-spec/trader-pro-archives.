"""Pré-enregistrement et correction globale d'une famille d'hypothèses.

Outil pur : aucune persistance implicite, aucun accès réseau, aucun ordre.
"""
from __future__ import annotations

from collections.abc import Mapping, Sequence
import hashlib
import json
import math


def canonical_family_id(*, study: str, universe: Sequence[str],
                        hypotheses: Sequence[str], protocol_version: str) -> str:
    """Identifiant stable d'une famille déclarée avant l'évaluation."""
    if not study.strip() or not protocol_version.strip():
        raise ValueError("study et protocol_version sont obligatoires")
    if not universe or not hypotheses:
        raise ValueError("univers et hypothèses non vides requis")
    payload = {
        "study": study.strip(),
        "universe": sorted({str(x).strip().upper() for x in universe}),
        "hypotheses": sorted({str(x).strip() for x in hypotheses}),
        "protocol_version": protocol_version.strip(),
    }
    if any(not x for x in payload["universe"]) or any(not x for x in payload["hypotheses"]):
        raise ValueError("élément vide interdit")
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def adjust_complete_family(expected_ids: Sequence[str],
                           p_values: Mapping[str, float]) -> dict:
    """Applique Holm à une famille entière ; refuse les familles incomplètes.

    Les IDs attendus doivent avoir été définis avant l'observation des résultats.
    Une p-value manquante ne peut pas être silencieusement omise.
    """
    expected = list(expected_ids)
    if not expected or len(expected) != len(set(expected)):
        raise ValueError("expected_ids doit être non vide et sans doublons")
    if set(p_values) != set(expected):
        raise ValueError("famille incomplète ou inattendue")
    cleaned = {}
    for key in expected:
        value = float(p_values[key])
        if not math.isfinite(value) or not 0.0 <= value <= 1.0:
            raise ValueError(f"p-value invalide pour {key}")
        cleaned[key] = value
    ordered = sorted(cleaned.items(), key=lambda item: (item[1], item[0]))
    m = len(ordered)
    adjusted = {}
    running = 0.0
    for rank, (key, p_value) in enumerate(ordered):
        running = max(running, min(1.0, (m-rank)*p_value))
        adjusted[key] = round(running, 10)
    return {"family_size": m, "adjustment": "holm_bonferroni",
            "adjusted_p_values": adjusted, "family_complete": True,
            "selection_authorized": False}
