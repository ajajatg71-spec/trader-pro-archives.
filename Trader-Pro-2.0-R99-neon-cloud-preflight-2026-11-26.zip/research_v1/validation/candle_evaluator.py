"""Évaluation descriptive sans anticipation des figures de chandeliers.

Les figures sont détectées à la clôture de la barre i. L'entrée se fait au
prochain open disponible et la sortie à la clôture après `horizon` barres.
Les coûts sont appliqués à l'aller et au retour. Aucun ordre n'est créé.
"""
from __future__ import annotations

from collections import defaultdict
from statistics import median
import random
from dataclasses import dataclass
from datetime import datetime, timezone
from types import SimpleNamespace
from typing import Iterable

from research_v1.quant.candles import detect


@dataclass(frozen=True)
class CandleEvaluationConfig:
    horizons: tuple[int, ...] = (1, 3, 5, 10)
    commission_bps_per_side: float = 5.0
    slippage_bps_per_side: float = 5.0
    development_fraction: float = 0.70
    min_observations: int = 20

    def validate(self) -> None:
        if not self.horizons or any(type(x) is not int or x < 1 for x in self.horizons):
            raise ValueError("horizons doit contenir des entiers positifs")
        if len(set(self.horizons)) != len(self.horizons):
            raise ValueError("horizons ne doit pas contenir de doublons")
        if self.commission_bps_per_side < 0 or self.slippage_bps_per_side < 0:
            raise ValueError("les coûts ne peuvent pas être négatifs")
        if not 0.5 <= self.development_fraction <= 0.9:
            raise ValueError("development_fraction doit être entre 0.5 et 0.9")
        if self.min_observations < 1:
            raise ValueError("min_observations doit être positif")


def _summary(values: list[float], min_observations: int) -> dict:
    n = len(values)
    avg = sum(values) / n if n else None
    wins = sum(x > 0 for x in values)
    # Aucun test de significativité : les champs restent descriptifs.
    return {
        "observations": n,
        "mean_net_return_pct": round(avg * 100, 5) if avg is not None else None,
        "median_net_return_pct": round(median(values) * 100, 5) if n else None,
        "win_rate_pct": round(wins / n * 100, 2) if n else None,
        "positive_mean": bool(avg is not None and avg > 0),
        "sample_sufficient": n >= min_observations,
    }


def _moving_block_bootstrap_ci(values: list[float], block_length: int, *,
                               repetitions: int = 1000, seed: int = 1729) -> dict:
    """IC percentile à 95 % de la moyenne, bootstrap par blocs contigus.

    Les blocs préservent partiellement la dépendance temporelle créée par les
    rendements chevauchants. Ce n'est pas un test de significativité ni une
    correction des comparaisons multiples.
    """
    n = len(values)
    if n < 2:
        return {"lower_95_pct": None, "upper_95_pct": None, "method": "moving_block_bootstrap",
                "block_length": block_length, "repetitions": repetitions}
    width = max(1, min(int(block_length), n))
    starts = list(range(n - width + 1))
    rng = random.Random(seed)
    means = []
    blocks_needed = (n + width - 1) // width
    for _ in range(repetitions):
        sample = []
        for _ in range(blocks_needed):
            start = rng.choice(starts)
            sample.extend(values[start:start + width])
        means.append(sum(sample[:n]) / n)
    means.sort()
    lo = means[int(0.025 * (repetitions - 1))]
    hi = means[int(0.975 * (repetitions - 1))]
    return {"lower_95_pct": round(lo * 100, 5), "upper_95_pct": round(hi * 100, 5),
            "method": "moving_block_bootstrap", "block_length": width, "repetitions": repetitions}


def evaluate_candle_patterns(bars: Iterable, config: CandleEvaluationConfig | None = None) -> dict:
    """Évalue chaque figure, par horizon et segment chronologique, sans look-ahead.

    `bars` doit être ordonné ancien->récent et chaque barre doit exposer o,h,l,c,v.
    Le segment est affecté selon la date du signal, jamais selon la date de sortie.
    Les observations dont la sortie dépasse la fin de l'historique sont écartées.
    """
    cfg = config or CandleEvaluationConfig()
    cfg.validate()
    raw = list(bars)
    if len(raw) < 30:
        raise ValueError("historique insuffisant : 30 barres minimum")
    normalized = []
    timestamp_presence = [getattr(b, "ts", None) is not None for b in raw]
    if any(timestamp_presence) and not all(timestamp_presence):
        raise ValueError("horodatages OHLCV partiels : chaque barre doit avoir un timestamp")
    previous_timestamp = None
    for i, b in enumerate(raw):
        try:
            row = SimpleNamespace(o=float(b.o), h=float(b.h), l=float(b.l),
                                  c=float(b.c), v=float(b.v))
        except (AttributeError, TypeError, ValueError) as exc:
            raise ValueError(f"barre OHLCV invalide à l'index {i}") from exc
        if not all(map(lambda x: x == x and abs(x) != float('inf'), (row.o,row.h,row.l,row.c,row.v))):
            raise ValueError(f"valeur OHLCV non finie à l'index {i}")
        if row.l <= 0 or row.v < 0 or row.h < max(row.o,row.c) or row.l > min(row.o,row.c) or row.h < row.l:
            raise ValueError(f"géométrie OHLCV invalide à l'index {i}")
        if all(timestamp_presence):
            raw_timestamp = getattr(b, "ts")
            try:
                stamp = raw_timestamp if isinstance(raw_timestamp, datetime) else datetime.fromisoformat(
                    str(raw_timestamp).replace("Z", "+00:00")
                )
            except (TypeError, ValueError) as exc:
                raise ValueError(f"horodatage OHLCV invalide à l'index {i}") from exc
            if stamp.tzinfo is None or stamp.utcoffset() is None:
                raise ValueError(f"horodatage OHLCV sans fuseau à l'index {i}")
            stamp = stamp.astimezone(timezone.utc)
            if previous_timestamp is not None and stamp <= previous_timestamp:
                raise ValueError("horodatages OHLCV dupliqués ou non chronologiques")
            previous_timestamp = stamp
            row.ts = stamp.isoformat()
        normalized.append(row)

    split = int(len(normalized) * cfg.development_fraction)
    cost = 2 * (cfg.commission_bps_per_side + cfg.slippage_bps_per_side) / 10_000
    results = defaultdict(lambda: defaultdict(lambda: {"development": [], "holdout": [], "benchmark_development": [], "benchmark_holdout": [], "paired_excess_holdout": []}))
    occurrences = 0
    for i in range(len(normalized) - 1):
        # detect() ne reçoit que les données disponibles à la clôture du signal.
        history = normalized[:i + 1]
        for pattern in detect(history, i):
            if pattern.direction not in ("haussier", "baissier"):
                continue
            entry_i = i + 1
            segment = "development" if i < split else "holdout"
            direction = 1.0 if pattern.direction == "haussier" else -1.0
            for horizon in cfg.horizons:
                exit_i = entry_i + horizon - 1
                if exit_i >= len(normalized):
                    continue
                entry = normalized[entry_i].o
                exit_price = normalized[exit_i].c
                if entry <= 0 or exit_price <= 0:
                    continue
                gross = direction * (exit_price / entry - 1)
                net = gross - cost
                # Benchmark directionnel simple, même entrée/sortie et mêmes coûts.
                benchmark = (exit_price / entry - 1) - cost
                key = (pattern.code, horizon)
                results[key][horizon][segment].append(net)
                results[key][horizon][f"benchmark_{segment}"].append(benchmark)
                if segment == "holdout":
                    results[key][horizon]["paired_excess_holdout"].append(net - benchmark)
                occurrences += 1

    patterns = []
    for (code, horizon), by_horizon in sorted(results.items()):
        row = by_horizon[horizon]
        dev = _summary(row["development"], cfg.min_observations)
        hold = _summary(row["holdout"], cfg.min_observations)
        bench = _summary(row["benchmark_holdout"], cfg.min_observations)
        delta = None
        if hold["mean_net_return_pct"] is not None and bench["mean_net_return_pct"] is not None:
            delta = round(hold["mean_net_return_pct"] - bench["mean_net_return_pct"], 5)
        ci = _moving_block_bootstrap_ci(row["paired_excess_holdout"], horizon)
        ci_lower = ci["lower_95_pct"]
        patterns.append({"pattern": code, "horizon_bars": horizon,
                         "development": dev, "holdout": hold,
                         "holdout_directional_benchmark": bench,
                         "holdout_excess_return_pct": delta,
                         "holdout_excess_return_ci_95": ci,
                         "statistical_support_screen": bool(hold["sample_sufficient"] and ci_lower is not None and ci_lower > 0),
                         "eligible_for_review": bool(hold["sample_sufficient"] and delta is not None and delta > 0)})

    return {
        "status": "DESCRIPTIVE_RESEARCH_ONLY",
        "lookahead_policy": "signal_at_close_enter_next_open_exit_after_horizon_closes",
        "split_index": split,
        "development_fraction": cfg.development_fraction,
        "costs": {"commission_bps_per_side": cfg.commission_bps_per_side,
                  "slippage_bps_per_side": cfg.slippage_bps_per_side,
                  "round_trip_total_bps": round(cost * 10_000, 4)},
        "horizons": list(cfg.horizons),
        "occurrence_horizon_observations": occurrences,
        "patterns": patterns,
        "automatic_strategy_activation": False,
        "orders_created": 0,
        "profitability_guaranteed": False,
        "limitations": ["résultats descriptifs, sans test de significativité", "observations de figures potentiellement chevauchantes",
                        "pas de correction pour comparaisons multiples", "IC bootstrap descriptif, non assimilable à une preuve de significativité", "qualité du résultat dépendante de la qualité OHLCV"]
    }
