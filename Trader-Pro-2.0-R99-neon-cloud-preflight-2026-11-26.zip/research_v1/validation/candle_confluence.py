"""Évaluation descriptive des confluences chandeliers/indicateurs, sans ordres.
Toutes les caractéristiques sont calculées sur le préfixe disponible à la clôture du signal.
"""
from __future__ import annotations
from collections import defaultdict
from types import SimpleNamespace
import math
import hashlib
from research_v1.quant.candles import detect
from research_v1.quant.indicators import rsi, macd, ema, atr


def _features(history):
    closes = [b.c for b in history]
    highs = [b.h for b in history]
    lows = [b.l for b in history]
    volumes = [b.v for b in history]
    r = rsi(closes, 14)
    m = macd(closes)
    e20, e50 = ema(closes, 20), ema(closes, 50)
    a = atr(highs, lows, closes, 14)
    avg_volume = sum(volumes[-20:]) / min(20, len(volumes)) if volumes else 0
    volume_ratio = volumes[-1] / avg_volume if avg_volume > 0 else None
    return {"rsi14": r, "macd_histogram": m[2] if m else None,
            "ema20": e20, "ema50": e50, "atr14": a,
            "volume_ratio20": volume_ratio, "close": closes[-1]}


def _purged_segment(signal_index, split_index, max_horizon):
    """Attribue un segment avec purge/embargo pour éviter les sorties qui traversent la frontière."""
    if signal_index + max_horizon < split_index:
        return "development"
    if signal_index >= split_index + max_horizon:
        return "holdout"
    return None



def _binomial_two_sided_p(wins, n):
    """Exact two-sided binomial p-value against a 50% win probability."""
    if n <= 0:
        return 1.0
    tail = min(wins, n - wins)
    probability = sum(math.comb(n, k) for k in range(tail + 1)) / (2 ** n)
    return min(1.0, 2.0 * probability)


def _holm_adjust(p_values):
    """Holm-Bonferroni adjusted p-values; keys are stable hypothesis IDs."""
    ordered = sorted(p_values.items(), key=lambda item: item[1])
    m = len(ordered)
    adjusted = {}
    running = 0.0
    for rank, (key, p_value) in enumerate(ordered):
        running = max(running, min(1.0, (m - rank) * p_value))
        adjusted[key] = running
    return adjusted



def _paired_block_inference(deltas, block_length, *, repetitions=2000, seed=2718):
    """IC bootstrap et test bilatéral par inversion de signe au niveau bloc.

    Les deltas doivent être ordonnés chronologiquement. Les blocs contigus
    limitent la pseudo-réplication due aux dépendances temporelles.
    Méthode exploratoire : elle ne remplace pas un holdout externe indépendant.
    """
    values = [float(x) for x in deltas]
    n = len(values)
    if n < 5:
        return {"matched_events": n, "mean_excess_pct": round(sum(values) / n * 100, 6) if n else None,
                "ci_95_lower_pct": None, "ci_95_upper_pct": None,
                "p_value_raw": None, "method": "paired_moving_block_bootstrap_and_block_sign_flip",
                "block_length": max(1, int(block_length)), "repetitions": repetitions,
                "inference_status": "INSUFFICIENT_PAIRED_EVENTS"}
    width = max(1, min(int(block_length), n))
    starts = list(range(n - width + 1))
    rng = __import__("random").Random(seed)
    blocks_needed = (n + width - 1) // width
    boot_means = []
    for _ in range(repetitions):
        sample = []
        for _ in range(blocks_needed):
            start = rng.choice(starts)
            sample.extend(values[start:start + width])
        boot_means.append(sum(sample[:n]) / n)
    boot_means.sort()
    lo = boot_means[int(0.025 * (repetitions - 1))]
    hi = boot_means[int(0.975 * (repetitions - 1))]
    observed = abs(sum(values) / n)
    # Rééchantillonne les blocs non chevauchants de la séquence observée et
    # inverse le signe de chaque bloc sous l'hypothèse nulle de delta moyen nul.
    blocks = [values[i:i + width] for i in range(0, n, width)]
    extreme = 0
    for _ in range(repetitions):
        permuted = []
        for block in blocks:
            sign = -1.0 if rng.random() < 0.5 else 1.0
            permuted.extend(sign * x for x in block)
        statistic = abs(sum(permuted) / len(permuted))
        if statistic >= observed - 1e-15:
            extreme += 1
    p_value = (extreme + 1) / (repetitions + 1)
    return {"matched_events": n, "mean_excess_pct": round(sum(values) / n * 100, 6),
            "ci_95_lower_pct": round(lo * 100, 6), "ci_95_upper_pct": round(hi * 100, 6),
            "p_value_raw": round(p_value, 8),
            "method": "paired_moving_block_bootstrap_and_block_sign_flip",
            "block_length": width, "repetitions": repetitions,
            "inference_status": "EXPLORATORY_BLOCKED_INFERENCE"}

def _non_overlapping_append(stats, last_exit, key, segment, signal_index, exit_index, value):
    """Greedy chronological event selection; accepted outcome windows cannot overlap."""
    slot = (key, segment)
    if signal_index <= last_exit.get(slot, -1):
        return False
    stats.setdefault(key, {}).setdefault(segment, []).append(value)
    last_exit[slot] = exit_index
    return True


def evaluate_candle_confluence(bars, *, horizons=(1, 3, 5),
                               commission_bps_per_side=5.0,
                               slippage_bps_per_side=5.0,
                               development_fraction=0.70,
                               min_observations=20):
    """Compare bougie seule et filtres RSI/MACD/tendance EMA/volume sur mêmes signaux.

    Signal à la clôture i, entrée à l'ouverture i+1, sortie à la clôture i+horizon.
    Les filtres ne lisent que les données jusqu'à i. Résultats recherche uniquement.
    """
    if not horizons or any(type(h) is not int or h < 1 for h in horizons) or len(set(horizons)) != len(horizons):
        raise ValueError("horizons invalides")
    if commission_bps_per_side < 0 or slippage_bps_per_side < 0:
        raise ValueError("coûts négatifs")
    if not 0.5 <= development_fraction <= 0.9 or min_observations < 1:
        raise ValueError("paramètres de validation invalides")
    raw = list(bars)
    if len(raw) < 60:
        raise ValueError("historique insuffisant : 60 barres minimum pour EMA50")
    clean=[]
    for i,b in enumerate(raw):
        try: x=SimpleNamespace(o=float(b.o),h=float(b.h),l=float(b.l),c=float(b.c),v=float(b.v))
        except (AttributeError,TypeError,ValueError) as exc: raise ValueError(f"OHLCV invalide à l'index {i}") from exc
        vals=(x.o,x.h,x.l,x.c,x.v)
        if not all(v == v and abs(v) != float('inf') for v in vals) or x.l <= 0 or x.v < 0 or x.h < max(x.o,x.c) or x.l > min(x.o,x.c) or x.h < x.l:
            raise ValueError(f"OHLCV invalide à l'index {i}")
        clean.append(x)
    split=int(len(clean)*development_fraction)
    cost=2*(commission_bps_per_side+slippage_bps_per_side)/10000
    max_horizon=max(horizons)
    policies=("candle_only","candle_rsi","candle_macd","candle_ema_trend","candle_volume","candle_rsi_macd","all_available")
    stats=defaultdict(lambda: defaultdict(list))
    last_exit={}
    accepted_events=defaultdict(dict)
    signal_count=0
    for i in range(59,len(clean)-1):
        history=clean[:i+1]
        features=_features(history)
        for pattern in detect(history,i):
            if pattern.direction not in ("haussier","baissier"): continue
            signal_count += 1
            direction=1 if pattern.direction=="haussier" else -1
            checks={
              "candle_only": True,
              "candle_rsi": features["rsi14"] is not None and (features["rsi14"] >= 50 if direction>0 else features["rsi14"] < 50),
              "candle_macd": features["macd_histogram"] is not None and features["macd_histogram"]*direction > 0,
              "candle_ema_trend": features["ema20"] is not None and features["ema50"] is not None and ((features["close"]>features["ema20"]>features["ema50"]) if direction>0 else (features["close"]<features["ema20"]<features["ema50"])),
              "candle_volume": features["volume_ratio20"] is not None and features["volume_ratio20"] >= 1.2,
            }
            checks["candle_rsi_macd"] = checks["candle_rsi"] and checks["candle_macd"]
            checks["all_available"] = all(checks[k] for k in ("candle_rsi","candle_macd","candle_ema_trend","candle_volume"))
            for h in horizons:
                entry_i=i+1; exit_i=entry_i+h-1
                if exit_i >= len(clean): continue
                entry=clean[entry_i].o; exit_price=clean[exit_i].c
                if entry<=0 or exit_price<=0: continue
                ret=direction*(exit_price/entry-1)-cost
                segment=_purged_segment(i, split, max_horizon)
                if segment is None:
                    continue
                for policy,passed in checks.items():
                    if passed:
                        key=(pattern.code,h,policy)
                        accepted = _non_overlapping_append(stats,last_exit,key,segment,i,exit_i,ret)
                        if accepted:
                            accepted_events[(pattern.code, h, policy, segment)][i] = ret
    rows=[]
    holdout_p_values={}
    paired_p_values={}
    for (pattern,h,policy),segments in sorted(stats.items()):
        def summary(v):
            n=len(v)
            return {"observations":n,"mean_net_return_pct":round(sum(v)/n*100,5) if n else None,
                    "win_rate_pct":round(sum(x>0 for x in v)/n*100,2) if n else None,
                    "sample_sufficient":n>=min_observations}
        holdout=summary(segments["holdout"])
        hypothesis=f"{pattern}|{h}|{policy}"
        holdout_p_values[hypothesis]=_binomial_two_sided_p(sum(x>0 for x in segments["holdout"]),len(segments["holdout"]))
        baseline = accepted_events.get((pattern, h, "candle_only", "holdout"), {})
        policy_events = accepted_events.get((pattern, h, policy, "holdout"), {})
        common = sorted(set(baseline).intersection(policy_events))
        paired_delta = [policy_events[idx] - baseline[idx] for idx in common]
        paired_inference = _paired_block_inference(paired_delta, h, seed=(int(hashlib.sha256(hypothesis.encode()).hexdigest()[:8], 16)))
        if paired_inference["p_value_raw"] is not None:
            paired_p_values[hypothesis] = paired_inference["p_value_raw"]
        rows.append({"pattern":pattern,"horizon_bars":h,"policy":policy,
                     "development":summary(segments["development"]),"holdout":holdout,
                     "holdout_winrate_p_raw":round(holdout_p_values[hypothesis],8),
                     "paired_candle_only_comparison": {
                         **paired_inference,
                         "interpretation": "same_pattern_same_horizon_same_signal_dates" if policy != "candle_only" else "baseline"
                     }})
    paired_adjusted = _holm_adjust(paired_p_values)
    for row in rows:
        hypothesis=f"{row['pattern']}|{row['horizon_bars']}|{row['policy']}"
        inference = row["paired_candle_only_comparison"]
        inference["p_value_holm"] = round(paired_adjusted[hypothesis], 8) if hypothesis in paired_adjusted else None
    adjusted=_holm_adjust(holdout_p_values)
    for row in rows:
        hypothesis=f"{row['pattern']}|{row['horizon_bars']}|{row['policy']}"
        row["holdout_winrate_p_holm"] = round(adjusted[hypothesis],8)
    return {"status":"DESCRIPTIVE_RESEARCH_ONLY","signals_scanned":signal_count,
            "policies":list(policies),"horizons":list(horizons),
            "split_index":split,"purge_embargo_bars":max_horizon,"split_policy":"development_exit_before_split_holdout_after_embargo","costs":{"commission_bps_per_side":commission_bps_per_side,
            "slippage_bps_per_side":slippage_bps_per_side,"round_trip_total_bps":round(cost*10000,4)},
            "results":rows,"lookahead_policy":"features_at_signal_close_enter_next_open_exit_at_horizon_close",
            "automatic_strategy_activation":False,"orders_created":0,
            "limitations":["comparaison descriptive uniquement","p-values de taux de réussite testées contre 50%, pas contre un benchmark de rendement",
            "inférence appariée exploratoire par bootstrap et inversion de signe en blocs ; petits échantillons exclus","filtres RSI/MACD/EMA/volume heuristiques non optimisés",
            "pas de preuve de rentabilité ou de robustesse multi-actifs",
            "signaux proches de la frontière développement/holdout exclus par purge et embargo"]}


def evaluate_multi_asset_regimes(assets, *, horizons=(1, 3, 5),
                                 commission_bps_per_side=5.0,
                                 slippage_bps_per_side=5.0,
                                 development_fraction=0.70,
                                 min_observations=20):
    """Compare les confluences par actif et régime historique connu au signal.

    `assets` est un mapping {symbole: iterable OHLCV}. Les régimes sont calculés
    sur le seul préfixe disponible à la clôture du signal (SMA50/200, ADX,
    percentile de volatilité). Les observations restent descriptives ; aucune
    mutualisation artificielle des historiques d'actifs n'est effectuée.
    """
    from research_v1.quant.regime import detect_regime
    if not isinstance(assets, dict) or not assets:
        raise ValueError("assets doit être un mapping non vide symbole -> OHLCV")
    if len(assets) > 100:
        raise ValueError("100 actifs maximum par lot")
    combined = defaultdict(lambda: defaultdict(list))
    combined_events = defaultdict(dict)
    last_exit={}
    asset_reports = {}
    regimes_seen = defaultdict(int)
    for symbol, source in sorted(assets.items()):
        ticker = str(symbol).strip().upper()
        if not ticker or len(ticker) > 24:
            raise ValueError("symbole invalide")
        bars = list(source)
        # Valide le contrat et produit les résultats de référence par actif.
        report = evaluate_candle_confluence(
            bars, horizons=horizons,
            commission_bps_per_side=commission_bps_per_side,
            slippage_bps_per_side=slippage_bps_per_side,
            development_fraction=development_fraction,
            min_observations=min_observations)
        asset_reports[ticker] = report
        clean = [SimpleNamespace(o=float(b.o), h=float(b.h), l=float(b.l),
                                 c=float(b.c), v=float(b.v)) for b in bars]
        split = int(len(clean) * development_fraction)
        max_horizon = max(horizons)
        for i in range(199, len(clean) - 1):
            history = clean[:i + 1]
            closes = [b.c for b in history]
            regime = detect_regime(closes, [b.h for b in history], [b.l for b in history])
            if regime is None:
                continue
            label = regime["label"]
            regimes_seen[label] += 1
            f = _features(history)
            for pattern in detect(history, i):
                if pattern.direction not in ("haussier", "baissier"):
                    continue
                direction = 1 if pattern.direction == "haussier" else -1
                checks = {
                    "candle_only": True,
                    "candle_rsi": f["rsi14"] is not None and (f["rsi14"] >= 50 if direction > 0 else f["rsi14"] < 50),
                    "candle_macd": f["macd_histogram"] is not None and f["macd_histogram"] * direction > 0,
                    "candle_ema_trend": f["ema20"] is not None and f["ema50"] is not None and ((f["close"] > f["ema20"] > f["ema50"]) if direction > 0 else (f["close"] < f["ema20"] < f["ema50"])),
                    "candle_volume": f["volume_ratio20"] is not None and f["volume_ratio20"] >= 1.2,
                }
                checks["candle_rsi_macd"] = checks["candle_rsi"] and checks["candle_macd"]
                checks["all_available"] = all(checks[k] for k in ("candle_rsi", "candle_macd", "candle_ema_trend", "candle_volume"))
                segment = _purged_segment(i, split, max_horizon)
                if segment is None:
                    continue
                for horizon in horizons:
                    exit_i = i + horizon
                    if exit_i >= len(clean):
                        continue
                    entry, exit_price = clean[i + 1].o, clean[exit_i].c
                    if entry <= 0 or exit_price <= 0:
                        continue
                    net = direction * (exit_price / entry - 1) - 2 * (commission_bps_per_side + slippage_bps_per_side) / 10000
                    for policy, passed in checks.items():
                        if passed:
                            key=(ticker, label, pattern.code, horizon, policy)
                            accepted = _non_overlapping_append(combined,last_exit,key,segment,i,i+horizon,net)
                            if accepted:
                                combined_events[(ticker, label, pattern.code, horizon, policy, segment)][i] = net
    rows = []
    holdout_p_values={}
    paired_p_values={}
    for key, segments in sorted(combined.items()):
        def summarize(values):
            n = len(values)
            return {"observations": n,
                    "mean_net_return_pct": round(sum(values) / n * 100, 5) if n else None,
                    "win_rate_pct": round(sum(v > 0 for v in values) / n * 100, 2) if n else None,
                    "sample_sufficient": n >= min_observations}
        hypothesis="|".join(map(str,key))
        holdout_p_values[hypothesis]=_binomial_two_sided_p(sum(v>0 for v in segments["holdout"]),len(segments["holdout"]))
        baseline_key=(key[0], key[1], key[2], key[3], "candle_only", "holdout")
        policy_key=(key[0], key[1], key[2], key[3], key[4], "holdout")
        baseline_events=combined_events.get(baseline_key, {})
        policy_events=combined_events.get(policy_key, {})
        common=sorted(set(baseline_events).intersection(policy_events))
        deltas=[policy_events[index]-baseline_events[index] for index in common]
        paired=_paired_block_inference(
            deltas, key[3],
            seed=int(hashlib.sha256(hypothesis.encode()).hexdigest()[:8], 16))
        if paired["p_value_raw"] is not None:
            paired_p_values[hypothesis]=paired["p_value_raw"]
        rows.append({"symbol": key[0], "regime": key[1], "pattern": key[2],
                     "horizon_bars": key[3], "policy": key[4],
                     "development": summarize(segments["development"]),
                     "holdout": summarize(segments["holdout"]),
                     "holdout_winrate_p_raw":round(holdout_p_values[hypothesis],8),
                     "paired_candle_only_comparison": {
                         **paired,
                         "interpretation": "same_asset_same_regime_same_pattern_same_horizon_same_signal_dates"
                         if key[4] != "candle_only" else "baseline"}})
    adjusted=_holm_adjust(holdout_p_values)
    paired_adjusted=_holm_adjust(paired_p_values)
    for row in rows:
        hypothesis="|".join(map(str,(row["symbol"],row["regime"],row["pattern"],row["horizon_bars"],row["policy"])))
        row["holdout_winrate_p_holm"]=round(adjusted[hypothesis],8)
        inference=row["paired_candle_only_comparison"]
        inference["p_value_holm"]=round(paired_adjusted[hypothesis],8) if hypothesis in paired_adjusted else None
    return {"status": "DESCRIPTIVE_MULTI_ASSET_REGIME_RESEARCH_ONLY",
            "assets": list(asset_reports), "asset_reports": asset_reports,
            "regime_signal_counts": dict(sorted(regimes_seen.items())),
            "regime_results": rows, "split_policy": "development_exit_before_split_holdout_after_embargo",
            "purge_embargo_bars": max(horizons), "automatic_strategy_activation": False,
            "orders_created": 0,
            "inference_scope": {
                "holdout_winrate_holm": "all asset/regime/pattern/horizon/policy rows in this call",
                "paired_return_holm": "all sufficiently-sized paired rows in this call",
                "cross_run_family_correction": False
            },
            "limitations": ["régimes SMA50/200, ADX et volatilité calculés au signal",
                            "résultats par actif non mutualisés",
                            "petits échantillons à interpréter avec prudence",
                            "test binomial de win-rate uniquement, sans preuve de rendement net positif",
                            "inférence appariée exploratoire ajoutée par actif/régime ; correction Holm limitée à cet appel",
            "déduplication gloutonne des fenêtres de sortie chevauchantes par figure/horizon/politique/segment",
                            "pas de preuve de rentabilité ni de robustesse hors échantillon",
            "signaux proches de la frontière développement/holdout exclus par purge et embargo"]}
