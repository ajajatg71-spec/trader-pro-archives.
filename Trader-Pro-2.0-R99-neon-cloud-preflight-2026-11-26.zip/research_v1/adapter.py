"""Isolated adapter for the historical 50-strategy research engine.

This module only produces research intents. It has no broker, order, or risk-service
imports. Production order submission remains exclusively in the V2 risk/order path.
"""
from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
from types import SimpleNamespace
from typing import Mapping, Sequence

from research_v1.strategies.catalog import REGISTRY, make
from research_v1.strategies.types import Context, SymbolData
from research_v1.quant.alignment import AlignmentError, daily_session_keys

UNIVERSE_STRATEGIES = frozenset({
    "dual_momentum", "inverse_volatility", "low_volatility", "momentum",
    "multi_factor", "rebalancing", "rs_rotation",
})
RULE_STRATEGIES = frozenset(REGISTRY) - UNIVERSE_STRATEGIES


class ResearchInputError(ValueError):
    pass


def to_research_bars(bars) -> list[SimpleNamespace]:
    """Convert OHLCV data only when timestamps and adjustment provenance are explicit."""
    if not bars.timestamps or len(bars.timestamps) != bars.count:
        raise ResearchInputError("Les stratégies de recherche exigent un horodatage pour chaque barre OHLCV")
    adjustment_mode = getattr(bars, "adjustment_mode", "unknown")
    if adjustment_mode not in {"raw", "split", "dividend", "all"}:
        raise ResearchInputError("Mode d'ajustement OHLCV inconnu : recherche quantitative refusée")
    out = []
    for o, h, low, c, v, ts in zip(
        bars.opens, bars.highs, bars.lows, bars.closes, bars.volumes, bars.timestamps
    ):
        if not isinstance(ts, datetime) or ts.tzinfo is None or ts.utcoffset() is None:
            raise ResearchInputError("Horodatage OHLCV sans fuseau")
        out.append(SimpleNamespace(o=o, h=h, l=low, c=c, v=v, ts=ts.isoformat()))
    if len(out) < 30:
        raise ResearchInputError("Historique OHLCV trop court (30 barres minimum)")
    return out


def evaluate_rule(kind: str, symbol: str, bars, *, params: Mapping | None = None,
                  position: Mapping | None = None, benchmark=None,
                  now: str | None = None) -> dict:
    """Evaluate one per-symbol strategy in dry-run; returns intents, never orders."""
    if kind not in RULE_STRATEGIES:
        raise ResearchInputError("Type de stratégie par titre inconnu ou stratégie d'univers")
    sym = str(symbol).strip().upper()
    converted = to_research_bars(bars)
    if benchmark is not None and getattr(benchmark, "adjustment_mode", "unknown") != bars.adjustment_mode:
        raise ResearchInputError("Actif et benchmark : modes d'ajustement différents")
    bench = to_research_bars(benchmark) if benchmark is not None else None
    data = {sym: SymbolData(sym, converted, bench=bench)}
    positions = {sym: dict(position)} if position else {}
    timestamp = now or converted[-1].ts
    strategy = make(kind, f"research-{kind}-{sym}", dict(params or {}), [sym])
    intents = strategy.evaluate(Context(timestamp, data, positions, 0.0))
    return {
        "mode": "RESEARCH_DRY_RUN",
        "strategy": kind,
        "symbol": sym,
        "bars": len(converted),
        "adjustment_mode": bars.adjustment_mode,
        "intents": [asdict(item) for item in intents],
        "broker_access": False,
        "orders_created": 0,
    }


def evaluate_universe(kind: str, bars_by_symbol: Mapping[str, object], *,
                      params: Mapping | None = None, positions: Mapping | None = None,
                      equity: float = 0.0, fundamentals: Mapping | None = None,
                      benchmarks: Mapping[str, object] | None = None,
                      now: str | None = None) -> dict:
    """Evaluate one portfolio strategy on a synchronised caller-supplied universe."""
    if kind not in UNIVERSE_STRATEGIES:
        raise ResearchInputError("Type de stratégie d'univers inconnu")
    if not isinstance(bars_by_symbol, Mapping) or len(bars_by_symbol) < 2:
        raise ResearchInputError("Une stratégie d'univers exige au moins deux titres")
    if equity <= 0:
        raise ResearchInputError("Capital de recherche strictement positif requis")
    data = {}
    adjustment_modes = {getattr(bars, "adjustment_mode", "unknown") for bars in bars_by_symbol.values()}
    if len(adjustment_modes) != 1 or "unknown" in adjustment_modes:
        raise ResearchInputError("Univers : provenance d'ajustement inconnue ou hétérogène")
    adjustment_mode = next(iter(adjustment_modes))
    for raw_symbol, bars in bars_by_symbol.items():
        sym = str(raw_symbol).strip().upper()
        if benchmarks and sym in benchmarks and getattr(benchmarks[sym], "adjustment_mode", "unknown") != adjustment_mode:
            raise ResearchInputError(f"Benchmark {sym} : mode d'ajustement différent de l'univers")
        converted = to_research_bars(bars)
        bench = to_research_bars(benchmarks[sym]) if benchmarks and sym in benchmarks else None
        fund = dict((fundamentals or {}).get(sym) or {}) or None
        data[sym] = SymbolData(sym, converted, fundamentals=fund, bench=bench)
    # Reject mismatched exchange-local sessions; never compare by array position
    # or by slicing the textual ISO timestamp.
    try:
        sessions = {
            daily_session_keys(item.bars, label=f"actif {symbol}")
            for symbol, item in data.items()
        }
    except AlignmentError as exc:
        raise ResearchInputError(f"Historique journalier invalide : {exc}") from exc
    if len(sessions) != 1:
        raise ResearchInputError("Univers non synchronisé : calendriers de barres différents")
    positions = {str(k).upper(): dict(v) for k, v in (positions or {}).items()}
    timestamp = now or next(iter(data.values())).bars[-1].ts
    strategy = make(kind, f"research-{kind}", dict(params or {}), list(data))
    intents = strategy.evaluate(Context(timestamp, data, positions, float(equity)))
    return {
        "mode": "RESEARCH_DRY_RUN",
        "strategy": kind,
        "symbols": sorted(data),
        "bars_per_symbol": len(next(iter(data.values())).bars),
        "adjustment_mode": adjustment_mode,
        "intents": [asdict(item) for item in intents],
        "broker_access": False,
        "orders_created": 0,
    }


def catalog_summary() -> dict:
    return {
        "total": len(REGISTRY),
        "per_symbol": len(RULE_STRATEGIES),
        "portfolio": len(UNIVERSE_STRATEGIES),
        "types": sorted(REGISTRY),
    }
