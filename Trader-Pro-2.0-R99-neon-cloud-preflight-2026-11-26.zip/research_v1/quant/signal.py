"""Signal explicable : chaque signal porte ses données sources, ses horodatages (données et calcul), sa source et sa justification. Un signal incomplet est refusé."""
import math
from dataclasses import asdict, dataclass
from datetime import datetime

KINDS = ("directional", "risk", "info")

@dataclass(frozen=True)
class Signal:
    symbol: str
    name: str
    kind: str
    value: float          # -1 (vente) à +1 (achat) pour un signal directionnel ; 0 pour risque/info
    direction: str
    as_of: str            # horodatage de la dernière donnée utilisée
    computed_at: str      # horodatage du calcul
    source: str
    inputs: dict
    rationale: str
    raw: float | None = None
    version: str = "1"

    def to_dict(self):
        """Représentation JSON du signal."""
        return asdict(self)

def direction_of(value, threshold=0.2):
    """achat si la valeur atteint le seuil, vente si elle passe sous l'opposé, sinon neutre."""
    return "achat" if value >= threshold else "vente" if value <= -threshold else "neutre"

def _is_ts(s):
    try: datetime.fromisoformat(s.replace("Z", "+00:00")); return True
    except Exception: return False

def make_signal(symbol, name, value, as_of, computed_at, source, inputs, rationale, kind="directional", raw=None, threshold=0.2):
    """Construit un signal après validation : symbole, nom, valeur finie dans [-1, 1], horodatages ISO, source, données sources et justification obligatoires."""
    errors = []
    if not symbol: errors.append("symbole manquant")
    if not name: errors.append("nom manquant")
    if kind not in KINDS: errors.append(f"type inconnu : {kind}")
    if not isinstance(value, (int, float)) or not math.isfinite(value) or abs(value) > 1 + 1e-9: errors.append("valeur hors [-1, 1]")
    for label, ts in (("as_of", as_of), ("computed_at", computed_at)):
        if not isinstance(ts, str) or not _is_ts(ts): errors.append(f"{label} invalide")
    if not source: errors.append("source manquante")
    if not isinstance(inputs, dict) or not inputs: errors.append("données sources manquantes")
    if not isinstance(rationale, str) or not rationale.strip(): errors.append("justification manquante")
    if errors: raise ValueError("Signal invalide : " + "; ".join(errors))
    clean = {k: (round(v, 6) if isinstance(v, float) else v) for k, v in inputs.items()}
    return Signal(symbol.upper(), name, kind, round(float(value), 4), direction_of(value, threshold) if kind == "directional" else "neutre", as_of, computed_at, source, clean, rationale.strip(), raw)
