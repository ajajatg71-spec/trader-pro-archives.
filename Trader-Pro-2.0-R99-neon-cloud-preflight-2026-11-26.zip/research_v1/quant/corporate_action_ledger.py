"""Append-only point-in-time ledger for corporate-action revisions and cancellations."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from research_v1.quant.corporate_actions import CorporateActionError, CorporateActionEvent

@dataclass(frozen=True)
class CorporateActionRevision:
    source: str
    event_id: str
    revision: int
    recorded_at: datetime
    status: str
    event: CorporateActionEvent | None = None

    def __post_init__(self):
        if not isinstance(self.source,str) or not self.source.strip() or not isinstance(self.event_id,str) or not self.event_id.strip():
            raise CorporateActionError("Identité de révision invalide")
        if not isinstance(self.revision,int) or isinstance(self.revision,bool) or self.revision < 1:
            raise CorporateActionError("Numéro de révision invalide")
        if not isinstance(self.recorded_at,datetime) or self.recorded_at.tzinfo is None or self.recorded_at.utcoffset() is None:
            raise CorporateActionError("recorded_at doit être horodaté avec fuseau")
        if self.status not in {"active","cancelled"}:
            raise CorporateActionError("Statut de révision invalide")
        if self.status == "active":
            if not isinstance(self.event,CorporateActionEvent) or self.event.source != self.source or self.event.event_id != self.event_id:
                raise CorporateActionError("Révision active sans événement correspondant")
            if self.event.available_at > self.recorded_at:
                raise CorporateActionError("Événement disponible après l'enregistrement de sa révision")
        elif self.event is not None:
            raise CorporateActionError("Une annulation ne doit pas embarquer d'événement actif")

def corporate_action_snapshot(revisions, *, as_of: datetime) -> tuple[CorporateActionEvent,...]:
    """Return latest known revision per source/event ID; cancellations are retained but not active."""
    if not isinstance(as_of,datetime) or as_of.tzinfo is None or as_of.utcoffset() is None:
        raise CorporateActionError("as_of doit être horodaté avec fuseau")
    if isinstance(revisions,(str,bytes)):
        raise CorporateActionError("Collection de révisions invalide")
    try: items=tuple(revisions)
    except TypeError: raise CorporateActionError("Collection de révisions invalide") from None
    if any(not isinstance(x,CorporateActionRevision) for x in items):
        raise CorporateActionError("Révision non validée")
    latest={}; versions=set()
    for item in items:
        key=(item.source,item.event_id,item.revision)
        if key in versions: raise CorporateActionError("Révision dupliquée")
        versions.add(key)
        if item.recorded_at > as_of: continue
        identity=(item.source,item.event_id)
        previous=latest.get(identity)
        if previous is None or (item.revision,item.recorded_at) > (previous.revision,previous.recorded_at):
            latest[identity]=item
    active=[item.event for item in latest.values() if item.status=="active"]
    return tuple(sorted(active,key=lambda e:(e.ex_date,e.symbol,e.action_type,e.event_id or "")))
