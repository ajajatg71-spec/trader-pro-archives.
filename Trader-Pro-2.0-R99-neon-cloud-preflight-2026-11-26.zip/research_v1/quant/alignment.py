"""Alignement causal des historiques journaliers actif/benchmark.

Les dates de session sont calculées dans le fuseau de la place boursière,
pas par découpage textuel d'un horodatage ISO. Aucune barre n'est interpolée.
"""
from __future__ import annotations

from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import math
from typing import Any, Sequence


class AlignmentError(ValueError):
    """Raised when daily histories cannot be safely aligned."""


def _session_index(bars: Sequence[Any], *, timezone_name: str, label: str):
    try:
        exchange_tz = ZoneInfo(timezone_name)
    except Exception as exc:
        raise AlignmentError(f"Fuseau de marché invalide pour {label}") from exc

    indexed: dict[str, tuple[float, datetime]] = {}
    previous_utc = None
    for index, bar in enumerate(bars):
        raw_ts = getattr(bar, "ts", None)
        try:
            stamp = raw_ts if isinstance(raw_ts, datetime) else datetime.fromisoformat(
                str(raw_ts).replace("Z", "+00:00")
            )
        except (TypeError, ValueError) as exc:
            raise AlignmentError(f"Horodatage invalide pour {label} à l'index {index}") from exc
        if stamp.tzinfo is None or stamp.utcoffset() is None:
            raise AlignmentError(f"Horodatage sans fuseau pour {label} à l'index {index}")
        stamp_utc = stamp.astimezone(timezone.utc)
        if previous_utc is not None and stamp_utc <= previous_utc:
            raise AlignmentError(f"Horodatages non strictement croissants pour {label}")
        previous_utc = stamp_utc

        session = stamp_utc.astimezone(exchange_tz).date().isoformat()
        if session in indexed:
            raise AlignmentError(f"Plusieurs barres journalières pour {label} le {session}")
        try:
            close = float(getattr(bar, "c"))
        except (AttributeError, TypeError, ValueError, OverflowError) as exc:
            raise AlignmentError(f"Clôture invalide pour {label} à l'index {index}") from exc
        if not math.isfinite(close) or close <= 0:
            raise AlignmentError(f"Clôture invalide pour {label} à l'index {index}")
        indexed[session] = (close, stamp_utc)
    return indexed


def daily_session_keys(
    bars: Sequence[Any], *, timezone_name: str = "America/New_York", label: str = "historique"
) -> tuple[str, ...]:
    """Return validated exchange-local session keys in input order."""
    indexed = _session_index(bars, timezone_name=timezone_name, label=label)
    return tuple(indexed.keys())


def align_daily_sessions(
    asset_bars: Sequence[Any],
    benchmark_bars: Sequence[Any],
    *,
    asset_timezone: str = "America/New_York",
    benchmark_timezone: str = "America/New_York",
) -> dict[str, Any]:
    """Align two daily histories by exchange-local session date.

    Returns one benchmark close (or None) per asset bar. Missing sessions are
    explicit; there is no forward-fill, interpolation, positional matching or
    use of a later benchmark observation.
    """
    if not isinstance(asset_bars, (list, tuple)) or not isinstance(benchmark_bars, (list, tuple)):
        raise AlignmentError("Les historiques doivent être des séquences de barres")
    asset = _session_index(asset_bars, timezone_name=asset_timezone, label="actif")
    benchmark = _session_index(benchmark_bars, timezone_name=benchmark_timezone, label="benchmark")
    asset_keys = tuple(asset.keys())
    benchmark_keys = tuple(benchmark.keys())
    shared = tuple(key for key in asset_keys if key in benchmark)
    asset_only = tuple(key for key in asset_keys if key not in benchmark)
    benchmark_only = tuple(key for key in benchmark_keys if key not in asset)
    values = tuple(benchmark[key][0] if key in benchmark else None for key in asset_keys)
    overlap = len(shared) / max(len(asset_keys), len(benchmark_keys)) * 100.0 if asset_keys and benchmark_keys else 0.0
    return {
        "asset_sessions": asset_keys,
        "benchmark_sessions": benchmark_keys,
        "benchmark_closes_by_asset_bar": values,
        "matched_sessions": shared,
        "asset_only_sessions": asset_only,
        "benchmark_only_sessions": benchmark_only,
        "matched_bars": len(shared),
        "overlap_pct": round(overlap, 4),
        "method": "exchange_local_session_date",
        "forward_fill": False,
        "interpolation": False,
    }
