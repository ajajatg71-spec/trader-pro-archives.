"""Indicateurs techniques (fonctions pures, listes de clôtures du plus ancien au plus récent)."""

def sma(v, n):
    """Moyenne mobile simple des n dernières valeurs, ou None."""
    return sum(v[-n:]) / n if len(v) >= n else None

def ema_series(v, n):
    """Série de moyennes mobiles exponentielles de période n."""
    k, e, out = 2 / (n + 1), None, []
    for x in v:
        e = x if e is None else x * k + e * (1 - k)
        out.append(e)
    return out

def rsi(v, n=14):
    """RSI de Wilder. None si pas assez de données."""
    if len(v) <= n: return None
    g = l = 0.0
    for i in range(1, n + 1):
        d = v[i] - v[i - 1]; g += max(d, 0); l += max(-d, 0)
    g, l = g / n, l / n
    for i in range(n + 1, len(v)):
        d = v[i] - v[i - 1]
        g, l = (g * (n - 1) + max(d, 0)) / n, (l * (n - 1) + max(-d, 0)) / n
    if g == 0 and l == 0: return 50.0
    return 100.0 if l == 0 else 100 - 100 / (1 + g / l)

def macd(v, fast=12, slow=26, sig=9):
    """(macd, signal, histogramme) au dernier point, ou None."""
    if len(v) < slow + sig: return None
    m = [a - b for a, b in zip(ema_series(v, fast), ema_series(v, slow))]
    s = ema_series(m, sig)
    return m[-1], s[-1], m[-1] - s[-1]

def ema(v, n):
    """Dernière moyenne mobile exponentielle (initialisée sur la première valeur) ; None si moins de n valeurs."""
    return ema_series(v, n)[-1] if len(v) >= n else None

def true_range(highs, lows, closes):
    """Vrai intervalle de chaque barre : max(haut-bas, |haut-clôture précédente|, |bas-clôture précédente|) ; le premier vaut haut-bas."""
    tr = [highs[0] - lows[0]]
    for i in range(1, len(closes)): tr.append(max(highs[i] - lows[i], abs(highs[i] - closes[i - 1]), abs(lows[i] - closes[i - 1])))
    return tr

def atr_series(highs, lows, closes, n=14):
    """ATR de Wilder à chaque point (None avant n valeurs) : moyenne des n premiers vrais intervalles, puis lissage (ATR*(n-1)+TR)/n."""
    tr = true_range(highs, lows, closes); out = [None] * len(tr)
    if len(tr) < n: return out
    a = sum(tr[:n]) / n; out[n - 1] = a
    for i in range(n, len(tr)): a = (a * (n - 1) + tr[i]) / n; out[i] = a
    return out

def atr(highs, lows, closes, n=14):
    """Dernier ATR de Wilder, ou None si moins de n barres."""
    return atr_series(highs, lows, closes, n)[-1]

def adx(highs, lows, closes, n=14):
    """(ADX, +DI, -DI) de Wilder (lissage de Wilder, ADX = moyenne lissée du DX) ; None s'il y a moins de 2n barres."""
    if len(closes) < 2 * n: return None
    tr = true_range(highs, lows, closes); pdm, mdm = [0.0], [0.0]
    for i in range(1, len(closes)):
        up, dn = highs[i] - highs[i - 1], lows[i - 1] - lows[i]
        pdm.append(up if up > dn and up > 0 else 0.0); mdm.append(dn if dn > up and dn > 0 else 0.0)
    s_tr, s_p, s_m = sum(tr[1:n + 1]), sum(pdm[1:n + 1]), sum(mdm[1:n + 1]); dxs, pdi, mdi = [], 0.0, 0.0
    for i in range(n, len(closes)):
        if i > n: s_tr, s_p, s_m = s_tr - s_tr / n + tr[i], s_p - s_p / n + pdm[i], s_m - s_m / n + mdm[i]
        pdi, mdi = (100 * s_p / s_tr, 100 * s_m / s_tr) if s_tr else (0.0, 0.0)
        dxs.append(100 * abs(pdi - mdi) / (pdi + mdi) if pdi + mdi else 0.0)
    a = sum(dxs[:n]) / n
    for dx in dxs[n:]: a = (a * (n - 1) + dx) / n
    return a, pdi, mdi

def bollinger(closes, n=20, k=2.0):
    """Bandes de Bollinger (écart-type de population) : milieu, haute, basse, %B (position dans les bandes) et largeur relative ; None si moins de n valeurs."""
    if len(closes) < n: return None
    w = closes[-n:]; mid = sum(w) / n; sd = (sum((x - mid) ** 2 for x in w) / n) ** .5; up, lo = mid + k * sd, mid - k * sd
    return {"mid": mid, "upper": up, "lower": lo, "pct_b": (closes[-1] - lo) / (up - lo) if up > lo else 0.5, "bandwidth": (up - lo) / mid if mid else 0.0}

def vwap(highs, lows, closes, volumes, n=None):
    """Prix moyen pondéré par les volumes (prix typique = (haut+bas+clôture)/3) sur les n dernières barres, ou toutes ; None si volume nul."""
    i = slice(-n, None) if n else slice(None); vs = volumes[i]; tv = sum(vs)
    return sum((h + l + c) / 3 * v for h, l, c, v in zip(highs[i], lows[i], closes[i], vs)) / tv if tv > 0 else None
