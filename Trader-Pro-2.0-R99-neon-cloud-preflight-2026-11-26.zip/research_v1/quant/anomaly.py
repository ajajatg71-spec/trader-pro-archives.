"""Détection de mouvements inhabituels : variation du jour (z-score sur 60 jours) et pic de volume."""
import math
import statistics as st
from research_v1.quant.indicators import atr, true_range

def unusual(closes, volumes=None, z=3.0, vol_x=2.5):
    """Détecte une variation du jour anormale (z-score au-dessus du seuil) et un pic de volume."""
    out = []
    if len(closes) >= 62:
        r = [closes[i] / closes[i - 1] - 1 for i in range(1, len(closes))]
        h, last = r[-61:-1], r[-1]; sd = st.pstdev(h)
        if sd > 0 and abs(last - st.mean(h)) / sd >= z:
            out.append(f"mouvement inhabituel : {last * 100:+.1f} % ({abs(last - st.mean(h)) / sd:.1f} écarts-types)")
    if volumes and len(volumes) >= 21:
        avg = sum(volumes[-21:-1]) / 20
        if avg > 0 and volumes[-1] >= vol_x * avg: out.append(f"volume {volumes[-1] / avg:.1f}× la moyenne")
    return out

# --- Anomalies statistiques robustes (médiane et MAD) : chaque détecteur renvoie un dict {kind, severity, value, threshold, message} ou None ---

def _robust_z(history, x):
    med = st.median(history); mad = st.median(abs(v - med) for v in history) * 1.4826
    if mad == 0: mad = 1.2533 * sum(abs(v - med) for v in history) / len(history)
    return (x - med) / mad if mad > 0 else 0.0

def _flag(kind, z, thr, msg):
    if abs(z) < thr: return None
    return {"kind": kind, "severity": "critical" if abs(z) >= 2 * thr else "warning", "value": round(z, 2), "threshold": thr, "message": msg.format(z=z)}

def return_anomaly(closes, window=60, z=4.0):
    """Rendement du jour anormal par rapport aux window rendements précédents (écart robuste) ; None si normal ou historique insuffisant."""
    if len(closes) < window + 2: return None
    r = [closes[i] / closes[i - 1] - 1 for i in range(1, len(closes))]
    return _flag("return", _robust_z(r[-window - 1:-1], r[-1]), z, f"Rendement du jour {r[-1] * 100:+.2f} % : {{z:+.1f}} écarts robustes")

def volume_anomaly(volumes, window=20, z=3.0):
    """Volume du jour anormalement élevé (échelle logarithmique, écart robuste) ; None si normal ou insuffisant."""
    if len(volumes) < window + 1 or min(volumes[-window - 1:]) <= 0: return None
    zz = _robust_z([math.log(v) for v in volumes[-window - 1:-1]], math.log(volumes[-1]))
    return _flag("volume", zz, z, "Volume du jour : {z:+.1f} écarts robustes") if zz > 0 else None

def gap_anomaly(opens, closes, atr_value, mult=2.0):
    """Écart d'ouverture supérieur à mult fois l'ATR ; None si normal ou ATR inconnu."""
    if len(closes) < 2 or not atr_value: return None
    gap = opens[-1] - closes[-2]; return _flag("gap", gap / atr_value, mult, f"Écart d'ouverture de {gap:+.2f} ({{z:+.1f}} ATR)")

def range_expansion(highs, lows, closes, n=14, mult=2.5):
    """Vrai intervalle du jour supérieur à mult fois l'ATR des barres précédentes ; None si normal ou insuffisant."""
    if len(closes) < n + 2: return None
    prev = atr(highs[:-1], lows[:-1], closes[:-1], n); tr = true_range(highs, lows, closes)[-1]
    return _flag("range", tr / prev, mult, "Amplitude du jour : {z:.1f} fois l'ATR") if prev else None

def _corr(a, b):
    ma, mb = sum(a) / len(a), sum(b) / len(b); sa, sb = sum((x - ma) ** 2 for x in a) ** .5, sum((x - mb) ** 2 for x in b) ** .5
    return sum((x - ma) * (y - mb) for x, y in zip(a, b)) / (sa * sb) if sa and sb else 0.0

def correlation_breakdown(ret_a, ret_b, window=60, drop=0.5):
    """Corrélation récente effondrée par rapport à la corrélation de long terme (rupture de lien avec l'indice) ; None si normal ou insuffisant."""
    n = min(len(ret_a), len(ret_b))
    if n < 2 * window: return None
    a, b = ret_a[-n:], ret_b[-n:]; longrun, now = _corr(a[:-window], b[:-window]), _corr(a[-window:], b[-window:])
    if longrun - now < drop: return None
    return {"kind": "correlation", "severity": "warning", "value": round(now, 2), "threshold": round(longrun - drop, 2), "message": f"Corrélation à l'indice tombée à {now:.2f} (long terme {longrun:.2f})"}

def detect_all(opens, highs, lows, closes, volumes, bench_closes=None):
    """Lance tous les détecteurs et renvoie les anomalies trouvées, les plus graves d'abord."""
    a = atr(highs[:-1], lows[:-1], closes[:-1]) if len(closes) > 15 else None
    found = [return_anomaly(closes), volume_anomaly(volumes), gap_anomaly(opens, closes, a), range_expansion(highs, lows, closes)]
    if bench_closes and len(bench_closes) >= len(closes) >= 130:
        n = len(closes); ra = [closes[i] / closes[i - 1] - 1 for i in range(1, n)]; rb = [bench_closes[-n + i] / bench_closes[-n + i - 1] - 1 for i in range(1, n)]; found.append(correlation_breakdown(ra, rb))
    return sorted([f for f in found if f], key=lambda f: f["severity"] != "critical")
