"""Facteurs Value, Growth, Quality et Momentum : entrées brutes, normalisation transversale (z-scores) et score composite explicable."""
import statistics
from research_v1.quant.momentum import momentum, momentum_12_1

FACTORS = ("value", "growth", "quality", "momentum")
DEFAULT_WEIGHTS = {"value": 0.25, "growth": 0.25, "quality": 0.25, "momentum": 0.25}

def raw_inputs(closes, fundamentals=None):
    """Entrées brutes d'un titre : rendement des bénéfices (BPA / cours), croissance du chiffre d'affaires, marge nette, momentum 12-1 (ou 6 mois à défaut)."""
    price = closes[-1] if closes else None; f = fundamentals or {}; eps = f.get("eps")
    mom, window = momentum_12_1(closes), "12-1"
    if mom is None: mom, window = momentum(closes, 126), "6 mois"
    return {"value": eps / price if eps is not None and price and price > 0 else None, "growth": f.get("growth_pct"), "quality": f.get("margin_pct"), "momentum": mom,
            "details": {"price": price, "eps": eps, "fundamentals_as_of": f.get("as_of"), "momentum_window": window if mom is not None else None}}

def winsorize(values, z=3.0):
    """Ramène les valeurs à ±z écarts-types de la moyenne (les None sont conservés)."""
    vs = [v for v in values if v is not None]
    if len(vs) < 3: return list(values)
    m, sd = statistics.fmean(vs), statistics.pstdev(vs)
    return list(values) if sd == 0 else [None if v is None else min(max(v, m - z * sd), m + z * sd) for v in values]

def zscores(values):
    """Scores centrés réduits (écart-type de population) ; tout est None s'il y a moins de 2 valeurs, 0 si elles sont identiques."""
    vs = [v for v in values if v is not None]
    if len(vs) < 2: return [None] * len(values)
    m, sd = statistics.fmean(vs), statistics.pstdev(vs)
    return [None if v is None else (0.0 if sd == 0 else (v - m) / sd) for v in values]

def factor_scores(universe, weights=None):
    """Compare les titres de l'univers : z-score par facteur, score composite (moyenne pondérée des facteurs disponibles), couverture et rang."""
    w = weights or DEFAULT_WEIGHTS; syms = list(universe); z = {}
    for f in FACTORS: z[f] = dict(zip(syms, zscores(winsorize([universe[s][f] for s in syms]))))
    out = {}
    for s in syms:
        avail = {f: z[f][s] for f in FACTORS if z[f][s] is not None and w.get(f, 0) > 0}; tw = sum(w[f] for f in avail)
        out[s] = {"z": {f: (None if z[f][s] is None else round(z[f][s], 4)) for f in FACTORS}, "raw": {f: universe[s][f] for f in FACTORS},
                  "composite": round(sum(w[f] * v for f, v in avail.items()) / tw, 4) if tw else None, "coverage": round(tw / sum(w.values()), 4), "details": universe[s].get("details", {}), "missing": [f for f in FACTORS if universe[s][f] is None]}
    order = sorted((s for s in syms if out[s]["composite"] is not None), key=lambda s: -out[s]["composite"])
    for s in syms: out[s]["rank"] = order.index(s) + 1 if s in order else None
    return out
