"""Lecture descriptive et explicable d'un graphique OHLCV.

Module autonome de recherche : n'émet aucun ordre, ne modifie aucune stratégie
et ne participe pas au chemin d'exécution. Les calculs sont limités aux barres
fournies et n'utilisent pas de données futures.
"""
from __future__ import annotations

import math
from datetime import datetime
from research_v1.quant import candles, levels
from research_v1.quant.features import Features

WARNING = (
    "Lecture descriptive uniquement. Les figures et le biais technique ne "
    "constituent pas une preuve de pouvoir prédictif après frais et glissement."
)


def _ok(*values):
    return all(value is not None and math.isfinite(float(value)) for value in values)


def _sign(label):
    return {"haussière": 1, "baissière": -1}.get(label, 0)


def _validate_bars(bars):
    if not isinstance(bars, (list, tuple)):
        raise ValueError("bars doit être une séquence de barres OHLCV")
    if len(bars) < 30:
        raise ValueError("Au moins 30 barres sont nécessaires pour lire un graphique")
    previous_ts = None
    for index, bar in enumerate(bars):
        try:
            o, h, low, close, volume = (
                float(getattr(bar, key)) for key in ("o", "h", "l", "c", "v")
            )
        except (AttributeError, TypeError, ValueError) as exc:
            raise ValueError(f"Barre OHLCV invalide à l'index {index}") from exc
        if not all(math.isfinite(value) for value in (o, h, low, close, volume)):
            raise ValueError(f"Valeur OHLCV non finie à l'index {index}")
        if low <= 0 or volume < 0 or h < max(o, close) or low > min(o, close) or h < low:
            raise ValueError(f"Géométrie OHLCV invalide à l'index {index}")
        ts = getattr(bar, "ts", None)
        if ts is not None:
            if not isinstance(ts, str) or not ts:
                raise ValueError(f"Horodatage invalide à l'index {index}")
            try:
                parsed_ts = datetime.fromisoformat(ts.replace("Z", "+00:00"))
            except ValueError as exc:
                raise ValueError(f"Horodatage ISO invalide à l'index {index}") from exc
            if previous_ts is not None:
                try:
                    if parsed_ts < previous_ts:
                        raise ValueError(
                            "Les barres doivent être ordonnées de la plus ancienne à la plus récente"
                        )
                except TypeError as exc:
                    raise ValueError("Les fuseaux horaires des barres doivent être cohérents") from exc
            previous_ts = parsed_ts


def _trend(features):
    close = features.close
    ema10, ema20 = features.v("ema", 10), features.v("ema", 20)
    ema50, sma50, sma200 = (
        features.v("ema", 50), features.v("sma", 50), features.v("sma", 200)
    )

    def classify(a, b, current):
        if _ok(a, b, current):
            if current > a > b:
                return "haussière"
            if current < a < b:
                return "baissière"
            return "neutre"
        return "indéterminée"

    return {
        "court": classify(ema10, ema20, close),
        "moyen": classify(ema20, ema50, close),
        "long": classify(sma50, sma200, close),
    }


def read(bars, bench=None, lookback=3):
    """Retourne une lecture structurée de la dernière barre, sans décision d'ordre."""
    _validate_bars(bars)
    if type(lookback) is not int or lookback < 1 or lookback > 30:
        raise ValueError("lookback doit être un entier entre 1 et 30")

    features = Features(bars, bench)
    last = bars[-1]
    avg = candles.avg_range(bars, features.n - 1)
    atr = features.v("atr", 14)
    price = last.c
    patterns = candles.scan(bars, lookback)
    trend = _trend(features)
    all_levels = features.levels()
    support, resistance = levels.nearest(all_levels)

    relative_volume = features.v("relvol", 20)
    obv, obv_average = features.v("obv"), features.v("obv_sma", 20)
    bandwidth_percentile = features.v("bw_pct", 126)
    rsi = features.v("rsi", 14)
    stochastic = features.v("stoch_k")
    macd_histogram = features.v("macd_hist")

    volume = {
        "relative": round(relative_volume, 2) if relative_volume is not None else None,
        "obv_above_average": bool(obv > obv_average) if _ok(obv, obv_average) else None,
    }
    volatility_state = (
        "indéterminée" if bandwidth_percentile is None
        else "compression" if bandwidth_percentile < 0.2
        else "expansion" if bandwidth_percentile > 0.8
        else "normale"
    )

    score = 0.5 * (
        _sign(trend["court"]) + _sign(trend["moyen"]) + 2 * _sign(trend["long"])
    ) / 4
    factors = []
    if any(trend[key] not in ("indéterminée", "neutre") for key in trend):
        factors.append(
            f"tendances {trend['court']} (court), {trend['moyen']} (moyen), "
            f"{trend['long']} (long)"
        )

    pattern_score = 0.0
    for pattern in patterns:
        if (
            pattern["bars_ago"] > 1
            or not pattern["context_ok"]
            or pattern["direction"] == "indécision"
        ):
            continue
        weight = 0.3 * pattern["strength"] * (
            0.0 if pattern["confirmed"] is False else 1.0
        )
        pattern_score += weight if pattern["direction"] == "haussier" else -weight
        factors.append(
            f"{pattern['name']} ({pattern['direction']}, force {pattern['strength']:.2f}"
            f"{', confirmée' if pattern['confirmed'] else ', non confirmée' if pattern['confirmed'] is False else ''})"
        )

    score += max(-0.4, min(0.4, pattern_score))
    if atr is not None and atr > 0:
        if support and support["distance_atr"] <= 0.5:
            score += 0.1
            factors.append(f"au contact du support {support['price']:.2f}")
        if resistance and resistance["distance_atr"] <= 0.5:
            score -= 0.1
            factors.append(f"au contact de la résistance {resistance['price']:.2f}")
    if macd_histogram is not None:
        score += 0.1 if macd_histogram > 0 else -0.1
        factors.append(
            f"histogramme MACD {'positif' if macd_histogram > 0 else 'négatif'}"
        )

    score = max(-1.0, min(1.0, round(score, 3)))
    label = "haussier" if score > 0.25 else "baissier" if score < -0.25 else "neutre"

    summary = [candles.describe(last, avg)]
    when = lambda pattern: (
        "aujourd'hui" if pattern["bars_ago"] == 0
        else f"il y a {pattern['bars_ago']} séance(s)"
    )
    summary.append(
        "Figures récentes : " + "; ".join(
            f"{pattern['name']} ({when(pattern)})" for pattern in patterns
        ) + "."
        if patterns else
        "Aucune figure de chandelier notable sur les dernières séances."
    )
    summary.append(
        f"Tendance {trend['court']} à court terme, {trend['moyen']} à moyen terme, "
        f"{trend['long']} à long terme."
    )
    if support or resistance:
        details = []
        if support:
            details.append(
                f"support {support['price']:.2f} ({support['distance_atr']:.1f} ATR sous le cours)"
            )
        if resistance:
            details.append(
                f"résistance {resistance['price']:.2f} "
                f"({resistance['distance_atr']:.1f} ATR au-dessus)"
            )
        summary.append("Niveaux : " + ", ".join(details) + ".")
    if relative_volume is not None:
        summary.append(
            f"Volume {relative_volume:.1f} fois la moyenne 20 séances"
            + (
                ", flux cumulé (OBV) au-dessus de sa moyenne."
                if volume["obv_above_average"] else "."
            )
        )
    summary.append(
        f"Biais {label} (score {score:+.2f}) : "
        + ("; ".join(factors) if factors else "aucun facteur marquant") + "."
    )

    candle = candles.anatomy(last, avg)
    candle = {
        key: round(value, 4) if isinstance(value, float) else value
        for key, value in candle.items()
    }
    candle["text"] = candles.describe(last, avg)

    return {
        "symbol": getattr(last, "symbol", None),
        "as_of": getattr(last, "ts", None),
        "price": price,
        "candle": candle,
        "patterns": patterns,
        "trend": trend,
        "levels": {
            "support": support,
            "resistance": resistance,
            "all": all_levels[:8],
        },
        "volume": volume,
        "volatility": {
            "atr": round(atr, 4) if atr is not None else None,
            "atr_pct": round(atr / price * 100, 2) if atr is not None else None,
            "state": volatility_state,
        },
        "momentum": {
            "rsi": round(rsi, 1) if rsi is not None else None,
            "stoch_k": round(stochastic, 1) if stochastic is not None else None,
            "macd_hist": round(macd_histogram, 4) if macd_histogram is not None else None,
        },
        "bias": {"score": score, "label": label, "factors": factors},
        "summary": " ".join(summary),
        "warning": WARNING,
        "research_only": True,
    }
