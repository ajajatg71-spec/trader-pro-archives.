"""Lecture des chandeliers japonais : anatomie d'une bougie, tendance précédente, 36 figures (1 à 5 bougies) avec contexte, force et explication chiffrée.
Aucune donnée postérieure à la barre analysée n'est lue. ATTENTION : des études sur plusieurs marchés trouvent que la plupart des figures n'ont pas de pouvoir prédictif
statistiquement significatif après coûts ; ce module décrit, il ne prouve rien (voir docs/STRATEGY_CATALOG.md)."""
import math
from dataclasses import asdict, dataclass

MIN_REL = 0.3   # amplitude minimale (en multiples de l'amplitude moyenne) pour qu'une figure à bougie unique ou multiple compte

# code -> (nom, direction, tendance requise avant la figure, nombre de bougies)
LABELS = {
    "doji": ("Doji", "indécision", None, 1), "long_legged_doji": ("Doji à longues jambes", "indécision", None, 1), "dragonfly_doji": ("Doji libellule", "haussier", "baissière", 1),
    "gravestone_doji": ("Doji pierre tombale", "baissier", "haussière", 1), "hammer": ("Marteau", "haussier", "baissière", 1), "hanging_man": ("Pendu", "baissier", "haussière", 1),
    "inverted_hammer": ("Marteau inversé", "haussier", "baissière", 1), "shooting_star": ("Étoile filante", "baissier", "haussière", 1), "bullish_marubozu": ("Marubozu haussier", "haussier", None, 1),
    "bearish_marubozu": ("Marubozu baissier", "baissier", None, 1), "spinning_top": ("Toupie", "indécision", None, 1),
    "bullish_engulfing": ("Avalement haussier", "haussier", "baissière", 2), "bearish_engulfing": ("Avalement baissier", "baissier", "haussière", 2), "piercing_line": ("Ligne perçante", "haussier", "baissière", 2),
    "dark_cloud_cover": ("Nuage noir couvrant", "baissier", "haussière", 2), "bullish_harami": ("Harami haussier", "haussier", "baissière", 2), "bearish_harami": ("Harami baissier", "baissier", "haussière", 2),
    "bullish_harami_cross": ("Harami croix haussier", "haussier", "baissière", 2), "bearish_harami_cross": ("Harami croix baissier", "baissier", "haussière", 2),
    "tweezer_bottom": ("Pince à épiler (creux)", "haussier", "baissière", 2), "tweezer_top": ("Pince à épiler (sommet)", "baissier", "haussière", 2),
    "bullish_kicker": ("Coup de pied haussier", "haussier", None, 2), "bearish_kicker": ("Coup de pied baissier", "baissier", None, 2), "inside_bar": ("Barre intérieure", "indécision", None, 2),
    "morning_star": ("Étoile du matin", "haussier", "baissière", 3), "morning_doji_star": ("Étoile du matin doji", "haussier", "baissière", 3), "evening_star": ("Étoile du soir", "baissier", "haussière", 3),
    "evening_doji_star": ("Étoile du soir doji", "baissier", "haussière", 3), "three_white_soldiers": ("Trois soldats blancs", "haussier", None, 3), "three_black_crows": ("Trois corbeaux noirs", "baissier", None, 3),
    "three_inside_up": ("Trois à l'intérieur haussier", "haussier", "baissière", 3), "three_inside_down": ("Trois à l'intérieur baissier", "baissier", "haussière", 3),
    "three_outside_up": ("Trois à l'extérieur haussier", "haussier", "baissière", 3), "three_outside_down": ("Trois à l'extérieur baissier", "baissier", "haussière", 3),
    "rising_three_methods": ("Trois méthodes ascendantes", "haussier", "haussière", 5), "falling_three_methods": ("Trois méthodes descendantes", "baissier", "baissière", 5)}

@dataclass(frozen=True)
class Pattern:
    code: str
    name: str
    direction: str            # haussier | baissier | indécision
    n_bars: int
    index: int                # indice de la dernière bougie
    strength: float           # 0 à 1 : taille, géométrie, volume
    needs_trend: str | None
    trend_before: str | None
    context_ok: bool          # la tendance précédente correspond à celle que la figure exige
    metrics: dict
    explanation: str

    def to_dict(self):
        """Représentation JSON de la figure."""
        return asdict(self)

def avg_range(bars, i, n=14):
    """Amplitude moyenne (haut - bas) des n barres précédant i ; l'amplitude de la barre elle-même s'il n'y en a pas."""
    w = bars[max(0, i - n):i]; return sum(b.h - b.l for b in w) / len(w) if w else bars[i].h - bars[i].l

def anatomy(b, avg):
    """Anatomie d'une bougie : corps, mèches, proportions de l'amplitude, couleur, taille relative à l'amplitude moyenne."""
    rng, top, bot = b.h - b.l, max(b.o, b.c), min(b.o, b.c); body = top - bot
    return {"rng": rng, "body": body, "top": top, "bot": bot, "upper": b.h - top, "lower": bot - b.l, "bull": b.c > b.o, "bear": b.c < b.o,
            "bp": body / rng if rng > 0 else 0.0, "up_p": (b.h - top) / rng if rng > 0 else 0.0, "lo_p": (bot - b.l) / rng if rng > 0 else 0.0, "rel": rng / avg if avg > 0 else 0.0}

def trend_before(bars, start, n=6, atr_mult=0.8):
    """Tendance des n séances précédant la barre start : haussière ou baissière si le mouvement dépasse atr_mult x amplitude moyenne relative x racine(n), sinon neutre ; None si historique insuffisant."""
    if start - 1 - n < 0 or bars[start - 1 - n].c <= 0: return None
    c1, c0 = bars[start - 1].c, bars[start - 1 - n].c; thr = atr_mult * (avg_range(bars, start) / c1) * math.sqrt(n); chg = c1 / c0 - 1
    return "haussière" if chg >= thr else "baissière" if chg <= -thr else "neutre"

def _strength(rel, geometry, vrel): return round(max(0.0, min(1.0, 0.4 * min(rel / 1.5, 1.0) + 0.4 * max(0.0, min(geometry, 1.0)) + 0.2 * min(vrel / 2, 1.0))), 3)

def detect(bars, i, trend_n=6):
    """Toutes les figures dont la dernière bougie est la barre i. Chaque figure indique si la tendance précédente correspond à son contexte (context_ok), sa force et une explication chiffrée."""
    out = []
    if not 0 <= i < len(bars): return out
    avg = avg_range(bars, i)
    if avg <= 0: return out
    vw = [b.v for b in bars[max(0, i - 20):i]]; vrel = bars[i].v / (sum(vw) / len(vw)) if vw and sum(vw) > 0 else 1.0; B = bars
    def add(code, n, geometry, why, rel=None):
        name, direction, needs, _ = LABELS[code]; tb = trend_before(B, i - n + 1, trend_n); ok = needs is None or tb == needs
        rel = (B[i].h - B[i].l) / avg if rel is None else rel
        out.append(Pattern(code, name, direction, n, i, _strength(rel, geometry, vrel), needs, tb, ok, {"rel_range": round(rel, 3), "vol_rel": round(vrel, 3)},
                           f"{name} : {why}" + (f", après une tendance {tb}" if tb else "") + ("" if ok or needs is None else f" (contexte requis : {needs})")))
    b = B[i]; ab = anatomy(b, avg); big = lambda a: a["body"] >= 0.5 * avg; long_ = lambda a: a["body"] >= 0.6 * avg and a["bp"] >= 0.5; pc = lambda x: f"{x * 100:.0f} %"
    if ab["rng"] > 0 and ab["rel"] >= MIN_REL:
        tb = trend_before(B, i, trend_n)
        if ab["bp"] <= 0.10:
            if ab["lo_p"] >= 0.6 and ab["up_p"] <= 0.1: add("dragonfly_doji", 1, ab["lo_p"], f"mèche basse {pc(ab['lo_p'])} de l'amplitude, corps quasi nul")
            elif ab["up_p"] >= 0.6 and ab["lo_p"] <= 0.1: add("gravestone_doji", 1, ab["up_p"], f"mèche haute {pc(ab['up_p'])} de l'amplitude, corps quasi nul")
            elif ab["up_p"] >= 0.3 and ab["lo_p"] >= 0.3: add("long_legged_doji", 1, min(ab["up_p"], ab["lo_p"]) * 2, f"mèches de {pc(ab['up_p'])} et {pc(ab['lo_p'])}, corps quasi nul")
            else: add("doji", 1, 0.5, f"corps de {pc(ab['bp'])} de l'amplitude")
        elif ab["bp"] <= 0.30 and ab["up_p"] >= 0.25 and ab["lo_p"] >= 0.25: add("spinning_top", 1, 0.5, f"corps de {pc(ab['bp'])}, mèches de {pc(ab['up_p'])} et {pc(ab['lo_p'])}")
        elif ab["body"] > 0 and ab["lower"] >= 2 * ab["body"] and ab["up_p"] <= 0.15:
            add("hanging_man" if tb == "haussière" else "hammer", 1, ab["lower"] / (3 * ab["body"]), f"mèche basse {ab['lower'] / ab['body']:.1f} fois le corps, mèche haute {pc(ab['up_p'])} de l'amplitude")
        elif ab["body"] > 0 and ab["upper"] >= 2 * ab["body"] and ab["lo_p"] <= 0.15:
            add("shooting_star" if tb == "haussière" else "inverted_hammer", 1, ab["upper"] / (3 * ab["body"]), f"mèche haute {ab['upper'] / ab['body']:.1f} fois le corps, mèche basse {pc(ab['lo_p'])} de l'amplitude")
        elif ab["bp"] >= 0.90 and ab["up_p"] <= 0.05 and ab["lo_p"] <= 0.05 and ab["rel"] >= 0.8: add("bullish_marubozu" if ab["bull"] else "bearish_marubozu", 1, ab["bp"], f"corps de {pc(ab['bp'])} de l'amplitude, sans mèche, amplitude {ab['rel']:.1f} fois la moyenne")
    if i >= 1:
        p = B[i - 1]; ap = anatomy(p, avg)
        if ap["rng"] > 0 and ab["rng"] > 0 and ab["rel"] >= MIN_REL:
            mid = (p.o + p.c) / 2
            if ap["bear"] and ab["bull"] and b.o <= p.c and b.c >= p.o and ab["body"] > ap["body"] and big(ab): add("bullish_engulfing", 2, ab["body"] / (2 * ap["body"]) if ap["body"] else 1, f"le corps haussier ({ab['body']:.2f}) avale le corps baissier précédent ({ap['body']:.2f})")
            if ap["bull"] and ab["bear"] and b.o >= p.c and b.c <= p.o and ab["body"] > ap["body"] and big(ab): add("bearish_engulfing", 2, ab["body"] / (2 * ap["body"]) if ap["body"] else 1, f"le corps baissier ({ab['body']:.2f}) avale le corps haussier précédent ({ap['body']:.2f})")
            if ap["bear"] and long_(ap) and ab["bull"] and b.o < p.c and mid < b.c < p.o: add("piercing_line", 2, (b.c - p.c) / (p.o - p.c), f"clôture à {pc((b.c - p.c) / (p.o - p.c))} de pénétration dans le corps baissier précédent")
            if ap["bull"] and long_(ap) and ab["bear"] and b.o > p.c and p.o < b.c < mid: add("dark_cloud_cover", 2, (p.c - b.c) / (p.c - p.o), f"clôture à {pc((p.c - b.c) / (p.c - p.o))} de pénétration dans le corps haussier précédent")
            inside = ab["top"] <= ap["top"] and ab["bot"] >= ap["bot"]
            if long_(ap) and inside and ab["body"] <= 0.5 * ap["body"]:
                if ap["bear"] and ab["bp"] <= 0.10: add("bullish_harami_cross", 2, 1 - ab["body"] / ap["body"], "un doji tient dans le corps baissier précédent")
                elif ap["bear"] and ab["bull"]: add("bullish_harami", 2, 1 - ab["body"] / ap["body"], f"le petit corps haussier tient dans le grand corps baissier ({pc(ab['body'] / ap['body'])} de sa taille)")
                elif ap["bull"] and ab["bp"] <= 0.10: add("bearish_harami_cross", 2, 1 - ab["body"] / ap["body"], "un doji tient dans le corps haussier précédent")
                elif ap["bull"] and ab["bear"]: add("bearish_harami", 2, 1 - ab["body"] / ap["body"], f"le petit corps baissier tient dans le grand corps haussier ({pc(ab['body'] / ap['body'])} de sa taille)")
            if ap["body"] >= 0.3 * avg and ab["body"] >= 0.3 * avg:
                if abs(p.l - b.l) <= 0.1 * avg and ap["bear"] and ab["bull"]: add("tweezer_bottom", 2, 1 - abs(p.l - b.l) / (0.1 * avg) * 0.5, f"deux creux quasi égaux ({p.l:.2f} et {b.l:.2f})")
                if abs(p.h - b.h) <= 0.1 * avg and ap["bull"] and ab["bear"]: add("tweezer_top", 2, 1 - abs(p.h - b.h) / (0.1 * avg) * 0.5, f"deux sommets quasi égaux ({p.h:.2f} et {b.h:.2f})")
            if long_(ap) and long_(ab):
                if ap["bear"] and ab["bull"] and b.o > p.o: add("bullish_kicker", 2, 1.0, f"ouverture haussière ({b.o:.2f}) au-dessus de l'ouverture de la bougie baissière ({p.o:.2f})")
                if ap["bull"] and ab["bear"] and b.o < p.o: add("bearish_kicker", 2, 1.0, f"ouverture baissière ({b.o:.2f}) sous l'ouverture de la bougie haussière ({p.o:.2f})")
        if b.h < p.h and b.l > p.l and ap["rng"] > 0: add("inside_bar", 2, 1 - ab["rng"] / ap["rng"], f"la barre tient dans celle de la veille ({pc(ab['rng'] / ap['rng'])} de son amplitude)", rel=ab["rng"] / avg)
    if i >= 2:
        a, p = B[i - 2], B[i - 1]; aa, ap = anatomy(a, avg), anatomy(p, avg); mid = (a.o + a.c) / 2
        if ab["rel"] >= MIN_REL and aa["rng"] > 0:
            if aa["bear"] and long_(aa) and ap["body"] <= 0.35 * aa["body"] and ap["top"] <= a.c + 0.05 * avg and ab["bull"] and big(ab) and b.c > mid:
                add("morning_doji_star" if ap["bp"] <= 0.10 else "morning_star", 3, (b.c - mid) / (a.o - mid) if a.o != mid else 1, f"petite bougie sous la clôture de la première, puis clôture haussière au-dessus du milieu de la première ({b.c:.2f} > {mid:.2f})")
            if aa["bull"] and long_(aa) and ap["body"] <= 0.35 * aa["body"] and ap["bot"] >= a.c - 0.05 * avg and ab["bear"] and big(ab) and b.c < mid:
                add("evening_doji_star" if ap["bp"] <= 0.10 else "evening_star", 3, (mid - b.c) / (mid - a.o) if a.o != mid else 1, f"petite bougie au-dessus de la clôture de la première, puis clôture baissière sous le milieu de la première ({b.c:.2f} < {mid:.2f})")
            if all(x["bull"] and x["body"] >= 0.5 * avg and x["bp"] >= 0.6 and x["up_p"] <= 0.25 for x in (aa, ap, ab)) and a.o <= p.o <= a.c and p.o <= b.o <= p.c and a.c < p.c < b.c:
                add("three_white_soldiers", 3, min(1.0, (b.c - a.o) / (3 * avg)), f"trois bougies haussières successives, clôtures {a.c:.2f}, {p.c:.2f}, {b.c:.2f}")
            if all(x["bear"] and x["body"] >= 0.5 * avg and x["bp"] >= 0.6 and x["lo_p"] <= 0.25 for x in (aa, ap, ab)) and a.c <= p.o <= a.o and p.c <= b.o <= p.o and a.c > p.c > b.c:
                add("three_black_crows", 3, min(1.0, (a.o - b.c) / (3 * avg)), f"trois bougies baissières successives, clôtures {a.c:.2f}, {p.c:.2f}, {b.c:.2f}")
            if aa["bear"] and long_(aa) and ap["bull"] and ap["top"] < aa["top"] and ap["bot"] > aa["bot"] and ap["body"] <= 0.6 * aa["body"] and ab["bull"] and b.c > a.o: add("three_inside_up", 3, 0.7, "harami haussier confirmé par une clôture au-dessus de l'ouverture de la première bougie")
            if aa["bull"] and long_(aa) and ap["bear"] and ap["top"] < aa["top"] and ap["bot"] > aa["bot"] and ap["body"] <= 0.6 * aa["body"] and ab["bear"] and b.c < a.o: add("three_inside_down", 3, 0.7, "harami baissier confirmé par une clôture sous l'ouverture de la première bougie")
            if aa["bear"] and ap["bull"] and p.o <= a.c and p.c >= a.o and ap["body"] > aa["body"] and ab["bull"] and b.c > p.c: add("three_outside_up", 3, 0.8, "avalement haussier confirmé par une clôture plus haute")
            if aa["bull"] and ap["bear"] and p.o >= a.c and p.c <= a.o and ap["body"] > aa["body"] and ab["bear"] and b.c < p.c: add("three_outside_down", 3, 0.8, "avalement baissier confirmé par une clôture plus basse")
    if i >= 4 and ab["rel"] >= MIN_REL:
        f, mids = B[i - 4], B[i - 3:i]; af = anatomy(f, avg); am = [anatomy(x, avg) for x in mids]
        small = all(x["body"] <= 0.5 * af["body"] for x in am) and all(x.h <= f.h and x.l >= f.l for x in mids)
        if af["bull"] and long_(af) and small and sum(x["bear"] for x in am) >= 2 and ab["bull"] and big(ab) and b.c > f.c: add("rising_three_methods", 5, 0.8, f"trois petites bougies contenues dans la grande bougie haussière, puis clôture au-dessus d'elle ({b.c:.2f} > {f.c:.2f})")
        if af["bear"] and long_(af) and small and sum(x["bull"] for x in am) >= 2 and ab["bear"] and big(ab) and b.c < f.c: add("falling_three_methods", 5, 0.8, f"trois petites bougies contenues dans la grande bougie baissière, puis clôture sous elle ({b.c:.2f} < {f.c:.2f})")
    return sorted(out, key=lambda x: (-x.strength, x.code))

def confirmation(bars, p):
    """La bougie suivante confirme-t-elle la figure ? Haussière : clôture au-dessus du plus haut de la figure ; baissière : sous son plus bas. None s'il n'y a pas de bougie suivante ou si la figure est neutre."""
    if p.index + 1 >= len(bars) or p.direction == "indécision": return None
    last, nxt = bars[p.index], bars[p.index + 1]; return nxt.c > last.h if p.direction == "haussier" else nxt.c < last.l

def scan(bars, lookback=3, only_context=False):
    """Figures des `lookback` dernières barres, avec leur ancienneté et leur confirmation, les plus récentes et les plus fortes d'abord."""
    n, out = len(bars), []
    for i in range(max(0, n - lookback), n):
        for p in detect(bars, i):
            if only_context and not p.context_ok: continue
            out.append({**p.to_dict(), "bars_ago": n - 1 - i, "confirmed": confirmation(bars, p)})
    return sorted(out, key=lambda x: (x["bars_ago"], -x["strength"]))

def describe(b, avg):
    """Phrase décrivant la bougie : couleur, corps, mèches et amplitude relative."""
    a = anatomy(b, avg); pc = lambda x: f"{x * 100:.0f} %"
    if a["rng"] <= 0: return "Bougie sans amplitude (haut = bas)."
    col = "haussière" if a["bull"] else "baissière" if a["bear"] else "neutre (ouverture = clôture)"
    return f"Bougie {col} : corps {pc(a['bp'])} de l'amplitude, mèche haute {pc(a['up_p'])}, mèche basse {pc(a['lo_p'])}, amplitude {a['rel']:.1f} fois la moyenne."
