"""Séries d'indicateurs causales : la valeur à l'indice t n'utilise que des données jusqu'à t (aucun regard dans le futur).
La classe Features les calcule une fois pour toute l'histoire et les lit « au curseur », ce qui permet d'évaluer une règle barre par barre sans recalcul."""
from research_v1.quant import indicators as I

def _sma_on(v, n):
    out = [None] * len(v)
    for i in range(n - 1, len(v)):
        w = v[i - n + 1:i + 1]
        if None not in w: out[i] = sum(w) / n
    return out

def sma_s(v, n):
    """Moyenne mobile simple à chaque point (None avant n valeurs)."""
    return _sma_on(v, n)

def ema_s(v, n):
    """Moyenne mobile exponentielle standard, initialisée sur la moyenne des n premières valeurs définies."""
    out, k = [None] * len(v), 2 / (n + 1); j = next((i for i, x in enumerate(v) if x is not None), None)
    if j is None or len(v) - j < n: return out
    e = sum(v[j:j + n]) / n; out[j + n - 1] = e
    for i in range(j + n, len(v)): e = v[i] * k + e * (1 - k); out[i] = e
    return out

def _rsi(g, l): return 50.0 if g == 0 and l == 0 else 100.0 if l == 0 else 100 - 100 / (1 + g / l)

def rsi_s(c, n=14):
    """RSI de Wilder à chaque point (None avant n+1 valeurs)."""
    out = [None] * len(c)
    if len(c) <= n: return out
    g = l = 0.0
    for i in range(1, n + 1): d = c[i] - c[i - 1]; g += max(d, 0); l += max(-d, 0)
    g, l = g / n, l / n; out[n] = _rsi(g, l)
    for i in range(n + 1, len(c)): d = c[i] - c[i - 1]; g, l = (g * (n - 1) + max(d, 0)) / n, (l * (n - 1) + max(-d, 0)) / n; out[i] = _rsi(g, l)
    return out

def adx_s(h, l, c, n=14):
    """(ADX, +DI, -DI) de Wilder à chaque point ; DI défini dès n barres, ADX dès 2n-1 barres."""
    N = len(c); adx, pdi, mdi = [None] * N, [None] * N, [None] * N
    if N < n + 1: return adx, pdi, mdi
    tr = I.true_range(h, l, c); pd, md = [0.0], [0.0]
    for i in range(1, N):
        up, dn = h[i] - h[i - 1], l[i - 1] - l[i]; pd.append(up if up > dn and up > 0 else 0.0); md.append(dn if dn > up and dn > 0 else 0.0)
    s_tr, s_p, s_m = sum(tr[1:n + 1]), sum(pd[1:n + 1]), sum(md[1:n + 1]); dxs = []; a = None
    for i in range(n, N):
        if i > n: s_tr, s_p, s_m = s_tr - s_tr / n + tr[i], s_p - s_p / n + pd[i], s_m - s_m / n + md[i]
        p, m = (100 * s_p / s_tr, 100 * s_m / s_tr) if s_tr else (0.0, 0.0); pdi[i], mdi[i] = p, m
        dxs.append(100 * abs(p - m) / (p + m) if p + m else 0.0)
        if len(dxs) == n: a = sum(dxs) / n
        elif len(dxs) > n: a = (a * (n - 1) + dxs[-1]) / n
        if a is not None: adx[i] = a
    return adx, pdi, mdi

def macd_s(c, fast=12, slow=26, sig=9):
    """(ligne MACD, signal, histogramme) à chaque point."""
    ef, es = ema_s(c, fast), ema_s(c, slow); line = [None if a is None or b is None else a - b for a, b in zip(ef, es)]; s = ema_s(line, sig)
    return line, s, [None if a is None or b is None else a - b for a, b in zip(line, s)]

def bollinger_s(c, n=20, k=2.0):
    """Bandes de Bollinger : dict de séries mid, up, lo, pctb, bw (écart-type de population)."""
    N = len(c); r = {x: [None] * N for x in ("mid", "up", "lo", "pctb", "bw")}
    for i in range(n - 1, N):
        w = c[i - n + 1:i + 1]; m = sum(w) / n; sd = (sum((x - m) ** 2 for x in w) / n) ** .5; up, lo = m + k * sd, m - k * sd
        r["mid"][i], r["up"][i], r["lo"][i] = m, up, lo; r["pctb"][i] = (c[i] - lo) / (up - lo) if up > lo else 0.5; r["bw"][i] = (up - lo) / m if m else 0.0
    return r

def _hh(v, n, i): return max(v[i - n + 1:i + 1])
def _ll(v, n, i): return min(v[i - n + 1:i + 1])

def stoch_s(h, l, c, k=14, d=3, smooth=3):
    """(%K lent, %D) de l'oscillateur stochastique."""
    raw = [None] * len(c)
    for i in range(k - 1, len(c)): hh, ll = _hh(h, k, i), _ll(l, k, i); raw[i] = 50.0 if hh == ll else (c[i] - ll) / (hh - ll) * 100
    ks = _sma_on(raw, smooth); return ks, _sma_on(ks, d)

def cci_s(h, l, c, n=20):
    """Commodity Channel Index."""
    tp = [(a + b + x) / 3 for a, b, x in zip(h, l, c)]; out = [None] * len(c)
    for i in range(n - 1, len(c)):
        w = tp[i - n + 1:i + 1]; m = sum(w) / n; md = sum(abs(x - m) for x in w) / n; out[i] = 0.0 if md == 0 else (tp[i] - m) / (0.015 * md)
    return out

def willr_s(h, l, c, n=14):
    """%R de Williams (de -100 à 0)."""
    out = [None] * len(c)
    for i in range(n - 1, len(c)): hh, ll = _hh(h, n, i), _ll(l, n, i); out[i] = -50.0 if hh == ll else -100 * (hh - c[i]) / (hh - ll)
    return out

def mfi_s(h, l, c, v, n=14):
    """Money Flow Index (RSI pondéré par les volumes)."""
    tp = [(a + b + x) / 3 for a, b, x in zip(h, l, c)]; out = [None] * len(c)
    for i in range(n, len(c)):
        pos = sum(tp[j] * v[j] for j in range(i - n + 1, i + 1) if tp[j] > tp[j - 1]); neg = sum(tp[j] * v[j] for j in range(i - n + 1, i + 1) if tp[j] < tp[j - 1])
        out[i] = 50.0 if pos == 0 and neg == 0 else 100.0 if neg == 0 else 100 - 100 / (1 + pos / neg)
    return out

def obv_s(c, v):
    """On-Balance Volume cumulé."""
    out, t = [0.0] * len(c), 0.0
    for i in range(1, len(c)): t += v[i] if c[i] > c[i - 1] else -v[i] if c[i] < c[i - 1] else 0.0; out[i] = t
    return out

def cmf_s(h, l, c, v, n=20):
    """Chaikin Money Flow (de -1 à 1)."""
    out = [None] * len(c); mfv = [0.0 if h[i] == l[i] else ((c[i] - l[i]) - (h[i] - c[i])) / (h[i] - l[i]) * v[i] for i in range(len(c))]
    for i in range(n - 1, len(c)): tv = sum(v[i - n + 1:i + 1]); out[i] = sum(mfv[i - n + 1:i + 1]) / tv if tv > 0 else 0.0
    return out

def roc_s(c, n):
    """Taux de variation sur n barres."""
    return [None if i < n or c[i - n] <= 0 else c[i] / c[i - n] - 1 for i in range(len(c))]

def zscore_s(c, n=20):
    """Écart du cours à sa moyenne mobile, en écarts-types (population)."""
    out = [None] * len(c)
    for i in range(n - 1, len(c)):
        w = c[i - n + 1:i + 1]; m = sum(w) / n; sd = (sum((x - m) ** 2 for x in w) / n) ** .5; out[i] = 0.0 if sd == 0 else (c[i] - m) / sd
    return out

def donchian_s(h, l, n):
    """(plus haut, plus bas) des n barres PRÉCÉDENTES (la barre courante est exclue)."""
    hi, lo = [None] * len(h), [None] * len(h)
    for i in range(n, len(h)): hi[i], lo[i] = max(h[i - n:i]), min(l[i - n:i])
    return hi, lo

def extreme_s(v, n, fn=max):
    """Plus haut (max) ou plus bas (min) des n dernières valeurs, barre courante incluse."""
    return [None if i < n - 1 else fn(v[i - n + 1:i + 1]) for i in range(len(v))]

def supertrend_s(h, l, c, n=10, mult=3.0):
    """(ligne Supertrend, direction +1 haussière / -1 baissière)."""
    a = I.atr_series(h, l, c, n); line, dirn, fu, fl, d = [None] * len(c), [None] * len(c), None, None, 1
    for i in range(len(c)):
        if a[i] is None: continue
        mid = (h[i] + l[i]) / 2; bu, bl = mid + mult * a[i], mid - mult * a[i]
        if fu is None: fu, fl, d = bu, bl, (1 if c[i] >= bl else -1)
        else:
            fu = bu if (bu < fu or c[i - 1] > fu) else fu; fl = bl if (bl > fl or c[i - 1] < fl) else fl
            if d == 1 and c[i] < fl: d = -1
            elif d == -1 and c[i] > fu: d = 1
        line[i], dirn[i] = (fl if d == 1 else fu), d
    return line, dirn

def aroon_s(h, l, n=25):
    """(Aroon haut, Aroon bas) de 0 à 100."""
    up, dn = [None] * len(h), [None] * len(h)
    for i in range(n, len(h)):
        wh, wl = h[i - n:i + 1], l[i - n:i + 1]; ih = max(k for k, x in enumerate(wh) if x == max(wh)); il = max(k for k, x in enumerate(wl) if x == min(wl))
        up[i], dn[i] = ih / n * 100, il / n * 100
    return up, dn

def ichimoku_s(h, l, t=9, k=26, b=52):
    """Ichimoku : tenkan, kijun, span A et span B (décalées de k barres vers l'avenir : valeur à t calculée avec les données de t-k)."""
    N = len(h); mid = lambda n: [None if i < n - 1 else (_hh(h, n, i) + _ll(l, n, i)) / 2 for i in range(N)]
    tk, kj, sb0 = mid(t), mid(k), mid(b); sa = [None if i < k or tk[i - k] is None or kj[i - k] is None else (tk[i - k] + kj[i - k]) / 2 for i in range(N)]
    return {"tenkan": tk, "kijun": kj, "span_a": sa, "span_b": [None if i < k else sb0[i - k] for i in range(N)]}

def keltner_s(h, l, c, n=20, atr_n=10, mult=2.0):
    """Canal de Keltner : (milieu EMA, haut, bas) avec ATR."""
    m, a = ema_s(c, n), I.atr_series(h, l, c, atr_n); return m, [None if x is None or y is None else x + mult * y for x, y in zip(m, a)], [None if x is None or y is None else x - mult * y for x, y in zip(m, a)]

def ibs_s(h, l, c):
    """Internal Bar Strength : position de la clôture dans l'amplitude du jour (0 = bas, 1 = haut)."""
    return [0.5 if h[i] == l[i] else (c[i] - l[i]) / (h[i] - l[i]) for i in range(len(c))]

def narrow_range_s(h, l, n=7):
    """Vrai quand l'amplitude du jour est la plus étroite des n dernières séances."""
    r = [a - b for a, b in zip(h, l)]; return [None if i < n - 1 else r[i] <= min(r[i - n + 1:i + 1]) for i in range(len(r))]

def vwap_s(h, l, c, v, n=20):
    """Prix moyen pondéré par les volumes sur n barres glissantes."""
    out = [None] * len(c)
    for i in range(n - 1, len(c)):
        tv = sum(v[i - n + 1:i + 1]); out[i] = sum((h[j] + l[j] + c[j]) / 3 * v[j] for j in range(i - n + 1, i + 1)) / tv if tv > 0 else None
    return out

def relvol_s(v, n=20):
    """Volume rapporté à la moyenne des n séances précédentes."""
    out = [None] * len(v)
    for i in range(n, len(v)): m = sum(v[i - n:i]) / n; out[i] = v[i] / m if m > 0 else None
    return out

def vol_s(c, n=20):
    """Écart-type des rendements simples sur n séances."""
    r = [None] + [c[i] / c[i - 1] - 1 for i in range(1, len(c))]; out = [None] * len(c)
    for i in range(n, len(c)): w = r[i - n + 1:i + 1]; m = sum(w) / n; out[i] = (sum((x - m) ** 2 for x in w) / (n - 1)) ** .5
    return out

def percentile_rank_s(series, window=126):
    """Rang percentile (0 à 1) de chaque valeur dans ses `window` dernières valeurs (None s'il y en a moins de 30)."""
    out = [None] * len(series)
    for i, x in enumerate(series):
        if x is None: continue
        w = [y for y in series[max(0, i - window + 1):i + 1] if y is not None]
        if len(w) >= 30: out[i] = (sum(y < x for y in w) + 0.5 * sum(y == x for y in w)) / len(w)
    return out

class Features:
    """Vue d'un historique de barres : séries calculées à la demande, lues au curseur (at=0 : barre courante, at=1 : précédente...)."""
    def __init__(self, bars, bench=None):
        self.bars, self.bench, self.cursor, self._c = bars, bench, len(bars) - 1, {}
        self.o, self.h, self.l, self.c, self.vol = ([getattr(b, k) for b in bars] for k in ("o", "h", "l", "c", "v"))

    def at(self, t):
        """Place le curseur sur la barre d'indice t."""
        self.cursor = t; return self

    n = property(lambda s: s.cursor + 1)
    close = property(lambda s: s.c[s.cursor]); open = property(lambda s: s.o[s.cursor]); high = property(lambda s: s.h[s.cursor]); low = property(lambda s: s.l[s.cursor]); volume = property(lambda s: s.vol[s.cursor])

    def _g(self, key, fn):
        if key not in self._c: self._c[key] = fn()
        return self._c[key]

    def _series(self, name, a):
        h, l, c, v = self.h, self.l, self.c, self.vol
        g = lambda key, fn: self._g((key,) + a, fn)
        if name in ("close", "open", "high", "low", "volume"): return {"close": c, "open": self.o, "high": h, "low": l, "volume": v}[name]
        if name == "sma": return g("sma", lambda: sma_s(c, *a))
        if name == "ema": return g("ema", lambda: ema_s(c, *a))
        if name == "rsi": return g("rsi", lambda: rsi_s(c, *a))
        if name == "atr": return g("atr", lambda: I.atr_series(h, l, c, *a))
        if name in ("adx", "pdi", "mdi"): return g("adx", lambda: adx_s(h, l, c, *a))[("adx", "pdi", "mdi").index(name)]
        if name in ("macd", "macd_signal", "macd_hist"): return g("macd", lambda: macd_s(c, *a))[("macd", "macd_signal", "macd_hist").index(name)]
        if name.startswith("bb_"): return g("bb", lambda: bollinger_s(c, *a))[name[3:]]
        if name in ("stoch_k", "stoch_d"): return g("stoch", lambda: stoch_s(h, l, c, *a))[name == "stoch_d"]
        if name == "cci": return g("cci", lambda: cci_s(h, l, c, *a))
        if name == "willr": return g("willr", lambda: willr_s(h, l, c, *a))
        if name == "mfi": return g("mfi", lambda: mfi_s(h, l, c, v, *a))
        if name == "obv": return g("obv", lambda: obv_s(c, v))
        if name == "obv_sma": return g("obv_sma", lambda: sma_s(obv_s(c, v), *a))
        if name == "cmf": return g("cmf", lambda: cmf_s(h, l, c, v, *a))
        if name == "roc": return g("roc", lambda: roc_s(c, *a))
        if name == "z": return g("z", lambda: zscore_s(c, *a))
        if name in ("don_hi", "don_lo"): return g("don", lambda: donchian_s(h, l, *a))[name == "don_lo"]
        if name == "hh": return g("hh", lambda: extreme_s(h, *a, max))
        if name == "ll": return g("ll", lambda: extreme_s(l, *a, min))
        if name == "close_hi": return g("close_hi", lambda: extreme_s(c, *a, max))
        if name == "close_lo": return g("close_lo", lambda: extreme_s(c, *a, min))
        if name in ("st_line", "st_dir"): return g("st", lambda: supertrend_s(h, l, c, *a))[name == "st_dir"]
        if name in ("aroon_up", "aroon_down"): return g("aroon", lambda: aroon_s(h, l, *a))[name == "aroon_down"]
        if name in ("tenkan", "kijun", "span_a", "span_b"): return g("ichi", lambda: ichimoku_s(h, l, *a))[name]
        if name in ("kc_mid", "kc_up", "kc_lo"): return g("kc", lambda: keltner_s(h, l, c, *a))[("kc_mid", "kc_up", "kc_lo").index(name)]
        if name == "ibs": return g("ibs", lambda: ibs_s(h, l, c))
        if name == "nr": return g("nr", lambda: narrow_range_s(h, l, *a))
        if name == "vwap": return g("vwap", lambda: vwap_s(h, l, c, v, *a))
        if name == "relvol": return g("relvol", lambda: relvol_s(v, *a))
        if name == "vol": return g("vol", lambda: vol_s(c, *a))
        if name == "tr": return g("tr", lambda: I.true_range(h, l, c))
        if name == "gap": return g("gap", lambda: [None] + [self.o[i] / c[i - 1] - 1 for i in range(1, len(c))])
        if name == "bw_pct": return g("bw_pct", lambda: percentile_rank_s(bollinger_s(c, 20, 2.0)["bw"], *a))
        if name in ("rs", "rs_sma", "rs_roc"):
            from research_v1.quant.alignment import align_daily_sessions
            def aligned_rs():
                if not self.bench:
                    self._c[("benchmark_alignment",)] = None
                    return [None] * len(self.bars)
                alignment = align_daily_sessions(self.bars, self.bench)
                self._c[("benchmark_alignment",)] = alignment
                return [
                    c[i] / benchmark_close
                    if benchmark_close is not None else None
                    for i, benchmark_close in enumerate(alignment["benchmark_closes_by_asset_bar"])
                ]
            rs = self._g(("rs",), aligned_rs)
            if name == "rs": return rs
            if name == "rs_sma": return g("rs_sma", lambda: _sma_on(rs, *a))
            return g("rs_roc", lambda: [None if i < a[0] or rs[i] is None or rs[i - a[0]] is None else rs[i] / rs[i - a[0]] - 1 for i in range(len(rs))])
        raise KeyError(f"Série inconnue : {name}")

    def v(self, name, *args, at=0):
        """Valeur de la série `name(*args)` à `at` barres avant le curseur ; None si indéfinie."""
        s = self._series(name, args); i = self.cursor - at
        return s[i] if 0 <= i < len(s) else None

    def benchmark_alignment(self):
        """Diagnostic d'alignement actif/benchmark, calculé à la demande."""
        if self.bench:
            self._series("rs", ())
        return self._c.get(("benchmark_alignment",))

    def patterns(self, at=0):
        """Figures de chandeliers se terminant à `at` barres avant le curseur (voir backend.quant.candles)."""
        from research_v1.quant import candles
        i = self.cursor - at; return self._g(("patterns", i), lambda: candles.detect(self.bars, i))

    def levels(self):
        """Niveaux de support et de résistance connus à la barre courante (voir backend.quant.levels)."""
        from research_v1.quant import levels
        sw = self._g(("swings",), lambda: levels.swings(self.h, self.l)); atr = self.v("atr", 14)
        return self._g(("levels", self.cursor), lambda: levels.levels_at(sw, self.cursor, self.close, atr) if atr else [])
