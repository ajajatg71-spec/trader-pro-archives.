"""Contrôle qualité/provenance des signaux quantitatifs.

Ce module est réservé à la recherche et à l'observabilité. Il n'altère pas les
valeurs des signaux, ne calcule pas de décision d'achat/vente et n'est pas
connecté au pipeline d'exécution.
"""
from __future__ import annotations

from datetime import datetime, timezone
import math
from typing import Any, Iterable, Mapping


def _parse_timestamp(value: Any, field: str) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} manquant ou invalide")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field} doit être un horodatage ISO 8601") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(f"{field} doit inclure un fuseau horaire")
    return parsed.astimezone(timezone.utc)


def assess(
    signals: Iterable[Mapping[str, Any] | Any],
    *,
    assessed_at: str,
    max_age_seconds: int = 86_400,
) -> dict[str, Any]:
    """Évalue la qualité des métadonnées des signaux, sans les modifier.

    `assessed_at` est fourni par l'appelant pour rendre le résultat déterministe.
    Un signal est rejeté pour la recherche s'il manque des métadonnées essentielles,
    si ses horodatages sont incohérents/futurs ou si sa valeur n'est pas finie.
    Un signal ancien est marqué stale et dégrade le rapport, sans être supprimé.
    """
    now = _parse_timestamp(assessed_at, "assessed_at")
    if type(max_age_seconds) is not int or max_age_seconds < 0:
        raise ValueError("max_age_seconds doit être un entier positif ou nul")

    rows: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for index, item in enumerate(signals):
        if hasattr(item, "to_dict"):
            item = item.to_dict()
        elif not isinstance(item, Mapping):
            rows.append({
                "index": index, "name": None, "status": "rejected",
                "issues": ["signal doit être un objet ou un mapping"],
            })
            continue

        name = str(item.get("name") or "").strip()
        symbol = str(item.get("symbol") or "").strip().upper()
        issues: list[str] = []
        warnings: list[str] = []

        if not name:
            issues.append("nom du signal manquant")
        if not symbol:
            issues.append("symbole manquant")
        if not str(item.get("source") or "").strip():
            issues.append("source manquante")
        if not isinstance(item.get("inputs"), Mapping) or not item.get("inputs"):
            issues.append("données sources manquantes")
        if not isinstance(item.get("rationale"), str) or not item.get("rationale", "").strip():
            issues.append("justification manquante")

        value = item.get("value")
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            issues.append("valeur non numérique ou non finie")
        elif abs(float(value)) > 1.0 + 1e-9:
            issues.append("valeur hors de l'intervalle [-1, 1]")

        parsed_data = parsed_calc = None
        try:
            parsed_data = _parse_timestamp(item.get("as_of"), "as_of")
        except ValueError as exc:
            issues.append(str(exc))
        try:
            parsed_calc = _parse_timestamp(item.get("computed_at"), "computed_at")
        except ValueError as exc:
            issues.append(str(exc))

        if parsed_data and parsed_calc:
            if parsed_data > parsed_calc:
                issues.append("donnée datée après le calcul du signal")
            if parsed_calc > now:
                issues.append("calcul daté dans le futur")
            age = (now - parsed_data).total_seconds()
            if age < 0:
                issues.append("donnée datée dans le futur")
            elif age > max_age_seconds:
                warnings.append("donnée ancienne au regard du seuil de fraîcheur")
        else:
            age = None

        key = (symbol, name.lower())
        if symbol and name and key in seen:
            warnings.append("signal dupliqué pour ce symbole et ce nom")
        if symbol and name:
            seen.add(key)

        status = "rejected" if issues else "degraded" if warnings else "valid"
        rows.append({
            "index": index,
            "symbol": symbol or None,
            "name": name or None,
            "status": status,
            "age_seconds": round(age, 3) if age is not None else None,
            "issues": issues,
            "warnings": warnings,
        })

    counts = {state: sum(row["status"] == state for row in rows)
              for state in ("valid", "degraded", "rejected")}
    overall = (
        "rejected" if counts["rejected"]
        else "degraded" if counts["degraded"]
        else "valid"
    )
    return {
        "status": overall,
        "research_only": True,
        "execution_authorized": False,
        "assessed_at": now.isoformat(),
        "max_age_seconds": max_age_seconds,
        "counts": counts,
        "signals": rows,
    }
