"""Détection du régime de marché : tendance (moyennes 50/200 jours), force de la tendance (ADX) et état de volatilité (percentile)."""
import math
from research_v1.quant import indicators as I

def vol_percentile(closes, window=20, lookback=252):
    """Position (0 à 1) de la volatilité réalisée récente dans sa distribution sur lookback fenêtres ; None si historique insuffisant."""
    if len(closes) < window + 60: return None
    r = [math.log(closes[i] / closes[i - 1]) for i in range(1, len(closes))]; vols = []
    for end in range(window, len(r) + 1):
        w = r[end - window:end]; m = sum(w) / window; vols.append(math.sqrt(sum((x - m) ** 2 for x in w) / (window - 1)))
    vols = vols[-lookback:]; last = vols[-1]
    return (sum(v < last for v in vols) + 0.5 * sum(v == last for v in vols)) / len(vols)

def detect_regime(closes, highs=None, lows=None):
    """Régime courant : tendance (haussier, baissier, transition), force (ADX), volatilité (calme, normal, volatil), étiquette, preuves et justification. None si moins de 200 clôtures."""
    if len(closes) < 200: return None
    c, s50, s200 = closes[-1], I.sma(closes, 50), I.sma(closes, 200)
    prev200 = sum(closes[-220:-20]) / 200 if len(closes) >= 220 else None; slope = s200 / prev200 - 1 if prev200 else None
    trend = "haussier" if c > s200 and s50 > s200 else "baissier" if c < s200 and s50 < s200 else "transition"
    a = I.adx(highs, lows, closes) if highs and lows else None; adx_v = a[0] if a else None
    strength = None if adx_v is None else "fort" if adx_v >= 25 else "modéré" if adx_v >= 20 else "faible"
    vp = vol_percentile(closes); vol_state = "normal" if vp is None else "volatil" if vp >= 0.67 else "calme" if vp <= 0.33 else "normal"
    label = "latéral" if strength == "faible" and trend == "transition" else f"{trend} {vol_state}"
    evidence = {"close": c, "sma50": s50, "sma200": s200, "sma200_slope": slope, "adx": adx_v, "vol_percentile": vp}
    why = (f"Cours {c:.2f} {'au-dessus' if c > s200 else 'sous'} la moyenne 200 j ({s200:.2f}), moyenne 50 j {'au-dessus' if s50 > s200 else 'sous'} la 200 j ; "
           f"tendance {strength or 'non mesurée'} (ADX {adx_v:.1f}) ; " if adx_v is not None else f"Cours {c:.2f} vs moyenne 200 j ({s200:.2f}) ; ")
    why += f"volatilité {vol_state}" + (f" (percentile {vp * 100:.0f} %)" if vp is not None else "")
    return {"trend": trend, "strength": strength, "vol_state": vol_state, "label": label, "evidence": evidence, "rationale": why}
