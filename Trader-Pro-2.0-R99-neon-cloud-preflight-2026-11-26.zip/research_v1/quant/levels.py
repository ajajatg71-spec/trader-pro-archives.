"""Supports et résistances : pivots (points hauts et bas locaux), regroupement en niveaux, proximité. Un pivot en i n'est connu qu'à partir de i + right (pas de regard dans le futur)."""

def swings(highs, lows, left=3, right=3):
    """Pivots (indice, prix, 'high' ou 'low') : un plus haut strictement supérieur aux `left` barres précédentes et au moins égal aux `right` suivantes (symétrique pour les bas)."""
    out = []
    for i in range(left, len(highs) - right):
        if highs[i] > max(highs[i - left:i]) and highs[i] >= max(highs[i + 1:i + right + 1]): out.append((i, highs[i], "high"))
        if lows[i] < min(lows[i - left:i]) and lows[i] <= min(lows[i + 1:i + right + 1]): out.append((i, lows[i], "low"))
    return out

def cluster(pivots, tol):
    """Regroupe les pivots dont les prix sont à moins de tol de la moyenne du groupe : niveaux {price, touches, first_index, last_index}."""
    out = []
    for p in sorted(pivots, key=lambda p: p[1]):
        if out and abs(p[1] - sum(x[1] for x in out[-1]) / len(out[-1])) <= tol: out[-1].append(p)
        else: out.append([p])
    return [{"price": sum(x[1] for x in g) / len(g), "touches": len(g), "first_index": min(x[0] for x in g), "last_index": max(x[0] for x in g)} for g in out]

def levels_at(pivots, t, price, atr, right=3, lookback=120, tol_atr=0.5):
    """Niveaux connus à la barre t : pivots confirmés (≤ t-right) sur `lookback` barres, regroupés à ±tol_atr x ATR, triés par distance au cours.
    Chaque niveau reçoit son type (support sous le cours, résistance au-dessus), sa distance en ATR et une force (touches pondérées par la récence)."""
    known = [p for p in pivots if t - lookback <= p[0] <= t - right]; out = []
    for lv in cluster(known, tol_atr * atr):
        age = (t - lv["last_index"]) / lookback; lv.update(kind="support" if lv["price"] <= price else "resistance", distance_atr=abs(price - lv["price"]) / atr, strength=round(lv["touches"] * (1.0 - 0.5 * age), 3)); out.append(lv)
    return sorted(out, key=lambda lv: lv["distance_atr"])

def nearest(levels):
    """(support le plus proche, résistance la plus proche) parmi les niveaux, ou None."""
    s = [x for x in levels if x["kind"] == "support"]; r = [x for x in levels if x["kind"] == "resistance"]; return (s[0] if s else None, r[0] if r else None)

def touching(levels, low, high, atr, tol_atr=0.5, kind=None):
    """Niveaux (du type demandé) touchés par la fourchette [low, high] à ±tol_atr x ATR."""
    return [x for x in levels if (kind is None or x["kind"] == kind) and low - tol_atr * atr <= x["price"] <= high + tol_atr * atr]
