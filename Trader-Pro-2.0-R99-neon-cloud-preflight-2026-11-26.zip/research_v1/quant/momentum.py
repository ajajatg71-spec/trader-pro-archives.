"""Momentum et force relative (fonctions pures sur des listes de clôtures du plus ancien au plus récent)."""
import math

def momentum(closes, n):
    """Rendement sur n barres (taux de variation) ; None si historique insuffisant."""
    return closes[-1] / closes[-1 - n] - 1 if len(closes) > n and closes[-1 - n] > 0 else None

def momentum_12_1(closes, lookback=252, skip=21):
    """Momentum « 12-1 » : rendement de il y a 12 mois à il y a 1 mois (le dernier mois est exclu pour éviter le retour à court terme) ; None si historique insuffisant."""
    if len(closes) <= lookback or closes[-1 - lookback] <= 0: return None
    return closes[-1 - skip] / closes[-1 - lookback] - 1

def risk_adjusted_momentum(closes, n=126):
    """Rendement sur n barres divisé par la volatilité annualisée sur la même fenêtre ; None si insuffisant ou volatilité nulle."""
    m = momentum(closes, n)
    if m is None: return None
    r = [math.log(closes[i] / closes[i - 1]) for i in range(len(closes) - n, len(closes))]; mu = sum(r) / len(r)
    vol = math.sqrt(sum((x - mu) ** 2 for x in r) / (len(r) - 1)) * math.sqrt(252)
    return m / vol if vol > 1e-9 else None

def rs_line(closes, bench):
    """Ligne de force relative : cours de l'actif / cours de l'indice, sur la période commune (alignée sur la fin)."""
    n = min(len(closes), len(bench)); return [c / b for c, b in zip(closes[-n:], bench[-n:])]

def relative_strength(closes, bench, n=63):
    """Surperformance relative sur n barres : (1 + rendement actif) / (1 + rendement indice) - 1 ; None si insuffisant."""
    a, b = momentum(closes, n), momentum(bench, n)
    return None if a is None or b is None else (1 + a) / (1 + b) - 1

def rs_rank(scores):
    """Rang percentile (0 à 100) de chaque score dans l'univers ; les valeurs None restent None."""
    vals = [v for v in scores.values() if v is not None]; n = len(vals)
    return {k: (None if v is None else round((sum(x < v for x in vals) + 0.5 * sum(x == v for x in vals)) / n * 100, 2)) for k, v in scores.items()}
