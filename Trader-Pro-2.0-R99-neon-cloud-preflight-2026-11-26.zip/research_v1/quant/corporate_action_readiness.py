"""Fail-closed readiness assessment for quantitative use of corporate actions."""
_REQUIRED = {
    "source_batch_complete": "pagination/source batch completeness not established",
    "raw_price_basis_verified": "raw price basis not independently verified",
    "cross_source_reconciliation": "independent source reconciliation not passed",
    "provider_history_verified": "provider event history/exhaustiveness not verified",
    "event_revision_ledger_persisted": "revision ledger not persisted durably",
    "currency_and_calendar_verified": "currency and exchange calendar not verified",
    "postgresql_validation_passed": "PostgreSQL/Neon integration validation not passed",
}

def assess_corporate_action_readiness(evidence: dict) -> dict:
    """Return blockers, never infer readiness from absent evidence."""
    if not isinstance(evidence, dict):
        raise ValueError("evidence doit être un dictionnaire")
    blockers=[]
    for key, message in _REQUIRED.items():
        value=evidence.get(key)
        if not isinstance(value,bool): blockers.append(f"{key}: evidence missing or invalid")
        elif not value: blockers.append(f"{key}: {message}")
    return {"ready": not blockers, "status": "READY" if not blockers else "BLOCKED",
            "blockers": blockers, "live_authorized": False, "orders_created": 0}


def assess_corporate_action_readiness_with_repository(evidence: dict, repository) -> dict:
    """Override claimed persistence evidence with an inspected durable DB proof."""
    if not isinstance(evidence, dict):
        raise ValueError("evidence doit être un dictionnaire")
    if not callable(getattr(repository, "storage_readiness", None)):
        raise ValueError("repository de registre invalide")
    storage = repository.storage_readiness()
    if not isinstance(storage, dict) or not isinstance(storage.get("ready"), bool):
        storage = {"ready": False, "issues": ["preuve de stockage invalide"]}
    verified = dict(evidence)
    verified["event_revision_ledger_persisted"] = storage["ready"]
    result = assess_corporate_action_readiness(verified)
    result["corporate_action_storage"] = storage
    return result
