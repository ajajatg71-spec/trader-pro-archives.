"""Validated point-in-time corporate-action event contracts.

This module records provider-sourced events; it does not infer, fabricate, or
silently apply corporate actions to price histories.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
import re

_CURRENCY = re.compile(r"^[A-Z]{3}$")
_SYMBOL = re.compile(r"^[A-Z][A-Z0-9.\-]{0,14}$")


class CorporateActionError(ValueError):
    """Invalid or unusable corporate-action event."""


def _decimal(value, label: str) -> Decimal:
    try:
        number = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise CorporateActionError(f"{label} invalide") from None
    if not number.is_finite():
        raise CorporateActionError(f"{label} invalide")
    return number


@dataclass(frozen=True)
class CorporateActionEvent:
    """One sourced corporate action, with an explicit point-in-time availability.

    split_ratio is new shares per old share (e.g. 2 for a 2:1 split).
    cash_amount is cash per share in currency on the ex-date.
    Exactly one payload is required according to action_type.
    """
    symbol: str
    action_type: str
    ex_date: date
    available_at: datetime
    source: str
    split_ratio: Decimal | str | int | float | None = None
    cash_amount: Decimal | str | int | float | None = None
    currency: str | None = None
    event_id: str | None = None

    def __post_init__(self):
        if not isinstance(self.symbol, str) or not _SYMBOL.fullmatch(self.symbol):
            raise CorporateActionError("Symbole d'opération sur titre invalide")
        if self.symbol != self.symbol.upper():
            raise CorporateActionError("Le symbole doit être normalisé en majuscules")
        if self.action_type not in {"split", "dividend"}:
            raise CorporateActionError("Type d'opération sur titre non pris en charge")
        if isinstance(self.ex_date, datetime) or not isinstance(self.ex_date, date):
            raise CorporateActionError("Date ex-date invalide")
        if (not isinstance(self.available_at, datetime) or self.available_at.tzinfo is None
                or self.available_at.utcoffset() is None):
            raise CorporateActionError("available_at doit être horodaté avec fuseau")
        if not isinstance(self.source, str) or not self.source.strip():
            raise CorporateActionError("Source de l'événement obligatoire")
        if self.event_id is not None and (not isinstance(self.event_id, str) or not self.event_id.strip()):
            raise CorporateActionError("Identifiant d'événement invalide")
        if self.action_type == "split":
            ratio = _decimal(self.split_ratio, "Ratio de split")
            if ratio <= 0 or self.cash_amount is not None or self.currency is not None:
                raise CorporateActionError("Payload de split invalide")
            object.__setattr__(self, "split_ratio", ratio)
        else:
            amount = _decimal(self.cash_amount, "Montant du dividende")
            if amount < 0 or self.split_ratio is not None:
                raise CorporateActionError("Payload de dividende invalide")
            if not isinstance(self.currency, str) or not _CURRENCY.fullmatch(self.currency):
                raise CorporateActionError("Devise du dividende invalide")
            object.__setattr__(self, "cash_amount", amount)


def validate_corporate_action_batch(events) -> tuple[CorporateActionEvent, ...]:
    """Validate a provider batch and reject duplicate event identities/economics.

    Provider IDs are scoped by source. If IDs are absent, an identical action
    from the same source is treated as an ambiguous duplicate and rejected;
    distinct same-date cash events remain possible when they have distinct IDs.
    """
    if isinstance(events, (str, bytes)):
        raise CorporateActionError("Collection d'événements invalide")
    try:
        items = tuple(events)
    except TypeError:
        raise CorporateActionError("Collection d'événements invalide") from None
    if any(not isinstance(item, CorporateActionEvent) for item in items):
        raise CorporateActionError("Événement non validé dans la collection")
    identities = set()
    anonymous_economics = set()
    for item in items:
        if item.event_id is not None:
            identity = (item.source.strip(), item.event_id.strip())
            if identity in identities:
                raise CorporateActionError("Identifiant d'événement fournisseur dupliqué")
            identities.add(identity)
        else:
            payload = (str(item.split_ratio) if item.action_type == "split" else
                       (str(item.cash_amount), item.currency))
            fingerprint = (item.source.strip(), item.symbol, item.action_type,
                           item.ex_date.isoformat(), payload)
            if fingerprint in anonymous_economics:
                raise CorporateActionError("Événement économique dupliqué sans identifiant fournisseur")
            anonymous_economics.add(fingerprint)
    return items




@dataclass(frozen=True)
class CorporateActionBatch:
    """Auditable query envelope; completeness is explicit, never inferred."""
    events: tuple[CorporateActionEvent, ...]
    requested_symbols: tuple[str, ...]
    start_date: date
    end_date: date
    retrieved_at: datetime
    pages_fetched: int
    pagination_complete: bool
    source: str

    def __post_init__(self):
        if not isinstance(self.start_date, date) or isinstance(self.start_date, datetime):
            raise CorporateActionError("Date de début du lot invalide")
        if not isinstance(self.end_date, date) or isinstance(self.end_date, datetime) or self.end_date < self.start_date:
            raise CorporateActionError("Période du lot invalide")
        if not isinstance(self.retrieved_at, datetime) or self.retrieved_at.tzinfo is None or self.retrieved_at.utcoffset() is None:
            raise CorporateActionError("retrieved_at doit être horodaté avec fuseau")
        if not isinstance(self.pages_fetched, int) or isinstance(self.pages_fetched, bool) or self.pages_fetched < 1:
            raise CorporateActionError("Nombre de pages du lot invalide")
        if not isinstance(self.pagination_complete, bool) or not self.pagination_complete:
            raise CorporateActionError("Lot incomplet : pagination non terminée")
        if not isinstance(self.source, str) or not self.source.strip():
            raise CorporateActionError("Source du lot obligatoire")
        if not isinstance(self.requested_symbols, (tuple, list)) or not self.requested_symbols:
            raise CorporateActionError("Univers demandé vide")
        symbols = tuple(self.requested_symbols)
        if any(not isinstance(symbol, str) or not _SYMBOL.fullmatch(symbol) or symbol != symbol.upper() for symbol in symbols):
            raise CorporateActionError("Symbole demandé invalide")
        if len(set(symbols)) != len(symbols):
            raise CorporateActionError("Symboles demandés dupliqués")
        events = validate_corporate_action_batch(self.events)
        if any(event.source != self.source or event.symbol not in symbols for event in events):
            raise CorporateActionError("Événement hors source ou hors univers demandé")
        object.__setattr__(self, "requested_symbols", symbols)
        object.__setattr__(self, "events", events)


def point_in_time_events(events, *, as_of: datetime, symbol: str | None = None) -> tuple[CorporateActionEvent, ...]:
    """Return only events known by as_of and whose ex-date has occurred.

    Events announced later are excluded even if their ex-date is in the past;
    future ex-dates are also excluded. The function never backfills knowledge.
    """
    if not isinstance(as_of, datetime) or as_of.tzinfo is None or as_of.utcoffset() is None:
        raise CorporateActionError("as_of doit être horodaté avec fuseau")
    if symbol is not None and (not isinstance(symbol, str) or not _SYMBOL.fullmatch(symbol)):
        raise CorporateActionError("Filtre symbole invalide")
    items = validate_corporate_action_batch(events)
    selected = [item for item in items if item.available_at <= as_of
                and item.ex_date <= as_of.date()
                and (symbol is None or item.symbol == symbol)]
    return tuple(sorted(selected, key=lambda item: (item.ex_date, item.symbol, item.action_type, item.event_id or "")))


def split_adjusted_closes(closes, timestamps, events, *, as_of: datetime, price_basis: str = "unknown", session_timezone: str = "America/New_York") -> tuple[float, ...]:
    """Restate historical closes to the latest included share basis using sourced splits.

    The input is raw close history. For a split ratio of 2 (two new shares per
    old share), closes strictly before the ex-date are divided by 2. Events are
    applied only when known by as_of. No dividends or total-return adjustment
    are included.
    """
    from math import isfinite
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
    if price_basis != "raw":
        raise CorporateActionError("La base de prix doit être explicitement déclarée raw")
    if not isinstance(as_of, datetime) or as_of.tzinfo is None or as_of.utcoffset() is None:
        raise CorporateActionError("as_of doit être horodaté avec fuseau")
    try:
        tz = ZoneInfo(session_timezone)
    except (ZoneInfoNotFoundError, TypeError):
        raise CorporateActionError("Fuseau de séance invalide") from None
    try:
        prices, stamps = tuple(closes), tuple(timestamps)
    except TypeError:
        raise CorporateActionError("Séries de clôture invalides") from None
    if len(prices) < 2 or len(prices) != len(stamps):
        raise CorporateActionError("Séries de clôture et horodatages désalignés")
    normalized = []
    for value, stamp in zip(prices, stamps):
        try:
            price = float(value)
        except (TypeError, ValueError, OverflowError):
            raise CorporateActionError("Cours de clôture invalide") from None
        if not isfinite(price) or price <= 0:
            raise CorporateActionError("Cours de clôture invalide")
        if not isinstance(stamp, datetime) or stamp.tzinfo is None or stamp.utcoffset() is None:
            raise CorporateActionError("Horodatage de clôture sans fuseau")
        if normalized and stamp <= normalized[-1][0]:
            raise CorporateActionError("Horodatages non strictement croissants")
        normalized.append((stamp, price))
    selected = point_in_time_events(events, as_of=as_of)
    if any(event.action_type != "split" for event in selected):
        raise CorporateActionError("split_adjusted_closes accepte uniquement les splits")
    session_dates = [stamp.astimezone(tz).date() for stamp, _ in normalized]
    if len(set(session_dates)) != len(session_dates):
        raise CorporateActionError("Plusieurs clôtures détectées pour une même séance")
    factors = [1.0] * len(normalized)
    date_to_index = {day: i for i, day in enumerate(session_dates)}
    for event in selected:
        if session_dates[0] <= event.ex_date <= session_dates[-1] and event.ex_date not in date_to_index:
            raise CorporateActionError("Date ex-date absente de l'historique")
        if event.ex_date in date_to_index:
            first_post = date_to_index[event.ex_date]
            for i in range(first_post):
                factors[i] *= float(event.split_ratio)
    adjusted = tuple(price / factor for (_, price), factor in zip(normalized, factors))
    if any(not isfinite(value) or value <= 0 for value in adjusted):
        raise CorporateActionError("Cours ajusté invalide")
    return adjusted


def dividend_total_return_index(closes, timestamps, events, *, initial_value: float = 100.0, currency: str, price_basis: str = "unknown", session_timezone: str = "America/New_York") -> tuple[float, ...]:
    """Build a dividend-reinvested total-return index from raw closes and events.

    Split ratios are new shares per old share. Dividend cash is per share in
    the post-split share basis on the ex-date. Prices and dividend events must
    use the same explicit currency. An event must have been available by its
    ex-date bar timestamp; late corrections are rejected to prevent lookahead.
    This is an event-driven calculation, not a provider total-return series.
    """
    from math import isfinite
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
    if price_basis != "raw":
        raise CorporateActionError("La base de prix doit être explicitement déclarée raw")
    if not isinstance(currency, str) or not _CURRENCY.fullmatch(currency):
        raise CorporateActionError("Devise de calcul invalide")
    try:
        start = float(initial_value)
    except (TypeError, ValueError, OverflowError):
        raise CorporateActionError("Valeur initiale invalide") from None
    if not isfinite(start) or start <= 0:
        raise CorporateActionError("Valeur initiale invalide")
    try:
        tz = ZoneInfo(session_timezone)
    except (ZoneInfoNotFoundError, TypeError):
        raise CorporateActionError("Fuseau de séance invalide") from None
    try:
        prices, stamps = tuple(closes), tuple(timestamps)
    except TypeError:
        raise CorporateActionError("Séries de clôture invalides") from None
    if len(prices) < 2 or len(prices) != len(stamps):
        raise CorporateActionError("Séries de clôture et horodatages désalignés")
    normalized = []
    for value, stamp in zip(prices, stamps):
        try:
            price = float(value)
        except (TypeError, ValueError, OverflowError):
            raise CorporateActionError("Cours de clôture invalide") from None
        if not isfinite(price) or price <= 0:
            raise CorporateActionError("Cours de clôture invalide")
        if not isinstance(stamp, datetime) or stamp.tzinfo is None or stamp.utcoffset() is None:
            raise CorporateActionError("Horodatage de clôture sans fuseau")
        if normalized and stamp <= normalized[-1][0]:
            raise CorporateActionError("Horodatages non strictement croissants")
        normalized.append((stamp, price))
    session_dates = [stamp.astimezone(tz).date() for stamp, _ in normalized]
    if len(set(session_dates)) != len(session_dates):
        raise CorporateActionError("Plusieurs clôtures détectées pour une même séance")
    date_to_index = {day: i for i, day in enumerate(session_dates)}
    selected = point_in_time_events(events, as_of=normalized[-1][0])
    by_date = {}
    for event in selected:
        if event.ex_date < session_dates[0]:
            continue  # the series begins after this event; its price basis is already post-event
        if event.ex_date > session_dates[-1]:
            continue
        if event.ex_date not in date_to_index:
            raise CorporateActionError("Date ex-date absente de l'historique")
        bar_stamp = normalized[date_to_index[event.ex_date]][0]
        if event.available_at > bar_stamp:
            raise CorporateActionError("Événement publié après l'ex-date : risque de lookahead")
        if event.action_type == "dividend" and event.currency != currency:
            raise CorporateActionError("Devise du dividende différente de celle des cours")
        by_date.setdefault(event.ex_date, []).append(event)
    result = [start]
    for index in range(1, len(normalized)):
        stamp, close = normalized[index]
        prior_close = normalized[index - 1][1]
        split_factor = 1.0
        dividend_per_share = 0.0
        for event in by_date.get(session_dates[index], ()):
            if event.action_type == "split":
                split_factor *= float(event.split_ratio)
            elif event.action_type == "dividend":
                dividend_per_share += float(event.cash_amount)
        gross_return = split_factor * (close + dividend_per_share) / prior_close
        if not isfinite(gross_return) or gross_return <= 0:
            raise CorporateActionError("Facteur de rendement total invalide")
        result.append(result[-1] * gross_return)
    if any(not isfinite(value) or value <= 0 for value in result):
        raise CorporateActionError("Indice de rendement total invalide")
    return tuple(result)


@dataclass(frozen=True)
class CorporateActionReconciliation:
    matched: tuple[tuple[str, str, str], ...]
    primary_only: tuple[tuple[str, str, str], ...]
    secondary_only: tuple[tuple[str, str, str], ...]
    economic_conflicts: tuple[tuple[str, str, str], ...]

    @property
    def consistent(self) -> bool:
        return not self.primary_only and not self.secondary_only and not self.economic_conflicts

def reconcile_corporate_action_sources(primary, secondary) -> CorporateActionReconciliation:
    """Compare two independent event sets without merging or selecting a winner."""
    left=validate_corporate_action_batch(primary); right=validate_corporate_action_batch(secondary)
    def key(event): return (event.symbol,event.action_type,event.ex_date.isoformat())
    def economic(event):
        return (str(event.split_ratio) if event.action_type=="split" else (str(event.cash_amount),event.currency))
    left_map={}; right_map={}
    for event in left: left_map.setdefault(key(event),[]).append(economic(event))
    for event in right: right_map.setdefault(key(event),[]).append(economic(event))
    matched=[]; primary_only=[]; secondary_only=[]; conflicts=[]
    for item in sorted(set(left_map)|set(right_map)):
        a=sorted(left_map.get(item,[])); b=sorted(right_map.get(item,[]))
        if not a: secondary_only.append(item)
        elif not b: primary_only.append(item)
        elif a==b: matched.append(item)
        else: conflicts.append(item)
    return CorporateActionReconciliation(tuple(matched),tuple(primary_only),tuple(secondary_only),tuple(conflicts))
