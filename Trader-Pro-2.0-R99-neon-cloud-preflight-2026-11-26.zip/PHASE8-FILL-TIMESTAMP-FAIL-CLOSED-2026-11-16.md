# Phase 8 — Fill timestamp validation (2026-11-16)

## Finding
The reconciliation preflight validated fill IDs, order IDs, side, quantity, price and fees, but accepted a missing execution timestamp. Later in the run, the individual fill ingestion rejected that fill as invalid only after account/position snapshots and stale-submission recovery had already been committed. This allowed a partial/incomplete broker activity history to be treated as a completed reconciliation run.

## Change
- Require each remote fill to provide `time`, `transaction_time`, or `executed_at` during the preflight validation pass.
- Parse the timestamp before the first local write. Naive timestamps are interpreted as UTC, preserving the existing ingestion convention.
- Missing or malformed timestamps now abort reconciliation before account snapshots, position snapshots, fill records, order status changes, or stale-submission recovery.
- Updated the former per-fill warning test to assert fail-closed behavior and no database writes.
- Updated unmatched/incomplete-history fixtures to provide a valid timestamp so they continue testing their intended behavior.

## Validation
- Full pytest output: 594 passed, 11 skipped, 194 subtests passed (the command wrapper timed out after printing the completed summary; see focused verification below).
- `tests/test_reconciliation.py`: 41 passed, 3 subtests passed.
- `python -m compileall -q .`: passed.
- `alembic heads`: one head, `b8d2f4a6c901`.

## Limitations
No real PostgreSQL server or authenticated Alpaca Paper connection was available in this environment. SQLite/unit tests do not certify PostgreSQL concurrency or broker integration. No broker order was submitted, replaced, or cancelled; Live remains disabled.
