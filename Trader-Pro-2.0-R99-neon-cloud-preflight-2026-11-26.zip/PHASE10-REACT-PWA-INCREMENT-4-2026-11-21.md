# Phase 10 — incrément 4 : fiabilité de l’affichage financier

Date : 21 novembre 2026

## Modifications

- Les valeurs `null`, `undefined` et chaînes vides sont désormais affichées comme indisponibles (`—`) au lieu d’être converties silencieusement en zéro.
- Les montants sont affichés avec deux décimales afin de ne pas masquer les centimes du compte, des liquidités, des positions et des ordres.
- Une variation quotidienne exactement nulle reçoit un style neutre, et non un avertissement.
- Un P/L de position absent n’est plus présenté visuellement comme un gain.

## Périmètre et sécurité

- Aucun endpoint, calcul de trading, règle de risque, ordre, approbation ou mode de courtier n’a été modifié.
- L’interface reste en lecture seule.
- Live reste verrouillé.

## Vérification

- Vérification du diff et des références de formatage effectuée.
- Le build TypeScript/Vite ne peut pas être certifié dans cet environnement : les dépendances npm ne sont pas présentes et le registre npm n’est pas accessible (échec DNS déjà documenté dans `TRADER-PRO-2-RELEASE-STATUS.md`).
- Aucun test PostgreSQL réel, accès Neon ou accès Alpaca Paper n’est revendiqué par cet incrément.
