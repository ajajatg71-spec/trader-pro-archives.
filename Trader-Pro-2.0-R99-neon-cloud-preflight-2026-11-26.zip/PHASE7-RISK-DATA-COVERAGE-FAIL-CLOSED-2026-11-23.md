# Phase 7 — couverture et alignement exact des données de risque

Date : 23 novembre 2026

## Problème observé

Le calcul avancé pouvait auparavant utiliser un sous-ensemble silencieux des positions ou aligner les séries par simple position d'index. Cela pouvait sous-estimer le risque si un actif détenu avait un historique incomplet ou décalé.

## Correction

- Toute position détenue doit avoir au moins 31 clôtures.
- Le chemin principal utilise maintenant `validated_daily_bar_series()` qui préserve les timestamps du contrat Market Data.
- Les timestamps de chaque position sont convertis en UTC et comparés exactement à ceux de SPY.
- Une séance manquante, décalée, un historique non horodaté ou un nombre de clôtures insuffisant bloque les métriques.
- Le snapshot précédent est effacé pour éviter qu'une mesure périmée passe le contrôle pré-transaction.
- Le résumé de données indique la couverture et le statut de vérification des timestamps.
- L'ancien lecteur close-only est conservé en compatibilité, mais il ne certifie que l'égalité des longueurs et marque l'alignement comme non vérifiable.

## Tests

- Tests ciblés `test_risk_service`, `test_market_data_service` et `test_ohlcv_market_data` : 64 passed, 24 subtests passed.
- Suite complète : 715 passed, 11 skipped, 202 subtests passed.
- `python -m compileall -q .` : passed.
- `node --check frontend/public/sw.js` : passed.

Les tests utilisent des historiques déterministes. La validation sur données réelles multi-titres, PostgreSQL réel et Alpaca Paper reste à effectuer. Aucun ordre soumis. Live demeure verrouillé.


En mode SIM, le fournisseur synthétique peut ne pas avoir de timestamps boursiers. Le moteur conserve alors les calculs de simulation via le lecteur de clôtures, mais marque `timestamp_alignment=not_available_simulation_or_legacy`. En mode connecté, `validated_daily_bar_series()` exige les timestamps et l'égalité UTC exacte des séances.
