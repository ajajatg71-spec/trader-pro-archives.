# Trader Pro 2.0 — R84 : lecteur Alpaca Corporate Actions en lecture seule

Base : R83.

## Modifications
- Nouveau lecteur `AlpacaCorporateActionsReader` pour l'endpoint Market Data `GET /v1/corporate-actions`.
- Lecture des splits forward/reverse et dividendes cash, avec pagination par `next_page_token`.
- Vérification des identifiants, dates, symboles, ratios, montants et devises ; les types non pris en charge sont refusés.
- Aucun endpoint d'ordre n'est utilisé.
- Les réponses sont conservées comme enregistrements fournisseur bruts normalisés ; conversion en `CorporateActionEvent` exige un `available_at` fourni explicitement par l'appelant.

## Validation
- 5 tests ciblés avec réponses HTTP simulées ; aucun appel réseau ni identifiant réel requis.

## Limites
- La documentation Alpaca avertit que la disponibilité des corporate actions peut être retardée. Le timestamp de récupération n'est pas une date historique de déclaration ; le lecteur ne l'invente pas.
- Pas de session Alpaca authentifiée exécutée.
