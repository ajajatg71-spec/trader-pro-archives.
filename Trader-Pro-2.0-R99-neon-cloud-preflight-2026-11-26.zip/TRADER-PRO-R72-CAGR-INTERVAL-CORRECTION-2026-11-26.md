# Trader Pro 2.0 — R72 : correction de l'annualisation CAGR

Date : 2026-11-26  
Base : archive R71 (`Trader-Pro-2.0-R71-fundamental-asof-guard-2026-11-26.zip`)

## Constat

Deux calculateurs du moteur de recherche annualisaient le rendement avec le nombre d'observations de valeur du portefeuille (`n`) au lieu du nombre d'intervalles de rendement (`n - 1`). Une courbe de `n` valeurs ne contient que `n - 1` rendements close-to-close.

Les implémentations de référence déjà présentes dans `research_v1/backtesting/walk_forward.py` et `research_v1/backtesting/portfolio_scoreboard.py` utilisent le nombre de rendements. Le correctif harmonise les deux calculateurs restants.

## Modifications

- `research_v1/backtesting/backtest.py` : durée annualisée calculée avec `(n - 1) / bpy`.
- `research_v1/backtesting/portfolio_backtest.py` : durée annualisée calculée avec `len(daily_returns) / 252`.
- `tests/test_research_v1_cagr_intervals.py` : trois tests ciblant un et deux intervalles, y compris cohérence de l'annualisation.

Aucune règle de stratégie, formule de risque, taille de position, coût, ni logique d'exécution n'a été modifiée.

## Validation

- Tests ciblés : 25 passed.
- Suite complète : 895 passed, 11 skipped, 202 subtests passed.
- Durée de la suite complète : 23.87 secondes.
- L'archive R71 source est conservée intacte.
- L'effet secondaire de test sur `history.jsonl` a été restauré depuis la copie R71 avant création de l'archive.

## État des données de marché — constat non corrigé dans R72

L'audit de provenance des prix a aussi relevé une limite qui doit être traitée séparément :

- l'adaptateur Alpaca demande explicitement `adjustment=split` ;
- l'adaptateur Twelve Data ne transmet pas, dans le contrat OHLCV actuel, une déclaration vérifiable du mode d'ajustement ;
- `DailyBars` et `OHLCVDailyBars` ne transportent pas de métadonnée d'ajustement ;
- `compare_daily_bars` compare prix et volumes aux timestamps communs, mais ne peut donc pas établir que les deux historiques ont le même traitement des splits/dividendes.

En conséquence, une comparaison inter-fournisseurs ne constitue pas actuellement une preuve de cohérence des corporate actions. R72 n'invente pas de mode d'ajustement, ne transforme pas les prix et ne présente pas le rendement comme un rendement total incluant les dividendes. Le prochain incrément devra introduire une provenance d'ajustement explicite et des contrôles fail-closed avant de comparer des séries pour un usage quantitatif.

## Statut

R72 est un candidat local de recherche. Pas de déploiement Replit, pas de validation Neon réelle et pas de session Alpaca Paper authentifiée revendiqués. Aucun ordre n'a été envoyé ; Live reste désactivé.
