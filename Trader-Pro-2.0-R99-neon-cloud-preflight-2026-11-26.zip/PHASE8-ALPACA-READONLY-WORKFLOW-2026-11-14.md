# Trader Pro 2.0 — Alpaca Paper read-only workflow

Date: 2026-11-14

## Change

Added `.github/workflows/alpaca-paper-readonly.yml`, a manually dispatched GitHub Actions workflow that runs only `scripts/verify_alpaca_paper_readonly.py` against the official Alpaca Paper endpoint. It uses the protected `alpaca-paper` GitHub environment and its two Paper secrets. The job has read-only repository permissions, a five-minute timeout, and a concurrency group to serialize checks.

The script checks account, positions, market clock and a small SPY bar sample. It does not submit, replace or cancel orders. The separate order/cancel smoke workflow remains separately gated by the exact confirmation string `PAPER_ONLY_ONE_LIMIT_ORDER` and the protected Paper environment.

## Local verification

- Full pytest suite: **519 passed, 10 skipped, 92 subtests passed**.
- All GitHub workflow YAML files parsed successfully with YAML BaseLoader (preserves GitHub's `on` key).
- Three PostgreSQL shell scripts passed `bash -n`.
- Python source syntax compilation passed for all discovered Python files.

## Not validated

This only adds a workflow definition. It has not been run in GitHub Actions, and no Alpaca credentials or authenticated Paper request were available in this runtime. It is not evidence of broker connectivity. No order was submitted.

## Phase gate

Phase 8 remains OPEN pending real PostgreSQL integration/backup-restore and authenticated Alpaca Paper read-only validation. The one-order/cancel smoke remains separately opt-in. Phase 9 remains gated; Live trading remains disabled.
