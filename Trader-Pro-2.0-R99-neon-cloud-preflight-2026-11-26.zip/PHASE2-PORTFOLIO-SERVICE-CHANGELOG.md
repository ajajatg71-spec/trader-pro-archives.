# Trader Pro 2.0 — PortfolioService extraction

## Scope
- Added `services/portfolio.py` with `PortfolioService` for portfolio snapshots, performance summaries, realized gains, and tax estimates.
- Injected broker fill and position readers; the service no longer depends on FastAPI or broker globals.
- Wired portfolio routes to the service while retaining the existing `portfolio.py` domain calculations unchanged.
- Added deterministic unit tests for FIFO output, summary calculations, tax delegation, and empty portfolios.

## Safety and compatibility
- No broker order submission or mutation endpoint was added.
- No financial formulas were rewritten; `portfolio.py` remains the source of truth for calculations.
- Existing route paths and response generation remain unchanged.
