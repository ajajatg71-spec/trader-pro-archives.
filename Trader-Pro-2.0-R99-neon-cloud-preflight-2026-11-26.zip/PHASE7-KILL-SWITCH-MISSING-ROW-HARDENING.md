# Phase 7 — durcissement du singleton du coupe-circuit

## Défaut corrigé

Le repository interprétait auparavant l'absence de la ligne singleton `risk_control_state(id=1)` comme une pause désactivée. Une table vide ou une suppression accidentelle de cette ligne pouvait donc effacer silencieusement l'état opérationnel attendu.

## Correction

- Nouvelle migration Alembic `f3b8c2d91a64` après la tête de fusion `e8a19c42d7b1`.
- La migration initialise explicitement la ligne singleton `id=1`, `paused=false`, `actor=system`.
- À l'exécution, si cette ligne est absente, `get_operational_pause()` retourne maintenant `paused=true` avec un motif explicite. Une anomalie de persistance ne peut donc pas être interprétée comme une autorisation de trading.
- Ajout d'un test de repository pour la ligne manquante.
- Extension de la suite PostgreSQL opt-in pour vérifier la présence de la ligne après migration, l'activation, la lecture via un nouveau repository (simulation de redémarrage), l'audit et la reprise.

## Validation locale

- `pytest -q` : 410 réussis, 4 ignorés, 88 sous-tests réussis.
- `unittest discover -q` : 406 réussis.
- `compileall` : réussi.
- Migration Alembic complète sur une base SQLite temporaire : réussie, tête unique `f3b8c2d91a64`.
- Vérification SQL après migration : ligne singleton `(1, paused=0, reason=NULL, actor='system')` présente.

## Limites

- Les 4 tests PostgreSQL sont opt-in et restent ignorés faute d'URL de test PostgreSQL et de pilote psycopg dans cet environnement.
- Aucune instance PostgreSQL réelle, aucun test multi-processus PostgreSQL et aucun Paper broker réel n'ont été exécutés.
- La migration doit être appliquée sur l'environnement utilisateur avant que le nouveau comportement de singleton initialisé soit présent dans sa base.
- Trading Live reste désactivé.
