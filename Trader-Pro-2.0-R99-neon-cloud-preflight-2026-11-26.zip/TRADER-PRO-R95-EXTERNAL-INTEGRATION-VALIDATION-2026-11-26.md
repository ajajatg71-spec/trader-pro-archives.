# Trader Pro 2.0 — R95
## Validation externe PostgreSQL, ingestion Alpaca et réconciliation Paper

Date : 26 novembre 2026
Base de travail : archive R94
Cible Neon : projet `Trader pro`, base `trader_pro_test` uniquement
Branche Neon parente : `production` (`br-frosty-hat-b9ccb798`)
Version Alembic constatée : `f19a6c3d8b42`

## Résumé exécutif

Les trois chantiers demandés ont été exécutés au niveau des composants et des frontières externes accessibles :
1. Chaîne complète de migrations Alembic générée en mode SQL, appliquée à `trader_pro_test`, puis contrôlée sur PostgreSQL 18.7.
2. Ingestion des 15 dividendes AAPL/MSFT renvoyés par Alpaca : le lecteur R94 a parsé le format réel, le service d'ingestion a persisté les événements sur une base SQLite de validation, et le rejeu est resté idempotent. Les mêmes 15 événements ont également été chargés dans le registre Neon de test pour vérification SQL.
3. Réconciliation Paper en lecture seule exécutée par `ReconciliationService` avec le snapshot réel du compte Alpaca. Le rapport a été persisté localement puis son justificatif a été enregistré dans les tables de test Neon.

**Important :** le code Python n'a pas ouvert directement une connexion SQLAlchemy vers Neon dans cet environnement. Les appels Neon ont été effectués via les outils SQL Neon, tandis que les services applicatifs ont été exercés localement avec les données réelles capturées. Le test de la chaîne complète *processus Python → connexion SQLAlchemy Neon* reste à effectuer dans Replit ou un runner disposant du pilote PostgreSQL et de l'accès réseau.

## 1. PostgreSQL / Alembic — validation externe

- PostgreSQL Neon : 18.7.
- Base ciblée : `trader_pro_test`.
- Tête Alembic : `f19a6c3d8b42`.
- 17 tables publiques.
- Table `corporate_action_revisions` : 7 colonnes.
- Contraintes : unicité `(source,event_id,revision)` et 3 CHECK.
- Trigger `trg_corporate_action_revisions_append_only` actif.
- Seed du coupe-circuit opérationnel présent.
- Seed de l'état global de sécurité présent (`RECONCILING`).
- Seed TOTP singleton présent.

Contrôles SQL sur une branche Neon temporaire puis sur `trader_pro_test` :
- précision numérique des montants/quantités ;
- unicité des identifiants de fill ;
- rejet des UPDATE/DELETE du registre append-only ;
- rollback complet des écritures de test ;
- absence de résidus des probes après rollback.

Les branches temporaires ont été supprimées après vérification. Aucun schéma de la branche `production` hors de la base `trader_pro_test` n'a été modifié.

### Limite sur les 11 tests PostgreSQL opt-in

Les 11 tests de `tests/test_postgres_integration.py` sont conditionnés par :
- `TRADER_PRO_TEST_DATABASE_URL`
- `TRADER_PRO_TEST_DATABASE_DISPOSABLE=YES`

Leur code refuse volontairement tout hôte distant : seuls `localhost`, `127.0.0.1` ou `::1` sont acceptés pour ces tests destructifs. Aucun binaire PostgreSQL, `psql`, `initdb`, `pg_ctl`, Docker ou pilote `psycopg` n'était disponible dans le runner. L'installation du pilote a échoué faute d'accès réseau sortant.

Ils n'ont donc pas été forcés contre Neon. Les équivalents SQL non destructifs/transactionnels ont été vérifiés directement sur une branche jetable Neon et sur la base de test.

## 2. Ingestion des événements Alpaca — données réelles

Source : endpoint Alpaca Corporate Actions, région US, période 2025-01-01 à 2026-11-26, symboles AAPL et MSFT.

Résultat fournisseur :
- 15 dividendes reçus ;
- 8 événements AAPL ;
- 7 événements MSFT ;
- une page, pagination complète ;
- devise absente du payload pour les lignes observées.

Traitement applicatif R94 :
- le lecteur `AlpacaCorporateActionsReader` a parsé la forme réelle du payload ;
- le résolveur explicite a fourni `USD` pour AAPL et MSFT ;
- première ingestion locale : 15 insérés ;
- rejeu identique : 15 inchangés, 0 nouvel insert ;
- snapshot point-in-time : 15 événements ;
- horodatage de connaissance basé sur l'heure de récupération, sans antidatage sur la date ex-date.

Neon `trader_pro_test` :
- 15 révisions Alpaca persistées ;
- 15 IDs distincts ;
- 15 payloads avec devise USD explicitement résolue ;
- 2 symboles ;
- `available_at` présent dans les 15 payloads ;
- rejeu SQL avec conflit unique : aucun doublon supplémentaire.

**Nuance :** l'ingestion Python applicative a été validée localement sur SQLite avec les données réellement récupérées d'Alpaca. Le chargement dans Neon a été réalisé via SQL Neon, pas via le repository SQLAlchemy exécuté depuis le processus applicatif.

## 3. Réconciliation Alpaca Paper — snapshot réel

Appels Alpaca en lecture seule :
- compte `ACTIVE` ;
- equity : 100 000 USD ;
- cash : 100 000 USD ;
- buying power : 200 000 USD ;
- positions : 0 ;
- ordres ouverts : 0 ;
- ordres historiques consultés : 0 ;
- activités de type FILL : 0 ;
- trading non bloqué.

`ReconciliationService` a traité ce snapshot :
- `account_snapshot_saved = true` ;
- ordres vus : 0 ;
- fills vus : 0 ;
- positions vues : 0 ;
- avertissements : 0 ;
- execution health : `healthy` ;
- `automatic_retry_permitted = false` ;
- preuve : `succeeded`, `snapshot_complete = true`, `unresolved_count = 0`.

Preuve persistée dans Neon `trader_pro_test` :
- run ID : `6855a242-5968-4740-b44f-76be3707340a`
- evidence SHA-256 : `0e6e09336049f17862326a50b73e093cf5a094404d1e7958537bd88bee37b970`
- un snapshot de compte Paper ;
- une preuve de réconciliation réussie.

La réconciliation financière reste `not_run` car aucun baseline de cash d'ouverture indépendant n'a été configuré. Aucun ordre Paper n'a été envoyé pour fabriquer artificiellement une activité de test.

## 4. État sécurité

- Compte Alpaca Paper toujours `ACTIVE`.
- Aucune position créée.
- Aucun ordre ouvert.
- Aucune transaction envoyée.
- `risk_control_state.paused = false` (valeur de départ, inchangée).
- `system_safety_state.status = RECONCILING` : le système reste en mode de validation.
- Trading Live non autorisé.
- Aucune modification de la branche de production en dehors de la base explicitement ciblée `trader_pro_test`.

## 5. Tests du code

Suite complète R94 réexécutée depuis l'archive :
- 1 004 tests réussis ;
- 11 tests PostgreSQL opt-in ignorés pour le garde-fou local décrit plus haut ;
- 205 sous-tests réussis ;
- `compileall` réussi.

Ce rapport est une validation R95 additive. Il ne modifie pas les stratégies, les règles de risque ni les autorisations d'exécution.
