# Phase 8 — protection persistante de l'authentification opérateur

## Changements

- `operator_auth_attempts` réserve atomiquement chaque tentative et conserve un compteur par empreinte SHA-256 de l'adresse IP TCP du client, dans une fenêtre de dix minutes. Les adresses IP brutes ne sont pas stockées dans cette table.
- `operator_totp_state` conserve un compteur TOTP maximal déjà accepté. Un compteur identique ou inférieur est refusé, ce qui empêche le rejeu d'un code déjà accepté.
- Chaque requête réserve sa tentative avant vérification des identifiants, ce qui évite qu’une rafale concurrente franchisse le seuil. Les lectures et mises à jour utilisent des transactions SQLAlchemy et `SELECT ... FOR UPDATE` pour sérialiser les opérations sur PostgreSQL.
- Le routeur opérateur refuse de démarrer avec un dépôt qui ne fournit pas ces opérations persistantes ou sans vérificateur TOTP retournant le compteur correspondant.
- Si PostgreSQL est indisponible, les contrôles opérateur échouent en mode fermé (503).

## Migration

Révision Alembic `a41d9c7e2b60`, enfant de `9e5b7c2d4a61`. Elle crée les deux tables et initialise le singleton TOTP à `-1`.

## Vérifications locales

Tests unitaires du dépôt sur SQLite : fenêtre de limitation, compteur persistant, monotonie et usage unique TOTP. Tests du routeur : rejeu refusé, refus d'un dépôt non persistant et refus si la base manque. Migration complète depuis une base SQLite vide vérifiée jusqu'à `a41d9c7e2b60`.

## Limites non certifiées

SQLite ne valide pas la sémantique réelle des verrous PostgreSQL. Deux tests d’intégration PostgreSQL multi-processus sont ajoutés : dix réservations simultanées (cinq maximum) et deux consommations simultanées du même compteur TOTP (une seule acceptée). Ils restent ignorés tant que `TRADER_PRO_TEST_DATABASE_URL` ne pointe pas vers une base PostgreSQL jetable dont le nom contient `test`. Cette livraison ne constitue pas une validation Alpaca Paper, ne déverrouille pas le trading et ne modifie pas l'autorisation Live.
