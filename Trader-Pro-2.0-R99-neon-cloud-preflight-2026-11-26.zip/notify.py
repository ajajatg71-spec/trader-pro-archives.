"""Notifications Telegram (variables TELEGRAM_TOKEN et TELEGRAM_CHAT_ID). Silencieux si non configuré."""
import os, requests

def send(text):
    t, c = os.getenv("TELEGRAM_TOKEN"), os.getenv("TELEGRAM_CHAT_ID")
    if not (t and c): return False
    try:
        requests.post(f"https://api.telegram.org/bot{t}/sendMessage", json={"chat_id": c, "text": text[:3500]}, timeout=10).raise_for_status()
        return True
    except requests.RequestException:
        return False
