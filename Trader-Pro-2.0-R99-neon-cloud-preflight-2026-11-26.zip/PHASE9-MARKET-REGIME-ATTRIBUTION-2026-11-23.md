# Phase 9 — attribution walk-forward par régime de marché

## Objectif
Ajouter une lecture de robustesse conditionnelle aux trois environnements de marché (hausse, latéral, baisse), sans réutiliser les rendements futurs pour déterminer le régime.

## Méthode implémentée
- Proxy de marché : indice OHLCV synchronisé déjà fourni au scoreboard multi-actifs.
- Mesure : rendement glissant sur 63 séances.
- Classification connue à la clôture précédente : `risk_on` au-dessus de +5 %, `risk_off` sous -5 %, `sideways` entre les deux.
- Chaque rendement OOS de la séance i est attribué au régime calculé à partir des données disponibles au plus tard à la clôture i-1.
- Rapport par régime : observations, rendement composé de la stratégie, rendement composé du benchmark équipondéré, surperformance et taille d'échantillon suffisante (20 observations minimum).
- Les observations précédant la disponibilité d'une fenêtre complète de 63 séances sont laissées non classifiées.

## Garde-fous
- Cette attribution ne déclenche ni sélection, ni activation, ni allocation.
- Les régimes insuffisamment échantillonnés sont signalés comme tels.
- `market_regime_analysis_validated` demeure `false`.
- La prévisualisation reste en mode recherche, 100 % cash, `capital_authorized=false`, zéro ordre.

## Tests
- `tests/test_research_v1_portfolio_scoreboard.py` : 9 tests réussis.
- Suite complète : 704 passed, 11 skipped, 202 subtests passed.
- `python -m compileall -q .` : réussi.
- `node --check frontend/public/sw.js` : réussi.

## Limites
Cette classification est une mesure descriptive et non une preuve que la stratégie est robuste dans tous les régimes. Les résultats doivent être produits sur plusieurs univers et des données réelles ajustées, puis validés avec des échantillons suffisants, frais réalistes, spreads, liquidité, secteurs et tests Paper. Les 11 tests PostgreSQL restent ignorés ; PostgreSQL réel, Alpaca Paper et le build React/PWA ne sont pas validés.
