# Trader Pro 2.0 — incrément R40

Date : 23 novembre 2026  
Base : candidat R39. Aucun changement de stratégie, de risque ou de mode broker.

## Correction ciblée

Le script Linux `scripts/verify_postgres.sh` exécutait les tests PostgreSQL avec `pytest`, mais ne vérifiait pas explicitement qu'au moins un test avait réellement tourné et qu'aucun n'avait été ignoré. Une suite entièrement marquée `skip` pouvait donc laisser le script poursuivre la sauvegarde/restauration et afficher un succès trompeur.

Le script exige désormais :
- un code de sortie pytest réussi ;
- au moins un test PostgreSQL réussi ;
- zéro test PostgreSQL ignoré.

Cette règle aligne le chemin Linux/CI avec le contrôle déjà présent dans le script Windows.

## Vérifications locales

- `BROKER=sim pytest -q tests/test_postgres_validation_script_contract.py tests/test_deployment_preflight.py tests/test_dockerfile_security.py` : **22 passed**.
- `bash -n scripts/verify_postgres.sh` : OK.
- `python -m compileall -q scripts tests` : OK.
- Archive ZIP : intégrité vérifiée, 362 fichiers.
- Aucun serveur PostgreSQL, Docker ou accès Neon disponible dans cet environnement : aucune validation PostgreSQL réelle n'est revendiquée.
- Aucun appel Alpaca, aucun ordre Paper/Live.
