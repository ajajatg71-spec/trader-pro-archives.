"""Logique pure : budget (copycat), rééquilibrage, contrôle du risque."""

def size(targets, budget, buffer, cap):
    """Répartit le budget selon les poids, plafonne chaque titre, redistribue l'excédent."""
    w = {t: float(x) for t, x in targets}
    if not w:
        return {}, set()
    inv, capamt = budget * (1 - buffer / 100), budget * cap / 100
    amt, capped, free, act = {t: 0.0 for t in w}, set(), inv, list(w)
    for _ in range(12):
        if not act:
            break
        sw, over = sum(w[t] for t in act), False
        for t in act:
            amt[t] = free * w[t] / sw
            if amt[t] > capamt:
                amt[t], over = capamt, True
                capped.add(t)
        if not over:
            break
        free = inv - sum(amt[t] for t in capped)
        act = [t for t in w if t not in capped]
    return {t: round(a, 2) for t, a in amt.items()}, capped

def rebalance(targets, pos, equity, buffer, band):
    """Ordres à passer quand l'écart à la cible dépasse la tolérance (en points)."""
    tw = {t: float(x) for t, x in targets}
    sw = sum(tw.values()) or 1.0
    inv = equity * (1 - buffer / 100)
    cur = {p["symbol"]: float(p["market_value"]) for p in pos}
    out = []
    for t in sorted(set(tw) | set(cur)):
        tv, cv = (inv * tw[t] / sw if t in tw else 0.0), cur.get(t, 0.0)
        if abs(cv - tv) / equity * 100 > band and abs(tv - cv) >= 1:
            out.append((t, "buy" if tv > cv else "sell", round(abs(tv - cv), 2)))
    return out

def daily_loss(acct):
    """Variation du jour en % (négative = perte)."""
    last = float(acct.get("last_equity") or 0)
    return (float(acct["equity"]) - last) / last * 100 if last else 0.0

def check(order, acct, pos, L, blocked, used=0.0, orders_today=0):
    """Renvoie '' si l'ordre est accepté, sinon la raison du blocage."""
    sym, side, amt = order
    eq, cash = float(acct["equity"]), float(acct["cash"]) - used
    cur = {p["symbol"]: float(p["market_value"]) for p in pos}
    if sym in blocked: return "Ticker bloqué"
    if amt > L["max_order"]: return "Ordre trop gros"
    if side == "buy" and orders_today >= L.get("max_orders_day", 20): return "Limite d’ordres du jour atteinte"
    if side == "buy" and amt > eq * L.get("max_order_pct", 25) / 100 + .05: return "Ordre trop gros pour le portefeuille"
    if side == "buy":
        if sym not in cur and len(cur) >= L.get("max_positions", 12): return "Nombre maximal de positions atteint"
        if (sum(cur.values()) + amt) / eq * 100 > L.get("max_gross", 90) + .01: return "Exposition totale trop élevée"
        if daily_loss(acct) < -L.get("max_daily_loss", 3.0): return "Perte journalière max atteinte"
        if (cur.get(sym, 0) + amt) / eq * 100 > L["max_pos"] + .01: return "Position trop grosse"
        if cash - amt < eq * L["min_cash"] / 100 - .05: return "Cash sous le coussin"
    elif amt > cur.get(sym, 0) + .05:
        return "Vente supérieure à la position"
    return ""
