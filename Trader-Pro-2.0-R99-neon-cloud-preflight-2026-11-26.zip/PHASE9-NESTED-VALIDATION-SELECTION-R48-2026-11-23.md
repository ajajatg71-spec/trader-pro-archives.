# Trader Pro 2.0 — R48

## Objectif
Séparer la sélection des paramètres de la validation finale hors échantillon dans le moteur `research_v1/backtesting/walk_forward.py`.

## Changements
- Ajout de `validation_bars` (30 séances par défaut), distinct de la fenêtre OOS.
- Pour chaque fenêtre, le préfixe chronologique antérieur à la validation ne sert qu'à fournir l'historique causal des indicateurs.
- Chaque configuration candidate est évaluée sur la queue de validation interne au préfixe d'entraînement.
- Le classement utilise le Sharpe, le drawdown maximal et le CAGR de validation, et non les résultats du test OOS.
- Les indices de début/fin de validation sont exposés dans le rapport de chaque fenêtre.
- Le test OOS demeure postérieur à la validation et n'est jamais utilisé pour sélectionner les paramètres.
- Ajout de tests pour les bornes validation/train/test et les validations insuffisantes.

## Validation locale
- `BROKER=sim pytest -q` : **799 passed, 11 skipped, 202 subtests passed**.
- `BROKER=sim python -m unittest discover -q` : **717 tests OK**.
- `python -m compileall -q .` : OK.
- `node --check frontend/public/sw.js` : OK.
- Archive ZIP : intégrité vérifiée.

## Limites
- Les candidats sont fournis à l'avance ; R48 ne crée pas encore de nouveaux paramètres ni n'entraîne un modèle.
- La queue de validation choisit parmi les candidats ; elle n'est donc pas un jeu de test final indépendant. Le segment OOS suivant reste la mesure indépendante.
- Les fenêtres OOS restent des diagnostics indépendants avec capital réinitialisé, pas un portefeuille continu.
- Données réelles, coûts d'exécution, corporate actions et qualité des snapshots doivent être vérifiés.
- PostgreSQL/Neon et Alpaca Paper n'ont pas été validés dans ce lot.
- Aucun broker, ordre, activation de stratégie ou capital autorisé ; aucune rentabilité n'est démontrée.
