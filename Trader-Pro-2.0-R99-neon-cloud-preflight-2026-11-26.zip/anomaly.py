"""Détection de mouvements inhabituels : variation du jour (z-score sur 60 jours) et pic de volume."""
import statistics as st

def unusual(closes, volumes=None, z=3.0, vol_x=2.5):
    out = []
    if len(closes) >= 62:
        r = [closes[i] / closes[i - 1] - 1 for i in range(1, len(closes))]
        h, last = r[-61:-1], r[-1]; sd = st.pstdev(h)
        if sd > 0 and abs(last - st.mean(h)) / sd >= z:
            out.append(f"mouvement inhabituel : {last * 100:+.1f} % ({abs(last - st.mean(h)) / sd:.1f} écarts-types)")
    if volumes and len(volumes) >= 21:
        avg = sum(volumes[-21:-1]) / 20
        if avg > 0 and volumes[-1] >= vol_x * avg: out.append(f"volume {volumes[-1] / avg:.1f}× la moyenne")
    return out
