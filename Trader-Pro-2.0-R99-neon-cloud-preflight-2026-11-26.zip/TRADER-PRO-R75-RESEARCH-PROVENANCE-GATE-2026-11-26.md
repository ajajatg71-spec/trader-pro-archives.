# Trader Pro 2.0 — R75 : verrou de provenance pour la recherche quantitative

Date : 2026-11-26  
Base : R74 (`Trader-Pro-2.0-R74-provenance-transport-2026-11-26.zip`)

## Constat

Même après ajout des métadonnées au contrat OHLCV, l'adaptateur historique R1 pouvait convertir des bougies en données de recherche sans vérifier leur mode d'ajustement. Cela permettait à des données dont la provenance était inconnue d'entrer dans les simulations et comparaisons de stratégies.

## Modifications

- `research_v1.adapter.to_research_bars` exige maintenant un mode déclaré parmi `raw`, `split`, `dividend` ou `all`, en plus des horodatages.
- `evaluate_rule` exige que l'actif et son benchmark aient le même mode d'ajustement.
- `evaluate_universe` refuse un univers avec provenance inconnue ou modes hétérogènes ; les benchmarks associés doivent respecter le même mode.
- Les résultats de recherche dry-run exposent le mode retenu pour rendre la provenance visible.
- Les fixtures synthétiques des tests déclarent explicitement leur convention `split`; les données de production ne sont pas requalifiées automatiquement.
- Tests ajoutés pour les données inconnues et le benchmark de mode différent.

Ce verrou ne convertit pas les cours et ne prétend pas que `split` inclut les dividendes. Il empêche seulement de lancer cette voie de recherche avec une provenance inconnue ou incohérente.

## Validation

- Tests ciblés adaptateur et API de recherche : 15 réussis.
- Suite complète : 902 réussis, 11 ignorés, 202 sous-tests réussis.
- Les tests PostgreSQL ignorés ne constituent pas une validation Neon.
- Aucun ordre envoyé ; Live reste désactivé.

## Limites

- `split` signifie ici que le fournisseur a déclaré/sollicité l'ajustement des divisions d'actions ; ce n'est pas un rendement total.
- Twelve Data reste en `unknown` et sera donc refusé par le moteur de recherche strict tant que son mode ne sera pas établi.
- Les rendements totaux nécessitent encore des événements de dividendes et une convention explicite de traitement/réinvestissement.
- Pas de déploiement Replit, validation Neon réelle, ni session Alpaca Paper authentifiée dans cette exécution.
