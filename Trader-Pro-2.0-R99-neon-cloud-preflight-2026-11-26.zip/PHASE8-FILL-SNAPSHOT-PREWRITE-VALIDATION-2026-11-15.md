# Phase 8 — fill snapshot pre-write validation (2026-11-15)

## Finding

The broker connector validates Alpaca FILL activity records, but `ReconciliationService` also accepts alternate broker adapters. Its previous preflight rejected non-dictionary entries only. A dictionary containing duplicate execution IDs or invalid numeric values could therefore reach the reconciliation write path; malformed fills might be reported only after account/position snapshots had already been saved.

## Change

Before stale-submission recovery, snapshot persistence, or any other database mutation, reconciliation now validates every fill record for:

- a non-empty execution ID, broker order ID, and symbol;
- unique execution IDs within the fetched snapshot;
- an optional side restricted to `buy` or `sell` (the existing fallback to the matched broker order remains supported);
- finite, strictly positive quantity and price;
- finite, non-negative fee;
- valid ISO timestamp syntax when a timestamp is supplied.

Missing timestamps retain the previous conservative behavior: they are not fabricated and are reported as invalid during ingestion, preserving existing operator diagnostics. The preflight does not silently convert a missing timestamp into an execution time.

## Regression coverage

Added tests proving that duplicate fill IDs and invalid numeric fields abort before account snapshots, fill ledger rows, or reconciliation evidence are written.

## Verification

- `python -m pytest -q`: **581 passed, 11 skipped, 194 subtests passed**.
- `python -m unittest discover -q`: **577 passed**.
- `python -m compileall -q .`: passed.
- `alembic heads`: one head, `b8d2f4a6c901`.
- ZIP integrity checked after packaging.

The 11 skipped tests remain PostgreSQL integration tests. This runtime has no Docker/Podman or `psql`, and no authenticated Alpaca Paper credentials. No real PostgreSQL test, authenticated broker request, Paper order, cancellation, or Live operation was performed. Phase 8 remains open.
