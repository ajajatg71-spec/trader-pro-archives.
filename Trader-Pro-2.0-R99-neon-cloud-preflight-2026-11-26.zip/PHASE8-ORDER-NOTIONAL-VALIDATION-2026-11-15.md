# Phase 8 — order notional validation hardening (2026-11-15)

## Audit finding

Both durable order-intent entry points previously relied on `notional <= 0`. That comparison does not reject all non-finite numeric values (for example NaN), and booleans can behave as integers in Python. This left malformed amounts to be rejected later, inconsistently by the database or adapter, and sell intents did not pass through the aggregate-buy reservation validation.

## Change

- Added one Decimal-based notional validator shared by `stage_order` and `stage_order_if_trading_enabled`.
- Rejects booleans, malformed values, NaN, positive/negative infinity, zero and negative amounts before opening a database transaction.
- Validates nonblank client order IDs and symbols and the supported side before persistence.
- Persists the normalized Decimal value rather than reparsing the caller's value.
- Does not change V1 budget calculations, broker submission behavior, or enable Live mode.

## Regression coverage

- Added tests for NaN, infinities, booleans and Decimal non-finite values on the regular intent path.
- Added equivalent fail-closed tests for the atomic submission path, including sell intents.

## Local verification (2026-11-15)

- `python -m pytest -q`: **566 passed, 11 skipped, 187 subtests passed**.
- `python -m unittest discover -q`: **562 passed**.
- `python -m compileall -q .`: passed.
- Focused `tests/test_order_repository.py`: **35 passed, 10 subtests passed**.

The 11 skipped tests require PostgreSQL. This runtime still has no PostgreSQL driver, Docker/Podman, `psql`, `pg_dump`, PostgreSQL server, or `TRADER_PRO_TEST_DATABASE_URL`. The PostgreSQL concurrency test exists but has not been executed against PostgreSQL. No authenticated Alpaca Paper connection or order was made.

## Remaining release gates

1. Execute migrations, transaction concurrency, and backup/restore against PostgreSQL 16.
2. Run authenticated Alpaca Paper read-only reconciliation and missed-event/reconnect tests.
3. Separately authorize any one-order Paper smoke test; no order is authorized by this report.
4. Keep Live disabled pending a separate explicit authorization after all release gates.
