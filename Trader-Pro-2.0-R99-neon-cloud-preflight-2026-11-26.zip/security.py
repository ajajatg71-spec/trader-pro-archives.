"""Helpers for reverse-proxy trust boundaries.

Only an explicitly configured immediate peer may assert X-Forwarded-Proto.
X-Forwarded-For is deliberately not used for authentication/rate-limit identity:
its left-most value can be client-controlled unless every proxy hop is configured.
"""
import ipaddress
import os


def _trusted_networks(value=None):
    raw = os.getenv("TRUSTED_PROXY_IPS", "") if value is None else value
    networks = []
    for item in raw.split(","):
        item = item.strip()
        if item:
            networks.append(ipaddress.ip_network(item, strict=False))
    return networks


def is_trusted_proxy(peer_ip, trusted=None):
    if not peer_ip:
        return False
    try:
        peer = ipaddress.ip_address(peer_ip)
        return any(peer in net for net in _trusted_networks(trusted))
    except ValueError:
        return False


def client_ip(request):
    """Return the TCP peer, not an untrusted forwarded header."""
    return request.client.host if request.client else "?"


def is_https(request, trusted=None):
    peer = request.client.host if request.client else None
    if is_trusted_proxy(peer, trusted):
        # The trusted ingress must overwrite (not append) this header.
        return request.headers.get("x-forwarded-proto", "").lower() == "https"
    return request.url.scheme.lower() == "https"
