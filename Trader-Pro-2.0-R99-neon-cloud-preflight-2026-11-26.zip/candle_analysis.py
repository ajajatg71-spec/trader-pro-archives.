"""Research-grade, deterministic OHLCV candle analysis.

This module describes observed candle structure and context. Pattern matches are
heuristics, not probabilities or forecasts, and this module never creates orders.
Bars must be chronological and use one consistent timeframe and price adjustment.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Mapping, Sequence


class CandleAnalysisError(ValueError):
    """Invalid or insufficient OHLCV input."""


@dataclass(frozen=True)
class Candle:
    open: float
    high: float
    low: float
    close: float
    volume: float
    timestamp: object | None = None

    @property
    def body(self) -> float:
        return abs(self.close - self.open)

    @property
    def range(self) -> float:
        return self.high - self.low

    @property
    def body_ratio(self) -> float:
        return self.body / self.range if self.range else 0.0

    @property
    def upper_wick(self) -> float:
        return self.high - max(self.open, self.close)

    @property
    def lower_wick(self) -> float:
        return min(self.open, self.close) - self.low

    @property
    def direction(self) -> str:
        return "BULLISH" if self.close > self.open else "BEARISH" if self.close < self.open else "DOJI"


@dataclass(frozen=True)
class PatternMatch:
    name: str
    direction: str
    bar_index: int
    description: str
    volume_confirmed: bool


@dataclass(frozen=True)
class CandleAnalysis:
    observations: int
    last_timestamp: object | None
    last_direction: str
    body_pct_of_range: float
    upper_wick_pct_of_range: float
    lower_wick_pct_of_range: float
    close_location_pct: float
    gap_pct: float | None
    atr_pct: float | None
    relative_volume: float | None
    trend: str
    structure: str
    patterns: tuple[PatternMatch, ...]
    limitations: tuple[str, ...]


def _number(value: object, label: str, *, minimum: float | None = None) -> float:
    if isinstance(value, bool):
        raise CandleAnalysisError(f"Valeur booléenne interdite pour {label}")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise CandleAnalysisError(f"Valeur non numérique pour {label}") from exc
    if not math.isfinite(result) or (minimum is not None and result < minimum):
        raise CandleAnalysisError(f"Valeur invalide pour {label}")
    return result


def validate_bars(raw_bars: Sequence[Mapping[str, object]]) -> tuple[Candle, ...]:
    if isinstance(raw_bars, (str, bytes)) or not isinstance(raw_bars, Sequence):
        raise CandleAnalysisError("Les bougies doivent être une séquence chronologique")
    if len(raw_bars) < 2:
        raise CandleAnalysisError("Au moins deux bougies sont nécessaires")
    result: list[Candle] = []
    timestamps = []
    timestamp_mode = None
    for index, raw in enumerate(raw_bars):
        if not isinstance(raw, Mapping):
            raise CandleAnalysisError(f"Bougie invalide à l'index {index}")
        try:
            o = _number(raw["open"], f"open[{index}]", minimum=0)
            h = _number(raw["high"], f"high[{index}]", minimum=0)
            low = _number(raw["low"], f"low[{index}]", minimum=0)
            c = _number(raw["close"], f"close[{index}]", minimum=0)
            v = _number(raw.get("volume", 0), f"volume[{index}]", minimum=0)
        except KeyError as exc:
            raise CandleAnalysisError(f"Champ OHLC manquant: {exc.args[0]}") from exc
        if min(o, h, low, c) <= 0 or h < max(o, c, low) or low > min(o, c):
            raise CandleAnalysisError(f"Géométrie OHLC incohérente à l'index {index}")
        stamp = raw.get("timestamp")
        has_stamp = stamp is not None
        if timestamp_mode is None:
            timestamp_mode = has_stamp
        if has_stamp != timestamp_mode:
            raise CandleAnalysisError("Les horodatages doivent être présents sur toutes les bougies ou aucune")
        if has_stamp:
            if not hasattr(stamp, "tzinfo") or stamp.tzinfo is None or stamp.utcoffset() is None:
                raise CandleAnalysisError("Chaque horodatage doit être timezone-aware")
            timestamps.append(stamp)
        result.append(Candle(o, h, low, c, v, stamp))
    if timestamps and any(a >= b for a, b in zip(timestamps, timestamps[1:])):
        raise CandleAnalysisError("Les bougies doivent être strictement ordonnées dans le temps")
    return tuple(result)


def _true_ranges(bars: Sequence[Candle]) -> list[float]:
    values = []
    previous_close = bars[0].close
    for bar in bars[1:]:
        values.append(max(bar.high - bar.low, abs(bar.high - previous_close),
                          abs(bar.low - previous_close)))
        previous_close = bar.close
    return values


def _trend(closes: Sequence[float]) -> str:
    if len(closes) < 20:
        return "UNKNOWN"
    fast = sum(closes[-10:]) / 10
    slow = sum(closes[-20:]) / 20
    if fast > slow * 1.002:
        return "UPTREND"
    if fast < slow * 0.998:
        return "DOWNTREND"
    return "RANGE"


def analyze_candles(raw_bars: Sequence[Mapping[str, object]], *,
                    atr_period: int = 14, volume_period: int = 20) -> CandleAnalysis:
    """Analyze candle anatomy, selected multi-bar patterns and local context.

    Pattern thresholds are transparent heuristics. Trend and volume are context
    filters only; they are not calibrated probabilities. Input must contain
    one timeframe, chronological OHLCV observations, and consistently adjusted prices.
    """
    if isinstance(atr_period, bool) or not isinstance(atr_period, int) or atr_period < 2:
        raise CandleAnalysisError("atr_period doit être un entier >= 2")
    if isinstance(volume_period, bool) or not isinstance(volume_period, int) or volume_period < 2:
        raise CandleAnalysisError("volume_period doit être un entier >= 2")
    bars = validate_bars(raw_bars)
    last = bars[-1]
    rng = last.range
    close_location = ((last.close - last.low) / rng * 100) if rng else 50.0
    gap = ((last.open / bars[-2].close) - 1) * 100 if bars[-2].close else None
    tr = _true_ranges(bars)
    atr = sum(tr[-atr_period:]) / atr_period if len(tr) >= atr_period else None
    atr_pct = atr / last.close * 100 if atr is not None else None
    prior_volumes = [b.volume for b in bars[-volume_period-1:-1]]
    avg_volume = sum(prior_volumes) / len(prior_volumes) if len(prior_volumes) == volume_period else None
    relative_volume = last.volume / avg_volume if avg_volume and avg_volume > 0 else None
    closes = [b.close for b in bars]
    trend = _trend(closes)
    structure = "HIGHER_HIGHS_LOWS" if len(bars) >= 3 and bars[-1].high > bars[-2].high > bars[-3].high and bars[-1].low > bars[-2].low > bars[-3].low else (
        "LOWER_HIGHS_LOWS" if len(bars) >= 3 and bars[-1].high < bars[-2].high < bars[-3].high and bars[-1].low < bars[-2].low < bars[-3].low else "MIXED")

    patterns: list[PatternMatch] = []
    volume_ok = relative_volume is not None and relative_volume >= 1.2
    body = last.body
    # Single-candle patterns.
    if rng > 0 and body / rng <= 0.10:
        patterns.append(PatternMatch("DOJI", "NEUTRAL", len(bars)-1,
                                     "Corps très réduit : équilibre temporaire, contexte requis", volume_ok))
    if rng > 0 and last.lower_wick >= max(body * 2.0, rng * 0.55) and last.upper_wick <= rng * 0.20:
        patterns.append(PatternMatch("HAMMER_OR_HANGING_MAN", "CONTEXT_DEPENDENT", len(bars)-1,
                                     "Longue mèche basse; la tendance précédente détermine l'interprétation", volume_ok))
    if rng > 0 and last.upper_wick >= max(body * 2.0, rng * 0.55) and last.lower_wick <= rng * 0.20:
        patterns.append(PatternMatch("SHOOTING_STAR_OR_INVERTED_HAMMER", "CONTEXT_DEPENDENT", len(bars)-1,
                                     "Longue mèche haute; la tendance précédente détermine l'interprétation", volume_ok))
    if rng > 0 and body / rng >= 0.90 and max(last.upper_wick, last.lower_wick) / rng <= 0.05:
        patterns.append(PatternMatch("MARUBOZU_LIKE", last.direction, len(bars)-1,
                                     "Corps dominant avec mèches réduites", volume_ok))

    # Two-candle engulfing: bodies must engulf, not merely ranges.
    if len(bars) >= 2:
        prev = bars[-2]
        if prev.direction == "BEARISH" and last.direction == "BULLISH" and last.open <= prev.close and last.close >= prev.open:
            patterns.append(PatternMatch("BULLISH_ENGULFING", "BULLISH", len(bars)-1,
                                         "Le corps haussier englobe le corps baissier précédent", volume_ok))
        if prev.direction == "BULLISH" and last.direction == "BEARISH" and last.open >= prev.close and last.close <= prev.open:
            patterns.append(PatternMatch("BEARISH_ENGULFING", "BEARISH", len(bars)-1,
                                         "Le corps baissier englobe le corps haussier précédent", volume_ok))
        if last.high < prev.high and last.low > prev.low:
            patterns.append(PatternMatch("INSIDE_BAR", "NEUTRAL", len(bars)-1,
                                         "La bougie est contenue dans l'amplitude précédente", volume_ok))
        if last.high > prev.high and last.low < prev.low:
            patterns.append(PatternMatch("OUTSIDE_BAR", last.direction, len(bars)-1,
                                         "La bougie dépasse les deux extrêmes précédents", volume_ok))

    # Three-candle stars; middle real body must be small relative to first body.
    if len(bars) >= 3:
        a, b, c = bars[-3:]
        small_middle = b.body <= a.body * 0.35 and b.body <= c.body * 0.35
        if a.direction == "BEARISH" and small_middle and c.direction == "BULLISH" and c.close >= (a.open + a.close) / 2:
            patterns.append(PatternMatch("MORNING_STAR_LIKE", "BULLISH", len(bars)-1,
                                         "Séquence baissière, indécision, reprise au-delà du milieu du premier corps", volume_ok))
        if a.direction == "BULLISH" and small_middle and c.direction == "BEARISH" and c.close <= (a.open + a.close) / 2:
            patterns.append(PatternMatch("EVENING_STAR_LIKE", "BEARISH", len(bars)-1,
                                         "Séquence haussière, indécision, repli sous le milieu du premier corps", volume_ok))

    limitations = []
    if len(bars) < max(20, atr_period + 1, volume_period + 1):
        limitations.append("Historique trop court pour un contexte complet ATR/volume/tendance")
    if relative_volume is None:
        limitations.append("Volume relatif indisponible : historique de volume insuffisant ou nul")
    if atr_pct is None:
        limitations.append("ATR indisponible : historique insuffisant")
    limitations.extend(("Les figures sont des heuristiques, pas des probabilités de réussite",
                        "L'analyse ne connaît pas le carnet d'ordres, le spread ni le chemin intrabougie"))
    return CandleAnalysis(
        observations=len(bars), last_timestamp=last.timestamp,
        last_direction=last.direction,
        body_pct_of_range=(body / rng * 100 if rng else 0.0),
        upper_wick_pct_of_range=(last.upper_wick / rng * 100 if rng else 0.0),
        lower_wick_pct_of_range=(last.lower_wick / rng * 100 if rng else 0.0),
        close_location_pct=close_location, gap_pct=gap, atr_pct=atr_pct,
        relative_volume=relative_volume, trend=trend, structure=structure,
        patterns=tuple(patterns), limitations=tuple(limitations))
