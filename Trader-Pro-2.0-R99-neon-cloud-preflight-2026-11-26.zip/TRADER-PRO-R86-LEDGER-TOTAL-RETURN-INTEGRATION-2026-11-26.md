# Trader Pro 2.0 — R86 : intégration du registre au backtest total return

Base : R85.

## Modifications
- Ajout de `evaluate_total_return_history_from_ledger`, qui sélectionne les révisions connues à `as_of` avant de calculer le rendement total.
- Les corrections et annulations ne modifient pas rétroactivement les snapshots historiques antérieurs à leur enregistrement.
- La fonction existante reste disponible ; le moteur de stratégie et l'exécution broker ne sont pas modifiés.

## Validation
- 3 tests ciblés ajoutés.

## Limites
- Le registre reste fourni en mémoire ; aucune persistance Neon n'est activée à ce jalon.
