# Trader Pro 2.0 — R79 : métriques de backtest rendement total

Base : R78.

## Modifications
- Ajout de `evaluate_total_return_history` dans le moteur de backtest historique.
- La fonction réutilise le calculateur événementiel R78, puis calcule les métriques de rendement/CAGR sur l'indice de rendement total.
- Vérification que les événements sont validés et concernent le symbole demandé.
- Le rapport expose explicitement devise, politique de réinvestissement, nombre d'événements et base de prix.
- Le moteur de stratégie `run` et le chemin d'exécution ne sont pas modifiés.
- Le validateur de métriques rejette désormais `bpy` nul, négatif, booléen ou non entier au lieu de provoquer une division par zéro.

## Tests
4 tests ciblés ajoutés. Suite complète : 929 passed, 11 skipped, 205 subtests passed in 23.07s.

## Limites
- Il s'agit d'un utilitaire de recherche buy-and-hold, pas encore du moteur principal multi-stratégies.
- Aucune source d'événements réels n'est branchée.
- La qualité de la série brute et l'exhaustivité des événements restent à établir.
