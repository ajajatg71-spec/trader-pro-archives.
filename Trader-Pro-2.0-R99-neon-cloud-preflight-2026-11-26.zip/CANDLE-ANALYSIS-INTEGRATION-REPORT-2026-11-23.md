# Trader Pro 2.0 — intégration de l'analyse des chandeliers

Date : 23 novembre 2026  
Base : candidat R6 (`8e3497b491a6dc169335be719af260ae0f756c641b84649d9cf7ae83d8e01fc8`)  
Résultat : candidat R7 — intégration de recherche en lecture seule, non certifié pour le trading.

## Vérification préalable

Le ZIP R6 a été ouvert et inspecté. Il conserve les modules `candle_analysis.py`, `research_v1/quant/candles.py`, les contrats OHLCV, l'adaptateur Twelve Data et les tests. Le rapport de fondation du 21/11 indique explicitement que le premier module n'était pas connecté au pipeline stratégie. Les règles de recherche V1 utilisent déjà le module avancé `research_v1.quant.candles` par l'intermédiaire de `research_v1/quant/features.py`.

## Modification R7

- Ajout de `POST /api/research/candles/analysis` dans `app.py`.
- Requête : symbole, limite OHLCV, période ATR et période de volume.
- Source de données : exclusivement `MARKET_DATA_SERVICE.daily_ohlcv()` via `_research_ohlcv()`, qui applique la validation des barres et le contrôle de fraîcheur existant.
- Calcul : `analyze_candles()` ; retour de l'anatomie de la dernière bougie, gap, ATR %, volume relatif, tendance, structure, figures détectées et limites explicites.
- Réponse marquée `CANDLE_RESEARCH_ONLY`, `execution=NONE`, `orders_created=0`, `strategies_activated=0` et `profitability_guaranteed=false`.
- La route exige l'authentification existante et ne reçoit aucune dépendance broker ni service d'ordre.
- Ajout d'un test de contrat API qui vérifie la réponse et l'absence d'exécution.

## Validation exécutée

- Tests ciblés chandeliers + OHLCV + Twelve Data + contrat API : **40 passed, 4 subtests passed**.
- Suite complète : **719 passed, 11 skipped, 202 subtests passed**, code de sortie 0.
- `python -m compileall -q .` : réussi.
- Deux avertissements FastAPI existants concernant `on_event` déprécié.
- Les 11 tests ignorés sont des intégrations PostgreSQL qui nécessitent une base jetable configurée ; ils ne constituent pas des validations PostgreSQL réelles.

## Limites restantes

- Le fournisseur configuré dans le contrat actuel est journalier (`1day`). Pas de validation intraday ou multi-timeframe.
- La route expose l'analyse de base `candle_analysis.py`. Les 36 motifs du module avancé de recherche restent dans le moteur de recherche V1 ; ils ne sont pas tous exposés par cette route de diagnostic.
- Les tests utilisent un fournisseur OHLCV simulé ; aucun téléchargement réel Twelve Data n'a été certifié dans cette passe.
- Aucune preuve de performance prédictive, aucune activation de stratégie, aucun ordre Paper ou Live.
- Les figures ne doivent pas être transformées en signaux de trading avant validation point-in-time, walk-forward/OOS, frais, glissement, spread et liquidité.

## Sécurité

Aucune clé ou donnée de compte n'est ajoutée. Aucun ordre n'est créé. Le mode Live reste verrouillé.
