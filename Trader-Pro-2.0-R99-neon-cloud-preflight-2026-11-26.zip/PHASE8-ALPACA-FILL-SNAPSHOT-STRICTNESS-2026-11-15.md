# Phase 8 — Alpaca fill snapshot strictness (2026-11-15)

## Change

The Alpaca `FILL` activity reader previously filtered out rows whose side, ID, or order ID was missing. That could make an incomplete broker activity response look like a complete but smaller execution history.

The reader now fails closed when:
- the activity endpoint does not return a list;
- a row is not an object;
- a required execution field is missing (`id`, `order_id`, `symbol`, `side`, `qty`, `price`, `transaction_time`);
- the side is not `buy` or `sell`;
- an execution ID repeats across fetched pages;
- pagination does not advance;
- the page count is outside 1..100.

Valid rows retain the provider's original quantity/price strings and optional fee. The reader remains read-only and does not submit, replace, or cancel orders.

## Tests

Added six focused tests for malformed page payload, incomplete activity, invalid side, valid normalization, duplicate IDs across pages, and invalid page counts.

## Validation boundary

These are mocked/unit tests. They do not establish live Alpaca Paper connectivity or PostgreSQL integration. The authenticated Alpaca Paper workflow remains read-only and requires repository secrets configured by the operator.
