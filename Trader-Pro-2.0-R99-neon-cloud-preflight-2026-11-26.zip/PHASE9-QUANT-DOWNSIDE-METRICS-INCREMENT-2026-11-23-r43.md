# Trader Pro 2.0 — Phase 9 — R43

Date: 2026-11-23
Base: R42 archive (verified SHA-256 `b546cb27fc82ae5e2206db64569d973b528366d5309d0b28f3d3725d752da1f6`).

## Objective
Expose downside-risk and drawdown-duration measures in the core single-strategy backtest evaluator, not only in the separate portfolio research scoreboard.

## Changes
- Added annualized Sortino ratio using downside deviation from zero daily return.
- Added Calmar ratio using annualized CAGR divided by absolute maximum drawdown.
- Added maximum consecutive underwater duration in bars; a new/equal equity high resets the duration.
- Return `None` for Sortino when the sample has no downside observations and for Calmar when there is no drawdown; this avoids misleading infinite/undefined values.
- Kept the existing Sharpe, return, CAGR, drawdown, trade and exposure fields unchanged.
- Added regression tests for ordinary drawdowns, undefined ratios and one-observation samples.

## Validation
- `BROKER=sim pytest -q`: **791 passed, 11 skipped, 202 subtests passed**.
- `python -m unittest discover -q`: **711 tests OK**.
- `python -m compileall -q .`: passed.
- `node --check frontend/public/sw.js`: passed.
- `frontend/public/manifest.webmanifest` JSON parse: passed.
- Skips remain external PostgreSQL integration tests; no live database was available in this local validation.

## Limitations
These are measurement improvements, not evidence of profitability. The existing walk-forward logic remains a historical research/backtest facility. This increment does not authorize strategy activation, capital allocation, Paper orders or Live trading. Real PostgreSQL/Neon and Alpaca Paper validations remain outstanding.
