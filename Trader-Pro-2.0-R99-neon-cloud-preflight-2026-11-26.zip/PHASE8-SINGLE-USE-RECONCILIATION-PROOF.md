# Phase 8 — Single-use reconciliation proof

## Change

- Added `reconciliation_runs.consumed_at` through Alembic revision `9e5b7c2d4a61`.
- The repository locks the global safety row and proof row, verifies the proof is fresh and unused, then marks it consumed in the same transaction as the transition to `READY`.
- A proof cannot be replayed after a later `DEGRADED` / `RECONCILING` cycle.
- Added local tests for replay rejection and expired-proof rejection.
- Added an opt-in PostgreSQL race test in which two operator transitions compete for one proof; exactly one may succeed.

## Verification

- Pytest: 510 passed, 8 skipped, 92 subtests passed.
- Alembic: one head, `9e5b7c2d4a61`; fresh SQLite migration from base to head succeeded.
- Python compilation succeeded.
- PostgreSQL integration tests remain skipped because `TRADER_PRO_TEST_DATABASE_URL` is not configured. No real PostgreSQL concurrency claim is made.
