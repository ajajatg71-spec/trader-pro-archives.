# Phase 8 — Retry policy for independent periodic reconciliation

## Problem

The broker-event worker previously attempted a full periodic reconciliation, then waited the entire normal interval (300 seconds by default) after a failure. During a transient outage this delayed the next independent snapshot unnecessarily.

## Change

`scripts/run_broker_event_worker.py` now schedules periodic reconciliation independently of inbox events and applies capped exponential retry after failures:

- first failure: 5 seconds;
- second failure: 10 seconds;
- third failure: 20 seconds;
- fourth failure: 40 seconds;
- fifth and later failures: 60 seconds by default;
- after a successful complete reconciliation: reset failure count and return to the configured normal interval (300 seconds by default).

The worker still attempts a full reconciliation immediately after startup. Retry parameters are configurable using `--reconcile-retry-base-seconds` and `--reconcile-retry-max-seconds`, with strict argument bounds. The retry delay never exceeds the configured normal reconciliation interval.

## Safety boundaries

- The worker remains Paper-only and PostgreSQL-only.
- It performs read-only broker reconciliation; it does not submit or retry orders.
- A failed or truncated snapshot is not considered successful.
- This retry policy does not itself implement a global `READY/DEGRADED/RECONCILING/HALTED` state machine or authorize trading. That remains a separate integration task.

## Verification

- Unit tests cover success interval, exponential progression, cap, interval ceiling, and invalid parameters.
- Current full local suite: `python -m pytest -q` — 492 passed, 7 skipped, 92 subtests.
- `python -m unittest discover -q` — 488 passed.
- `python -m compileall -q .` — passed.
- Shell syntax checks and GitHub Actions YAML parsing — passed.
- PostgreSQL-specific tests remain skipped without a real PostgreSQL service. No authenticated Alpaca Paper connection was made.
