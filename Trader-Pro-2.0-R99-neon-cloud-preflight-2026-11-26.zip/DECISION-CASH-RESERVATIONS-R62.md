# Réservations de trésorerie — R62

## Fonctionnement existant conservé
Le service récupère un snapshot des ordres broker ouverts, le rapproche avec les intentions persistées en base, déduplique les ordres présents des deux côtés et effectue une réservation agrégée atomique lors de la création de l'intention de soumission. Les plafonds de trésorerie, d'exposition brute et par symbole sont conservés.

## Amélioration R62
Pour un achat partiellement exécuté, le montant engagé restant est calculé à partir de la quantité restante (`qty - filled_qty`) multipliée par `limit_price`, lorsque ces champs sont disponibles. Si le prix limite est absent mais que `notional`, `qty` et `filled_qty` sont disponibles, le nominal initial est proratisé selon la quantité restante.

Un ordre déclaré `partially_filled` sans quantité exécutée vérifiable, avec quantités incohérentes, ou sans base de calcul fiable bloque l'approbation. Aucun montant restant n'est deviné. Pour les autres achats ouverts, le nominal est utilisé ; à défaut, `qty × limit_price` est accepté.

## Limites
La logique est testée avec des snapshots simulés et des tests unitaires. La validation de la représentation exacte des ordres et des remplissages auprès d'un compte Alpaca Paper réel reste nécessaire. Ce travail ne valide pas le financement, le règlement, ni l'absence de marge sur un compte réel. Live demeure verrouillé.
