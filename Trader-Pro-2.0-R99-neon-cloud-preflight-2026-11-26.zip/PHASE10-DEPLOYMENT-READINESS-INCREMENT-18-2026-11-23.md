# Trader Pro 2.0 — incrément R39

Date : 23 novembre 2026  
Base : R38, sans modification des règles de trading ni activation du mode Live.

## Corrections apportées

1. Workflow frontend/Docker : suppression du cache npm configuré sur `frontend/package.json`. Le cache `setup-node` est normalement indexé sur un lockfile ; aucun lockfile n'est encore présent avant l'étape qui le génère. Le workflow génère toujours le vrai `package-lock.json`, exécute `npm ci`, le typecheck, le build Vite et le build Docker.
2. Runbook de déploiement : correction du prévol de configuration. Le script Python local ne charge pas automatiquement `.env`; il est désormais lancé via `docker compose run`, qui injecte les variables Compose. Le prévol est effectué avant le démarrage du service PostgreSQL et sans afficher les secrets.
3. Tests statiques : ajout de garde-fous pour éviter la réintroduction de ces deux erreurs de procédure.

## Vérifications exécutées

- `BROKER=sim pytest -q` : **785 passed, 11 skipped, 202 subtests passed**.
- Le test complet utilise le simulateur ; il ne constitue pas une validation PostgreSQL réelle ni une connexion Alpaca Paper.
- Aucun ordre Paper ou Live n'a été envoyé.
- Aucun build Docker, build Vite avec dépendances installées, workflow GitHub Actions ou test Neon n'a été exécuté dans cet environnement.

## Blocages restant à lever

- Exécuter le workflow frontend/Docker dans un runner avec accès npm et examiner le lockfile généré.
- Exécuter le workflow PostgreSQL sur PostgreSQL 16, y compris migration, tests d'intégration, sauvegarde et restauration.
- Effectuer le contrôle Alpaca Paper en lecture seule avec les secrets Paper configurés dans l'environnement protégé.
- Effectuer ensuite seulement une validation Paper avec ordre/cancel, qui nécessite une autorisation explicite distincte.

R39 améliore la fiabilité de la procédure CI/déploiement ; il ne certifie pas le système comme opérationnel.
