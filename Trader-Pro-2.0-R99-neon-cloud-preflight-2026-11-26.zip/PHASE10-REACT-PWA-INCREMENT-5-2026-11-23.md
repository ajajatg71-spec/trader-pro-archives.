# Trader Pro 2.0 — Phase 10 React/PWA increment 5 (R26)

Date: 2026-11-23
Base: R25

## Delivered

- Versioned service-worker cache (`trader-pro-static-v3`) with cleanup limited to this app's own cache namespace.
- Static asset caching is restricted to same-origin GET requests under `/assets/` and a short explicit public-shell allowlist.
- API paths, cross-origin resources, non-GET requests, authenticated navigation documents and login pages are never cached.
- Navigations remain network-only and fall back to a neutral offline page; financial/account data are not persisted by the service worker.
- React clears in-memory account, risk, orders and health state immediately when the browser emits `offline`.
- Automatic refresh is suspended while the document is hidden or the browser is offline; online restoration triggers a refresh.
- Added accessible skip navigation and dashboard/research anchor navigation.
- Added an install button when the browser emits `beforeinstallprompt`.
- Expanded the PWA manifest with French locale, scope, standalone display, orientation and icon purposes.
- No trading, order, pause, rebalance, strategy activation or portfolio mutation controls were added.

## Validation

- Full Python suite: **756 passed, 11 skipped, 202 subtests passed**.
- 11 skipped tests require an external PostgreSQL environment; no claim of real Neon/PostgreSQL validation is made.
- Frontend contract tests: **14 passed**.
- `python -m compileall -q .`: passed.
- `node --check frontend/public/sw.js`: passed.
- ZIP integrity (`ZipFile.testzip()`): passed; 342 entries.
- Frontend production build / TypeScript typecheck: **not verified**. `npm install --ignore-scripts --no-audit --no-fund --prefer-offline` timed out in this environment and dependencies are not available. No compiled `dist` output is claimed.
- No browser-device test, Lighthouse audit, Neon test, Alpaca Paper API test, or live order was performed.

## Security and deployment notes

- The service worker intentionally does not make the authenticated terminal usable with cached financial information offline. Offline mode is informational only and the client clears displayed financial state.
- Do not deploy R26 as the production frontend until dependencies are installed, `npm run typecheck` and `npm run build` pass, and real-browser tests validate session, CSRF, logout, offline/online transitions and mobile layouts.
- Existing backend legacy dashboard fallback remains intact until a compiled React `dist/index.html` exists.
- Live trading remains locked.
