# Trader Pro 2.0 — R35 : cycle de vie ASGI et stockage runtime
Date : 23 novembre 2026

## Changements
- Remplacement du hook FastAPI `@app.on_event("startup")` déprécié par un gestionnaire ASGI `lifespan`.
- Le contrôle PostgreSQL au démarrage, la restauration des propositions Paper et le lancement du scheduler restent exécutés au démarrage ASGI.
- Le chemin `TRADER_STATE_DIR` introduit en R34 pilote désormais explicitement état, historique et sauvegardes.
- `StateService.load()` recherche les sauvegardes dans le répertoire configuré, et non plus dans un `backups/` relatif au répertoire courant.
- La sauvegarde automatique transmet les chemins absolus réels du service d'état.
- Ajout de tests de contrat lifespan et de restauration depuis le répertoire de sauvegarde configuré.

## Validations exécutées sur R35
- `BROKER=sim pytest -q` : **781 passed, 11 skipped, 202 subtests passed**.
- `python -m unittest discover -q` : **708 tests OK**.
- `python -m compileall -q .` : réussi.
- `node --check frontend/public/sw.js` : réussi.
- `frontend/public/manifest.webmanifest` : JSON valide.
- Les avertissements de dépréciation FastAPI liés à `@app.on_event` ont disparu dans le rapport pytest.

## Limites
- Les 11 tests PostgreSQL sont toujours conditionnés à une URL PostgreSQL jetable et au consentement explicite `TRADER_PRO_TEST_DATABASE_DISPOSABLE=YES`.
- Le registre npm est toujours inaccessible dans cet environnement ; `package-lock.json` n'a pas été généré et le build React n'est pas certifié.
- Docker/Podman non disponibles ; image non construite/démarrée.
- PostgreSQL réel, restauration sur serveur, Neon, Alpaca Paper et HTTPS distant non validés.
- Aucun ordre réel envoyé ; mode Live verrouillé.

## Décision
R35 améliore le cycle de vie FastAPI et fiabilise la persistance du répertoire runtime. Candidat de livraison, non certifié production.
