# Trader Pro 2.0 — R89 : invariants du calcul de rendement total

Base : R88.

## Modifications
- Ajout de tests déterministes couvrant dividendes multiples à la même ex-date, reverse split, combinaison split/dividende et identifiants distincts.
- Vérification que les événements distincts sont agrégés sans être dédupliqués à tort et que les ratios de split conservent la valeur économique.
- Aucun changement de formule de calcul ; cette version renforce la preuve par tests.

## Validation
- 4 tests ciblés ajoutés. Tests ciblés : 18 passed.

## Limites
- Ces invariants synthétiques ne remplacent pas une comparaison avec des événements réels vérifiés.
