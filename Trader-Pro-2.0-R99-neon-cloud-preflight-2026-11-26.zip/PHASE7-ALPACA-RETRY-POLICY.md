# Phase 7 — Politique de reprise du fournisseur Alpaca/IEX

L'adaptateur de données de liquidité applique maintenant une politique de reprise courte et bornée afin de mieux tolérer les incidents transitoires sans retarder indéfiniment l'autorisation pré-trade.

- Statuts rejouables : HTTP 429, 500, 502, 503 et 504.
- Exceptions rejouables : timeout et erreur de connexion.
- Statuts client non rejouables : notamment 400, 401 et 403.
- Nombre de reprises par défaut : 2, configurable de 0 à 3.
- Temporisation exponentielle par défaut : 250 ms, plafonnée à 2 secondes.
- `Retry-After` (secondes ou date HTTP) est respecté, avec un plafond de 2 secondes.
- Chaque nouvelle tentative réutilise le même endpoint et les mêmes paramètres ; aucune route d'ordre n'est appelée.
- À l'épuisement des tentatives, une erreur fournisseur assainie remonte à l'appelant. Le contrôle de liquidité refuse alors l'ordre (fail-closed).

La politique ne met pas en cache une ancienne cotation et ne transforme pas une erreur fournisseur en approbation. Les tests utilisent des réponses HTTP simulées ; l'accès externe Alpaca et le comportement réel sous quota restent à vérifier avec des identifiants Paper autorisés.
