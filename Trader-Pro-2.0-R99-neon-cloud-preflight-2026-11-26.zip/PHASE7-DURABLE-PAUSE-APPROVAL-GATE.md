# Phase 7 — durable pause recheck at order approval

Date: 11 November 2026

## Finding

The durable pause state was restored at application startup, but order approval subsequently relied on the process-local in-memory flag. In a multi-worker deployment, a worker could retain a stale unpaused value after another worker activated the durable kill switch.

## Correction

`OrderService` now accepts an `operational_pause_reader`. When configured, `approve()` queries the durable state before any portfolio/risk checks and before staging/submitting the order. The database state is authoritative across workers. A read error, malformed response, or missing state (reported as paused by the repository) blocks approval and forces the local in-memory state to paused. The FastAPI app injects this reader from `OrderRepository` when database persistence is active.

## Local verification

- `python -m pytest -q`: **413 passed, 5 skipped, 88 subtests passed**.
- `python -m unittest discover -q`: **409 tests passed**.
- Prior SQLite Alembic migration smoke test reached `f3b8c2d91a64` (head).
- Prior FastAPI import smoke tests passed in simulation and non-simulation configurations (35 routes each); the new reader is wired at app construction.

## Limitations

This recheck narrows the stale-worker window to the interval between the database read and broker submission. A stronger cross-process guarantee requires an execution lease/lock held across approval and broker submission, with careful timeout and recovery semantics. Do not describe the current implementation as a distributed atomic kill switch. PostgreSQL `SELECT FOR UPDATE` concurrency and the full multi-process path still require the opt-in real PostgreSQL integration run. Live remains disabled.
