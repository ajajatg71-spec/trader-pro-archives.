# Trader Pro 2.0 — R50
## Phase 9 — Comparateur adaptatif vs paramètres fixes
Date : 23 novembre 2026

### Objectif
Ajouter une comparaison appariée entre la sélection walk-forward adaptative (R49) et un témoin à paramètres fixes, sans fuite de données hors échantillon.

### Changement
- Le témoin fixe les paramètres sélectionnés par la toute première fenêtre de validation.
- Ces mêmes paramètres sont conservés pour toutes les fenêtres OOS suivantes.
- Pour chaque fenêtre, adaptatif et témoin utilisent exactement les mêmes dates, données, simulateur, frais, slippage et capital initial/reset.
- Le rapport expose le rendement OOS du témoin, son Sharpe et son drawdown, l'écart de rendement adaptatif moins fixe, la moyenne des écarts et la proportion de fenêtres où l'adaptatif surperforme.
- La première fenêtre est identique par construction : elle sélectionne les paramètres de référence du témoin. Elle ne constitue donc pas une preuve de supériorité.

### Contrôles anti-fuite
- Les paramètres du témoin sont choisis sur la validation de la première fenêtre uniquement.
- Aucun résultat OOS n'est utilisé pour sélectionner ou modifier les paramètres du témoin.
- Les fenêtres restent indépendantes et redémarrent avec le capital initial. Ce n'est toujours PAS un portefeuille continu.
- Aucun accès broker, ordre, activation de stratégie ou autorisation de capital.

### Validation locale
- pytest : 801 passed, 11 skipped, 202 subtests passed.
- unittest : 719 tests OK.
- compileall : exit 0.
- Le démarrage Python affiche un avertissement indépendant de warmup du runtime tableur, mais les commandes de tests terminent avec code 0.

### Limites
- Le comparateur fixe est un témoin de référence choisi lors de la première validation, pas un benchmark optimisé séparément.
- Les résultats dépendent des données, de l'univers, du traitement des événements d'entreprise et des hypothèses de coûts.
- Aucun résultat de performance n'est présenté comme preuve de rentabilité.
- Les validations PostgreSQL/Neon réelles et Alpaca Paper restent obligatoires avant toute déclaration d'opérationnalité. Live reste verrouillé.

### Fichiers modifiés
- research_v1/backtesting/walk_forward.py
- tests/test_walk_forward_parameter_search.py
