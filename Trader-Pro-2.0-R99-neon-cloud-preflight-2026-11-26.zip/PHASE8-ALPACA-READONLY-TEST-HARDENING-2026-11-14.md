# Trader Pro 2.0 — Alpaca Paper read-only test hardening

Date: 2026-11-14

## Change

Added `tests/test_alpaca_paper_readonly_script.py` with eight isolated tests for `scripts/verify_alpaca_paper_readonly.py`.

Coverage:
- valid read-only path calls account, positions, clock and SPY bars;
- simulated broker mode is refused before any broker request;
- non-Paper endpoint is refused;
- missing credentials are refused;
- broker-blocked account fails closed;
- empty or inconsistent market data fails closed;
- malformed account response fails closed.

The script under test only imports read methods (`account`, `positions`, `clock`, `bars3`). The test suite uses mocked broker functions and sends no network request or order.

## Local verification

- Focused tests: **8 passed**.
- Full pytest suite: **527 passed, 10 skipped, 92 subtests passed**.
- unittest discovery: **523 tests, OK**.
- Python syntax compilation: **124 files, 0 errors**.
- All 4 GitHub Actions workflow YAML files parsed successfully.
- PostgreSQL shell scripts passed `bash -n`.

The 10 skipped tests are opt-in PostgreSQL integration tests; no PostgreSQL service is available in this runtime.

## Not validated

- No GitHub Actions workflow was dispatched or observed running.
- No authenticated Alpaca Paper API request was made.
- No PostgreSQL migration/integration/backup/restore run against a live PostgreSQL server was performed.
- No order was submitted, cancelled, replaced, or otherwise mutated.

## Phase gate

Phase 8 remains OPEN pending real PostgreSQL integration/backup-restore and authenticated Alpaca Paper read-only validation. The separately gated one-order/cancel smoke remains subject to explicit authorization. Phase 9 remains gated. Live trading remains disabled.
