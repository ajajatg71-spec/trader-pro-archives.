# Trader Pro 2.0 — R94: Alpaca live-payload currency resolution

Date: 2026-11-26

## Finding from external validation

The connected Alpaca corporate-actions endpoint returned US cash-dividend rows
without a `currency` field. R93's reader rejected such a row before the R93
ingestion layer could invoke its explicit `currency_resolver`. This made the
resolver unreachable for the exact provider response shape observed live.

## Change

- The provider reader now preserves a missing currency as `None`.
- It still rejects malformed non-empty currency values.
- The ingestion service remains fail-closed: a missing currency cannot be
  persisted without an explicit resolver.
- Added end-to-end regression tests using the observed Alpaca payload shape,
  including explicit USD mapping, first persistence, and idempotent replay.
- Updated the older adapter test to reflect the corrected contract.

## Validation

- Full test suite and targeted tests are recorded after execution.
- PostgreSQL/Neon schema and trigger were independently checked using a
  disposable Neon migration branch. Actual Alpaca historical bars and
  corporate-action records were fetched through the connected Alpaca Paper
  integration; no order was placed.
- The 11 opt-in PostgreSQL integration tests remain guarded to local disposable
  PostgreSQL only; remote Neon checks are executed separately without bypassing
  that guard.
- No Live orders. No production database migration. `trader_pro_test` only.

## Scope

This is an additive R94 patch over R93. No historic release/archive is deleted.

## Final test results

- Targeted R84/R91/R92/R93/R94 coverage: **29 passed**.
- Full suite: **1004 passed, 11 skipped, 205 subtests passed**.
- `compileall`: passed.
- The 11 skips are the intentionally opt-in local-PostgreSQL integration tests; Neon was checked independently through its isolated branch and SQL interface.
