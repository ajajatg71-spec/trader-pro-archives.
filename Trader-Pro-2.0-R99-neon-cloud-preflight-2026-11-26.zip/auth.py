"""Double authentification TOTP (RFC 6238) et jetons de session signés, sans dépendance externe."""
import base64, hashlib, hmac, struct, time

def totp(secret, t=None, digits=6, step=30):
    s = secret.replace(" ", "").upper()
    key = base64.b32decode(s + "=" * (-len(s) % 8))
    h = hmac.new(key, struct.pack(">Q", int((time.time() if t is None else t) // step)), hashlib.sha1).digest()
    o = h[-1] & 15
    return str((struct.unpack(">I", h[o:o + 4])[0] & 0x7FFFFFFF) % 10 ** digits).zfill(digits)

def matching_totp_counter(secret, code, window=1, t=None, step=30):
    """Return the matched RFC 6238 counter, or None; callers persist replay state."""
    now = time.time() if t is None else t
    current = int(now // step)
    supplied = (code or "").strip()
    if len(supplied) != 6 or not supplied.isdigit():
        return None
    for counter in range(current - window, current + window + 1):
        if counter < 0:
            continue
        if hmac.compare_digest(totp(secret, counter * step, step=step), supplied):
            return counter
    return None

def verify_totp(secret, code, window=1, t=None):
    return matching_totp_counter(secret, code, window=window, t=t) is not None

def make_token(key, ttl=43200, now=None):
    iat = int(time.time() if now is None else now); exp = iat + ttl
    return f"{iat}.{exp}.{hmac.new(key, f'{iat}.{exp}'.encode(), hashlib.sha256).hexdigest()}"

def check_token(key, tok, revoke_before=0.0, now=None):
    try:
        iat, exp, sig = tok.split(".", 2)
        good = hmac.compare_digest(hmac.new(key, f"{iat}.{exp}".encode(), hashlib.sha256).hexdigest(), sig)
        return good and int(exp) > (time.time() if now is None else now) and int(iat) >= revoke_before
    except Exception:
        return False
