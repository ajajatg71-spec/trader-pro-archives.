# Trader Pro 2.0 — R99
## Précontrôle SQLAlchemy Neon exécutable dans un runner cloud indépendant

Date : 26 novembre 2026  
Base : R98  
Cible autorisée : `trader_pro_test` uniquement  
Tête Alembic attendue : `f19a6c3d8b42`

## Objectif

Réduire la dépendance à Replit et au poste Windows en préparant un contrôle direct SQLAlchemy → Neon depuis un runner GitHub Actions, sans autoriser d'écriture, de migration ou de test destructif sur Neon.

## Changement R99

Ajout de `.github/workflows/neon-readonly-preflight.yml` :
- déclenchement manuel uniquement (`workflow_dispatch`) ;
- Python 3.12 et dépendances projet ;
- URL fournie exclusivement par le secret GitHub `TRADER_PRO_TEST_DATABASE_URL` ;
- exécution du précontrôle SQLAlchemy déjà durci (hôte Neon, TLS, base exacte, transaction READ ONLY, tables requises, tête Alembic et trigger append-only) ;
- aucun affichage volontaire de l'URL, aucune migration, aucun test d'écriture et aucun ordre broker.

Ajout d'un test statique empêchant que ce workflow devienne un déclenchement push/PR ou appelle le script d'ordre Paper.

## Résultats des tests R99

| Validation | Résultat |
|---|---:|
| Tests ciblés (workflow R99 + précontrôle Neon + E2E Paper simulé) | 10 réussis |
| Suite Pytest complète | 1 014 réussis, 11 ignorés, 205 sous-tests réussis |
| Unittest | 849 réussis |
| Compileall | Réussi |

Les 11 tests ignorés sont les tests PostgreSQL réels protégés par garde-fou ; ils ne sont pas comptabilisés comme réussis.

## Limites de l'exécution dans cette session

Le runner courant ne possède ni Docker/Podman, ni PostgreSQL local, ni `psql`, ni `psycopg`. La résolution DNS sortante échoue pour Neon et Alpaca depuis le conteneur. Il est donc impossible d'exécuter ici les 11 tests PostgreSQL ou le précontrôle Python SQLAlchemy direct vers Neon.

Le connecteur Neon confirme toutefois séparément, via son API SQL, que `trader_pro_test` est PostgreSQL 18.7, à la tête `f19a6c3d8b42`, avec 17 tables publiques, trigger append-only présent et état `RECONCILING`. Ce contrôle API ne constitue pas une preuve de connexion SQLAlchemy. Le runner local ne résout pas les hôtes Neon/Alpaca (échec DNS), et le pilote `psycopg` est absent.

Le compte Alpaca Paper est actif, sans ordre ni position, avec `trading_blocked=false`. L'horloge Alpaca confirme que le marché est fermé et donne la prochaine ouverture au 27 novembre à 09:30 ET (clôture anticipée à 13:00 ET). Aucun ordre n'a été envoyé. Le cycle Paper réel reste à réaliser pendant cette séance, avec cotation IEX fraîche et annulation confirmée.

## Pour activer le parcours cloud

Dans un dépôt GitHub privé contrôlé, ajouter le secret de dépôt `TRADER_PRO_TEST_DATABASE_URL` contenant l'URL TLS de la base Neon `trader_pro_test`, puis lancer manuellement le workflow **Neon SQLAlchemy read-only preflight**. Ne jamais utiliser `neondb`, `trader_pro_restore` ou la base de production.

Le workflow PostgreSQL existant doit ensuite tourner sur son service Postgres 16 local éphémère : ne jamais pointer ses tests destructifs vers Neon.

## Sécurité

- `system_safety_state` reste `RECONCILING`.
- Trading Live non autorisé et non activé.
- Aucun ordre Paper créé dans R99.
- Aucun changement de schéma Neon.
- Aucune modification de `neondb` ou `trader_pro_restore`.
- Aucun secret inclus dans l'archive.

**Conclusion :** R99 prépare un troisième environnement indépendant de Replit pour vérifier réellement SQLAlchemy → Neon dès qu'un dépôt GitHub privé et son secret sont accessibles. Le workflow n'a pas pu être déclenché depuis cette session car aucun dépôt GitHub accessible n'a été trouvé.
