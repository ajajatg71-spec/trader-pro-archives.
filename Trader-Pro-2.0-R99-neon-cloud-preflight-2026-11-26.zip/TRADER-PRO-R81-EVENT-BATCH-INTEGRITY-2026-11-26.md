# Trader Pro 2.0 — R81 : intégrité des lots d'opérations sur titres

Base : R80.

## Modifications
- Ajout de `validate_corporate_action_batch` pour contrôler l'intégrité d'un lot fournisseur avant traitement point-in-time.
- Rejet des identifiants dupliqués au sein d'une même source.
- Rejet des doublons économiques ambigus lorsque l'identifiant fournisseur manque.
- Des événements identiques provenant de sources distinctes ou portant des IDs distincts restent différenciables.
- `point_in_time_events` utilise désormais ce contrôle commun.

## Validation
- Tests ciblés corporate actions : 37 passed, 3 subtests passed.
- Suite complète : 939 passed, 11 skipped, 205 subtests passed.
- Les 11 tests ignorés nécessitent une URL PostgreSQL jetable.
- Les tests n'envoient aucun ordre.

## Limites
- Ce contrôle ne prouve pas l'exhaustivité d'un fournisseur et ne remplace pas un historique de révisions.
- La base Neon `trader_pro_test` est accessible en lecture et identifiée sous PostgreSQL 18.7, mais elle est vide ; aucune migration n'a été appliquée.
