# Trader Pro 2.0 — Phase 2 RiskService

## Changes
- Added `services/risk.py` with an injected `RiskService` for risk snapshot orchestration.
- Replaced the `app.py` risk snapshot implementation with a delegation to `RISK_SERVICE.snapshot()`.
- Kept the original V1 financial functions delegated to `core.py`, `portfolio.py`, and `risklib.py`.
- Added unit tests for daily loss/drawdown/alerts, unavailable market data, advanced metrics, and zero equity.

## Verification
- `python -m pytest -q`: 142 passed.
- `python -m unittest discover -s tests -q`: 142 passed.
- `python -m compileall -q .`: passed.
- FastAPI application import: passed; 31 routes registered; `/api/risk` present.
- `core.py`, `scoring.py`, `risklib.py`, `portfolio.py`, `indicators.py`, and `backtest.py` compare byte-for-byte identical to the V1 source.
- Tests use injected/fake providers; no broker order was submitted and no live/paper account was connected.

## Scope
Phase 2 remains in progress. This change extracts risk snapshot orchestration only; order and strategy services, configuration cleanup, and final integration review remain outstanding.
- Removed the now-unused duplicate `advanced()` implementation from `app.py`; market-data cache and today's-order counter remain injected helpers used by `RiskService`.
