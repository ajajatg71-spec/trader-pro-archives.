# Phase 7 — Coupe-circuit opérationnel durable

## Fonction livrée

Le système conserve désormais le statut du coupe-circuit dans `risk_control_state` (ligne singleton `id=1`) : `paused`, `reason`, `actor`, `updated_at`. Chaque changement écrit également un événement immuable dans `audit_events`, dans la même transaction.

### Garanties de comportement

- Une activation manuelle est persistée avant le changement de l'état mémoire.
- Une reprise manuelle est également auditée.
- Un arrêt automatique issu des contrôles de perte journalière, drawdown ou perte hebdomadaire est persisté avec l'acteur `risk_engine`.
- À l'initialisation, l'application recharge la pause durable avant de traiter les requêtes.
- Si la lecture ou l'écriture DB échoue, le système ne prétend pas avoir enregistré la transition ; une erreur de lecture au démarrage empêche le démarrage normal.
- En mode local sans `DATABASE_URL`, le mécanisme historique d'état local continue de fonctionner ; il ne doit pas être présenté comme une persistance DB.

## Migration

`alembic upgrade head` inclut la création de `risk_control_state`. La migration de fusion `e8a19c42d7b1` réunit aussi la branche existante `position_snapshots` et la nouvelle branche du coupe-circuit.

## Validation effectuée

- Tests repository + service : 32 réussis.
- Suite complète pytest : 381 réussis, 3 ignorés, 76 sous-tests réussis.
- Migration complète depuis une base SQLite vide : réussie, une seule tête Alembic `e8a19c42d7b1`.
- Import FastAPI en simulation : 35 routes enregistrées.
- Compilation Python : réussie.

## Non validé / limites

- Pas de test sur une instance PostgreSQL réelle ni de test multi-processus concurrent.
- Pas de validation d'un redémarrage de déploiement complet sur serveur externe.
- Le coupe-circuit ne remplace pas la réconciliation broker ni les contrôles pré-trade.
- Trading Live reste désactivé ; validation cible Paper uniquement.
