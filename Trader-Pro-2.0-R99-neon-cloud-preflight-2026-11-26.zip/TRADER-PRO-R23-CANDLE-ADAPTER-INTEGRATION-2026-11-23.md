# Trader Pro 2.0 — R23 : adaptateur chandeliers → exécution de recherche traçable

Date : 23 novembre 2026  
Base : R22 (`Trader-Pro-2.0-consolide-candidat-2026-11-23-r22.zip`)

## Objectif

Raccorder l'évaluateur backend `evaluate_candle_confluence` au contrat de provenance R22, sans route publique, sans saisie de statistiques par le navigateur et sans connexion au moteur d'ordres.

## Changements

- Ajout de `services/candle_research_adapter.py`.
- Le service accepte un manifeste `candle_confluence` et un snapshot OHLCV structuré.
- Il lance `evaluate_candle_confluence` avec les paramètres immuables déclarés dans les métadonnées du protocole.
- Il extrait uniquement les p-values brutes des comparaisons appariées `policy` contre `candle_only`.
- Les hypothèses `candle_only` sont exclues car elles ne disposent pas d'une comparaison appariée à elles-mêmes.
- Si une hypothèse pré-enregistrée ne dispose pas d'une p-value appariée calculable, l'adaptateur échoue explicitement : aucune valeur de substitution et aucun verrouillage partiel.
- Ajout d'un test de raccordement entre l'adaptateur, `ResearchExecutionService` et `HypothesisRegistry`.
- Aucune route HTTP, aucun accès broker, aucun ordre, aucune autorisation de sélection ou d'allocation ajoutés.

## Validation locale

- Tests ciblés adaptateur + provenance : **8 passed**.
- Suite complète avec `BROKER=sim` : **747 passed, 11 skipped, 202 subtests passed**.
- Compilation Python (`compileall`) : réussie.
- Alembic : une seule tête, `ea21c7b4d903`.
- 11 tests ignorés : intégrations PostgreSQL externe non disponibles dans cet environnement.
- 2 avertissements de dépréciation FastAPI (`on_event`).

## Limites non certifiées

- Le test de raccordement utilise un évaluateur simulé pour isoler et vérifier le contrat de provenance ; il ne constitue pas une validation statistique sur des données de marché réelles.
- Pas de validation de la qualité, complétude ou licence d'un flux OHLCV externe.
- Pas d'application de migration sur Neon/PostgreSQL réel.
- Pas de build React certifié.
- Pas de test authentifié Alpaca Paper ni de soumission d'ordre.
- Les résultats restent descriptifs/recherche uniquement. Aucune sélection automatique, allocation de capital ou exécution Live n'est autorisée.

## Décision

R23 améliore la chaîne backend jusqu'au raccordement testé adaptateur → exécuteur → registre. Prochaine étape : construire une commande/service de recherche contrôlé qui charge un snapshot OHLCV vérifiable, crée ou retrouve une famille pré-enregistrée, exécute l'évaluateur et archive le manifeste et les empreintes. Avant tout usage réel, tester la migration et les transactions sur une base PostgreSQL dédiée, puis valider la provenance des données.
