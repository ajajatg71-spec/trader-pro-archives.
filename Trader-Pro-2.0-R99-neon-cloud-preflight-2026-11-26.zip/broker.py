"""Alpaca Paper-only connector with fail-closed account verification."""
import threading
import time
from datetime import datetime, timezone
from urllib.parse import urlsplit
import requests
from config import BASE, KEY, SECRET
from broker_errors import BrokerError

PAPER_BASE = "https://paper-api.alpaca.markets"
DATA = "https://data.alpaca.markets"


class BrokerMutationUnknown(BrokerError):
    """A write may have reached Alpaca; never repeat it automatically."""

    def __init__(self, message="Résultat de la requête incertain; réconciliation requise."):
        super().__init__(message, 503)


class PaperAccountUnavailable(BrokerError):
    """The Paper account authenticated but Alpaca currently blocks trading."""

    def __init__(self):
        super().__init__("Compte Alpaca Paper bloqué ou inactif", 423)


_HEALTH_LOCK = threading.RLock()
_HEALTH = {
    "provider": "alpaca_paper",
    "paper_confirmed": False,
    "connection_health": "unavailable",
    "last_successful_check": None,
    "last_check_at": None,
    "confirmation_basis": None,
    "message": "Connexion Alpaca Paper non vérifiée.",
    "_verified_monotonic": 0.0,
    "_account": None,
}
_HEALTH_TTL_SECONDS = 15


def _now_iso():
    return datetime.now(timezone.utc).isoformat()


def _set_unavailable(message, *, paper_confirmed=None):
    with _HEALTH_LOCK:
        if paper_confirmed is not None:
            _HEALTH["paper_confirmed"] = paper_confirmed
        _HEALTH["connection_health"] = "unavailable"
        _HEALTH["last_check_at"] = _now_iso()
        _HEALTH["message"] = message
        _HEALTH["_verified_monotonic"] = 0.0


def _safe_status():
    with _HEALTH_LOCK:
        return {key: value for key, value in _HEALTH.items() if not key.startswith("_")}


def _validate_account(account):
    from decimal import Decimal, InvalidOperation

    if not isinstance(account, dict):
        raise BrokerError("Réponse du compte Alpaca Paper invalide")
    if not isinstance(account.get("id"), str) or not account["id"].strip():
        raise BrokerError("Identité du compte Alpaca Paper absente")
    if not isinstance(account.get("status"), str) or not account["status"].strip():
        raise BrokerError("Statut du compte Alpaca Paper absent")
    for field in ("equity", "cash"):
        try:
            value = Decimal(str(account[field]))
            if not value.is_finite() or value < 0:
                raise ValueError
        except (KeyError, InvalidOperation, TypeError, ValueError):
            raise BrokerError("Données financières du compte Alpaca Paper invalides") from None
    for field in ("account_blocked", "trading_blocked", "trade_suspended_by_user"):
        if not isinstance(account.get(field), bool):
            raise BrokerError("Drapeaux de sécurité du compte Alpaca Paper incomplets")
    return account


def _check_account_ready(account):
    _validate_account(account)
    if (account["status"].strip().upper() != "ACTIVE"
            or account["account_blocked"]
            or account["trading_blocked"]
            or account["trade_suspended_by_user"]):
        with _HEALTH_LOCK:
            _HEALTH.update({
                "paper_confirmed": True,
                "connection_health": "unavailable",
                "last_check_at": _now_iso(),
                "last_successful_check": _now_iso(),
                "confirmation_basis": "authenticated_paper_api_endpoint",
                "message": "Le compte Paper est bloqué ou inactif.",
                "_verified_monotonic": 0.0,
                "_account": None,
            })
        raise PaperAccountUnavailable()


def _request_once(method, path, *, base=None, **kwargs):
    method = str(method).upper()
    endpoint = BASE if base is None else base
    if not isinstance(path, str) or not path.startswith("/") or path.startswith("//"):
        raise BrokerError("Chemin Alpaca invalide")
    if endpoint == BASE:
        if not is_approved_paper_url(endpoint):
            _set_unavailable("Hôte de trading non autorisé.", paper_confirmed=False)
            raise BrokerError("Seule l'URL officielle Alpaca Paper est autorisée")
    elif endpoint == DATA:
        if (method != "GET"
                or not path.startswith(("/v2/stocks/", "/v1beta1/news"))):
            raise BrokerError("Route de données Alpaca non autorisée")
    else:
        raise BrokerError("Hôte Alpaca non autorisé")
    if not KEY.strip() or not SECRET.strip():
        _set_unavailable("Identifiants Paper absents.", paper_confirmed=False)
        raise BrokerError("Identifiants Alpaca Paper non configurés")

    try:
        response = requests.request(
            method,
            endpoint + path,
            headers=H,
            timeout=15,
            allow_redirects=False,
            **kwargs,
        )
    except requests.RequestException as exc:
        if method in {"POST", "PUT", "PATCH", "DELETE"}:
            raise BrokerMutationUnknown() from None
        raise BrokerError("Alpaca Paper indisponible") from None

    status = int(response.status_code)
    if 300 <= status < 400:
        if method in {"POST", "PUT", "PATCH", "DELETE"}:
            raise BrokerMutationUnknown("Redirection inattendue; résultat incertain, réconciliation requise.")
        raise BrokerError("Redirection Alpaca bloquée", status)
    if not response.ok:
        if method in {"POST", "PUT", "PATCH", "DELETE"} and status >= 500:
            raise BrokerMutationUnknown("Alpaca Paper n'a pas confirmé la requête; réconciliation requise.")
        # Never include a provider response body: it can contain account data.
        raise BrokerError(f"Requête Alpaca Paper refusée (HTTP {status})", status)
    if not response.content:
        if method in {"POST", "PUT", "PATCH", "DELETE"}:
            raise BrokerMutationUnknown("Réponse de mutation vide; résultat incertain, réconciliation requise.")
        return {}
    try:
        return response.json()
    except (ValueError, requests.RequestException):
        if method in {"POST", "PUT", "PATCH", "DELETE"}:
            raise BrokerMutationUnknown("Réponse de mutation illisible; résultat incertain, réconciliation requise.") from None
        raise BrokerError("Réponse Alpaca Paper illisible", status) from None

def is_approved_paper_url(value):
    try:
        parsed = urlsplit(value)
        return (parsed.scheme == "https" and parsed.hostname == "paper-api.alpaca.markets"
                and parsed.port in (None, 443) and parsed.username is None and parsed.password is None
                and parsed.path in ("", "/") and not parsed.query and not parsed.fragment)
    except (TypeError, ValueError):
        return False


if not is_approved_paper_url(BASE):
    raise SystemExit("Trading réel désactivé : seule l'URL officielle HTTPS Alpaca Paper est autorisée.")
H = {"APCA-API-KEY-ID": KEY.strip(), "APCA-API-SECRET-KEY": SECRET.strip()}

def _request_with_retry(method, path, *, retries=3, base=None, **kw):
    """Retry safe GETs only; all writes are one-shot."""
    method = str(method).upper()
    attempts = max(1, retries) if method in {"GET", "HEAD"} else 1
    for attempt in range(attempts):
        try:
            return _request_once(method, path, base=base, **kw)
        except BrokerMutationUnknown:
            raise
        except BrokerError as exc:
            retryable = exc.status == 0 or exc.status in (429, 500, 502, 503, 504)
            if not retryable or attempt + 1 >= attempts:
                raise
            time.sleep(min(2 ** attempt, 8))
    raise BrokerError("Alpaca Paper indisponible")


def _ensure_paper_ready(*, force=False):
    if not is_approved_paper_url(BASE):
        _set_unavailable("Hôte de trading non autorisé.", paper_confirmed=False)
        raise BrokerError("Seule l'URL officielle Alpaca Paper est autorisée")
    if not KEY.strip() or not SECRET.strip():
        _set_unavailable("Identifiants Paper absents.", paper_confirmed=False)
        raise BrokerError("Identifiants Alpaca Paper non configurés")
    with _HEALTH_LOCK:
        fresh = (
            not force
            and _HEALTH["paper_confirmed"]
            and _HEALTH["connection_health"] == "healthy"
            and time.monotonic() - _HEALTH["_verified_monotonic"] < _HEALTH_TTL_SECONDS
            and isinstance(_HEALTH["_account"], dict)
        )
        if fresh:
            return _HEALTH["_account"]

    try:
        account = _request_with_retry("GET", "/v2/account", base=BASE)
        _check_account_ready(account)
    except PaperAccountUnavailable:
        _set_unavailable("Compte Paper confirmé, mais bloqué ou inactif.",
                         paper_confirmed=True)
        raise
    except BrokerMutationUnknown:
        _set_unavailable("Vérification du compte Paper incertaine.", paper_confirmed=False)
        raise BrokerError("Vérification du compte Alpaca Paper incertaine") from None
    except BrokerError:
        _set_unavailable("Le compte Paper n'a pas pu être vérifié.", paper_confirmed=False)
        raise

    now = _now_iso()
    with _HEALTH_LOCK:
        _HEALTH.update({
            "paper_confirmed": True,
            "connection_health": "checking",
            "last_check_at": now,
            "last_successful_check": now,
            "confirmation_basis": "authenticated_paper_api_endpoint",
            "message": "Compte Paper confirmé; vérification de l'horloge en cours.",
            "_verified_monotonic": 0.0,
            "_account": account,
        })
    try:
        clock = _request_with_retry("GET", "/v2/clock", base=BASE)
        if not isinstance(clock, dict) or not isinstance(clock.get("is_open"), bool):
            raise BrokerError("Horloge Alpaca Paper invalide")
    except BrokerError:
        _set_unavailable("Compte Paper confirmé, mais le service Alpaca est indisponible.",
                         paper_confirmed=True)
        raise BrokerError("Santé Alpaca Paper indisponible") from None

    with _HEALTH_LOCK:
        _HEALTH.update({
            "paper_confirmed": True,
            "connection_health": "healthy",
            "last_check_at": _now_iso(),
            "last_successful_check": _now_iso(),
            "confirmation_basis": "authenticated_paper_api_endpoint",
            "message": "Compte Paper confirmé et connexion disponible.",
            "_verified_monotonic": time.monotonic(),
            "_account": account,
        })
    return account


def paper_status():
    """Force a fresh Paper account + trading-clock check; return no secrets."""
    try:
        _ensure_paper_ready(force=True)
    except BrokerError:
        pass
    return _safe_status()


def _r(method, path, retries=3, base=None, **kw):
    method = str(method).upper()
    endpoint = BASE if base is None else base
    if endpoint not in {BASE, DATA}:
        raise BrokerError("Hôte Alpaca non autorisé")
    if method == "GET" and endpoint == BASE and path == "/v2/account":
        return _ensure_paper_ready(force=True)
    _ensure_paper_ready(force=method not in {"GET", "HEAD"})
    try:
        return _request_with_retry(method, path, retries=retries, base=endpoint, **kw)
    except BrokerMutationUnknown:
        _set_unavailable("Résultat d'une requête Alpaca incertain; réconciliation requise.",
                         paper_confirmed=_HEALTH["paper_confirmed"])
        raise
    except BrokerError as exc:
        if endpoint == BASE and exc.status in (0, 401, 403, 429, 500, 502, 503, 504):
            _set_unavailable("Service Alpaca Paper indisponible.",
                             paper_confirmed=False if exc.status in (401, 403) else _HEALTH["paper_confirmed"])
        raise


def account():
    return _ensure_paper_ready(force=True)


def positions(): return _r("GET", "/v2/positions")

def asset_metadata(symbol):
    """Read trusted Alpaca asset metadata; never infer eligibility from a ticker."""
    normalized = str(symbol).strip().upper()
    if not normalized or len(normalized) > 20 or not normalized.replace(".", "").replace("-", "").isalnum():
        raise BrokerError("Symbole d'instrument invalide")
    payload = _r("GET", f"/v2/assets/{normalized}")
    if not isinstance(payload, dict):
        raise BrokerError("Métadonnées d'instrument Alpaca invalides")
    asset_class, status, tradable = payload.get("class"), payload.get("status"), payload.get("tradable")
    if (not isinstance(asset_class, str) or not asset_class.strip()
            or not isinstance(status, str) or not status.strip()
            or not isinstance(tradable, bool)):
        raise BrokerError("Classification ou statut d'instrument Alpaca incomplet")
    return {"symbol": normalized, "asset_class": asset_class.strip().lower(),
            "status": status.strip().lower(), "active": status.strip().lower() == "active",
            "tradable": tradable}

def clock(): return _r("GET", "/v2/clock")
def orders(status="all", limit=25):
    """Fetch a complete bounded order snapshot using Alpaca page tokens.

    `limit` is the requested total, not the per-request page size. Alpaca's
    endpoint accepts at most 500 records per page. If the bounded pagination
    guard is reached while a page is full, fail closed instead of returning a
    silently truncated snapshot.
    """
    if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 10000:
        raise BrokerError("Limite d'ordres invalide (1..10000)")
    page_size = 500
    max_pages = 20
    result = []
    page_token = None
    seen_ids = set()
    for page_number in range(max_pages):
        remaining = limit - len(result)
        if remaining <= 0:
            return result
        size = min(page_size, remaining)
        params = {"status": status, "limit": size, "direction": "desc"}
        if page_token:
            params["page_token"] = page_token
        page = _r("GET", "/v2/orders", params=params)
        if not isinstance(page, list):
            raise BrokerError("Réponse de pagination des ordres invalide")
        if len(page) > size:
            raise BrokerError("Page d'ordres supérieure à la limite demandée")
        for item in page:
            if not isinstance(item, dict) or not item.get("id"):
                raise BrokerError("Ordre sans identifiant dans la page broker")
            order_id = str(item["id"])
            if order_id in seen_ids:
                raise BrokerError("Pagination broker répétée : identifiant dupliqué")
            seen_ids.add(order_id)
            result.append(item)
        if len(page) < size:
            return result
        if len(result) >= limit:
            return result
        next_token = str(page[-1]["id"])
        if next_token == page_token:
            raise BrokerError("Token de pagination broker non progressif")
        page_token = next_token
    raise BrokerError("Pagination des ordres interrompue : plafond de pages atteint")
def order_get(oid): return _r("GET", f"/v2/orders/{oid}")
def cancel(oid): return _r("DELETE", f"/v2/orders/{oid}")

def _lookup_order_by_client_id(cid):
    return _r("GET", "/v2/orders:by_client_order_id",
              params={"client_order_id": cid})


def _same_market_intent(existing, symbol, order_side, amount):
    from decimal import Decimal, InvalidOperation
    try:
        return (
            isinstance(existing, dict)
            and str(existing.get("symbol", "")).strip().upper() == symbol
            and str(existing.get("side", "")).strip().lower() == order_side
            and str(existing.get("type", "")).strip().lower() == "market"
            and str(existing.get("time_in_force", "")).strip().lower() == "day"
            and Decimal(str(existing.get("notional"))) == amount.quantize(Decimal("0.01"))
            and bool(existing.get("id"))
        )
    except (AttributeError, InvalidOperation, TypeError, ValueError):
        return False


def _same_limit_intent(existing, symbol, order_side, quantity, price):
    from decimal import Decimal, InvalidOperation
    try:
        return (
            isinstance(existing, dict)
            and str(existing.get("symbol", "")).strip().upper() == symbol
            and str(existing.get("side", "")).strip().lower() == order_side
            and str(existing.get("type", "")).strip().lower() == "limit"
            and Decimal(str(existing.get("qty"))) == quantity
            and Decimal(str(existing.get("limit_price"))) == price
            and str(existing.get("time_in_force", "")).strip().lower() == "day"
            and bool(existing.get("id"))
        )
    except (AttributeError, InvalidOperation, TypeError, ValueError):
        return False


def order(sym, side, notional, cid):
    """Submit a market order; a duplicate client ID is reusable only for the same intent."""
    from decimal import Decimal, InvalidOperation

    symbol = str(sym).strip().upper()
    order_side = str(side).strip().lower()
    try:
        amount = Decimal(str(notional))
    except (InvalidOperation, TypeError, ValueError):
        raise BrokerError("Montant d'ordre invalide") from None
    if (not symbol or len(symbol) > 20 or order_side not in {"buy", "sell"}
            or not amount.is_finite() or amount <= 0
            or not isinstance(cid, str) or not cid.strip() or len(cid) > 128):
        raise BrokerError("Paramètres d'ordre au marché invalides")

    body = {"symbol": symbol, "side": order_side, "type": "market", "time_in_force": "day",
            "notional": f"{amount:.2f}", "client_order_id": cid}
    try:
        return _r("POST", "/v2/orders", json=body)
    except BrokerMutationUnknown:
        # The POST is never repeated. A read-only lookup may resolve an accepted
        # order; otherwise the existing durable intent remains submission_unknown.
        try:
            existing = _lookup_order_by_client_id(cid)
        except BrokerError:
            raise BrokerMutationUnknown("Soumission incertaine; réconciliation obligatoire, aucun renvoi automatique.") from None
        if _same_market_intent(existing, symbol, order_side, amount):
            return existing
        raise BrokerMutationUnknown("Ordre non confirmé après soumission; réconciliation obligatoire, aucun renvoi automatique.")
    except BrokerError as exc:
        if exc.status == 422:
            try:
                existing = _lookup_order_by_client_id(cid)
            except BrokerError:
                raise exc
            if not _same_market_intent(existing, symbol, order_side, amount):
                raise BrokerError("client_order_id déjà utilisé pour un ordre au marché différent ou incomplet", 409) from exc
            return existing
        raise


def limit_order(sym, side, qty, limit_price, cid):
    """Submit an idempotent DAY limit order; duplicate IDs must match exactly."""
    from decimal import Decimal, InvalidOperation

    symbol = str(sym).strip().upper()
    side = str(side).strip().lower()
    if not symbol or len(symbol) > 20 or side not in {"buy", "sell"}:
        raise BrokerError("Paramètres d'ordre limite invalides")
    if not isinstance(cid, str) or not cid.strip() or len(cid) > 128:
        raise BrokerError("client_order_id invalide")
    try:
        quantity = Decimal(str(qty))
        price = Decimal(str(limit_price))
    except (InvalidOperation, ValueError, TypeError):
        raise BrokerError("Quantité ou prix limite invalide") from None
    if not quantity.is_finite() or not price.is_finite() or quantity <= 0 or price <= 0:
        raise BrokerError("Quantité et prix limite doivent être finis et positifs")
    quantity_places = max(0, -quantity.normalize().as_tuple().exponent)
    price_places = max(0, -price.normalize().as_tuple().exponent)
    allowed_price_places = 2 if price >= 1 else 4
    if quantity_places > 9 or price_places > allowed_price_places:
        raise BrokerError("Précision quantité/prix supérieure aux règles Alpaca")

    qty_text = format(quantity.normalize(), "f")
    price_text = format(price.normalize(), "f")
    body = {"symbol": symbol, "side": side, "type": "limit", "time_in_force": "day",
            "qty": qty_text, "limit_price": price_text, "client_order_id": cid}
    try:
        return _r("POST", "/v2/orders", json=body)
    except BrokerMutationUnknown:
        try:
            existing = _lookup_order_by_client_id(cid)
        except BrokerError:
            raise BrokerMutationUnknown("Soumission incertaine; réconciliation obligatoire, aucun renvoi automatique.") from None
        if _same_limit_intent(existing, symbol, side, quantity, price):
            return existing
        raise BrokerMutationUnknown("Ordre non confirmé après soumission; réconciliation obligatoire, aucun renvoi automatique.")
    except BrokerError as exc:
        if exc.status != 422:
            raise
        try:
            existing = _lookup_order_by_client_id(cid)
        except BrokerError:
            raise exc
        if not _same_limit_intent(existing, symbol, side, quantity, price):
            raise BrokerError("client_order_id déjà utilisé pour un ordre différent", 409) from exc
        return existing

def bars(sym, limit=250):
    """Clôtures journalières (ancien -> récent). Flux IEX gratuit."""
    from datetime import datetime, timedelta
    start = (datetime.utcnow() - timedelta(days=400)).strftime("%Y-%m-%dT00:00:00Z")
    js = _r("GET", f"/v2/stocks/{sym}/bars", base=DATA,
            params={"timeframe": "1Day", "start": start, "limit": 1000, "adjustment": "split", "feed": "iex", "sort": "asc"})
    return [b["c"] for b in (js.get("bars") or [])][-limit:]

def news(sym, limit=15):
    js = _r("GET", "/v1beta1/news", base=DATA, params={"symbols": sym, "limit": limit})
    return [n["headline"] for n in js.get("news", [])]

def fills(pages=10):
    """Fetch complete FILL activity pages; reject malformed rows instead of hiding them."""
    if not isinstance(pages, int) or isinstance(pages, bool) or not 1 <= pages <= 100:
        raise BrokerError("Nombre de pages d'exécutions invalide (1..100)")
    out, token, seen_ids, seen_tokens = [], None, set(), set()
    for page_number in range(pages):
        params = {"direction": "desc", "page_size": 100}
        if token:
            params["page_token"] = token
        js = _r("GET", "/v2/account/activities/FILL", params=params)
        if not isinstance(js, list) or len(js) > 100:
            raise BrokerError("Réponse de pagination des exécutions invalide")
        for activity in js:
            if not isinstance(activity, dict):
                raise BrokerError("Activité FILL mal formée")
            required = ("id", "order_id", "symbol", "side", "qty", "price", "transaction_time")
            if any(activity.get(key) in (None, "") for key in required):
                raise BrokerError("Activité FILL incomplète : identifiant, ordre, instrument ou données d'exécution absents")
            if activity["side"] not in ("buy", "sell"):
                raise BrokerError("Activité FILL avec un sens invalide")
            activity_id = str(activity["id"])
            if activity_id in seen_ids:
                raise BrokerError("Pagination des exécutions répétée : identifiant dupliqué")
            seen_ids.add(activity_id)
            out.append({"id": activity_id, "order_id": str(activity["order_id"]),
                        "symbol": str(activity["symbol"]), "side": activity["side"],
                        "qty": activity["qty"], "price": activity["price"],
                        "time": activity["transaction_time"], "fee": activity.get("fee", 0)})
        if len(js) < 100:
            break
        next_token = str(js[-1]["id"])
        if next_token == token or next_token in seen_tokens:
            raise BrokerError("Pagination des exécutions non progressive")
        seen_tokens.add(next_token)
        token = next_token
        if page_number == pages - 1:
            raise BrokerError(
                "Pagination des exécutions interrompue : plafond de pages atteint "
                "alors que la dernière page est pleine"
            )
    return out

def _historical_daily_bars(sym, count):
    """Fetch up to count split-adjusted daily bars, following Alpaca page tokens."""
    from datetime import datetime, timedelta, timezone
    if not isinstance(count, int) or count < 1 or count > 10000:
        raise ValueError("count doit être compris entre 1 et 10000")
    # Allow for weekends and market holidays; pagination handles long histories.
    start = (datetime.now(timezone.utc) - timedelta(days=max(400, count * 2))).strftime("%Y-%m-%dT00:00:00Z")
    params = {"timeframe": "1Day", "start": start, "limit": 1000,
              "adjustment": "split", "feed": "iex", "sort": "asc"}
    collected = []
    token = None
    seen_tokens = set()
    for _ in range(20):  # hard bound: at most 20,000 provider rows per request
        if token:
            params["page_token"] = token
        js = _r("GET", f"/v2/stocks/{sym}/bars", base=DATA, params=dict(params))
        page = js.get("bars") or []
        if not isinstance(page, list):
            raise BrokerError("Réponse historique Alpaca mal formée")
        collected.extend(page)
        next_token = js.get("next_page_token")
        if not next_token or len(collected) >= count:
            break
        if next_token in seen_tokens:
            raise BrokerError("Pagination historique Alpaca incohérente")
        seen_tokens.add(next_token)
        token = next_token
    else:
        raise BrokerError("Historique trop volumineux : limite de pagination atteinte")
    # Keep provider order but reject malformed or non-monotonic timestamps.
    bars = collected[-count:]
    previous = None
    for bar in bars:
        stamp = bar.get("t")
        if not stamp or (previous is not None and stamp <= previous):
            raise BrokerError("Horodatages historiques absents, dupliqués ou désordonnés")
        previous = stamp
        if "c" not in bar or "v" not in bar:
            raise BrokerError("Barre historique incomplète")
    return bars


def bars2(sym, limit=250):
    """(clôtures, volumes) journaliers, ancien -> récent, avec pagination."""
    b = _historical_daily_bars(sym, limit)
    return [x["c"] for x in b], [x["v"] for x in b]

def bars3(sym, limit=250):
    """Daily UTC timestamps, closes and volumes (oldest -> newest)."""
    b = _historical_daily_bars(sym, limit)
    return [x["t"] for x in b], [x["c"] for x in b], [x["v"] for x in b]

bars3.adjustment_mode = "split"  # _historical_daily_bars requests Alpaca adjustment=split.
def bars(sym, limit=250): return bars2(sym, limit)[0]

def equity_curve(period="1M"):
    js = _r("GET", "/v2/account/portfolio/history", params={"period": period, "timeframe": "1D"})
    return list(zip(js.get("timestamp", []), js.get("equity", [])))

def closes_long(sym, days=1800):
    """Clôtures journalières sur plusieurs années, avec pagination Alpaca."""
    return [bar["c"] for bar in _historical_daily_bars(sym, days)]

