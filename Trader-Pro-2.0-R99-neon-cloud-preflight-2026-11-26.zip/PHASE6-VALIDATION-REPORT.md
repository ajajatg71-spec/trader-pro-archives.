# Trader Pro 2.0 — Phase 6 validation report

Date: 2026-11-11

## Implemented in this delivery
- Phase 5 Walk-Forward rolling-window training isolation retained (`start_index=train_start`).
- Phase 6 strategy lifecycle manager with STOPPED / INITIALIZING / ACTIVE / ERROR states and per-strategy fault isolation.
- Four initial deterministic strategy adapters.
- Regime adapter based only on the existing V1 `risklib.regime` rule; insufficient history returns UNKNOWN.
- Regime allow-list selector that fails closed for unknown regimes.
- Correlation-family signal aggregation so Momentum and Trend Following are not treated as independent confirmations.
- Capped indicative allocation proposals; no order creation.
- Explicit fail-closed external risk gate. A passing gate marks a proposal for Paper review only; it does not execute it.
- Quantitative strategy evaluation/comparison delegated to Phase 5 engine.
- Bounded thread-safe in-memory signal audit logger.

## Validation results
- `python -m compileall -q .`: passed.
- `python -m pytest -q`: 283 passed, 72 subtests.
- `python -m unittest discover -q`: 279 passed.
- `BROKER=sim APP_PASSWORD=<test-only> python -c 'import app'`: passed; 32 FastAPI routes registered.
- ZIP integrity check: performed on delivery archive.

Pytest and unittest counts differ because the two runners discover/represent parametrized and subtests differently; both suites completed successfully.

## Not validated / not claimed
- No live broker, real-money order or Live mode tested or enabled.
- Strategy-to-production-RiskService-to-PaperExecution end-to-end integration is not connected in this phase; only the strict injected risk-gate contract is implemented and unit-tested.
- Signal audit is in-memory, not PostgreSQL-persistent.
- PostgreSQL server startup, migration, backup/restore and production persistence remain Phase 3 validation items.
- Live market-data provider credentials, subscription rights, quotas and real feed failover remain Phase 4 validation items.
- The V1 regime detector only distinguishes bullish/bearish when it has sufficient history; no unsupported sideways/volatile classification is inferred.

## Safety
The strategy layer has no broker dependency and cannot submit orders. A strategy signal is not a trading recommendation. Any future Paper execution integration must call the actual risk service first, reject on any error, and remain separated from Live execution.

## 2026-11-11 — hardening complémentaire
- Configuration de stratégie : valeurs booléennes, non numériques et non finies rejetées.
- Agrégateur : mélange de symboles rejeté explicitement ; seuils booléens interdits.
- Allocateur : seuils booléens interdits.
- Pipeline batch : erreurs propres à un symbole retournées dans le résultat de ce symbole (`SYMBOL_REJECTED` / `SYMBOL_ERROR`), sans effacer les résultats des autres symboles.
- Nouvelle suite `python -m pytest -q` : **339 passed, 3 skipped, 76 subtests passed**. Les 3 tests PostgreSQL restent ignorés faute de base de test configurée.
- `python -m compileall -q .` : réussi.
- Import SIM : réussi, 35 routes FastAPI, `StrategyExecutionPipeline` chargé et `paper_mode=True`.
- `unittest discover` a affiché 335 tests réussis, mais le processus n'a pas terminé proprement dans le délai de l'environnement après le rapport `OK`; le résultat de référence est donc la suite pytest complète.

## 2026-11-11 — intégration Paper locale et idempotence des fills
- Ajout de `tests/test_phase6_paper_integration.py` : cycle stratégie → proposition persistée → restauration après redémarrage simulé → approbation manuelle → exécution du courtier simulé → réconciliation et grand livre financier.
- Ajout d'un scénario d'arrêt d'urgence : une perte journalière dépassant le seuil met le système en pause et empêche toute soumission.
- Le scénario de rejeu a révélé un défaut réel : après arrondi des colonnes SQL `Numeric`, le même fill Alpaca transmis comme float pouvait être signalé à tort comme conflit d'identifiant.
- Correction de `OrderRepository.record_fill` : comparaison idempotente à l'échelle décimale déclarée en base (quantité 10 décimales, prix/frais 8 décimales). Les vrais conflits de données restent rejetés.
- Ajout du test de non-régression `test_fill_replay_is_idempotent_after_numeric_column_rounding`.
- Résultat final local : `python -m pytest -q` = **342 passed, 3 skipped, 76 subtests passed**.
- `python -m compileall -q .`, syntaxe du script PostgreSQL, import FastAPI en SIM (35 routes) et aller-retour Alembic SQLite (upgrade/downgrade/upgrade) réussis.
- Limites externes : aucune clé Alpaca Paper ni `DATABASE_URL` PostgreSQL n'est configurée dans cet environnement. Aucun ordre réel Paper n'a été envoyé, et aucun test PostgreSQL serveur n'est revendiqué.
- Ajout de `scripts/verify_alpaca_paper_readonly.py`, contrôle facultatif et strictement en lecture seule de la connexion Alpaca Paper, du compte, des positions, de l'horloge et de 5 barres SPY. Le script ne soumet ni n'annule d'ordre.
