# Phase 4 — Extension OHLCV isolée (21 novembre 2026)

## Objectif
Fournir aux futures analyses de chandeliers les cinq champs réels d'une barre — open, high, low, close, volume — sans modifier le contrat historique `DailyBars` (close + volume), utilisé par les consommateurs existants.

## Changements
- Ajout de `OHLCVDailyBars`, modèle immuable avec OHLCV, horodatages et source.
- Ajout du paramètre optionnel `ohlcv_reader` et de `MarketDataService.daily_ohlcv()` : validation des séries alignées, prix/volumes finis, géométrie cohérente, horodatages timezone-aware strictement croissants, cache TTL et invalidation dédiée.
- Extension opt-in de l'adaptateur Twelve Data via `include_ohlc=True`. Le mode historique reste inchangé.
- Configuration applicative : un lecteur OHLCV Twelve Data distinct est construit uniquement hors SIM et si `TWELVEDATA_API_KEY` est explicitement fourni. En SIM ou sans clé, `daily_ohlcv()` échoue explicitement « fournisseur non configuré » au lieu d'inventer O/H/L.
- Le ProviderChain historique et les appels `daily_bars()` n'ont pas changé de contrat.

## Tests
Tests ajoutés pour le modèle OHLCV, les séries désalignées, géométrie impossible, valeurs non finies, timestamps naïfs/dupliqués, cache, invalidation, mode de compatibilité, adaptateur Twelve Data et intégration service-adaptateur.

## Limites / sécurité
- Cette extension ne signifie pas que des données OHLCV réelles ont été téléchargées ou vérifiées avec un compte Twelve Data. Les tests d'adaptateur utilisent des réponses simulées.
- Le flux OHLCV n'est pas encore consommé par `candle_analysis.py`, les stratégies, le moteur de risque ou le moteur d'exécution. Aucun signal ni ordre n'en découle.
- La configuration réelle est opt-in et requiert une clé Twelve Data; aucune clé n'est incluse dans le code.
- La granularité actuellement activée dans l'adaptateur est quotidienne (`1day`). Les intervalles intraday et l'alignement multi-timeframe restent à construire.
