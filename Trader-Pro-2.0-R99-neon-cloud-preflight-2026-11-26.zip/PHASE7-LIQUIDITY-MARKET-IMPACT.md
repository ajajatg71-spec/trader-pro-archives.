# Phase 7 — Liquidity and market-impact pre-trade controls

## Delivered in this increment

The institutional pre-trade gate now supports three opt-in limits, evaluated for new buy orders:

- `max_participation_pct`: proposed order notional divided by trusted average daily dollar volume (`risk_metadata[SYMBOL].avg_daily_dollar_volume`), expressed as a percentage.
- `max_spread_pct`: quoted spread `(ask - bid) / midpoint * 100`, using `risk_metadata[SYMBOL].bid` and `.ask`.
- `max_estimated_impact_pct`: configurable square-root screening estimate `impact_coefficient * sqrt(order_notional / avg_daily_dollar_volume) * 100`, using `risk_metadata[SYMBOL].impact_coefficient`.

All three controls are opt-in. If a control is enabled and its required metadata is absent, malformed, non-finite, non-positive where positivity is required, or a crossed quote is supplied, the order is rejected (fail-closed). No volume, quote, or impact coefficient is fabricated. Existing V1 formulas and order checks are not replaced.

## Example configuration

```json
{
  "limits": {
    "max_participation_pct": 1.0,
    "max_spread_pct": 0.25,
    "max_estimated_impact_pct": 0.15
  },
  "risk_metadata": {
    "NVDA": {
      "avg_daily_dollar_volume": 2500000000,
      "bid": 120.10,
      "ask": 120.12,
      "impact_coefficient": 0.5
    }
  }
}
```

The values above are illustrative only, not calibrated recommendations or live market data. Metadata must come from a trusted, timestamped quote/reference-data source and be refreshed before order approval. The current increment does not connect a new quote/ADV provider, persist source timestamps, or validate real-market calibration. The square-root estimate is a conservative screening proxy, not a prediction or execution guarantee.

## Validation performed

- `python -m pytest -q`: 376 passed, 3 skipped, 76 subtests passed.
- `python -m unittest discover -q`: 372 passed.
- `python -m compileall -q .`: passed.
- FastAPI simulation-mode import: passed; 35 routes registered.
- New tests cover ADV participation breach, missing ADV fail-closed, wide spread, invalid/crossed quote, and estimated-impact breach.

The 3 skipped tests are opt-in PostgreSQL integration tests. No live quote source, external Paper broker, PostgreSQL server, or Live broker was exercised by this increment.

## Remaining Phase 7 blockers

- Trusted quote and average daily dollar volume provider, including freshness/source validation.
- Durable emergency kill-switch state and restart verification.
- Calibration and Paper-account end-to-end validation.

## Contrôle de fraîcheur ajouté (incrément suivant)

Toute activation d'au moins une limite de participation, spread ou impact exige désormais un champ `risk_metadata[SYMBOL].as_of` au format Unix epoch secondes. La fraîcheur maximale est configurable via `liquidity_max_age_seconds` (120 secondes par défaut). Un horodatage absent, invalide, futur de plus de 5 secondes ou trop ancien bloque l'ordre. Cette barrière valide la fraîcheur déclarée, mais ne prouve pas à elle seule l'identité ou la qualité du fournisseur : l'intégration d'une source de cotations/ADV de confiance reste à faire.

## Increment: Alpaca/IEX liquidity feed integration

A new `AlpacaLiquiditySnapshot` adapter reads the latest IEX quote and recent IEX daily bars from Alpaca's market-data API. It returns the quote timestamp, bid/ask, source identifier, and an average daily dollar-volume proxy calculated as `close × volume` over up to 20 non-zero-volume observations (at least 10 required).

In non-simulation mode, the adapter is injected into the order service only when Alpaca credentials are configured. If any liquidity limit is enabled for a buy order, the order service refreshes this snapshot immediately before the institutional risk gate. Missing configuration, provider errors, malformed quotes, and insufficient ADV history block the order before any broker submission. Existing sector/factor metadata is preserved while market-derived fields are refreshed. Provider error details and credentials are not exposed.

Important limitations:
- The ADV value is an IEX-feed close-times-volume proxy, not consolidated all-exchange dollar volume.
- Quote freshness is checked by the existing `liquidity_max_age_seconds` policy (120 seconds by default).
- Alpaca does not supply the square-root impact coefficient in this adapter. If `max_estimated_impact_pct` is enabled without a separately calibrated coefficient in trusted instrument metadata, the risk gate blocks the order; no coefficient is fabricated.
- The integration has been tested with deterministic mocked HTTP responses. No external Alpaca account, live API request, or Paper order was exercised in this development environment.


## Increment: exclude incomplete daily bars from ADV

The IEX ADV calculation now excludes any daily bar stamped with the current UTC calendar date, because that session may still be in progress and its partial volume is not comparable to completed daily observations. Such a bar does not count toward the minimum of 10 observations and does not advance `adv_as_of`. A bar stamped with a future calendar date is rejected. The adapter continues to require at least 10 completed, non-zero-volume observations and reports the latest completed session included.

Validation added: current-session partial bar exclusion, current-session bar not counting toward the minimum history, and future-calendar-session rejection. This improves data hygiene but does not turn IEX volume into consolidated market-wide ADV and does not calibrate the square-root impact coefficient.
