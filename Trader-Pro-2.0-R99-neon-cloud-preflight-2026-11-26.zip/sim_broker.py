"""Courtier simulé (BROKER=sim) : même interface que broker.py, prix synthétiques déterministes, aucune clé requise.
Sert à voir le vrai serveur et le vrai tableau de bord fonctionner avant de brancher Alpaca. Données fictives."""
import hashlib, math, random, time, uuid
from datetime import datetime, timezone
from broker_errors import BrokerError

START = 100000.0
S = {}

def reset():
    S.clear(); S.update(cash=START, pos={}, orders=[], fills=[], cids={}, day="", day_eq=START)
reset()

def _seed(sym): return int(hashlib.sha256(sym.encode()).hexdigest()[:8], 16)

def _series(sym, n=1800):
    rnd = random.Random(_seed(sym)); p = 50 + rnd.random() * 250; out, vol = [], []
    for _ in range(n): p *= 1 + rnd.gauss(0.0004, 0.014); out.append(round(p, 2)); vol.append(int(1e6 * (0.5 + rnd.random())))
    return out, vol

def _px(sym): return round(_series(sym)[0][-1] * (1 + 0.01 * math.sin(time.time() / 300 + _seed(sym) % 7)), 2)
def _now(): return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
def _equity(): return S["cash"] + sum(p["qty"] * _px(s) for s, p in S["pos"].items())

def account():
    eq, d = _equity(), time.strftime("%Y-%m-%d")
    if S["day"] != d: S["day"], S["day_eq"] = d, eq
    return {"equity": f"{eq:.2f}", "cash": f"{S['cash']:.2f}", "last_equity": f"{S['day_eq']:.2f}", "buying_power": f"{S['cash']:.2f}",
            "status": "ACTIVE", "trading_blocked": False}

def positions():
    out = []
    for s, p in S["pos"].items():
        px = _px(s)
        out.append({"symbol": s, "qty": str(round(p["qty"], 6)), "market_value": f"{p['qty'] * px:.2f}", "current_price": f"{px:.2f}",
                    "avg_entry_price": f"{p['avg']:.2f}", "unrealized_pl": f"{(px - p['avg']) * p['qty']:.2f}"})
    return out

def clock(): return {"is_open": True}

def orders(status="all", limit=25):
    o = [x for x in reversed(S["orders"]) if status != "open" or x["status"] in ("new", "accepted")]
    return o[:limit]

def order_get(oid):
    for o in S["orders"]:
        if o["id"] == oid: return o
    raise BrokerError("Alpaca 404: ordre introuvable", 404)

def cancel(oid):
    o = order_get(oid)
    if o["status"] not in ("new", "accepted"): raise BrokerError("Alpaca 422: ordre déjà exécuté", 422)
    o["status"] = "canceled"; return {}

def order(sym, side, notional, cid):
    if cid in S["cids"]: return S["cids"][cid]
    if not sym.isalpha() or len(sym) > 10 or side not in ("buy", "sell") or notional < 1:
        raise BrokerError("Alpaca 422: ordre invalide", 422)
    px = _px(sym); qty = notional / px; p = S["pos"].get(sym)
    if side == "buy":
        if notional > S["cash"] + 1e-6: raise BrokerError("Alpaca 403: pouvoir d'achat insuffisant", 403)
        S["cash"] -= notional
        if p: p["avg"] = (p["avg"] * p["qty"] + notional) / (p["qty"] + qty); p["qty"] += qty
        else: S["pos"][sym] = {"qty": qty, "avg": px}
    else:
        if not p or qty > p["qty"] + 1e-6: raise BrokerError("Alpaca 403: quantité insuffisante", 403)
        qty = min(qty, p["qty"]); S["cash"] += qty * px; p["qty"] -= qty
        if p["qty"] < 1e-6: del S["pos"][sym]
    o = {"id": uuid.uuid4().hex, "client_order_id": cid, "symbol": sym, "side": side, "notional": f"{notional:.2f}", "qty": str(round(qty, 6)),
         "status": "filled", "filled_avg_price": f"{px:.2f}", "submitted_at": _now()}
    S["orders"].append(o); S["cids"][cid] = o
    S["fills"].append({"id": uuid.uuid4().hex, "order_id": o["id"], "symbol": sym,
                       "side": side, "qty": str(qty), "price": str(px), "time": _now(), "fee": "0"}); return o

def fills(pages=10): return list(S["fills"])
def bars2(sym, limit=250): c, v = _series(sym); return c[-limit:], v[-limit:]
def bars3(sym, limit=250):
    # The simulator has no exchange timestamps; an empty timestamp series
    # explicitly prevents synthetic dates from being mistaken for market data.
    c, v = _series(sym)
    return [], c[-limit:], v[-limit:]
def bars(sym, limit=250): return bars2(sym, limit)[0]
def closes_long(sym, days=1800): return _series(sym)[0][-days:]

_POS = ["{} beats estimates as revenue surges", "{} raises guidance after record quarter", "Analysts upgrade {} on strong growth"]
_NEG = ["{} misses estimates and shares fall", "Regulators open probe into {}", "{} cuts outlook amid weak demand"]
_NEU = ["{} holds annual meeting", "{} announces leadership update"]
def news(sym, limit=15):
    rnd = random.Random(_seed(sym) + int(time.time() // 3600))
    return [rnd.choice(_POS + _NEG + _NEU).format(sym) for _ in range(min(limit, 8))]

def equity_curve(period="1M"):
    n = {"1W": 7, "1M": 30, "3M": 90, "1A": 250}.get(period, 30); rnd = random.Random(_seed("equity" + period))
    v, now = [1.0], int(time.time())
    for _ in range(n - 1): v.append(v[-1] * (1 + rnd.gauss(0.0004, 0.006)))
    k = _equity() / v[-1]
    return [(now - (n - 1 - i) * 86400, round(x * k, 2)) for i, x in enumerate(v)]
