# Trader Pro 2.0 — R90 : readiness gate et audit de jalon

Base : R89.

## Modifications
- Ajout de `assess_corporate_action_readiness`, préflight fail-closed pour l'usage quantitatif des corporate actions.
- Sept preuves sont exigées : lot complet, prix bruts vérifiés, réconciliation indépendante, historique fournisseur, registre persistant, devise/calendrier et validation PostgreSQL.
- Les absences de preuve sont des blocages explicites ; aucun passage automatique à READY.
- Le préflight ne peut jamais autoriser le Live ni créer des ordres.

## Validation
- 5 tests ciblés ajoutés.
- Suite complète : 980 passed, 11 skipped, 205 subtests passed in 30.26s.
- Tests ciblés readiness / corporate actions : 25 passed.
- Compilation Python (`compileall`) : réussie.

## État externe observé
- Neon projet Trader pro accessible, PostgreSQL 18.7.
- `trader_pro_test` est présent mais contient 0 table utilisateur ; seules des lectures SELECT ont été exécutées.
- Replit/GitHub ne retournent aucun projet/dépôt Trader Pro accessible dans cette session.
- Pas de session Alpaca authentifiée ni de récupération réelle d'événements ; l'adaptateur Alpaca est validé par mocks.

## Limites
- R90 reste un candidat local de recherche. PostgreSQL/Neon, Alpaca Paper et l'exhaustivité des données de corporate actions ne sont pas certifiés.
- Live reste désactivé.


## Intégrité de livraison
- `history.jsonl` restauré octet pour octet depuis R89 après les tests (les tests avaient modifié ce fichier de travail).
- Aucun fichier source R80→R90 supprimé ; R90 ajoute le préflight de readiness.
