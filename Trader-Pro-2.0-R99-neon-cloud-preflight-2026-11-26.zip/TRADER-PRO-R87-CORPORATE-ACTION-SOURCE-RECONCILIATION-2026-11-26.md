# Trader Pro 2.0 — R87 : réconciliation économique inter-fournisseurs

Base : R86.

## Modifications
- Ajout de `reconcile_corporate_action_sources` pour comparer deux sources indépendantes par symbole, type et ex-date.
- Les montants/ratios divergents sont signalés comme conflits économiques ; les événements manquants sont exposés séparément.
- Aucun fournisseur n'est automatiquement priorisé, fusionné ou déclaré vrai.

## Validation
- 4 tests ciblés ajoutés.

## Limites
- La réconciliation ne démontre pas l'exhaustivité des deux fournisseurs ; elle identifie uniquement les écarts observables dans les lots reçus.
