# Phase 5 — Walk-forward validation

## Implémentation
- Ajout de `backtest.walk_forward()` avec fenêtres chronologiques expansives ou glissantes.
- Sélection de paramètres sur le seul historique disponible avant chaque segment de test.
- Segments OOS successifs non chevauchants, capital frais et exposition remise à zéro par pli.
- Comparaison à un benchmark buy-and-hold réinitialisé sur chaque pli.
- Agrégation des rendements close-to-close OOS, stabilité des paramètres et bootstrap des trades OOS.
- Tests couvrant les frontières temporelles, l'absence de fuite de données, la remise à zéro, les fenêtres glissantes et les entrées invalides.

## Limites connues
- Le moteur reste long-only et mono-actif par exécution.
- Les fenêtres agrégées composent les rendements observés à l'intérieur de chaque pli ; les gaps entre plis ne sont pas simulés.
- Les résultats dépendent de la qualité et de l'alignement des prix fournis par l'appelant.
- Aucun flux de marché réel, compte broker, ordre réel, environnement Windows ou PostgreSQL externe n'est validé par ces tests.
- Le mode Live demeure désactivé ; cette fonctionnalité ne constitue pas une autorisation de trading réel.


## Correctif d'audit — fenêtres glissantes
- Les simulations d'apprentissage de chaque pli glissant démarrent désormais à `train_start` : l'historique antérieur sert uniquement à chauffer les indicateurs.
- La sélection des paramètres et les métriques d'apprentissage utilisent exactement la même convention de capital frais et d'exposition nulle au début de la fenêtre.
- Tests de non-régression ajoutés : un signal antérieur à la fenêtre ne peut ni influencer les métriques ni favoriser artificiellement un paramètre.
