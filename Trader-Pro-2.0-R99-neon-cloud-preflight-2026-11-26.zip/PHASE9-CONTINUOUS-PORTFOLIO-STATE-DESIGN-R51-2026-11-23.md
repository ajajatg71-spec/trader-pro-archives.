# Trader Pro 2.0 — R51
## Phase 9 — Spécification technique du portefeuille walk-forward continu
Date : 23 novembre 2026

### Résultat de l'inspection de R50
Le simulateur `research_v1/backtesting/portfolio_backtest.py` maintient actuellement son état en variables locales :
- trésorerie (`cash`) ;
- positions (`qty`, `avg`, `held_since`) ;
- intentions à exécuter à l'ouverture suivante (`pending`) ;
- capital précédent, courbes, transactions clôturées et exécutions.

La boucle exécute d'abord les intentions de la veille à l'ouverture, valorise à la clôture, puis calcule les intentions du jour. Le contrat temporel est donc : décision à la clôture t, exécution à l'ouverture t+1.

Le walk-forward `research_v1/backtesting/walk_forward.py` appelle actuellement `simulate_portfolio` séparément pour chaque fenêtre OOS et réinitialise le capital. C'est explicitement indiqué dans le code et dans le rapport. La continuité de portefeuille n'existe donc pas encore.

### Pourquoi une simple concaténation des courbes serait incorrecte
1. Les positions et le cash seraient recréés à chaque appel.
2. L'intention produite à la clôture précédant la frontière serait perdue ou exécutée deux fois.
3. Les frais, le prix de revient et les quantités résiduelles seraient mal comptabilisés si on reconstruisait l'état à partir de la seule valeur du portefeuille.
4. Les positions doivent être valorisées au cours de clôture de la dernière barre, puis marquées à l'ouverture suivante avant les exécutions.
5. Une modification de paramètres à la frontière ne doit pas réinitialiser les positions.
6. Les indicateurs doivent conserver tout leur historique causal, même si la simulation ne traite que les nouvelles barres.
7. Les métriques OOS doivent être calculées sur un capital de référence commun et ne pas réinclure les périodes de warmup.

### Contrat d'état requis avant l'implémentation
Un état de portefeuille sérialisable et validable doit contenir :
- version de schéma ;
- univers et devise ;
- cash disponible ;
- positions par symbole : quantité, coût d'entrée unitaire tout compris, date d'entrée ;
- intentions en attente, avec stratégie, symbole, côté, type, notional/poids et date de décision ;
- dernier index et timestamp traité ;
- dernière valeur de portefeuille ;
- cumul des frais et slippage ;
- historique append-only des fills et trades clôturés, ou identifiants permettant d'éviter leur duplication.

Les états doivent être validés strictement : symboles connus, quantités positives finies, cash fini et non négatif dans le modèle long-only, prix de revient positifs, intentions cohérentes, timestamp monotone, et version de schéma reconnue. Un état corrompu doit être rejeté, jamais remplacé silencieusement par du cash initial.

### Protocole de reprise
- L'appel initial crée l'état et traite le warmup.
- Chaque segment suivant reçoit l'état précédent et ne traite que les nouvelles barres.
- À la frontière, l'intention déjà émise la veille est exécutée au prochain open avant toute nouvelle décision.
- Les paramètres peuvent changer pour les décisions prises après cette exécution, sans liquider ou réinitialiser les positions.
- Les indicateurs lisent l'historique causal complet, mais les métriques du segment ne comptent que les observations nouvelles.
- Un test d'équivalence doit comparer une simulation monolithique avec plusieurs segments consécutifs aux mêmes paramètres : equity curve, cash, positions, fills et trades doivent être identiques à la tolérance numérique définie.
- Un second test doit changer les paramètres à une frontière et démontrer que l'état financier est conservé et que seule la politique de décision change.

### Séquence de développement
1. Introduire `PortfolioState` versionné, validation stricte et sérialisation.
2. Ajouter `start_index`/`end_index` et la reprise d'état au simulateur sans changer le résultat monolithique existant.
3. Prouver l'équivalence monolithique vs segments.
4. Ajouter le changement de paramètres à frontière, avec exécution des intentions pendantes selon la convention temporelle.
5. Remplacer ensuite les fenêtres indépendantes du walk-forward par une trajectoire OOS continue.
6. Ajouter comparaison adaptative/fixe en continu, avec un portefeuille distinct par politique, mêmes dates et coûts.

### Garde-fous
- Aucun accès broker, aucune commande d'ordre, aucun capital réel.
- Les stratégies restent des générateurs d'intentions de recherche.
- Le moteur de recherche de paramètres ne reçoit jamais le droit d'allouer du capital.
- PostgreSQL/Neon et Alpaca Paper ne sont pas validés par ce travail.
- Live reste verrouillé.

### Portée de R51
Cette livraison est une inspection de code et une spécification de conception, pas une implémentation de portefeuille continu. Aucun test nouveau ni gain de performance n'est revendiqué. La base de code R50 est conservée sans modification.
