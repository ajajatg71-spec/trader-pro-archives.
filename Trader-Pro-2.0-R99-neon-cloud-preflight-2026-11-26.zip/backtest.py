"""Moteur de backtest (long seulement) : exécution à la clôture suivante (pas de regard dans le futur), frais, glissement,
règles de risque optionnelles (stops, taille selon la volatilité), séparation apprentissage / test, bootstrap des trades."""
import math
import random
import sys
from numbers import Real
from indicators import rsi
import risklib, scoring


def _finite_number(value, name, *, minimum=None, maximum=None, strict_min=False):
    if isinstance(value, bool) or not isinstance(value, Real) or not math.isfinite(float(value)):
        raise ValueError(f"{name} doit être un nombre fini")
    value = float(value)
    if minimum is not None and (value <= minimum if strict_min else value < minimum):
        op = ">" if strict_min else ">="
        raise ValueError(f"{name} doit être {op} {minimum}")
    if maximum is not None and value > maximum:
        raise ValueError(f"{name} doit être <= {maximum}")
    return value


def _validate_prices(closes):
    if not isinstance(closes, (list, tuple)) or len(closes) < 2:
        raise ValueError("closes doit contenir au moins deux cours")
    for i, price in enumerate(closes):
        _finite_number(price, f"closes[{i}]", minimum=0, strict_min=True)


def _validate_costs(cash, fee, slip):
    _finite_number(cash, "cash", minimum=0, strict_min=True)
    fee = _finite_number(fee, "fee", minimum=0, maximum=1)
    slip = _finite_number(slip, "slip", minimum=0, maximum=1)
    if fee >= 1 or slip >= 1:
        raise ValueError("fee et slip doivent être strictement inférieurs à 1")


def _validate_sizing(sizing):
    if sizing is None:
        return
    if not isinstance(sizing, dict):
        raise ValueError("sizing doit être un dictionnaire")
    _finite_number(sizing.get("risk"), "sizing.risk", minimum=0, maximum=100, strict_min=True)
    _finite_number(sizing.get("k"), "sizing.k", minimum=0, strict_min=True)
    _finite_number(sizing.get("max_frac", 1.0), "sizing.max_frac", minimum=0, maximum=1, strict_min=True)


def _validate_rules(rules):
    if rules is None:
        return
    if not isinstance(rules, dict):
        raise ValueError("rules doit être un dictionnaire")
    for key in ("stop_loss_pct", "trailing_pct", "take_profit_pct"):
        if key in rules:
            _finite_number(rules[key], f"rules.{key}", minimum=0, maximum=100)
    if "cooldown" in rules:
        value = rules["cooldown"]
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError("rules.cooldown doit être un entier >= 0")

def _validate_strategy_params(name, params):
    if not isinstance(params, dict):
        raise ValueError("params doit être un dictionnaire")
    if name == "bh":
        if params:
            raise ValueError("la stratégie bh n'accepte aucun paramètre")
    elif name == "sma":
        for key in ("fast", "slow"):
            value = params.get(key)
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f"params.{key} doit être un entier >= 1")
        if params["fast"] >= params["slow"]:
            raise ValueError("params.fast doit être inférieur à params.slow")
    elif name == "rsi":
        value = params.get("n")
        if isinstance(value, bool) or not isinstance(value, int) or value < 2:
            raise ValueError("params.n doit être un entier >= 2")
        low = _finite_number(params.get("low"), "params.low", minimum=0, maximum=100)
        high = _finite_number(params.get("high"), "params.high", minimum=0, maximum=100)
        if low >= high:
            raise ValueError("params.low doit être inférieur à params.high")
    elif name == "tech":
        _finite_number(params.get("buy"), "params.buy", minimum=0, strict_min=True)


def _sma(c, i, n): return sum(c[i - n + 1:i + 1]) / n

def s_bh(c, i, p, pos): return 1
def s_sma(c, i, p, pos):
    if i < p["slow"]: return pos
    return 1 if _sma(c, i, p["fast"]) > _sma(c, i, p["slow"]) else 0
def s_rsi(c, i, p, pos):
    r = rsi(c[max(0, i - 120):i + 1], p["n"])
    if r is None: return pos
    return 1 if r < p["low"] else 0 if r > p["high"] else pos
def s_tech(c, i, p, pos):
    t = scoring.tech_signal(c[max(0, i - 120):i + 1])
    if t is None: return pos
    return 1 if t >= p["buy"] else 0 if t <= -p["buy"] else pos

STRATS = {"bh": s_bh, "sma": s_sma, "rsi": s_rsi, "tech": s_tech}
GRIDS = {"bh": [{}],
         "sma": [{"fast": f, "slow": s} for f in (5, 10, 20, 30) for s in (40, 60, 100, 150) if f < s],
         "rsi": [{"n": 14, "low": l, "high": h} for l in (20, 25, 30, 35) for h in (60, 65, 70, 75)],
         "tech": [{"buy": b} for b in (0.3, 0.4, 0.7)]}

def run(c, name, p, cash=10000.0, fee=0.0, slip=0.0, rules=None, sizing=None, start_index=0):
    """Signal calculé à la clôture i, exécuté à la clôture i+1.
    rules : stop_loss_pct, trailing_pct, take_profit_pct, cooldown (barres sans rachat après un stop).
    sizing : {risk, k, max_frac} -> fraction investie = min(max_frac, risk % / (k x volatilité journalière))."""
    _validate_prices(c)
    _validate_costs(cash, fee, slip)
    _validate_sizing(sizing)
    _validate_rules(rules)
    if name not in STRATS:
        raise ValueError(f"stratégie inconnue: {name}")
    if name in ("bh", "sma", "rsi", "tech"):
        _validate_strategy_params(name, p)
    elif not isinstance(p, dict):
        raise ValueError("params doit être un dictionnaire")
    if isinstance(start_index, bool) or not isinstance(start_index, int) or not 0 <= start_index < len(c):
        raise ValueError("start_index doit désigner une barre existante")
    fn, rules, pos, qty, entry_val, want = STRATS[name], rules or {}, 0, 0.0, 0.0, None
    ent_px = hi = 0.0; cool = 0; eq, trades, ps = [], [], []
    for i, px in enumerate(c):
        # Warm up signals on pre-test history, but do not carry positions,
        # cash exposure, stops or trades into the out-of-sample window.
        if i < start_index:
            eq.append(cash); ps.append(0)
            want = fn(c, i, p, 0)
            continue
        if want is not None and want != pos:
            if want:
                fill = px * (1 + slip); frac = 1.0
                if sizing:  # volatilité inconnue (historique trop court) : on prend la taille maximale autorisée, jamais 100 %
                    mf, vol = sizing.get("max_frac", 1.0), risklib.daily_vol(c[:i])
                    frac = min(mf, sizing["risk"] / 100 / (sizing["k"] * vol)) if vol else mf
                entry_val = cash * frac; qty = entry_val * (1 - fee) / fill; cash -= entry_val; ent_px, hi = fill, px
            else:
                proceeds = qty * px * (1 - slip) * (1 - fee); cash += proceeds; trades.append((i, proceeds / entry_val - 1)); qty = 0.0
            pos = want
        eq.append(cash + qty * px); ps.append(pos)
        if pos: hi = max(hi, px)
        if pos and rules and risklib.stops(ent_px, px, hi, rules): want, cool = 0, int(rules.get("cooldown", 5))
        else:
            want = fn(c, i, p, pos)
            if cool > 0 and not pos:
                cool -= 1
                if want: want = 0
    return {"eq": eq, "trades": trades, "pos": ps}


def _validate_ohlc(opens, highs, lows, closes):
    series = {"opens": opens, "highs": highs, "lows": lows, "closes": closes}
    for name, values in series.items():
        if not isinstance(values, (list, tuple)) or len(values) < 2:
            raise ValueError(f"{name} doit contenir au moins deux cours")
    lengths = {len(values) for values in series.values()}
    if len(lengths) != 1:
        raise ValueError("les séries OHLC doivent avoir la même longueur")
    for i, (o, h, low, c) in enumerate(zip(opens, highs, lows, closes)):
        for name, value in (("open", o), ("high", h), ("low", low), ("close", c)):
            _finite_number(value, f"{name}[{i}]", minimum=0, strict_min=True)
        if low > min(o, c) or h < max(o, c) or low > h:
            raise ValueError(f"bougie OHLC incohérente à l'index {i}")


def run_ohlc(opens, highs, lows, closes, name, p, cash=10000.0, fee=0.0, slip=0.0,
             rules=None, start_index=0, sizing=None):
    """Backtest OHLC conservateur.

    Les signaux sont calculés à la clôture et les ordres de stratégie sont exécutés
    à l'ouverture suivante. Les stops actifs avant la bougie sont évalués à son
    ouverture (gap) puis sur son range. Si stop et objectif sont tous deux touchés
    dans la même bougie, le stop est prioritaire. Le trailing high n'est actualisé
    qu'après le contrôle des stops de la bougie : aucun chemin intrabar n'est inventé.
    sizing reprend la convention du moteur close-only : {risk, k, max_frac}.
    """
    _validate_ohlc(opens, highs, lows, closes)
    _validate_costs(cash, fee, slip)
    _validate_sizing(sizing)
    _validate_rules(rules)
    if name not in STRATS:
        raise ValueError(f"stratégie inconnue: {name}")
    _validate_strategy_params(name, p)
    if isinstance(start_index, bool) or not isinstance(start_index, int) or not 0 <= start_index < len(closes):
        raise ValueError("start_index doit désigner une barre existante")

    rules = rules or {}
    pos = 0
    qty = 0.0
    entry_price = 0.0
    highest_close_or_high = 0.0
    pending = None
    cooldown_left = 0
    equity, positions, trades = [], [], []
    for i, (op, hi, low, close) in enumerate(zip(opens, highs, lows, closes)):
        if i < start_index:
            equity.append(cash)
            positions.append(0)
            pending = STRATS[name](closes, i, p, 0)
            continue

        stopped = False
        if pending is not None and pending != pos:
            if pending:
                fill = op * (1 + slip)
                frac = 1.0
                if sizing:
                    # Même convention que run(): si l'historique pré-entrée est
                    # trop court pour estimer la volatilité, utiliser max_frac.
                    vol = risklib.daily_vol(closes[:i])
                    max_frac = sizing.get("max_frac", 1.0)
                    frac = (min(max_frac, sizing["risk"] / 100 /
                                (sizing["k"] * vol)) if vol else max_frac)
                invested = cash * frac
                qty = invested * (1 - fee) / fill
                if (not math.isfinite(fill) or fill <= 0 or
                        not math.isfinite(invested) or invested <= 0 or
                        not math.isfinite(qty) or qty <= 0):
                    raise OverflowError("dimensionnement OHLC non représentable numériquement")
                cash -= invested
                if not math.isfinite(cash) or cash < 0:
                    raise OverflowError("trésorerie OHLC non représentable numériquement")
                entry_price = fill
                highest_close_or_high = op
                pos = 1
            else:
                fill = op * (1 - slip)
                proceeds = qty * fill * (1 - fee)
                if not math.isfinite(proceeds) or proceeds < 0:
                    raise OverflowError("produit de cession OHLC non représentable numériquement")
                cash += proceeds
                trade_return = proceeds / invested - 1
                if not math.isfinite(cash) or not math.isfinite(trade_return):
                    raise OverflowError("résultat de cession OHLC non représentable numériquement")
                trades.append((i, trade_return))
                qty = 0.0
                pos = 0

        if pos:
            stop_candidates = []
            if rules.get("stop_loss_pct", 0) > 0:
                stop_candidates.append(entry_price * (1 - rules["stop_loss_pct"] / 100))
            if rules.get("trailing_pct", 0) > 0 and highest_close_or_high > 0:
                stop_candidates.append(highest_close_or_high * (1 - rules["trailing_pct"] / 100))
            stop_level = max(stop_candidates) if stop_candidates else None
            take_level = (entry_price * (1 + rules["take_profit_pct"] / 100)
                          if rules.get("take_profit_pct", 0) > 0 else None)

            exit_fill = None
            # Gap-through protection: fill at the open, not at the stale stop level.
            if stop_level is not None and op <= stop_level:
                exit_fill = op * (1 - slip)
            elif take_level is not None and op >= take_level:
                exit_fill = op * (1 - slip)
            else:
                # Conservative intrabar ordering: if both are touched, stop wins.
                if stop_level is not None and low <= stop_level:
                    exit_fill = stop_level * (1 - slip)
                elif take_level is not None and hi >= take_level:
                    exit_fill = take_level * (1 - slip)

            if exit_fill is not None:
                proceeds = qty * exit_fill * (1 - fee)
                if not math.isfinite(proceeds) or proceeds < 0:
                    raise OverflowError("produit de stop OHLC non représentable numériquement")
                cash += proceeds
                trade_return = proceeds / invested - 1
                if not math.isfinite(cash) or not math.isfinite(trade_return):
                    raise OverflowError("résultat de stop OHLC non représentable numériquement")
                trades.append((i, trade_return))
                qty = 0.0
                pos = 0
                stopped = True
                cooldown_left = int(rules.get("cooldown", 5))
            else:
                highest_close_or_high = max(highest_close_or_high, hi)

        marked_equity = cash + qty * close
        if not math.isfinite(marked_equity) or marked_equity <= 0:
            raise OverflowError("valorisation du portefeuille OHLC non représentable numériquement")
        equity.append(marked_equity)
        positions.append(pos)
        if stopped:
            pending = 0
        else:
            pending = STRATS[name](closes, i, p, pos)
            if not pos and cooldown_left > 0:
                pending = 0
                cooldown_left -= 1

    return {"eq": equity, "trades": trades, "pos": positions,
            "execution_model": "ohlc_next_open_conservative_stop_first"}

def evaluate(res, lo=0, hi=None, bpy=252):
    if not isinstance(res, dict) or not isinstance(res.get("eq"), list) or not isinstance(res.get("pos"), list):
        raise ValueError("res doit contenir les listes eq et pos")
    if len(res["eq"]) != len(res["pos"]):
        raise ValueError("eq et pos doivent avoir la même longueur")
    if not isinstance(res.get("trades"), list):
        raise ValueError("trades doit être une liste")
    for i, value in enumerate(res["eq"]):
        _finite_number(value, f"eq[{i}]", minimum=0, strict_min=True)
    for i, position in enumerate(res["pos"]):
        if isinstance(position, bool) or position not in (0, 1):
            raise ValueError(f"pos[{i}] doit être 0 ou 1")
    for i, trade in enumerate(res["trades"]):
        if not isinstance(trade, (tuple, list)) or len(trade) != 2:
            raise ValueError(f"trades[{i}] doit contenir (index, rendement)")
        trade_index, trade_return = trade
        if isinstance(trade_index, bool) or not isinstance(trade_index, int) or not 0 <= trade_index < len(res["eq"]):
            raise ValueError(f"trades[{i}].index hors limites")
        _finite_number(trade_return, f"trades[{i}].return", minimum=-1, strict_min=True)
    if isinstance(lo, bool) or not isinstance(lo, int) or lo < 0:
        raise ValueError("lo doit être un entier >= 0")
    hi = len(res["eq"]) if hi is None else hi
    if isinstance(hi, bool) or not isinstance(hi, int) or hi < lo or hi > len(res["eq"]):
        raise ValueError("hi doit être un entier compris entre lo et la longueur des données")
    if isinstance(bpy, bool) or not isinstance(bpy, int) or bpy <= 0:
        raise ValueError("bpy doit être un entier > 0")
    eq, ps = res["eq"][lo:hi], res["pos"][lo:hi]
    tr = [r for i, r in res["trades"] if lo <= i < hi]; n = len(eq)
    if n < 2:
        return {"return_pct": 0.0, "cagr_pct": 0.0, "max_dd_pct": 0.0,
                "sharpe": 0.0, "sortino": None, "calmar": None,
                "max_drawdown_duration_bars": 0, "trades": 0,
                "win_rate_pct": 0.0, "exposure_pct": 0.0}
    r = [eq[i] / eq[i - 1] - 1 for i in range(1, n)]
    m = sum(r) / len(r); sd = (sum((x - m) ** 2 for x in r) / len(r)) ** .5
    downside = (sum(min(x, 0.0) ** 2 for x in r) / len(r)) ** .5
    peak, dd, underwater, max_underwater = eq[0], 0.0, 0, 0
    for v in eq:
        if v >= peak:
            peak, underwater = v, 0
        else:
            underwater += 1
            max_underwater = max(max_underwater, underwater)
        dd = min(dd, v / peak - 1)
    # n equity observations contain n-1 return intervals.
    yrs = (n - 1) / bpy
    cagr = ((eq[-1] / eq[0]) ** (1 / yrs) - 1) * 100 if eq[-1] > 0 else -100.0
    sortino = (m / downside * bpy ** .5) if downside > 0 else None
    calmar = (cagr / abs(dd * 100)) if dd < 0 else None
    return {"return_pct": round((eq[-1] / eq[0] - 1) * 100, 2),
            "cagr_pct": round(cagr, 2),
            "max_dd_pct": round(dd * 100, 2), "sharpe": round(m / sd * bpy ** .5, 2) if sd > 0 else 0.0,
            "sortino": round(sortino, 2) if sortino is not None else None,
            "calmar": round(calmar, 2) if calmar is not None else None,
            "max_drawdown_duration_bars": max_underwater,
            "trades": len(tr), "win_rate_pct": round(sum(t > 0 for t in tr) / len(tr) * 100, 1) if tr else 0.0,
            "exposure_pct": round(sum(ps) / n * 100, 1)}

def bootstrap(trades, n=1000, seed=1, block_size=1):
    """Bootstrap des rendements de trades.

    block_size=1 reproduit le bootstrap IID historique. Une taille >1
    rééchantillonne des blocs circulaires contigus pour préserver une partie
    de la dépendance temporelle entre trades. Ce n'est pas un modèle de régime.
    None si moins de cinq trades sont fournis.
    """
    if not isinstance(trades, (list, tuple)):
        raise ValueError("trades doit être une liste ou un tuple de rendements")
    if isinstance(n, bool) or not isinstance(n, int) or n < 1:
        raise ValueError("n doit être un entier >= 1")
    if isinstance(seed, bool) or not isinstance(seed, int):
        raise ValueError("seed doit être un entier")
    if isinstance(block_size, bool) or not isinstance(block_size, int) or block_size < 1:
        raise ValueError("block_size doit être un entier >= 1")
    for i, value in enumerate(trades):
        _finite_number(value, f"trades[{i}]", minimum=-1, strict_min=True)
    if block_size > max(1, len(trades)):
        raise ValueError("block_size ne peut pas dépasser le nombre de trades")
    if len(trades) < 5:
        return None
    rnd, out, count = random.Random(seed), [], len(trades)
    for _ in range(n):
        sample, growth = [], 1.0
        while len(sample) < count:
            start = rnd.randrange(count)
            sample.extend(trades[(start + offset) % count]
                          for offset in range(block_size))
        log_growth = sum(math.log1p(trade_return) for trade_return in sample[:count])
        # Keep the reported percentage finite. Extreme but finite input returns
        # can otherwise silently overflow the compounded equity to infinity.
        if log_growth > math.log1p(sys.float_info.max / 100.0):
            raise OverflowError("rendement bootstrap trop élevé pour être représenté en pourcentage")
        growth = math.expm1(log_growth) + 1.0
        if not math.isfinite(growth):
            raise OverflowError("capital bootstrap non fini")
        out.append(growth - 1.0)
    out.sort()
    q = lambda p: round(out[int(p * (n - 1))] * 100, 2)
    return {"p5": q(.05), "p50": q(.5), "p95": q(.95),
            "prob_loss_pct": round(sum(x < 0 for x in out) / n * 100, 1),
            "n_trades": count, "bootstrap_samples": n,
            "block_size": block_size, "method": "iid" if block_size == 1 else "circular_block"}

def _down(v, n=200):
    if len(v) <= n: return [round(x, 2) for x in v]
    step = (len(v) - 1) / (n - 1)
    return [round(v[round(i * step)], 2) for i in range(n)]


def walk_forward(c, name, train_size=252, test_size=63, step=None, expanding=True,
                 fee=0.0005, slip=0.0005, cash=10000.0, rules=None, sizing=None):
    """Validation walk-forward chronologique : réglages appris uniquement avant chaque test.

    expanding=True utilise tout l'historique depuis l'origine pour l'apprentissage ;
    sinon la fenêtre d'apprentissage est limitée à train_size barres. Les tests sont
    indépendants (capital frais, exposition nulle) et ne se chevauchent pas.
    """
    _validate_prices(c)
    _validate_costs(cash, fee, slip)
    _validate_sizing(sizing)
    _validate_rules(rules)
    if name not in GRIDS or name not in STRATS:
        raise ValueError(f"stratégie inconnue: {name}")
    if isinstance(train_size, bool) or not isinstance(train_size, int) or train_size < 2:
        raise ValueError("train_size doit être un entier >= 2")
    if isinstance(test_size, bool) or not isinstance(test_size, int) or test_size < 2:
        raise ValueError("test_size doit être un entier >= 2")
    step = test_size if step is None else step
    if isinstance(step, bool) or not isinstance(step, int) or step < test_size:
        raise ValueError("step doit être un entier >= test_size pour éviter le chevauchement")
    if len(c) < train_size + test_size:
        raise ValueError("historique insuffisant pour créer au moins une fenêtre train/test")

    folds, stitched, stitched_bh, all_trades = [], [cash], [cash], []
    total_oos_exposure = total_benchmark_exposure = total_test_bars = 0
    # The initial equity point is the last close before the first OOS bar.
    # Position arrays carry a placeholder for that anchor; aggregate exposure
    # is recomputed over actual OOS bars below.
    stitched_positions, stitched_bh_positions = [0], [0]
    train_end = train_size
    while train_end + test_size <= len(c):
        train_start = 0 if expanding else train_end - train_size
        best, best_score = None, None
        # Parameter selection sees only observations strictly before train_end.
        for params in GRIDS[name]:
            candidate = run(c[:train_end], name, params, cash, fee, slip, rules, sizing,
                            start_index=train_start)
            score = evaluate(candidate, train_start, train_end)["sharpe"]
            if best_score is None or score > best_score:
                best, best_score = params, score

        test_end = train_end + test_size
        test_run = run(c[:test_end], name, best, cash, fee, slip, rules, sizing,
                       start_index=train_end)
        benchmark_run = run(c[:test_end], "bh", {}, cash, fee, slip,
                            start_index=train_end)
        # Include the transition from the final training close to the first
        # test close. The first test bar may execute a signal formed at the
        # final training close, so its entry fee/slippage belongs to OOS PnL.
        test_metrics = evaluate(test_run, train_end - 1, test_end)
        benchmark_metrics = evaluate(benchmark_run, train_end - 1, test_end)
        test_metrics["exposure_pct"] = round(
            sum(test_run["pos"][train_end:test_end]) / test_size * 100, 1)
        benchmark_metrics["exposure_pct"] = round(
            sum(benchmark_run["pos"][train_end:test_end]) / test_size * 100, 1)
        folds.append({
            "train_start": train_start, "train_end": train_end,
            "test_start": train_end, "test_end": test_end,
            "params": dict(best), "train": evaluate(
                run(c[:train_end], name, best, cash, fee, slip, rules, sizing,
                    start_index=train_start),
                train_start, train_end),
            "test": test_metrics, "benchmark_test": benchmark_metrics,
        })
        # Stitch every OOS close-to-close return, including the first test bar
        # where a training-close signal may incur entry fees and slippage.
        for i in range(train_end, test_end):
            stitched.append(stitched[-1] * (test_run["eq"][i] / test_run["eq"][i - 1]))
            stitched_bh.append(stitched_bh[-1] * (benchmark_run["eq"][i] / benchmark_run["eq"][i - 1]))
            stitched_positions.append(test_run["pos"][i])
            stitched_bh_positions.append(benchmark_run["pos"][i])
        all_trades.extend(r for i, r in test_run["trades"] if train_end <= i < test_end)
        total_oos_exposure += sum(test_run["pos"][train_end:test_end])
        total_benchmark_exposure += sum(benchmark_run["pos"][train_end:test_end])
        total_test_bars += test_end - train_end
        train_end += step

    aggregate_trades = [(i, value) for i, value in enumerate(all_trades)]
    aggregate = evaluate({"eq": stitched, "pos": stitched_positions, "trades": aggregate_trades})
    benchmark_aggregate = evaluate({"eq": stitched_bh, "pos": stitched_bh_positions, "trades": []})
    if total_test_bars:
        aggregate["exposure_pct"] = round(total_oos_exposure / total_test_bars * 100, 1)
        benchmark_aggregate["exposure_pct"] = round(
            total_benchmark_exposure / total_test_bars * 100, 1)
    param_counts = []
    for params in GRIDS[name]:
        count = sum(f["params"] == params for f in folds)
        if count:
            param_counts.append({"params": dict(params), "folds": count})
    param_counts.sort(key=lambda item: (-item["folds"], repr(sorted(item["params"].items()))))
    return {
        "strategy": name, "expanding": expanding, "train_size": train_size,
        "test_size": test_size, "step": step, "folds": folds,
        "aggregate_oos": aggregate, "benchmark_aggregate_oos": benchmark_aggregate,
        "parameter_stability": param_counts, "mc": bootstrap(all_trades),
    }


def optimize(c, name, split=0.6, fee=0.0005, slip=0.0005, cash=10000.0, rules=None, sizing=None):
    """Choisit les réglages sur la partie apprentissage, puis juge sur la partie test (jamais vue)."""
    _validate_prices(c)
    _validate_costs(cash, fee, slip)
    _validate_sizing(sizing)
    _validate_rules(rules)
    if name not in GRIDS or name not in STRATS:
        raise ValueError(f"stratégie inconnue: {name}")
    split = _finite_number(split, "split", minimum=0, maximum=1, strict_min=True)
    k = int(len(c) * split)
    if k < 2 or len(c) - k < 2:
        raise ValueError("split doit laisser au moins deux cours dans chaque fenêtre")
    best, bs = None, None
    for p in GRIDS[name]:
        s = evaluate(run(c, name, p, cash, fee, slip, rules, sizing), 0, k)["sharpe"]
        if bs is None or s > bs: best, bs = p, s
    # Keep a continuous curve for visual context, but evaluate the test window
    # from fresh cash and flat exposure. This prevents a training-period holding
    # from leaking into the out-of-sample score.
    res = run(c, name, best, cash, fee, slip, rules, sizing)
    test_res = run(c, name, best, cash, fee, slip, rules, sizing, start_index=k)
    bh = run(c, "bh", {}, cash, fee, slip)
    test_bh = run(c, "bh", {}, cash, fee, slip, start_index=k)
    tr, te = evaluate(res, 0, k), evaluate(test_res, k - 1)
    te["exposure_pct"] = round(sum(test_res["pos"][k:]) / (len(c) - k) * 100, 1)
    benchmark_test_metrics = evaluate(test_bh, k - 1)
    benchmark_test_metrics["exposure_pct"] = round(
        sum(test_bh["pos"][k:]) / (len(c) - k) * 100, 1)
    m = min(len(c), 200)
    return {"strategy": name, "params": best, "realistic": bool(rules or sizing), "train": tr, "test": te,
            "benchmark_train": evaluate(bh, 0, k),
            "benchmark_test": benchmark_test_metrics,
            "overfit": bool(tr["sharpe"] > 0.3 and te["sharpe"] < 0.5 * tr["sharpe"]),
            "mc": bootstrap([r for i, r in test_res["trades"] if i >= k]),
            "curve": {"strategy": _down(res["eq"]), "benchmark": _down(bh["eq"]), "split": round(k / (len(c) - 1) * (m - 1))}}
