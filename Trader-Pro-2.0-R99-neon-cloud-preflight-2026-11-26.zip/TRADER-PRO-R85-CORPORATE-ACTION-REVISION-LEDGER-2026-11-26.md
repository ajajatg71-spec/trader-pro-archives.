# Trader Pro 2.0 — R85 : registre point-in-time des révisions corporate actions

Base : R84.

## Modifications
- Nouveau registre append-only de révisions par source et identifiant d'événement.
- Gestion des révisions actives et des annulations sans effacer l'historique antérieur.
- `corporate_action_snapshot` sélectionne uniquement la dernière révision connue à `as_of`.
- Les révisions futures ne fuient pas dans les snapshots historiques.

## Validation
- 5 tests ciblés ajoutés.

## Limites
- Le registre n'est pas encore persisté en base ; il définit le contrat et la logique point-in-time.
