# Trader Pro 2.0 — état du paquet source

Date de référence : 18 novembre 2026 — incrément de sélection du courtier.

Ce document décrit le contenu du paquet livré. Il ne certifie ni un déploiement, ni une connexion externe, ni une rentabilité.

## Contenu applicatif

- Backend FastAPI modulaire (`routers/`, `services/`).
- Modèles SQLAlchemy et migrations Alembic (`db/`, `alembic/`).
- Moteurs de données de marché, quantitatif, stratégies, risque institutionnel et exécution/réconciliation.
- Adaptateur simulateur et garde-fous Paper ; Live reste verrouillé.
- Interface React + TypeScript + Vite et ressources PWA (`frontend/`).
- Tests Python, workflows CI et scripts de validation.

## Résultats exécutés sur cette copie

- `python -m pytest -q -rs` : **628 passed, 11 skipped, 202 subtests passed**, zéro échec (après l’incrément de sélection du courtier).
- `python -m compileall -q .` : réussi.
- `node --check frontend/public/sw.js` : réussi.
- Smoke test serveur local en `BROKER=sim` : `/health` a répondu `{"ok":true,...}` et `/login` a répondu HTTP 200.
- L'installation npm a échoué dans cet environnement par `EAI_AGAIN` (résolution DNS vers `registry.npmjs.org`). Il n'y a donc ni lockfile généré, ni `node_modules`, ni build Vite certifié.

## Bloqueurs avant qualification opérationnelle

1. Installer les dépendances frontend depuis un environnement réseau fonctionnel, générer et revoir `package-lock.json`, exécuter `npm ci`, `npm run typecheck`, `npm run build` et les tests navigateur.
2. Exécuter les 11 tests PostgreSQL sur PostgreSQL réel jetable, puis migration, sauvegarde, restauration et tests de concurrence.
3. Exécuter le vérificateur Neon en lecture seule sur la base de validation prévue, sans tests destructifs.
4. Exécuter le vérificateur Alpaca Paper en lecture seule ; vérifier compte, positions, horloge et données de marché.
5. Tester le cycle Paper complet seulement après ces contrôles, avec autorisation explicite pour le workflow qui soumet un ordre Paper.
6. Tester reprise après crash, rapprochement courtier, kill switch et worker sur un environnement durable.
7. Conserver le mode Live désactivé. Aucune performance financière ne doit être promise avant des validations indépendantes longues, hors échantillon et en Paper.

## Provenance / non-régression

Cette archive applicative est construite depuis la dernière copie complète récupérable dans la bibliothèque au moment de cette session (base Audit 5, incrément interface Audit 8). Elle ne doit pas être fusionnée à l'aveugle dans un dépôt plus récent : comparer d'abord les hashes et l'historique du dépôt cible, puis appliquer uniquement les différences absentes. Les calculs V1, tailles de position, seuils de risque et règles Live n'ont pas été modifiés dans l'incrément interface.

## Mise à jour — vérification de restauration PostgreSQL (18 novembre 2026)

- `scripts/verify_postgres_restore.py` compare maintenant, en lecture seule, les tables publiques, le nombre de lignes de chaque table et la révision Alembic entre la base source `_test` et la base restaurée `_restore`.
- `scripts/verify_postgres.sh` appelle ce vérificateur après `pg_restore`; la simple présence de quatre tables ne suffit plus à valider la restauration.
- Garde testée : une URL PostgreSQL distante est refusée avant toute connexion.
- Vérifications locales après modification : `bash -n scripts/verify_postgres.sh`, compilation Python du nouveau vérificateur, puis **624 passed, 11 skipped, 202 subtests passed**.
- La vérification PostgreSQL réelle reste non exécutée ici : les 11 tests d'intégration sont toujours ignorés faute d'un PostgreSQL jetable explicitement configuré. Ce changement améliore le contrôle CI mais ne constitue pas une preuve de restauration réelle.


## Incrément — sélection fail-safe du courtier (18 novembre 2026)

- `BROKER` absent sélectionne désormais le simulateur ; Alpaca exige `BROKER=alpaca` explicite.
- Une valeur inconnue de `BROKER` arrête le démarrage au lieu de sélectionner implicitement un fournisseur réseau.
- `broker.py` reste l’adaptateur Alpaca ; le choix de l’adaptateur simulé est effectué par l’application, évitant de modifier globalement les fonctions du module Alpaca lors de son import.
- 4 tests dédiés couvrent le défaut simulation, l’opt-in Alpaca, la normalisation et le refus des valeurs inconnues.
- Suite complète : **628 passed, 11 skipped, 202 subtests passed**. Les tests PostgreSQL réels restent ignorés faute de base jetable explicitement configurée.

## Incrément R3 — fiabilité de l'affichage financier (21 novembre 2026)

- Les valeurs financières absentes (`null`, `undefined`, chaîne vide) restent indisponibles au lieu d'être affichées comme zéro.
- Les montants affichent deux décimales ; une variation quotidienne nulle est neutre ; un P/L absent n'est pas coloré comme un gain.
- Ajout d'un test de contrat frontend et mise à jour du test du comportement neutre.
- Validation locale : **629 passed, 11 skipped, 202 subtests passed**, zéro échec ; `compileall` et `node --check frontend/public/sw.js` réussis.
- Les 11 tests PostgreSQL restent ignorés faute de base jetable configurée. Aucun contrôle Neon ou Alpaca Paper n'a été exécuté. Le build TypeScript/Vite reste non certifié faute de dépendances npm disponibles.
- Aucun changement aux règles de trading, au calcul de budget, au moteur de risque, aux approbations ou à la sélection du courtier. Live reste verrouillé.

## Correctif complémentaire R3 — validation de restauration Windows (21 novembre 2026)

- Les deux parcours PowerShell de validation PostgreSQL utilisent maintenant le comparateur commun en lecture seule qui contrôle toutes les tables publiques, le nombre de lignes de chacune et la révision Alembic, au lieu de vérifier seulement quatre tables.
- Deux tests de contrat protègent cette cohérence entre les parcours Windows et Bash.
- Suite complète actualisée : **631 passed, 11 skipped, 202 subtests passed**, zéro échec ; `compileall` et syntaxe du service worker réussis.
- Cela vérifie le contrat des scripts, pas leur exécution réelle sous Windows ou sur PostgreSQL. Les 11 tests d'intégration PostgreSQL sont toujours ignorés dans cet environnement.
