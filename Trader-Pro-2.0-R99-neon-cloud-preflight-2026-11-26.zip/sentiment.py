"""Analyse simple et explicable des titres d'actualité (lexique anglais + négation)."""
import re
POS = set("beat beats surge surges soar soars record upgrade upgraded growth profit profits strong gain gains rally rallies raises raised buyback outperform".split())
NEG = set("miss misses missed plunge plunges fall falls downgrade downgraded lawsuit probe recall loss losses weak cut cuts fraud bankruptcy layoffs decline declines warns warning investigation slump".split())
NOT = {"not", "no", "never", "fails", "without"}

def score(headlines):
    """Moyenne de -1 (négatif) à +1 (positif). None s'il n'y a aucun titre."""
    if not headlines: return None
    tot = n = 0
    for h in headlines:
        w, s = re.findall(r"[a-z']+", h.lower()), 0
        for i, x in enumerate(w):
            v = 1 if x in POS else -1 if x in NEG else 0
            if v and i and w[i - 1] in NOT: v = -v
            s += v
        if s: tot += max(-1, min(1, s)); n += 1
    return round(tot / n, 3) if n else 0.0
