# Phase 8 — open buy-order reservation hardening (2026-11-15)

## Finding

`OrderService.approve()` previously calculated reserved buying power from `orders_reader("open", 50)`. An account with more than 50 open orders could therefore omit later reservations from the institutional pre-trade exposure and cash checks. In addition, a buy order without a reported `notional` was silently treated as zero through `or 0`, understating reserved exposure.

## Change

- Request up to 10,000 open orders, matching the bounded pagination capacity of the Alpaca adapter.
- Treat a result at the 10,000-record ceiling as potentially truncated and block approval.
- Validate the snapshot shape, order side, and every open buy order's notional.
- Refuse unknown, non-positive, boolean, non-finite or malformed buy notionals; do not count them as zero.
- Sum reservations with `math.fsum` and reject a non-finite total.
- Fail closed with HTTP-compatible 423 before the broker submission path if the reservation snapshot is unavailable or incomplete.

## Regression coverage

- 75 open buy orders are all included in the reserved total (not just the first 50).
- A snapshot at the 10,000-record ceiling blocks approval as potentially truncated.
- An open buy order with quantity but no notional blocks approval rather than being counted as zero.
- In all blocking cases, the broker submitter is not called.

## Reproduced verification

- Focused order/risk suites: **71 passed**.
- Full pytest: **559 passed, 10 skipped, 177 subtests passed**.
- `python -m unittest discover -q`: **555 tests passed**.
- `python -m compileall -q .`: passed.

The ten skipped tests remain PostgreSQL integration tests. This change is locally tested only; it does not establish real Alpaca Paper or PostgreSQL validation. No broker order was submitted or cancelled.

## Remaining limitation

The 10,000-order safety ceiling is deliberately conservative. If an account reaches it, approval is blocked until the order snapshot can be reconciled through a complete supported mechanism. This avoids silently under-reserving buying power.
