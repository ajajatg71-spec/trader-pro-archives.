# Trader Pro 2.0 — R78 : indice de rendement total avec dividendes

Base : R77.

## Modifications
- Ajout de `dividend_total_return_index`, qui calcule un indice réinvesti à partir des clôtures brutes et d'événements sourcés.
- Les splits multiplient le nombre de titres détenus à l'ex-date ; les dividendes sont crédités par action post-split.
- Devise des cours explicitement requise et comparée à celle de chaque dividende.
- Les événements publiés après le timestamp de l'ex-date sont refusés afin d'éviter le lookahead.
- Les ex-dates absentes de l'historique sont refusées ; aucune interpolation ni création de séance.

## Convention
Les ratios de split sont « nouvelles actions / anciennes actions ». Le dividende est exprimé en espèces par action dans la base post-split de l'ex-date. L'indice suppose le réinvestissement du dividende au cours de clôture ex-date.

## Tests
8 tests ciblés ajoutés. Suite complète : à renseigner après exécution.

## Limites
- Pas de source réelle d'événements connectée ni de preuve que l'historique reçu est brut.
- Les événements doivent être complets, exacts et exprimés dans la même devise.
- Le calcul n'est pas encore branché sur le backtest/scoreboard ; ce sera un jalon distinct après audit de l'intégration.
