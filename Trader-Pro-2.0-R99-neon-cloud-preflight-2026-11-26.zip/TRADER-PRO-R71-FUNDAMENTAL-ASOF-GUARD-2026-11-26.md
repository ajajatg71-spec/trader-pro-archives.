# Trader Pro 2.0 — R71 : validation temporelle des fondamentaux

Date : 2026-11-26

## Objectif
Renforcer le contrôle point-in-time des snapshots fondamentaux utilisés par la stratégie Multi-Factor. R70 vérifiait `available_at` et l'ordre chronologique des snapshots, mais acceptait toute chaîne non vide dans `as_of`. Un `as_of` futur ou ambigu pouvait donc être accepté alors que le snapshot était réputé disponible plus tôt.

## Correction
- `as_of` est maintenant interprété comme une période de référence explicite : `YYYY`, `YYYY-Qn`, `YYYY-MM-DD` ou datetime ISO avec fuseau.
- Les formats ambigus ou non interprétables sont rejetés.
- La fin de période `as_of` ne peut pas être postérieure à la date `available_at`.
- Les libellés trimestriels sont normalisés sur leur fin de trimestre pour la comparaison.
- Les tests scoreboard ont été corrigés pour utiliser un trimestre effectivement antérieur à la disponibilité des données, plutôt que de conserver un exemple temporel incohérent.

## Tests
- Suite complète : **892 passed, 11 skipped, 202 subtests passed**.
- `compileall -q research_v1` : code retour 0.
- Les 11 tests ignorés demeurent les tests qui nécessitent l'environnement PostgreSQL externe ; aucune validation Neon n'est revendiquée.
- Aucun ordre broker n'a été soumis.

## Périmètre du diff R70 → R71
Modifiés :
- `research_v1/backtesting/portfolio_backtest.py`
- `tests/test_research_v1_portfolio_backtest.py`
- `tests/test_research_v1_portfolio_scoreboard.py`

Ajouté :
- ce rapport

Supprimé : aucun fichier.
`history.jsonl`, modifié comme effet secondaire des tests, a été restauré à l'identique depuis R70.

## Limites restantes
- Le flux Alpaca historique demande `adjustment=split`; cela ne prouve pas une reconstruction du rendement total incluant les dividendes.
- Le moteur ne possède pas encore de registre complet des événements corporate actions avec date d'annonce, date ex et disponibilité point-in-time.
- Les backtests doivent donc être interprétés comme simulations sur prix OHLCV fournis, pas comme preuve de rendement total ajusté des dividendes.
- Aucun déploiement Replit, test Neon distant ou test Alpaca Paper authentifié n'a été réalisé dans cette étape.

## Sécurité
Mode Live inchangé et verrouillé. Les simulations de recherche restent sans accès broker (`broker_access=False`, `orders_created=0`).
