# Trader Pro 2.0 — R82 : verrou explicite de la base de prix brute

Base : R81.

## Modifications
- `split_adjusted_closes` et `dividend_total_return_index` exigent `price_basis="raw"`.
- Les appels internes de backtest et scoreboard transmettent explicitement cette hypothèse.
- Les appels sans provenance explicite ou avec une base ajustée sont refusés afin d'éviter le double comptage des splits/dividendes.
- Le résultat de recherche expose `input_price_basis` et le prix brut + événements utilisés.

## Validation
- Tests ciblés corporate actions : 33 passed.
- Suite complète : 944 passed, 11 skipped, 205 subtests passed (31.31 s).
- `compileall` à exécuter lors du packaging final.

## Limites
- `price_basis="raw"` est une assertion explicite de l'appelant, pas une preuve indépendante de la source.
- Les 11 tests PostgreSQL restent ignorés faute de base jetable configurée dans la suite locale.
