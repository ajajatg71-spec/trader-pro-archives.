# Phase 7 — real-environment validation harness

Date: 2026-11-12

## Delivered

### PostgreSQL
- Added a GitHub Actions workflow using a disposable PostgreSQL 16 service.
- Added a seventh opt-in PostgreSQL integration test that races an atomic order-intent claim against a durable kill-switch activation. The allowed outcomes are: claim commits first and the pause commits after it, or pause commits first and the claim is blocked. The final durable state must be paused.
- Hardened `scripts/verify_postgres.sh`: SQLAlchemy driver URLs are converted to libpq URLs for native tools; `psql` is checked; restore target must be empty; dump and restore remain separate and non-destructive.
- Added `.env.example` and local setup instructions.

### Alpaca Paper
- Added `broker.limit_order()` with input validation, stable `client_order_id`, and duplicate-ID lookup that verifies the existing order payload before returning it.
- Added `scripts/verify_alpaca_paper_orders.py`, an explicit opt-in smoke test. It verifies Paper account status, verifies a tradable equity, requires an open market and a fresh IEX quote, submits one DAY limit buy order one percent below the observed bid, looks it up by client ID, requests cancellation, and requires broker status `canceled` with zero filled quantity.
- Added a manual-only GitHub Actions workflow. It requires exact manual confirmation and Paper-only GitHub environment secrets. It cannot use the Live endpoint.
- Existing read-only connectivity test remains separate and sends no orders.

## Local verification

- `python -m pytest -q`: **444 passed, 7 skipped, 88 subtests passed**.
- `python -m unittest discover -q`: **440 tests passed**.
- `python -m compileall -q .`: passed.
- `bash -n scripts/verify_postgres.sh`: passed.
- YAML parsing of compose and GitHub workflows: passed.
- Focused broker/Paper harness tests: **15 passed**.

## Not yet verified externally

- No PostgreSQL server or native PostgreSQL client tools exist in this runtime. The PostgreSQL integration tests are prepared but skipped.
- Docker/Podman is unavailable.
- `psycopg` is not installed; package installation was attempted but failed because outbound DNS/network is unavailable.
- No Alpaca credentials are configured. No authenticated Paper API call or Paper order was sent.
- The GitHub Actions workflows have not run because no GitHub repository is connected in this runtime.

## Safety

- `broker.py` continues to reject every endpoint except `https://paper-api.alpaca.markets`.
- Paper order smoke test requires `TRADER_PRO_ENABLE_PAPER_ORDER_TEST=YES_I_CONFIRM_PAPER_ONLY` and submits one non-marketable-at-observation limit order only.
- No Live endpoint, Live key, or real-money order is supported by this harness.
- A cancellation request is not treated as confirmed until broker status is observed as `canceled`.

## Next execution gate

1. Push this project to GitHub and let `PostgreSQL integration and backup/restore` complete.
2. Add Paper-only API keys to the `alpaca-paper` GitHub environment, or configure them locally without pasting them into chat.
3. Run the read-only Paper check first, then explicitly dispatch the one-order Paper smoke test.
4. Archive CI logs and reports; only then assess closure of the relevant Phase 3/7 validation gates.

## Durcissement complémentaire du test Paper (12 novembre 2026)

Le script `scripts/verify_alpaca_paper_orders.py` dispose maintenant d'une fonction
`cancel_and_confirm()` commune au chemin normal et au chemin d'erreur. Dès qu'un
ordre a été accepté par Alpaca, toute erreur ultérieure déclenche une tentative
d'annulation de rattrapage, sans nouvelle soumission. Le test ne réussit que si
le statut terminal est `canceled` et `filled_qty` vaut zéro. Si l'annulation ou
la vérification échoue, l'identifiant de l'ordre est affiché pour contrôle manuel.

Trois tests unitaires couvrent l'annulation confirmée, le remplissage partiel et
le statut `filled`. Vérification locale après ce changement : `pytest` 447 passed,
7 skipped, 88 subtests; `unittest` 443 tests OK; `compileall`, syntaxe shell et
parsing YAML des workflows/compose OK. Les 7 tests PostgreSQL restent ignorés,
et aucune requête Alpaca Paper réelle n'a été exécutée dans cet environnement.
