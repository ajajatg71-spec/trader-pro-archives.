# Phase 3 — Strategy proposal persistence

## Delivered
- Added `strategy_proposals` with fixed-precision financial fields, range constraints, signal payloads, regime, strategy provenance, risk reason, broker ID and lifecycle status.
- Added Alembic revision `b21f6a9d3c10` after the initial relational schema.
- Added `StrategyPersistence` repository with transactional stage/status/audit writes and restoration of pending or interrupted submissions.
- Wired strategy pipeline persistence before an order can be staged in application state. Persistence failure fails closed and does not create a volatile-only proposal.
- Wired OrderService to persist `SUBMITTING` before the broker call and `SUBMITTED` after the broker response; the existing stable client order ID remains the broker idempotency key. Manual rejection is persisted before removal from pending state.
- When DATABASE_URL is configured, PostgreSQL becomes authoritative for strategy-generated pending proposals at startup; stale JSON copies are removed and database pending/interrupted states are restored.
- Added authenticated `/api/system/database` diagnostics. No database URL means the app remains in its documented JSON-only development mode.

## Validation
- Alembic upgrade -> downgrade -> upgrade succeeded on a temporary SQLite database.
- Persistence tests cover transaction round-trip, audit correlation, status lifecycle, restoration, duplicate-ID protection and invalid transitions.
- Pipeline tests prove a persistence failure does not stage an unrecoverable proposal.
- Order service tests prove status persistence ordering around Paper submission and manual rejection.
- SQLite is not a substitute for PostgreSQL. Actual PostgreSQL connection, concurrency, crash recovery against the broker, backup/restore and full legacy data reconciliation remain release gates.
- Live trading remains disabled; this feature only supports the Paper workflow.

## Extension — persistance des ordres, fills, comptes et risques (11 novembre 2026)
- Ajout de `db/order_repository.py` : intention d'ordre durable et idempotente via `client_order_id`, mise à jour des statuts et lien vers l'identifiant courtier.
- Ajout de l'enregistrement idempotent des fills via `broker_fill_id`, avec contrôle de l'ordre parent et valeurs positives.
- Ajout de snapshots de compte et d'événements de risque, avec journal d'audit.
- Raccordement optionnel du dépôt SQL au `OrderService` : l'intention est persistée avant l'appel au courtier ; si la base échoue, l'appel courtier est bloqué.
- Un timeout réseau est stocké comme `submission_unknown` (résultat ambigu) pour éviter de conclure à tort à un échec et de créer un doublon.
- Tests automatisés : idempotence client/fill, conflit d'identifiant, ordre/fill, snapshot, audit, risque, panne DB avant soumission et timeout courtier.
- Validation locale : SQLite + Alembic upgrade/downgrade/upgrade. PostgreSQL réel et réconciliation avec un compte Paper externe restent à tester.
