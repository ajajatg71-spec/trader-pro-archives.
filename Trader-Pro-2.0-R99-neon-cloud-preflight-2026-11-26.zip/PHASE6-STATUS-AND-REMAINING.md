# Phase 6 — état de livraison et points restants

## Livré et vérifié localement
- Quatre stratégies déterministes : Momentum, Trend Following, Mean Reversion, Breakout.
- Registre, cycle de vie, sélection par régime et agrégation par familles de signaux.
- Propositions long-only BUY, contrôle de risque préalable, mise en attente d'approbation manuelle et second contrôle dans `OrderService.approve`.
- Persistance PostgreSQL des propositions et restauration au démarrage lorsque `DATABASE_URL` est configurée et que les migrations sont appliquées.
- Durcissement des paramètres, des signaux multi-symboles et du traitement des lots.
- Tests pytest : 339 réussis, 3 ignorés, 76 sous-tests réussis.

## Non validé / dépendances externes
- Pas de test sur un vrai compte Alpaca Paper ni de flux de marché réel avec les identifiants de l'utilisateur.
- Pas de validation PostgreSQL dans cet environnement ; la persistance DB et la restauration doivent être testées avec le serveur PostgreSQL réel (Phase 3).
- Le détecteur de régime ne sait distinguer que TRENDING / UNKNOWN avec la règle V1 actuelle. RANGING et VOLATILE ne sont pas activés sur la base de suppositions.
- Le pipeline automatique ne génère que des propositions BUY long-only. Les signaux SELL restent informatifs.
- Pas d'exécution automatique : chaque proposition doit être approuvée séparément et repasse par les contrôles de risque.
- Mode Live désactivé.

## Critère de clôture
La Phase 6 est fonctionnellement avancée, mais ne doit pas être déclarée totalement clôturée avant validation Paper intégrée, persistance PostgreSQL et vérification du cycle complet de réconciliation.

## Mise à jour du 11 novembre 2026
- Le parcours complet stratégie → approbation manuelle → simulateur Paper → persistance SQLite → réconciliation est maintenant couvert par un test d'intégration.
- Le scénario d'arrêt d'urgence bloque l'approbation avant appel du courtier simulé.
- Un défaut d'idempotence sur les fills après arrondi SQL a été corrigé et couvert par un test.
- Validation locale actualisée : 342 passed, 3 skipped, 76 subtests ; les 3 tests ignorés sont les tests PostgreSQL opt-in.
- Toujours en attente : compte Alpaca Paper réel (identifiants absents) et serveur PostgreSQL (URL/serveur absents). Le contrôle Alpaca fourni est volontairement en lecture seule ; aucun ordre n'a été envoyé à un compte externe.
