import tempfile
import unittest
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from sqlalchemy import create_engine, select, func, event
from db.base import Base
from db.models import OrderRecord, FillRecord, AccountSnapshotRecord, PositionSnapshotRecord, RiskEventRecord, AuditEventRecord, RiskControlStateRecord, SystemSafetyStateRecord
from db.order_repository import OrderRepository, OrderRepositoryError
from db.session import build_session_factory


class OrderRepositoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.engine = create_engine(f"sqlite:///{Path(self.tmp.name) / 'orders.db'}")
        Base.metadata.create_all(self.engine)
        self.sessions = build_session_factory(self.engine)
        with self.sessions.begin() as session:
            session.add(RiskControlStateRecord(id=1, paused=False, reason=None, actor="system"))
            session.add(SystemSafetyStateRecord(id=1, status="READY", reason=None, actor="test", generation=1))
        self.repo = OrderRepository(self.sessions)

    def tearDown(self):
        self.engine.dispose(); self.tmp.cleanup()

    def test_reconciliation_snapshot_rolls_back_account_when_position_flush_fails(self):
        def fail_on_position(session, flush_context, instances):
            if any(isinstance(obj, PositionSnapshotRecord) for obj in session.new):
                raise RuntimeError("injected position flush failure")
        event.listen(self.sessions.class_, "before_flush", fail_on_position)
        try:
            with self.assertRaisesRegex(OrderRepositoryError, "Snapshot de réconciliation non persisté"):
                self.repo.record_reconciliation_snapshot(
                    account={"equity": "10000", "cash": "5000", "buying_power": "8000"},
                    positions=[{"symbol": "AAPL", "qty": "2", "market_value": "400"}],
                )
        finally:
            event.remove(self.sessions.class_, "before_flush", fail_on_position)
        with self.sessions() as session:
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(PositionSnapshotRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(AuditEventRecord)), 0)

    def test_order_intent_rejects_non_finite_or_boolean_notionals(self):
        for invalid in (float("nan"), float("inf"), float("-inf"), True, Decimal("NaN"), Decimal("Infinity")):
            with self.subTest(invalid=invalid):
                with self.assertRaises(OrderRepositoryError):
                    self.repo.stage_order(client_order_id=f"invalid-{len(str(invalid))}-{type(invalid).__name__}",
                        symbol="AAPL", side="buy", notional=invalid)

    def test_atomic_order_claim_rejects_non_finite_sell_notionals(self):
        for invalid in (float("nan"), float("inf"), True, Decimal("NaN")):
            with self.subTest(invalid=invalid):
                with self.assertRaises(OrderRepositoryError):
                    self.repo.stage_order_if_trading_enabled(
                        client_order_id=f"invalid-sell-{type(invalid).__name__}-{str(invalid)}",
                        symbol="AAPL", side="sell", notional=invalid)

    def test_intent_is_idempotent_and_conflicts_are_rejected(self):
        self.assertTrue(self.repo.stage_order(client_order_id="c-1", symbol="AAPL", side="buy", notional=100))
        self.assertFalse(self.repo.stage_order(client_order_id="c-1", symbol="AAPL", side="buy", notional=100))
        with self.assertRaises(OrderRepositoryError):
            self.repo.stage_order(client_order_id="c-1", symbol="MSFT", side="buy", notional=100)
        with self.sessions() as s:
            self.assertEqual(s.scalar(select(func.count()).select_from(OrderRecord)), 1)

    def test_atomic_submission_claim_rejects_when_durable_pause_is_active(self):
        self.repo.set_operational_pause(paused=True, reason="maintenance", actor="operator")
        with self.assertRaises(PermissionError):
            self.repo.stage_order_if_trading_enabled(client_order_id="c-paused",
                symbol="AAPL", side="buy", notional=100)
        with self.sessions() as session:
            self.assertIsNone(session.scalar(select(OrderRecord).where(
                OrderRecord.client_order_id == "c-paused")))
            event = session.scalar(select(AuditEventRecord).where(
                AuditEventRecord.event_type == "order_submission_blocked"))
            self.assertIsNotNone(event)
            self.assertEqual(event.details["gate"], "DURABLE_PAUSE_ATOMIC_CLAIM")

    def test_atomic_submission_claim_creates_intent_when_unpaused(self):
        self.assertTrue(self.repo.stage_order_if_trading_enabled(client_order_id="c-claim",
            symbol="AAPL", side="buy", notional=100))
        self.assertFalse(self.repo.stage_order_if_trading_enabled(client_order_id="c-claim",
            symbol="AAPL", side="buy", notional=100))
        with self.sessions() as session:
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "c-claim"))
            self.assertEqual(row.status, "submitting")

    def test_atomic_aggregate_buy_reservation_blocks_cumulative_overcommit(self):
        self.repo.stage_order(client_order_id="c-reserved-1", symbol="AAPL", side="buy", notional=100)
        with self.assertRaises(PermissionError):
            self.repo.stage_order_if_trading_enabled(client_order_id="c-reserved-2",
                symbol="MSFT", side="buy", notional=60,
                max_total_buy_reservations=150, max_symbol_buy_reservation=150,
                external_open_buy_orders=[])
        with self.sessions() as session:
            assert session.scalar(select(OrderRecord).where(
                OrderRecord.client_order_id == "c-reserved-2")) is None
            event = session.scalar(select(AuditEventRecord).where(
                AuditEventRecord.correlation_id == "c-reserved-2",
                AuditEventRecord.event_type == "order_submission_blocked"))
            self.assertIsNotNone(event)
            self.assertEqual(event.details["gate"], "ATOMIC_AGGREGATE_BUY_RESERVATION")

    def test_atomic_symbol_reservation_blocks_same_ticker_overcommit(self):
        self.repo.stage_order(client_order_id="c-symbol-1", symbol="AAPL", side="buy", notional=100)
        with self.assertRaises(PermissionError):
            self.repo.stage_order_if_trading_enabled(client_order_id="c-symbol-2",
                symbol="AAPL", side="buy", notional=60,
                max_total_buy_reservations=500, max_symbol_buy_reservation=150,
                external_open_buy_orders=[])
        with self.sessions() as session:
            self.assertIsNone(session.scalar(select(OrderRecord).where(
                OrderRecord.client_order_id == "c-symbol-2")))

    def test_atomic_aggregate_reservation_deduplicates_broker_order_already_local(self):
        self.repo.stage_order(client_order_id="c-reserved-broker", symbol="AAPL", side="buy", notional=100)
        self.repo.update_order("c-reserved-broker", status="accepted", broker_order_id="broker-reserved-1")
        # The broker snapshot contains the same 100 USD reservation. It must be
        # counted once, not twice; adding 40 USD stays under the 150 USD ceiling.
        self.assertTrue(self.repo.stage_order_if_trading_enabled(client_order_id="c-reserved-next",
            symbol="MSFT", side="buy", notional=40,
            max_total_buy_reservations=150, max_symbol_buy_reservation=150,
            external_open_buy_orders=[{"broker_order_id": "broker-reserved-1", "symbol": "AAPL", "notional": "100"}]))

    def test_atomic_reservation_blocks_local_broker_notional_mismatch(self):
        self.repo.stage_order(client_order_id="c-reservation-mismatch", symbol="AAPL", side="buy", notional=100)
        self.repo.update_order("c-reservation-mismatch", status="accepted", broker_order_id="broker-mismatch")
        with self.assertRaises(PermissionError):
            self.repo.stage_order_if_trading_enabled(client_order_id="c-reservation-mismatch-next",
                symbol="MSFT", side="buy", notional=10,
                max_total_buy_reservations=500, max_symbol_buy_reservation=100,
                external_open_buy_orders=[{"broker_order_id": "broker-mismatch",
                    "symbol": "AAPL", "notional": "90"}])

    def test_atomic_submission_claim_fails_closed_if_pause_row_missing(self):
        with self.sessions.begin() as session:
            session.delete(session.get(RiskControlStateRecord, 1))
        with self.assertRaises(OrderRepositoryError):
            self.repo.stage_order_if_trading_enabled(client_order_id="c-no-state",
                symbol="AAPL", side="buy", notional=100)
        with self.sessions() as session:
            self.assertIsNone(session.scalar(select(OrderRecord).where(
                OrderRecord.client_order_id == "c-no-state")))

    def test_global_safety_state_blocks_claim_until_ready(self):
        self.repo.transition_system_safety_state(status="DEGRADED", reason="broker down", actor="worker")
        with self.assertRaises(PermissionError):
            self.repo.stage_order_if_trading_enabled(client_order_id="c-degraded",
                symbol="AAPL", side="buy", notional=100)
        self.repo.transition_system_safety_state(status="RECONCILING", reason="broker restored", actor="worker")
        with self.assertRaises(OrderRepositoryError):
            self.repo.transition_system_safety_state(status="READY", reason=None, actor="worker")
        with self.assertRaises(OrderRepositoryError):
            self.repo.transition_system_safety_state(status="READY", reason=None, actor="operator")
        self.repo.record_reconciliation_run(run_id="proof-ready", source="paper", status="succeeded",
            snapshot_complete=True, unresolved_count=0, orders_seen=0, fills_seen=0,
            positions_seen=0, evidence_hash="a" * 64, details={})
        self.repo.transition_system_safety_state(status="READY", reason=None, actor="operator",
            reconciliation_run_id="proof-ready")
        self.assertTrue(self.repo.stage_order_if_trading_enabled(client_order_id="c-ready",
            symbol="AAPL", side="buy", notional=100))

    def test_reconciliation_proof_is_single_use_across_safety_cycles(self):
        self.repo.transition_system_safety_state(status="DEGRADED", reason="test", actor="worker")
        self.repo.transition_system_safety_state(status="RECONCILING", reason="test", actor="worker")
        self.repo.record_reconciliation_run(run_id="proof-single-use", source="paper", status="succeeded",
            snapshot_complete=True, unresolved_count=0, orders_seen=0, fills_seen=0,
            positions_seen=0, evidence_hash="c" * 64, details={})
        self.repo.transition_system_safety_state(status="READY", reason=None, actor="operator",
            reconciliation_run_id="proof-single-use")
        self.repo.transition_system_safety_state(status="DEGRADED", reason="new incident", actor="worker")
        self.repo.transition_system_safety_state(status="RECONCILING", reason="recovery", actor="worker")
        with self.assertRaises(OrderRepositoryError):
            self.repo.transition_system_safety_state(status="READY", reason=None, actor="operator",
                reconciliation_run_id="proof-single-use")
        proof = self.repo.get_reconciliation_run("proof-single-use")
        self.assertIsNotNone(proof["consumed_at"])

    def test_ready_rejects_expired_persisted_proof(self):
        from datetime import timedelta
        from db.models import ReconciliationRunRecord
        self.repo.transition_system_safety_state(status="DEGRADED", reason="test", actor="worker")
        self.repo.transition_system_safety_state(status="RECONCILING", reason="test", actor="worker")
        self.repo.record_reconciliation_run(run_id="proof-expired", source="paper", status="succeeded",
            snapshot_complete=True, unresolved_count=0, orders_seen=0, fills_seen=0,
            positions_seen=0, evidence_hash="d" * 64, details={})
        with self.sessions.begin() as session:
            proof = session.scalar(select(ReconciliationRunRecord).where(
                ReconciliationRunRecord.run_id == "proof-expired"))
            proof.completed_at = datetime.now(timezone.utc) - timedelta(minutes=6)
        with self.assertRaises(OrderRepositoryError):
            self.repo.transition_system_safety_state(status="READY", reason=None, actor="operator",
                reconciliation_run_id="proof-expired")

    def test_ready_rejects_inconclusive_or_incomplete_persisted_proof(self):
        self.repo.transition_system_safety_state(status="DEGRADED", reason="test", actor="worker")
        self.repo.transition_system_safety_state(status="RECONCILING", reason="test", actor="worker")
        self.repo.record_reconciliation_run(run_id="proof-inconclusive", source="paper", status="inconclusive",
            snapshot_complete=False, unresolved_count=1, orders_seen=1, fills_seen=0,
            positions_seen=0, evidence_hash="b" * 64, details={})
        with self.assertRaises(OrderRepositoryError):
            self.repo.transition_system_safety_state(status="READY", reason=None, actor="operator",
                reconciliation_run_id="proof-inconclusive")

    def test_halted_requires_explicit_operator_and_cannot_jump_to_ready(self):
        self.repo.transition_system_safety_state(status="HALTED", reason="critical discrepancy", actor="risk_engine")
        with self.assertRaises(OrderRepositoryError):
            self.repo.transition_system_safety_state(status="READY", reason=None, actor="operator",
                reconciliation_run_id="missing-proof")
        with self.assertRaises(OrderRepositoryError):
            self.repo.transition_system_safety_state(status="RECONCILING", reason="retry", actor="worker")
        self.repo.transition_system_safety_state(status="RECONCILING", reason="operator authorized investigation", actor="operator")

    def test_missing_global_safety_state_fails_closed(self):
        with self.sessions.begin() as session:
            session.delete(session.get(SystemSafetyStateRecord, 1))
        with self.assertRaises(PermissionError):
            self.repo.stage_order_if_trading_enabled(client_order_id="c-no-global-state",
                symbol="AAPL", side="buy", notional=100)

    def test_broker_cancel_request_is_audited_and_not_marked_final_until_reconciled(self):
        self.repo.stage_order(client_order_id="c-cancel", symbol="AAPL", side="buy", notional=100)
        self.repo.update_order("c-cancel", status="accepted", broker_order_id="broker-cancel-1")
        self.repo.record_order_cancel_event(client_order_id="c-cancel",
            broker_order_id="broker-cancel-1", outcome="requested")
        with self.sessions() as session:
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "c-cancel"))
            event = session.scalar(select(AuditEventRecord).where(
                AuditEventRecord.event_type == "broker_cancel_requested"))
            self.assertEqual(row.status, "pending_cancel")
            self.assertIsNotNone(event)
            self.assertFalse(event.details["final_status_confirmed"])

    def test_cancel_request_never_regresses_a_terminal_filled_order(self):
        self.repo.stage_order(client_order_id="c-cancel-filled", symbol="AAPL", side="buy", notional=100)
        self.repo.update_order("c-cancel-filled", status="accepted", broker_order_id="broker-cancel-filled")
        self.repo.update_order("c-cancel-filled", status="filled")
        self.repo.record_order_cancel_event(client_order_id="c-cancel-filled",
            broker_order_id="broker-cancel-filled", outcome="requested")
        with self.sessions() as session:
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "c-cancel-filled"))
            event = session.scalar(select(AuditEventRecord).where(
                AuditEventRecord.event_type == "broker_cancel_requested",
                AuditEventRecord.correlation_id == "c-cancel-filled"))
            self.assertEqual(row.status, "filled")
            self.assertTrue(event.details["terminal_status_preserved"])
            self.assertFalse(event.details["final_status_confirmed"])

    def test_failed_broker_cancel_request_does_not_claim_cancellation(self):
        self.repo.stage_order(client_order_id="c-cancel-fail", symbol="MSFT", side="sell", notional=100)
        self.repo.update_order("c-cancel-fail", status="accepted", broker_order_id="broker-cancel-2")
        self.repo.record_order_cancel_event(client_order_id="c-cancel-fail",
            broker_order_id="broker-cancel-2", outcome="request_failed", reason="TimeoutError")
        with self.sessions() as session:
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "c-cancel-fail"))
            event = session.scalar(select(AuditEventRecord).where(
                AuditEventRecord.event_type == "broker_cancel_request_failed"))
            self.assertEqual(row.status, "accepted")
            self.assertEqual(event.details["reason"], "TimeoutError")
            self.assertFalse(event.details["final_status_confirmed"])

    def test_stale_submitting_intent_becomes_unknown_without_retry(self):
        from datetime import timedelta
        self.repo.stage_order(client_order_id="c-stale", symbol="AAPL", side="buy", notional=100)
        self.repo.stage_order(client_order_id="c-fresh", symbol="MSFT", side="buy", notional=100)
        with self.sessions.begin() as session:
            stale = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "c-stale"))
            stale.updated_at = datetime.now(timezone.utc) - timedelta(minutes=10)
        recovered = self.repo.recover_stale_submissions(stale_after_seconds=120)
        self.assertEqual(recovered, ["c-stale"])
        with self.sessions() as session:
            stale = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "c-stale"))
            fresh = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "c-fresh"))
            self.assertEqual(stale.status, "submission_unknown")
            self.assertEqual(fresh.status, "submitting")
            event = session.scalar(select(AuditEventRecord).where(
                AuditEventRecord.event_type == "order_recovery",
                AuditEventRecord.correlation_id == "c-stale"))
            self.assertIsNotNone(event)
            self.assertFalse(event.details["automatic_resubmission"])

    def test_stale_submission_recovery_rejects_invalid_threshold(self):
        with self.assertRaises(OrderRepositoryError):
            self.repo.recover_stale_submissions(stale_after_seconds=0)


    def test_stale_broker_snapshot_cannot_regress_filled_order(self):
        self.repo.stage_order(client_order_id="c-lifecycle-filled", symbol="AAPL", side="buy", notional=100)
        self.repo.update_order("c-lifecycle-filled", status="accepted", broker_order_id="broker-lifecycle-1")
        self.repo.update_order("c-lifecycle-filled", status="filled")
        self.repo.update_order("c-lifecycle-filled", status="new", broker_order_id="broker-lifecycle-1")
        with self.sessions() as session:
            row = session.scalar(select(OrderRecord).where(
                OrderRecord.client_order_id == "c-lifecycle-filled"))
            ignored = session.scalar(select(AuditEventRecord).where(
                AuditEventRecord.event_type == "order_status_ignored",
                AuditEventRecord.correlation_id == "c-lifecycle-filled"))
            self.assertEqual(row.status, "filled")
            self.assertIsNotNone(ignored)
            self.assertEqual(ignored.details["current_status"], "filled")
            self.assertEqual(ignored.details["incoming_status"], "new")

    def test_cancel_fill_race_allows_broker_confirmed_fill_after_cancel_pending(self):
        self.repo.stage_order(client_order_id="c-lifecycle-race", symbol="MSFT", side="buy", notional=100)
        self.repo.update_order("c-lifecycle-race", status="accepted", broker_order_id="broker-lifecycle-2")
        self.repo.update_order("c-lifecycle-race", status="pending_cancel")
        self.repo.update_order("c-lifecycle-race", status="filled")
        with self.sessions() as session:
            row = session.scalar(select(OrderRecord).where(
                OrderRecord.client_order_id == "c-lifecycle-race"))
            self.assertEqual(row.status, "filled")

    def test_status_and_broker_id_are_persisted(self):
        self.repo.stage_order(client_order_id="c-2", symbol="MSFT", side="sell", notional=50)
        self.repo.update_order("c-2", status="accepted", broker_order_id="b-2", quantity=2)
        with self.sessions() as s:
            row = s.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "c-2"))
            self.assertEqual(row.status, "accepted"); self.assertEqual(row.broker_order_id, "b-2")
            self.assertEqual(row.quantity, Decimal("2"))

    def test_fill_is_idempotent_and_linked_to_order(self):
        self.repo.stage_order(client_order_id="c-3", symbol="AAPL", side="buy", notional=100)
        args = dict(broker_fill_id="f-1", client_order_id="c-3", symbol="AAPL", quantity=1, price=100, fee=.1,
                    executed_at=datetime.now(timezone.utc))
        self.assertTrue(self.repo.record_fill(**args))
        self.assertFalse(self.repo.record_fill(**args))
        with self.sessions() as s:
            self.assertEqual(s.scalar(select(func.count()).select_from(FillRecord)), 1)

    def test_fill_replay_is_idempotent_after_numeric_column_rounding(self):
        self.repo.stage_order(client_order_id="c-round", symbol="AAPL", side="buy", notional=316.0)
        args = dict(broker_fill_id="f-round", client_order_id="c-round", symbol="AAPL",
                    quantity=2.899687958883994, price=108.96, fee=0.0,
                    executed_at=datetime.now(timezone.utc))
        self.assertTrue(self.repo.record_fill(**args))
        # Same provider payload must be recognized after Numeric(24,10)/(24,8)
        # has rounded the stored values, rather than reported as a conflicting ID.
        self.assertFalse(self.repo.record_fill(**args))
        with self.sessions() as s:
            self.assertEqual(s.scalar(select(func.count()).select_from(FillRecord)), 1)

    def test_decimal_fractional_fill_is_preserved_without_float_conversion(self):
        self.repo.stage_order(client_order_id="c-decimal", symbol="AAPL", side="buy", notional=100)
        self.repo.record_fill(broker_fill_id="f-decimal", client_order_id="c-decimal", symbol="AAPL",
            quantity=Decimal("0.1234567891"), price=Decimal("123.45678901"), fee=Decimal("0.00000001"))
        with self.sessions() as session:
            fill = session.scalar(select(FillRecord).where(FillRecord.broker_fill_id == "f-decimal"))
            self.assertEqual(fill.quantity, Decimal("0.1234567891"))
            self.assertEqual(fill.price, Decimal("123.45678901"))
            self.assertEqual(fill.fee, Decimal("0.00000001"))

    def test_reused_fill_id_with_different_data_is_rejected(self):
        self.repo.stage_order(client_order_id="c-4", symbol="AAPL", side="buy", notional=100)
        self.repo.record_fill(broker_fill_id="f-4", client_order_id="c-4", symbol="AAPL", quantity=1, price=100)
        with self.assertRaises(OrderRepositoryError):
            self.repo.record_fill(broker_fill_id="f-4", client_order_id="c-4", symbol="AAPL", quantity=2, price=100)

    def test_fill_symbol_must_match_order(self):
        self.repo.stage_order(client_order_id="c-5", symbol="AAPL", side="buy", notional=100)
        with self.assertRaises(OrderRepositoryError):
            self.repo.record_fill(broker_fill_id="f-5", client_order_id="c-5", symbol="MSFT", quantity=1, price=100)

    def test_fill_without_order_and_invalid_values_fail(self):
        with self.assertRaises(OrderRepositoryError):
            self.repo.record_fill(broker_fill_id="f-x", client_order_id="missing", symbol="AAPL", quantity=1, price=1)
        with self.assertRaises(OrderRepositoryError):
            self.repo.record_fill(broker_fill_id="f-y", client_order_id="missing", symbol="AAPL", quantity=-1, price=1)

    def test_pretrade_decisions_are_durable_and_correlated(self):
        self.repo.record_risk_decision(client_order_id="cid-risk-1", symbol="AAPL", side="buy",
            notional=125.0, decision="approved", gate="ALL_PRETRADE_GATES",
            metrics={"equity": 10000.0, "position_count": 2})
        self.repo.record_risk_decision(client_order_id="cid-risk-2", symbol="MSFT", side="buy",
            notional=250.0, decision="blocked", gate="INSTITUTIONAL_RISK",
            reason="Concentration cap", metrics={"equity": 10000.0})
        with self.sessions() as session:
            rows = session.scalars(select(AuditEventRecord).where(
                AuditEventRecord.event_type == "risk_decision").order_by(AuditEventRecord.id)).all()
            self.assertEqual([row.correlation_id for row in rows], ["cid-risk-1", "cid-risk-2"])
            self.assertEqual(rows[0].details["decision"], "approved")
            self.assertEqual(rows[1].details["reason"], "Concentration cap")
            risk = session.scalar(select(RiskEventRecord).where(RiskEventRecord.rule == "INSTITUTIONAL_RISK"))
            self.assertIsNotNone(risk)

    def test_missing_operational_pause_row_fails_closed(self):
        with self.sessions.begin() as session:
            session.delete(session.get(RiskControlStateRecord, 1))
        state = self.repo.get_operational_pause()
        self.assertTrue(state["paused"])
        self.assertIn("absent", state["reason"])
        with self.assertRaises(OrderRepositoryError):
            self.repo.set_operational_pause(paused=True, reason="must not recreate", actor="test")

    def test_operational_pause_survives_repository_restart_and_is_audited(self):
        self.repo.set_operational_pause(paused=True, reason="test emergency", actor="risk_engine")
        # A new repository instance represents a new application process.
        restarted = OrderRepository(self.sessions)
        state = restarted.get_operational_pause()
        self.assertTrue(state["paused"])
        self.assertEqual(state["reason"], "test emergency")
        self.assertEqual(state["actor"], "risk_engine")
        restarted.set_operational_pause(paused=False, actor="operator")
        self.assertFalse(self.repo.get_operational_pause()["paused"])
        with self.sessions() as session:
            events = session.scalars(select(AuditEventRecord).where(
                AuditEventRecord.event_type.in_(["emergency_pause", "trading_resume"])
            ).order_by(AuditEventRecord.id)).all()
            self.assertEqual([event.event_type for event in events], ["emergency_pause", "trading_resume"])

    def test_operational_pause_rejects_invalid_actor(self):
        with self.assertRaises(OrderRepositoryError):
            self.repo.set_operational_pause(paused=True, actor="x" * 65)

    def test_account_and_risk_events_are_durable(self):
        self.repo.record_account_snapshot(equity=10000, cash=5000, buying_power=8000)
        self.repo.record_risk_event(severity="warning", rule="MAX_DRAWDOWN", message="test", metrics={"drawdown": 4.2})
        with self.sessions() as s:
            snap = s.scalar(select(AccountSnapshotRecord))
            risk = s.scalar(select(RiskEventRecord))
            self.assertEqual(snap.equity, Decimal("10000")); self.assertEqual(risk.metrics["drawdown"], 4.2)
            self.assertGreaterEqual(s.scalar(select(func.count()).select_from(AuditEventRecord)), 2)

    def test_operator_auth_throttle_is_persistent_and_windowed(self):
        now = datetime.now(timezone.utc)
        key = "a" * 64
        self.assertFalse(self.repo.operator_auth_is_rate_limited(key, now=now))
        for _ in range(5):
            self.repo.record_operator_auth_failure(key, now=now)
        self.assertTrue(self.repo.operator_auth_is_rate_limited(key, now=now))
        later = datetime.fromtimestamp(now.timestamp() + 601, timezone.utc)
        self.assertFalse(self.repo.operator_auth_is_rate_limited(key, now=later))

    def test_operator_totp_counter_is_single_use_and_monotonic(self):
        self.assertTrue(self.repo.consume_operator_totp_counter(1000))
        self.assertFalse(self.repo.consume_operator_totp_counter(1000))
        self.assertFalse(self.repo.consume_operator_totp_counter(999))
        self.assertTrue(self.repo.consume_operator_totp_counter(1001))

    def test_operator_attempt_reservation_enforces_limit_before_authentication(self):
        now = datetime.now(timezone.utc)
        key = "b" * 64
        self.assertTrue(self.repo.reserve_operator_auth_attempt(key, now=now, limit=2))
        self.assertTrue(self.repo.reserve_operator_auth_attempt(key, now=now, limit=2))
        self.assertFalse(self.repo.reserve_operator_auth_attempt(key, now=now, limit=2))
        later = datetime.fromtimestamp(now.timestamp() + 601, timezone.utc)
        self.assertTrue(self.repo.reserve_operator_auth_attempt(key, now=later, limit=2))


if __name__ == "__main__": unittest.main()
