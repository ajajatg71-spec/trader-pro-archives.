from routers.research_registry import create_research_registry_router
from unittest.mock import Mock

def test_registry_router_exposes_preregister_and_list_but_no_client_result_injection():
    registry = Mock()
    routes = create_research_registry_router(lambda: None, registry).routes
    family_routes = [r for r in routes if r.path == "/api/research/registry/families"]
    assert {method for route in family_routes for method in route.methods} == {"GET", "POST"}
    assert not any(r.path.endswith("/{family_id}/results") for r in routes)
