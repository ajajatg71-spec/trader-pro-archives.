import unittest
from scripts.run_broker_event_worker import (
    validate_environment, run_periodic_reconciliation, periodic_reconciliation_delay,
)


class BrokerEventWorkerEnvironmentTests(unittest.TestCase):
    def base(self):
        return {
            "BROKER": "alpaca",
            "DATABASE_URL": "postgresql+psycopg://user:password@localhost/trader_test",
            "ALPACA_BASE_URL": "https://paper-api.alpaca.markets",
            "APCA_API_KEY_ID": "paper-key",
            "APCA_API_SECRET_KEY": "paper-secret",
        }

    def test_accepts_postgres_and_official_paper_endpoint(self):
        database_url, base_url = validate_environment(self.base())
        self.assertTrue(database_url.startswith("postgresql+psycopg://"))
        self.assertEqual(base_url, "https://paper-api.alpaca.markets")

    def test_rejects_simulator_mode(self):
        env = self.base()
        env["BROKER"] = "sim"
        with self.assertRaises(ValueError):
            validate_environment(env)

    def test_rejects_sqlite_and_non_paper_urls(self):
        env = self.base()
        env["DATABASE_URL"] = "sqlite:///trader.db"
        with self.assertRaises(ValueError):
            validate_environment(env)
        env = self.base()
        env["ALPACA_BASE_URL"] = "https://api.alpaca.markets"
        with self.assertRaises(ValueError):
            validate_environment(env)

    def test_rejects_missing_credentials(self):
        env = self.base()
        env["APCA_API_SECRET_KEY"] = ""
        with self.assertRaises(ValueError):
            validate_environment(env)

    def test_periodic_reconciliation_runs_without_inbox_event(self):
        class Reconciliation:
            calls = 0
            def run(self):
                self.calls += 1
                return {"account_snapshot_saved": True, "truncated_order_snapshot": False,
                        "truncated_fill_snapshot": False, "execution_health": {"status": "healthy"}}
        reconciliation = Reconciliation()
        report = run_periodic_reconciliation(reconciliation)
        self.assertEqual(reconciliation.calls, 1)
        self.assertEqual(report["execution_health"]["status"], "healthy")

    def test_periodic_reconciliation_rejects_truncated_snapshot(self):
        class Reconciliation:
            def run(self):
                return {"account_snapshot_saved": True, "truncated_order_snapshot": True,
                        "truncated_fill_snapshot": False, "execution_health": {"status": "warning"}}
        with self.assertRaises(RuntimeError):
            run_periodic_reconciliation(Reconciliation())

    def test_periodic_reconciliation_retry_uses_capped_exponential_backoff(self):
        self.assertEqual(periodic_reconciliation_delay(failures=0, interval_seconds=300), 300)
        self.assertEqual(periodic_reconciliation_delay(failures=1, interval_seconds=300), 5)
        self.assertEqual(periodic_reconciliation_delay(failures=2, interval_seconds=300), 10)
        self.assertEqual(periodic_reconciliation_delay(failures=3, interval_seconds=300), 20)
        self.assertEqual(periodic_reconciliation_delay(failures=4, interval_seconds=300), 40)
        self.assertEqual(periodic_reconciliation_delay(failures=5, interval_seconds=300), 60)
        self.assertEqual(periodic_reconciliation_delay(failures=99, interval_seconds=30), 30)

    def test_periodic_reconciliation_retry_rejects_invalid_parameters(self):
        for kwargs in (
            {"failures": -1, "interval_seconds": 300},
            {"failures": 1, "interval_seconds": 29},
            {"failures": True, "interval_seconds": 300},
            {"failures": 1, "interval_seconds": 300, "retry_base_seconds": 10, "retry_max_seconds": 5},
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                periodic_reconciliation_delay(**kwargs)


if __name__ == "__main__":
    unittest.main()


class ReconciliationSafetyStateTests(unittest.TestCase):
    def test_failed_reconciliation_degrades_ready_state(self):
        from scripts.run_broker_event_worker import record_reconciliation_outcome
        class Repo:
            state = {"status": "READY"}
            def get_system_safety_state(self): return dict(self.state)
            def transition_system_safety_state(self, **kwargs): self.state.update(kwargs)
        repo = Repo()
        record_reconciliation_outcome(repo, success=False, error_type="TimeoutError")
        self.assertEqual(repo.state["status"], "DEGRADED")
        self.assertIn("TimeoutError", repo.state["reason"])

    def test_successful_reconciliation_never_auto_promotes_to_ready(self):
        from scripts.run_broker_event_worker import record_reconciliation_outcome
        class Repo:
            state = {"status": "DEGRADED"}
            def get_system_safety_state(self): return dict(self.state)
            def transition_system_safety_state(self, **kwargs): self.state.update(kwargs)
        repo = Repo()
        record_reconciliation_outcome(repo, success=True)
        self.assertEqual(repo.state["status"], "RECONCILING")
        self.assertNotEqual(repo.state["status"], "READY")

    def test_halted_state_is_not_overwritten_by_worker_failure_or_success(self):
        from scripts.run_broker_event_worker import record_reconciliation_outcome
        class Repo:
            state = {"status": "HALTED"}
            def get_system_safety_state(self): return dict(self.state)
            def transition_system_safety_state(self, **kwargs): self.state.update(kwargs)
        repo = Repo()
        record_reconciliation_outcome(repo, success=False, error_type="TimeoutError")
        record_reconciliation_outcome(repo, success=True)
        self.assertEqual(repo.state["status"], "HALTED")
