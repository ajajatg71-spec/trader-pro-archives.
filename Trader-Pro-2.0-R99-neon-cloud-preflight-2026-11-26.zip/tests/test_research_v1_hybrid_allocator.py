import pytest

from research_v1.backtesting.hybrid_allocator import allocate_hybrid_portfolio


def candidate(sid, expected=12, vol=20, dd=12, confidence=.9, stability=.9, liquidity=.9):
    return {
        "strategy_id": sid,
        "expected_return_pct": expected,
        "volatility_pct": vol,
        "max_drawdown_pct": dd,
        "confidence": confidence,
        "stability_score": stability,
        "liquidity_score": liquidity,
    }


def test_hybrid_allocator_combines_multiple_factors_and_is_research_only():
    result = allocate_hybrid_portfolio([
        candidate("momentum", expected=15, vol=22),
        candidate("value", expected=10, vol=12, confidence=.95),
        candidate("quality", expected=9, vol=10, stability=.98),
    ])
    assert result["selected_count"] == 3
    assert 0 < result["total_exposure"] <= .90
    assert all(0 < weight <= .35 for weight in result["weights"].values())
    assert result["capital_authorized"] is False
    assert result["orders_created"] == 0
    assert result["broker_access"] is False


def test_hybrid_allocator_rejects_non_positive_expectancy_and_excess_drawdown():
    result = allocate_hybrid_portfolio([
        candidate("negative", expected=-2),
        candidate("deep_dd", dd=40),
        candidate("eligible"),
    ])
    assert set(result["weights"]) == {"eligible"}
    assert {row["strategy_id"] for row in result["rejected"]} == {"negative", "deep_dd"}


def test_hybrid_allocator_diversification_penalizes_high_correlation():
    rows = [candidate("A", expected=15), candidate("B", expected=14), candidate("C", expected=8)]
    corr = {"A": {"B": .99, "C": .05}, "B": {"C": .05}}
    result = allocate_hybrid_portfolio(rows, correlations=corr)
    assert result["selection_order"][0] == "A"
    assert result["selection_order"][1] == "C"


def test_hybrid_allocator_missing_correlation_is_conservative():
    rows = [candidate("A", expected=15), candidate("B", expected=14)]
    result = allocate_hybrid_portfolio(rows, correlations={})
    assert result["selected_count"] == 2
    assert result["diagnostics"]["B"]["mean_positive_correlation"] == 1.0


def test_hybrid_allocator_respects_zero_budget_and_custom_caps():
    result = allocate_hybrid_portfolio(
        [candidate("A")], max_total_exposure=.5, max_strategy_weight=.2,
        risk_budget_pct=0,
    )
    assert result["weights"] == {}
    result = allocate_hybrid_portfolio(
        [candidate("A"), candidate("B")], max_total_exposure=.5,
        max_strategy_weight=.2, risk_budget_pct=.5,
    )
    assert result["total_exposure"] <= .4 + 1e-9
    assert all(w <= .2 for w in result["weights"].values())


@pytest.mark.parametrize("bad", [
    {"expected_return_pct": float("nan")},
    {"volatility_pct": 0},
    {"confidence": 1.1},
    {"liquidity_score": -0.1},
])
def test_hybrid_allocator_rejects_invalid_metrics(bad):
    row = candidate("A")
    row.update(bad)
    with pytest.raises(ValueError):
        allocate_hybrid_portfolio([row])


def test_hybrid_allocator_rejects_invalid_correlation():
    with pytest.raises(ValueError):
        allocate_hybrid_portfolio(
            [candidate("A"), candidate("B")],
            correlations={"A": {"B": 1.5}},
        )


from research_v1.backtesting.hybrid_allocator import build_hybrid_allocation_from_scoreboard


def scoreboard_row(kind, *, cagr=18, vol=20, dd=-12, t=2.4, positive=.8,
                   verdict="prometteuse", evaluated=True):
    return {
        "kind": kind, "cagr_pct": cagr, "volatility_pct": vol,
        "max_drawdown_pct": dd, "hac_t_stat": t,
        "positive_fold_ratio": positive, "verdict": verdict,
        "evaluated": evaluated,
    }


def test_scoreboard_adapter_uses_only_evaluated_promising_rows_and_oos_correlation():
    scoreboard = {
        "results": [
            scoreboard_row("momentum", cagr=18, t=2.4),
            scoreboard_row("trend", cagr=12, t=1.8),
            scoreboard_row("rejected", verdict="rejetée"),
            scoreboard_row("unevaluated", evaluated=False),
        ],
        "strategy_return_correlation": {
            "matrix": {
                "momentum": {"trend": .10},
                "trend": {"momentum": .10},
            }
        },
    }
    result = build_hybrid_allocation_from_scoreboard(
        scoreboard, liquidity_scores={"momentum": .9, "trend": .8}
    )
    assert set(result["weights"]) == {"momentum", "trend"}
    assert result["source"] == "evaluated_promising_portfolio_oos_scoreboard"
    assert result["capital_authorized"] is False
    assert result["orders_created"] == 0


def test_scoreboard_adapter_fails_closed_when_liquidity_evidence_is_missing():
    scoreboard = {
        "results": [scoreboard_row("momentum")],
        "strategy_return_correlation": {"matrix": {"momentum": {"momentum": 1.0}}},
    }
    result = build_hybrid_allocation_from_scoreboard(scoreboard, liquidity_scores={})
    assert result["weights"] == {}
    assert result["rejected"] == [{
        "strategy_id": "momentum", "reason": "validated_liquidity_score_missing"
    }]


def test_scoreboard_adapter_uses_hac_confidence_and_positive_fold_stability():
    scoreboard = {
        "results": [scoreboard_row("momentum", t=0.0)],
        "strategy_return_correlation": {"matrix": {"momentum": {"momentum": 1.0}}},
    }
    result = build_hybrid_allocation_from_scoreboard(
        scoreboard, liquidity_scores={"momentum": 1.0}
    )
    assert result["weights"] == {}
    assert result["rejected"][0]["reason"] == "insufficient_quality_score"


def test_scoreboard_adapter_rejects_malformed_scoreboard():
    with pytest.raises(ValueError):
        build_hybrid_allocation_from_scoreboard({}, liquidity_scores={})
    with pytest.raises(ValueError):
        build_hybrid_allocation_from_scoreboard(
            {"results": [scoreboard_row("x")],
             "strategy_return_correlation": {"matrix": {"x": {"x": 1.0}}}},
            liquidity_scores={"x": 1.2},
        )
