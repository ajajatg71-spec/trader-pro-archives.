"""Static deployment guardrails for the runtime container."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_runtime_container_drops_root_privileges():
    dockerfile = (ROOT / "Dockerfile").read_text(encoding="utf-8")
    runtime = dockerfile.split("FROM python:3.12-slim AS runtime", 1)[1]
    assert "groupadd --system --gid 10001 trader" in runtime
    assert "useradd --system --uid 10001" in runtime
    assert "USER 10001:10001" in runtime


def test_runtime_code_is_not_owned_by_unprivileged_user():
    dockerfile = (ROOT / "Dockerfile").read_text(encoding="utf-8")
    assert "COPY . ./" in dockerfile
    assert "COPY --chown=10001:10001 . ./" not in dockerfile
    assert "chown -R 10001:10001 /app" not in dockerfile


def test_only_dedicated_state_directory_is_writable():
    dockerfile = (ROOT / "Dockerfile").read_text(encoding="utf-8")
    assert "TRADER_STATE_DIR=/var/lib/trader-pro" in dockerfile
    assert "chown -R 10001:10001 /var/lib/trader-pro" in dockerfile


def test_frontend_build_is_copied_into_runtime_image():
    dockerfile = (ROOT / "Dockerfile").read_text(encoding="utf-8")
    assert "COPY --from=frontend-build /web/dist ./frontend/dist" in dockerfile



def test_production_compose_runs_app_fail_closed_with_persistent_state():
    compose = (ROOT / "compose.yaml").read_text(encoding="utf-8")
    assert "  app:" in compose
    assert "condition: service_healthy" in compose
    assert "BROKER: alpaca" in compose
    assert "ALPACA_BASE_URL: https://paper-api.alpaca.markets" in compose
    assert "DATABASE_URL: ${DATABASE_URL:?Set DATABASE_URL" in compose
    assert "trader_pro_state:/var/lib/trader-pro" in compose
    assert '127.0.0.1:${APP_PORT:-8000}:8000' in compose
    assert "read_only: true" in compose
    assert "cap_drop:" in compose and "      - ALL" in compose
    assert "TRADER_OPERATOR_TOTP_SECRET" in compose



def test_deployment_runbook_and_example_env_are_present_and_secret_free():
    runbook = (ROOT / "DEPLOY.md").read_text(encoding="utf-8")
    example = (ROOT / ".env.example").read_text(encoding="utf-8")
    assert "alembic upgrade head" in runbook
    assert "scripts/verify_postgres.sh" in runbook
    assert "scripts/verify_alpaca_paper_readonly.py" in runbook
    assert "REPLACE_WITH_ALPACA_PAPER_KEY" in example
    assert "REPLACE_WITH_ALPACA_PAPER_SECRET" in example
    assert "REPLACE_WITH_UNIQUE_BASE32_TOTP_SECRET" in example
    assert "paper-api.alpaca.markets" in (ROOT / "compose.yaml").read_text(encoding="utf-8")



def test_frontend_lock_bootstrap_and_online_ci_are_documented():
    script = (ROOT / "scripts/prepare_frontend_build.sh").read_text(encoding="utf-8")
    workflow = (ROOT / ".github/workflows/frontend-docker-build.yml").read_text(encoding="utf-8")
    assert "npm install --package-lock-only" in script
    assert "npm ci" in script
    assert "npm run typecheck" in script
    assert "npm run build" in script
    assert "npm install --package-lock-only" in workflow
    assert "docker build --tag trader-pro:ci ." in workflow
    assert "cache-dependency-path" not in workflow
    assert "docker compose run --rm --no-deps app python scripts/deployment_preflight.py" in (ROOT / "DEPLOY.md").read_text(encoding="utf-8")
    assert "actions/upload-artifact@v4" in workflow
