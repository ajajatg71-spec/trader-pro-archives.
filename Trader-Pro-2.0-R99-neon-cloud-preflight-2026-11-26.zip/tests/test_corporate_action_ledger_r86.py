import unittest
from datetime import date,datetime,timezone,timedelta
from research_v1.quant.corporate_actions import CorporateActionEvent
from research_v1.quant.corporate_action_ledger import CorporateActionRevision
from research_v1.backtesting.backtest import evaluate_total_return_history_from_ledger
class LedgerBacktestIntegrationTests(unittest.TestCase):
 def setUp(self):
  self.ts=[datetime(2025,1,d,21,tzinfo=timezone.utc) for d in (2,3,6,7)]
  self.event=CorporateActionEvent("AAPL","dividend",date(2025,1,6),self.ts[0],"alpaca",cash_amount="1",currency="USD",event_id="e1")
 def test_uses_point_in_time_event_snapshot(self):
  rev=CorporateActionRevision("alpaca","e1",1,self.ts[0],"active",self.event)
  out=evaluate_total_return_history_from_ledger([100,100,99,99],self.ts,[rev],as_of=self.ts[-1],symbol="AAPL",currency="USD",price_basis="raw")
  self.assertEqual(out["corporate_action_events"],1);self.assertEqual(out["total_return_index"],[100.0,100.0,100.0,100.0])
 def test_cancellation_prevents_using_old_dividend(self):
  active=CorporateActionRevision("alpaca","e1",1,self.ts[0],"active",self.event)
  cancelled=CorporateActionRevision("alpaca","e1",2,self.ts[2],"cancelled",None)
  out=evaluate_total_return_history_from_ledger([100,100,99,99],self.ts,[active,cancelled],as_of=self.ts[-1],symbol="AAPL",currency="USD",price_basis="raw")
  self.assertEqual(out["corporate_action_events"],0);self.assertAlmostEqual(out["total_return_index"][-1],99)
 def test_rejects_wrong_symbol_after_snapshot(self):
  rev=CorporateActionRevision("alpaca","e1",1,self.ts[0],"active",self.event)
  with self.assertRaisesRegex(ValueError,"appartenir au symbole"):
   evaluate_total_return_history_from_ledger([100,100,99,99],self.ts,[rev],as_of=self.ts[-1],symbol="MSFT",currency="USD",price_basis="raw")
if __name__=="__main__":unittest.main()
