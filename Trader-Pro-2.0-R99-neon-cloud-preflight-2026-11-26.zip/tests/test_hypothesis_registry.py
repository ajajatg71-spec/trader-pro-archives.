import pytest
from research_v1.validation.hypothesis_registry import canonical_family_id, adjust_complete_family


def test_family_id_is_order_independent_and_changes_with_protocol():
    a = canonical_family_id(study="candles", universe=["msft", "AAPL"], hypotheses=["h2", "h1"], protocol_version="v1")
    b = canonical_family_id(study=" candles ", universe=["AAPL", "MSFT"], hypotheses=["h1", "h2"], protocol_version="v1")
    c = canonical_family_id(study="candles", universe=["AAPL", "MSFT"], hypotheses=["h1", "h2"], protocol_version="v2")
    assert a == b
    assert a != c


def test_holm_requires_complete_family_and_adjusts_all_p_values():
    result = adjust_complete_family(["a", "b", "c"], {"a": .01, "b": .04, "c": .03})
    assert result["family_size"] == 3
    assert result["adjusted_p_values"] == {"a": .03, "c": .06, "b": .06}
    assert result["selection_authorized"] is False
    with pytest.raises(ValueError, match="incomplète"):
        adjust_complete_family(["a", "b"], {"a": .01})


def test_holm_rejects_invalid_values_and_duplicate_ids():
    with pytest.raises(ValueError):
        adjust_complete_family(["a"], {"a": float("nan")})
    with pytest.raises(ValueError):
        adjust_complete_family(["a", "a"], {"a": .01})
