from __future__ import annotations

import pytest
from scripts.verify_neon_sqlalchemy_readonly import (
    EXPECTED_DATABASE,
    PreflightError,
    validate_database_url,
)


def test_preflight_accepts_only_the_dedicated_postgresql_test_database():
    url = validate_database_url(
        "postgresql://trader:secret@example.neon.tech/trader_pro_test?sslmode=require"
    )
    assert url.get_backend_name() == "postgresql"
    assert url.database == EXPECTED_DATABASE


@pytest.mark.parametrize("database", ["neondb", "trader_pro_restore", "production"])
def test_preflight_refuses_every_database_except_trader_pro_test(database):
    with pytest.raises(PreflightError, match="only 'trader_pro_test' is allowed"):
        validate_database_url(f"postgresql://user:secret@localhost/{database}")


def test_preflight_requires_a_url():
    with pytest.raises(PreflightError, match="TRADER_PRO_TEST_DATABASE_URL is required"):
        validate_database_url(None)


def test_preflight_refuses_non_postgresql_urls():
    with pytest.raises(PreflightError, match="Only PostgreSQL is supported"):
        validate_database_url("sqlite:///trader_pro_test.db")


def test_preflight_requires_neon_host_and_tls():
    with pytest.raises(PreflightError, match="Only a Neon PostgreSQL endpoint"):
        validate_database_url("postgresql://user:secret@localhost/trader_pro_test?sslmode=require")
    with pytest.raises(PreflightError, match="must require TLS"):
        validate_database_url("postgresql://user:secret@example.neon.tech/trader_pro_test")


def test_preflight_accepts_neon_pooler_endpoint_with_tls():
    url = validate_database_url(
        "postgresql://user:secret@ep-example-pooler.eu-central-1.aws.neon.tech/"
        "trader_pro_test?sslmode=verify-full"
    )
    assert url.host.endswith(".neon.tech")
