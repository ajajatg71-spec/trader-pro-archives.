"""Fail-closed and no-order tests for the Alpaca Paper read-only smoke script."""
from __future__ import annotations

import contextlib
import io
import runpy
import sys
import types
import unittest
from unittest.mock import Mock, patch

SCRIPT = "scripts/verify_alpaca_paper_readonly.py"


class AlpacaPaperReadonlyScriptTests(unittest.TestCase):
    def run_script(self, *, sim=False, base="https://paper-api.alpaca.markets",
                   key="paper-key", secret="paper-secret", account_result=None,
                   positions_result=None, clock_result=None, bars_result=None):
        config = types.ModuleType("config")
        config.BASE, config.KEY, config.SECRET, config.SIM = base, key, secret, sim

        broker = types.ModuleType("broker")
        broker.is_approved_paper_url = lambda value: value == "https://paper-api.alpaca.markets"
        broker.account = Mock(return_value=account_result if account_result is not None else {"status": "ACTIVE", "trading_blocked": False})
        broker.positions = Mock(return_value=positions_result if positions_result is not None else [])
        broker.clock = Mock(return_value=clock_result if clock_result is not None else {"is_open": False})
        broker.bars3 = Mock(return_value=bars_result if bars_result is not None else (["2026-11-13T00:00:00Z"], [600.0], [1000]))

        stdout, stderr = io.StringIO(), io.StringIO()
        with patch.dict(sys.modules, {"config": config, "broker": broker}), \
             contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            try:
                namespace = runpy.run_path(SCRIPT, run_name="readonly_test_module")
                result = namespace["main"]()
            except SystemExit as exc:
                result = int(exc.code)
        return result, stdout.getvalue(), stderr.getvalue(), broker

    def test_valid_paper_check_calls_only_read_methods(self):
        result, out, err, broker = self.run_script()
        self.assertEqual(result, 0, err)
        self.assertIn("ALPACA_PAPER_READ_ONLY_OK", out)
        self.assertIn("orders_submitted=0", out)
        broker.account.assert_called_once_with()
        broker.positions.assert_called_once_with()
        broker.clock.assert_called_once_with()
        broker.bars3.assert_called_once_with("SPY", limit=5)
        self.assertFalse(any(name in broker.__dict__ for name in ("order", "limit_order", "cancel")))

    def test_simulated_broker_is_refused_before_network_calls(self):
        result, _, err, broker = self.run_script(sim=True)
        self.assertEqual(result, 2)
        self.assertIn("BROKER=sim", err)
        broker.account.assert_not_called()

    def test_non_paper_endpoint_is_refused(self):
        result, _, err, broker = self.run_script(base="https://api.alpaca.markets")
        self.assertEqual(result, 2)
        self.assertIn("URL officielle Alpaca Paper", err)
        broker.account.assert_not_called()

    def test_missing_credentials_are_refused(self):
        result, _, err, broker = self.run_script(key="")
        self.assertEqual(result, 2)
        self.assertIn("manquant", err)
        broker.account.assert_not_called()

    def test_blocked_account_fails_closed(self):
        result, _, err, _ = self.run_script(account_result={"status": "ACTIVE", "trading_blocked": True})
        self.assertEqual(result, 1)
        self.assertIn("compte Paper est bloqué", err)

    def test_malformed_market_data_fails_closed(self):
        result, _, err, _ = self.run_script(bars_result=(["t1", "t2"], [1.0], [10]))
        self.assertEqual(result, 1)
        self.assertIn("absentes ou incohérentes", err)

    def test_empty_market_data_fails_closed(self):
        result, _, err, _ = self.run_script(bars_result=([], [], []))
        self.assertEqual(result, 1)
        self.assertIn("absentes ou incohérentes", err)

    def test_malformed_account_response_fails_closed(self):
        result, _, err, _ = self.run_script(account_result=[])
        self.assertEqual(result, 1)
        self.assertIn("Réponse Alpaca mal formée", err)

    def test_missing_account_safety_fields_fail_closed(self):
        result, _, err, _ = self.run_script(account_result={"status": "ACTIVE"})
        self.assertEqual(result, 1)
        self.assertIn("statut ou trading_blocked absent", err)

    def test_malformed_position_fails_closed(self):
        result, _, err, _ = self.run_script(positions_result=[{"symbol": "AAPL"}])
        self.assertEqual(result, 1)
        self.assertIn("positions mal formée", err)

    def test_missing_market_clock_state_fails_closed(self):
        result, _, err, _ = self.run_script(clock_result={})
        self.assertEqual(result, 1)
        self.assertIn("horloge de marché incomplète", err)

    def test_non_finite_market_bar_fails_closed(self):
        result, _, err, _ = self.run_script(
            bars_result=(["2026-11-13T00:00:00Z"], [float("nan")], [1000])
        )
        self.assertEqual(result, 1)
        self.assertIn("valeurs invalides", err)

    def test_non_numeric_market_bar_fails_closed(self):
        result, _, err, _ = self.run_script(
            bars_result=(["2026-11-13T00:00:00Z"], ["not-a-price"], [1000])
        )
        self.assertEqual(result, 1)
        self.assertIn("valeurs non numériques", err)


if __name__ == "__main__":
    unittest.main()
