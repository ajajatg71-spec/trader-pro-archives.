import pytest

import broker
from broker_errors import BrokerError


def test_asset_metadata_normalizes_trusted_alpaca_equity_fields(monkeypatch):
    monkeypatch.setattr(broker, "_r", lambda method, path: {
        "class": "us_equity", "status": "active", "tradable": True
    })
    assert broker.asset_metadata("aapl") == {
        "symbol": "AAPL", "asset_class": "us_equity", "status": "active",
        "active": True, "tradable": True,
    }


@pytest.mark.parametrize("payload", [
    None,
    {"class": "us_equity", "status": "active"},
    {"class": None, "status": "active", "tradable": True},
    {"class": "us_equity", "status": "unknown", "tradable": "yes"},
])
def test_asset_metadata_rejects_incomplete_provider_payload(monkeypatch, payload):
    monkeypatch.setattr(broker, "_r", lambda method, path: payload)
    with pytest.raises(BrokerError):
        broker.asset_metadata("AAPL")


def test_asset_metadata_rejects_invalid_symbol_before_provider_call(monkeypatch):
    called = []
    monkeypatch.setattr(broker, "_r", lambda *args, **kwargs: called.append(args))
    with pytest.raises(BrokerError):
        broker.asset_metadata("../AAPL")
    assert called == []
