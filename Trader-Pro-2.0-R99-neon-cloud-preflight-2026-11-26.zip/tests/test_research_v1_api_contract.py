import os
from datetime import datetime, timedelta, timezone

os.environ.setdefault("BROKER", "sim")
os.environ.setdefault("APP_PASSWORD", "research-test-password-long-enough")

from fastapi.testclient import TestClient
import app as trader_app
from services.market_data import OHLCVDailyBars


def fake_bars(symbol: str, n: int = 320, offset: float = 0.0):
    stamps = tuple(datetime(2025, 1, 1, tzinfo=timezone.utc) + timedelta(days=i) for i in range(n))
    closes = tuple(100 + offset + i * 0.08 + ((i % 9) - 4) * 0.12 for i in range(n))
    opens = tuple(c - 0.2 for c in closes)
    highs = tuple(c + 0.8 for c in closes)
    lows = tuple(c - 0.8 for c in closes)
    volumes = tuple(100_000 + (i % 11) * 1_000 for i in range(n))
    return OHLCVDailyBars(symbol, opens, highs, lows, closes, volumes,
                          datetime.now(timezone.utc), source="test", timestamps=stamps, adjustment_mode="split")


class FakeMarketData:
    def daily_ohlcv(self, symbol, limit):
        return fake_bars(symbol, min(limit, 320), offset=sum(map(ord, symbol)) % 7)


class TestResearchAPIContract:
    def setup_method(self):
        self.client = TestClient(trader_app.app)
        self.old_service = trader_app.MARKET_DATA_SERVICE
        self.old_freshness = trader_app.require_fresh_daily_bars
        trader_app.MARKET_DATA_SERVICE = FakeMarketData()
        trader_app.require_fresh_daily_bars = lambda *a, **k: None
        trader_app.app.dependency_overrides[trader_app.guard] = lambda: None

    def teardown_method(self):
        trader_app.MARKET_DATA_SERVICE = self.old_service
        trader_app.require_fresh_daily_bars = self.old_freshness
        trader_app.app.dependency_overrides.pop(trader_app.guard, None)

    def test_candle_analysis_endpoint_uses_validated_ohlcv_and_never_trades(self):
        response = self.client.post("/api/research/candles/analysis", json={
            "symbol": "AAPL", "limit": 250, "atr_period": 14, "volume_period": 20
        })
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["symbol"] == "AAPL"
        assert body["timeframe"] == "1day"
        assert body["mode"] == "CANDLE_RESEARCH_ONLY"
        assert body["execution"] == "NONE"
        assert body["orders_created"] == 0
        assert body["strategies_activated"] == 0
        assert body["analysis"]["observations"] == 250
        assert "patterns" in body["analysis"]
        assert isinstance(body["advanced_patterns"], list)
        assert body["advanced_pattern_catalog_size"] == 36
        assert body["advanced_scan_lookback"] == 5
        assert body["profitability_guaranteed"] is False

    def test_catalog_exposes_50_types_without_activation(self):
        response = self.client.get("/api/research/strategies/catalog")
        assert response.status_code == 200
        body = response.json()
        assert (body["total"], body["per_symbol"], body["portfolio"]) == (50, 43, 7)
        assert body["execution"] == "DRY_RUN_ONLY"
        assert body["orders_created"] == 0

    def test_single_symbol_dry_run_never_creates_orders(self):
        response = self.client.post("/api/research/strategies/golden_cross/dry-run", json={
            "symbol": "AAPL", "limit": 320, "benchmark_symbol": "SPY", "params": {}
        })
        assert response.status_code == 200
        body = response.json()
        assert body["mode"] == "RESEARCH_DRY_RUN"
        assert body["broker_access"] is False
        assert body["orders_created"] == 0

    def test_portfolio_dry_run_requires_universe_and_never_creates_orders(self):
        response = self.client.post("/api/research/portfolio-strategies/dual_momentum/dry-run", json={
            "symbols": ["AAPL", "MSFT"], "equity": 100_000, "limit": 320, "params": {}
        })
        assert response.status_code == 200
        body = response.json()
        assert body["mode"] == "RESEARCH_DRY_RUN"
        assert body["broker_access"] is False
        assert body["orders_created"] == 0

    def test_portfolio_backtest_endpoint_is_simulation_only(self):
        response = self.client.post("/api/research/portfolio-strategies/dual_momentum/backtest", json={
            "symbols": ["AAPL", "MSFT", "NVDA"], "benchmark_symbol": "SPY",
            "limit": 320, "warmup": 60, "initial_cash": 100000,
            "params": {"lookback": 60, "top_n": 1, "exit_rank": 2,
                       "position_pct": 0.8, "abs_min": -0.2}
        })
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["mode"] == "RESEARCH_BACKTEST"
        assert body["execution"] == "HISTORICAL_SIMULATION_ONLY"
        assert body["broker_access"] is False
        assert body["orders_created"] == 0
        assert body["strategies_activated"] == 0
        assert len(body["equity_curve"]) == 320



    def test_multi_factor_backtest_requires_point_in_time_fundamentals(self):
        response = self.client.post("/api/research/portfolio-strategies/multi_factor/backtest", json={
            "symbols": ["AAPL", "MSFT", "NVDA"], "benchmark_symbol": "SPY",
            "limit": 320, "warmup": 130,
        })
        assert response.status_code == 422, response.text
        assert "point-in-time" in response.json()["detail"]

    def test_portfolio_scoreboard_is_walk_forward_and_never_activates(self):
        response = self.client.post("/api/research/portfolio-strategies/scoreboard", json={
            "symbols": ["AAPL", "MSFT", "NVDA"], "benchmark_symbol": "SPY",
            "limit": 500, "warmup": 60, "test_window": 63,
            "min_oos_bars": 756, "min_folds": 6,
        })
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["mode"] == "WALK_FORWARD_OOS_RESEARCH"
        assert body["execution"] == "NONE"
        assert body["broker_access"] is False
        assert body["orders_created"] == 0
        assert body["strategies_activated"] == 0
        assert body["profitability_guaranteed"] is False
        assert len(body["results"]) == 7
        assert all(row["verdict"] == "non démontrée" for row in body["results"])
        momentum = next(row for row in body["results"] if row["kind"] == "momentum")
        assert momentum["effective_warmup"] >= 253
        multi = next(row for row in body["results"] if row["kind"] == "multi_factor")
        assert multi["evaluated"] is False
        assert multi["blocked_by"] == "point_in_time_fundamentals_missing"
        assert body["multiple_testing"]["evaluated_count"] == 6
        assert body["multiple_testing"]["family_size"] == 50
        assert body["multiple_testing"]["strategies_in_scoreboard"] == 7
        assert body["multiple_testing"]["z_threshold"] > 3.2

    def test_scoreboard_endpoint_is_historical_research_only(self):
        response = self.client.post("/api/research/strategies/scoreboard", json={
            "symbols": ["AAPL", "MSFT", "NVDA"], "benchmark_symbol": "SPY",
            "limit": 320, "split": 0.6, "fee": 0.0005, "slippage": 0.0005,
            "warmup": 60
        })
        assert response.status_code == 200
        body = response.json()
        assert body["mode"] == "HISTORICAL_OOS_RESEARCH"
        assert body["execution"] == "NONE"
        assert body["strategies_activated"] == 0
        assert body["profitability_guaranteed"] is False
        assert body["tested"] == 43
        assert body["family_size"] == 50
        assert body["z_threshold"] > 3.2
