from fastapi import FastAPI
from fastapi.testclient import TestClient
from types import SimpleNamespace

from routers.analytics import create_analytics_router


class Broker:
    def clock(self):
        return {"is_open": True}

    def equity_curve(self, period):
        return [("2026-01-01", 100.0), ("2026-01-02", None)]

    def news(self, symbol, limit):
        return [f"{symbol} headline"]

    def closes_long(self, symbol):
        return [100.0] * 300


class Backtest:
    STRATS = {"sma"}

    @staticmethod
    def optimize(*args, **kwargs):
        return {"params": {}, "overfit": False,
                "test": {"return_pct": 1.2, "sharpe": 0.8}}


def build_client():
    state = {"paused": False, "inst": {}, "limits": {
        "stop_loss_pct": 8, "trailing_pct": 12, "take_profit_pct": 0,
        "risk_per_trade": 1, "stop_k": 2, "max_pos": 25}}
    history = [
        {"kind": "decision", "msg": "AAPL : acheter", "t": "2026-01-01T10:00:00"},
        {"kind": "order", "msg": "Achat AAPL", "t": "2026-01-01T10:01:00"},
    ]
    writes = []
    router = create_analytics_router(
        guard_dependency=lambda: None, broker=Broker(), state=state,
        history_reader=lambda n: history[-n:], history_writer=lambda *a, **k: writes.append((a, k)),
        beat={"t": 9999999999}, totp_enabled=False, mode="simulation",
        sentiment=SimpleNamespace(score=lambda items: 0.5),
        thirteen_f=SimpleNamespace(compare=lambda value: {"count": len(value)}),
        backtest=Backtest, risklib=SimpleNamespace(),
    )
    app = FastAPI()
    app.include_router(router)
    return TestClient(app), writes


def test_read_only_analytics_routes():
    client, _ = build_client()
    assert client.get("/api/health").json()["mode"] == "simulation"
    assert client.get("/api/equity?period=1M").json() == [{"t": "2026-01-01", "v": 100.0}]
    assert len(client.get("/api/decisions?n=10").json()) == 1
    assert len(client.get("/api/opportunities").json()) == 1
    assert "2026-01-01" in client.get("/api/calendar").json()
    assert client.get("/api/news?symbols=aapl").json()[0]["symbol"] == "AAPL"
    assert client.get("/api/compare").json() == {"count": 0}


def test_analytics_validation_and_backtest_audit():
    client, writes = build_client()
    assert client.get("/api/equity?period=bad").status_code == 400
    assert client.get("/api/backtest?symbol=AAPL&strategy=bad").status_code == 400
    response = client.get("/api/backtest?symbol=AAPL")
    assert response.status_code == 200
    assert writes and writes[0][0][0] == "backtest"
