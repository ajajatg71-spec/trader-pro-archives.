import json
import math
import unittest
from types import SimpleNamespace

from research_v1.quant.chart_reading import read


def make_bars(n=260, drift=0.002):
    bars = []
    previous = 100.0
    for i in range(n):
        close = 100.0 * ((1.0 + drift) ** i) * (1.0 + 0.012 * math.sin(i / 5.0))
        open_ = previous
        high = max(open_, close) * 1.006
        low = min(open_, close) * 0.994
        bars.append(SimpleNamespace(
            symbol="TEST", ts=f"2025-{(i // 28) + 1:02d}-{(i % 28) + 1:02d}T16:00:00Z",
            o=open_, h=high, l=low, c=close, v=1000.0 + (i % 13) * 25.0
        ))
        previous = close
    return bars


class ChartReadingTests(unittest.TestCase):
    def test_returns_descriptive_structure_and_json(self):
        result = read(make_bars())
        for key in (
            "symbol", "as_of", "price", "candle", "patterns", "trend",
            "levels", "volume", "volatility", "momentum", "bias",
            "summary", "warning", "research_only",
        ):
            self.assertIn(key, result)
        self.assertEqual(result["symbol"], "TEST")
        self.assertTrue(result["research_only"])
        self.assertIn(result["bias"]["label"], ("haussier", "baissier", "neutre"))
        self.assertGreaterEqual(result["bias"]["score"], -1.0)
        self.assertLessEqual(result["bias"]["score"], 1.0)
        json.dumps(result)

    def test_no_lookahead_for_truncated_history(self):
        bars = make_bars()
        for end in (100, 180, len(bars) - 1):
            result = read(bars[:end + 1])
            self.assertEqual(result["price"], bars[end].c)
            self.assertEqual(result["as_of"], bars[end].ts)

    def test_rejects_short_history_and_bad_ohlcv(self):
        with self.assertRaises(ValueError):
            read(make_bars(29))
        bars = make_bars()
        bars[50] = SimpleNamespace(symbol="TEST", ts="2025-02-23T16:00:00Z",
                                   o=100, h=99, l=98, c=100, v=10)
        with self.assertRaises(ValueError):
            read(bars)

    def test_rejects_out_of_order_timestamps(self):
        bars = make_bars()
        bars[10].ts, bars[11].ts = bars[11].ts, bars[10].ts
        with self.assertRaises(ValueError):
            read(bars)

    def test_deterministic_output(self):
        bars = make_bars()
        self.assertEqual(read(bars), read(bars))


if __name__ == "__main__":
    unittest.main()
