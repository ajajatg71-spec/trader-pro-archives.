from datetime import datetime, timezone
import unittest

from services.strategy_engine import (
    BreakoutStrategy, Direction, MeanReversionStrategy, MomentumStrategy,
    StrategyConfig, StrategyError, StrategyRegistry, StrategySignal,
    TrendFollowingStrategy,
)

NOW = datetime(2026, 11, 11, 12, 0, tzinfo=timezone.utc)


class SignalModelTests(unittest.TestCase):
    def test_rejects_naive_timestamp(self):
        with self.assertRaises(StrategyError):
            StrategySignal("momentum", "AAPL", Direction.BUY, .5, .5,
                           datetime(2026, 1, 1), "1.0", "test")

    def test_rejects_out_of_range_strength(self):
        with self.assertRaises(StrategyError):
            StrategySignal("momentum", "AAPL", Direction.BUY, 1.1, .5,
                           NOW, "1.0", "test")


class StrategyTests(unittest.TestCase):
    def test_momentum_returns_normalized_signal(self):
        strategy = MomentumStrategy()
        prices = [100 + i for i in range(40)]
        signal = strategy.generate_signal("aapl", prices, timestamp=NOW,
                                          config=StrategyConfig({"lookback": 10}))
        self.assertEqual(signal.strategy_id, "momentum")
        self.assertEqual(signal.symbol, "AAPL")
        self.assertEqual(signal.direction, Direction.BUY)
        self.assertGreater(signal.strength, 0)
        self.assertEqual(signal.parameters_version, "1.0.0")

    def test_insufficient_history_is_neutral(self):
        signal = MomentumStrategy().generate_signal(
            "MSFT", [100, 101], timestamp=NOW, config=StrategyConfig({"lookback": 20}))
        self.assertEqual(signal.direction, Direction.NEUTRAL)
        self.assertEqual(signal.confidence, 0)

    def test_all_initial_strategies_produce_typed_signals(self):
        prices = [100 + i * .2 for i in range(80)]
        for strategy in (MomentumStrategy(), TrendFollowingStrategy(),
                         MeanReversionStrategy(), BreakoutStrategy()):
            with self.subTest(strategy=strategy.metadata.strategy_id):
                signal = strategy.generate_signal("SPY", prices, timestamp=NOW,
                                                   config=StrategyConfig({}))
                self.assertIsInstance(signal, StrategySignal)
                self.assertEqual(signal.strategy_id, strategy.metadata.strategy_id)

    def test_invalid_configuration_rejected(self):
        with self.assertRaises(StrategyError):
            MomentumStrategy().generate_signal("AAPL", [100, 101], timestamp=NOW,
                                               config=StrategyConfig({"lookback": 1}))


class RegistryTests(unittest.TestCase):
    def test_register_activate_deactivate(self):
        registry = StrategyRegistry()
        strategy = MomentumStrategy()
        registry.register(strategy)
        self.assertFalse(registry.is_active("momentum"))
        registry.activate("momentum")
        self.assertTrue(registry.is_active("momentum"))
        registry.deactivate("momentum")
        self.assertFalse(registry.is_active("momentum"))

    def test_duplicate_and_unknown_strategy_rejected(self):
        registry = StrategyRegistry()
        registry.register(MomentumStrategy())
        with self.assertRaises(StrategyError):
            registry.register(MomentumStrategy())
        with self.assertRaises(StrategyError):
            registry.get("missing")

    def test_unhealthy_strategy_cannot_activate(self):
        strategy = MomentumStrategy()
        strategy.health_check = lambda: False
        registry = StrategyRegistry()
        registry.register(strategy)
        with self.assertRaises(StrategyError):
            registry.activate("momentum")
        self.assertFalse(registry.is_active("momentum"))

    def test_breakout_rejects_invalid_market_data(self):
        for prices in ([100, 0, 101], [100, float("nan"), 102], [100, "bad", 102]):
            with self.subTest(prices=prices), self.assertRaises(StrategyError):
                BreakoutStrategy().generate_signal("SPY", prices, timestamp=NOW,
                                                   config=StrategyConfig({}))

    def test_configuration_requires_version(self):
        with self.assertRaises(StrategyError):
            StrategyConfig({}, version=" ")

    def test_configuration_rejects_bool_non_numeric_and_non_finite_parameters(self):
        for parameters in ({"lookback": True}, {"scale_pct": float("nan")},
                           {"scale_pct": float("inf")}, {"lookback": "20"}):
            with self.subTest(parameters=parameters), self.assertRaises(StrategyError):
                StrategyConfig(parameters)

class OrchestrationTests(unittest.TestCase):
    def test_correlation_family_counts_as_one_vote(self):
        from services.strategy_engine.orchestration import SignalAggregator
        signals = [
            StrategySignal("momentum", "AAPL", Direction.BUY, 1, 1, NOW, "1", "m"),
            StrategySignal("trend_following", "AAPL", Direction.BUY, 1, 1, NOW, "1", "t"),
            StrategySignal("breakout", "AAPL", Direction.SELL, 1, 1, NOW, "1", "b"),
        ]
        aggregate = SignalAggregator().aggregate(signals, symbol="AAPL")
        self.assertEqual(aggregate.independent_groups, 2)
        self.assertEqual(aggregate.direction, Direction.NEUTRAL)

    def test_unknown_regime_fails_closed(self):
        from services.strategy_engine.orchestration import StrategySelector
        self.assertEqual(StrategySelector().select("NOT_KNOWN", ["momentum"]), ())

    def test_aggregator_rejects_mixed_symbol_signals(self):
        from services.strategy_engine.orchestration import SignalAggregator
        signal = StrategySignal("momentum", "MSFT", Direction.BUY, 1, 1, NOW, "1", "m")
        with self.assertRaises(StrategyError):
            SignalAggregator().aggregate([signal], symbol="AAPL")

    def test_aggregator_and_allocator_reject_boolean_thresholds(self):
        from services.strategy_engine.orchestration import SignalAggregator, StrategyAllocator
        with self.assertRaises(StrategyError):
            SignalAggregator(minimum_confidence=True)
        with self.assertRaises(StrategyError):
            StrategyAllocator(max_allocation_pct=True)
        with self.assertRaises(StrategyError):
            StrategyAllocator(min_confidence=True)

    def test_allocator_creates_proposal_not_order(self):
        from services.strategy_engine.orchestration import AggregatedSignal, StrategyAllocator
        proposal = StrategyAllocator().propose(AggregatedSignal(
            "AAPL", Direction.BUY, .5, .8, ("momentum",), 1, "test"))
        self.assertEqual(proposal.allocation_pct, 2.5)
        self.assertEqual(proposal.status, "PENDING_RISK")
        self.assertFalse(proposal.approved_by_risk)

    def test_risk_gate_fails_closed_and_never_approves_non_buy(self):
        from services.strategy_engine.orchestration import (
            AggregatedSignal, StrategyAllocator, risk_gate,
        )
        proposal = StrategyAllocator().propose(AggregatedSignal(
            "AAPL", Direction.BUY, .5, .8, ("momentum",), 1, "test"))
        rejected = risk_gate(proposal, lambda _p: False)
        self.assertEqual(rejected.status, "REJECTED_BY_RISK")
        self.assertEqual(rejected.allocation_pct, 0)
        approved = risk_gate(proposal, lambda _p: True)
        self.assertEqual(approved.status, "APPROVED_FOR_PAPER_REVIEW")
        self.assertTrue(approved.approved_by_risk)
        neutral = StrategyAllocator().propose(AggregatedSignal(
            "AAPL", Direction.NEUTRAL, 0, 0, (), 0, "none"))
        self.assertEqual(risk_gate(neutral, lambda _p: True).status, "NO_ALLOCATION")

    def test_manager_isolates_strategy_failure(self):
        from services.strategy_engine.orchestration import StrategyManager, StrategyState
        manager = StrategyManager()
        good, bad = MomentumStrategy(), TrendFollowingStrategy()
        bad.generate_signal = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("boom"))
        manager.register(good)
        manager.register(bad)
        manager.activate("momentum")
        manager.activate("trend_following")
        run = manager.run("AAPL", [100 + i for i in range(40)], timestamp=NOW,
                          configs={"momentum": StrategyConfig({}),
                                   "trend_following": StrategyConfig({})})
        self.assertEqual(len(run.signals), 1)
        self.assertEqual(len(run.errors), 1)
        self.assertEqual(dict(run.states)["trend_following"], StrategyState.ERROR)
        self.assertEqual(dict(run.states)["momentum"], StrategyState.ACTIVE)

    def test_regime_selection_is_applied_before_strategy_run(self):
        from services.strategy_engine.orchestration import StrategyManager, StrategySelector
        manager = StrategyManager()
        manager.register(MomentumStrategy())
        manager.register(MeanReversionStrategy())
        manager.activate("momentum")
        manager.activate("mean_reversion")
        selected = StrategySelector().select("RANGING", ["momentum", "mean_reversion"])
        run = manager.run("AAPL", [100 + i for i in range(40)], timestamp=NOW,
                          configs={"mean_reversion": StrategyConfig({})},
                          selected_ids=selected)
        self.assertEqual([s.strategy_id for s in run.signals], ["mean_reversion"])

class EvaluationAndAuditTests(unittest.TestCase):
    def test_market_regime_detector_uses_existing_v1_rule_and_fails_closed(self):
        from services.strategy_engine import MarketRegimeDetector
        detector = MarketRegimeDetector()
        self.assertEqual(detector.detect([100 + i for i in range(220)]).label, "TRENDING")
        self.assertEqual(detector.detect([100, 101]).label, "UNKNOWN")

    def test_evaluator_delegates_to_quantitative_engine(self):
        from services.strategy_engine import StrategyEvaluator
        result = StrategyEvaluator().evaluate([.01, -.005, .02, .01, -.002])
        self.assertEqual(result.observations, 5)
        comparison = StrategyEvaluator().compare({
            "momentum": [.01, -.005, .02, .01, -.002],
            "breakout": [.005, .002, .01, -.001, .003],
        })
        self.assertEqual(len(comparison.strategies), 2)

    def test_signal_logger_is_bounded_and_thread_safe_api(self):
        from services.strategy_engine import SignalLogger
        logger = SignalLogger(max_entries=2)
        logger("a", "one")
        logger("b", "two")
        logger("c", "three")
        entries = logger.snapshot()
        self.assertEqual(len(entries), 2)
        self.assertEqual([entry.event for entry in entries], ["b", "c"])
        self.assertIsNotNone(entries[-1].timestamp.tzinfo)

class StrategyPipelineTests(unittest.TestCase):
    def setUp(self):
        import threading
        from services.strategy_engine import (MomentumStrategy, TrendFollowingStrategy,
            MeanReversionStrategy, BreakoutStrategy, StrategyManager, StrategyExecutionPipeline)
        self.state = {"paused": False, "blocked": [], "limits": {
            "max_order": 1500.0, "max_order_pct": 25.0, "max_positions": 12,
            "max_gross": 90.0, "max_daily_loss": 3.0, "max_pos": 25.0,
            "min_cash": 10.0, "max_orders_day": 20,
        }, "pending": {}, "peak": 10000.0, "week": {"eq": 10000.0},
            "strategy": {"enabled": True}}
        self.account = {"equity": 10000.0, "cash": 9000.0,
                        "last_equity": 10000.0, "trading_blocked": False}
        self.positions = []
        self.saved, self.events = [], []
        manager = StrategyManager()
        for strategy in (MomentumStrategy(), TrendFollowingStrategy(),
                         MeanReversionStrategy(), BreakoutStrategy()):
            manager.register(strategy)
            manager.activate(strategy.get_metadata().strategy_id)
        self.pipeline = StrategyExecutionPipeline(
            manager=manager, state=self.state, lock=threading.RLock(),
            save=lambda: self.saved.append(True),
            history=lambda *a, **k: self.events.append((a, k)),
            account_reader=lambda: dict(self.account),
            positions_reader=lambda: list(self.positions),
            bars_reader=lambda symbol: [100 + i for i in range(250 if symbol == "SPY" else 80)],
            orders_today_reader=lambda: 0, paper_mode=True,
            system_safety_reader=lambda: {"status": "READY", "reason": None},
        )

    def test_pipeline_fails_closed_when_global_state_is_not_ready(self):
        from services.strategy_engine import StrategyPipelineError
        self.pipeline.system_safety_reader = lambda: {"status": "RECONCILING", "reason": "startup"}
        with self.assertRaises(StrategyPipelineError) as ctx:
            self.pipeline.run(["AAPL"])
        self.assertEqual(ctx.exception.status_code, 423)
        self.assertEqual(self.state["pending"], {})

    def test_strategy_signal_is_risk_checked_and_staged_for_manual_paper_approval(self):
        result = self.pipeline.run(["AAPL"])
        item = result["results"][0]
        self.assertEqual(result["mode"], "PAPER")
        self.assertEqual(result["execution"], "MANUAL_APPROVAL_REQUIRED")
        self.assertEqual(item["paper_order"]["status"], "PENDING_MANUAL_APPROVAL")
        oid = item["paper_order"]["order_id"]
        pending = self.state["pending"][oid]
        self.assertEqual(pending["source"], "strategy_engine")
        self.assertEqual(pending["risk_status"], "PRECHECK_PASSED_RECHECK_REQUIRED")
        self.assertGreater(pending["amt"], 0.0)
        self.assertLessEqual(pending["amt"], 500.0)
        self.assertTrue(self.saved)

    def test_persistence_failure_never_stages_an_unrecoverable_order(self):
        class BrokenPersistence:
            def stage(self, **_kwargs):
                raise RuntimeError("database unavailable")
        self.pipeline.persistence = BrokenPersistence()
        result = self.pipeline.run(["AAPL"])
        self.assertIn("error", result["results"][0])
        self.assertEqual(self.state["pending"], {})

    def test_persistence_receives_proposal_before_state_is_saved(self):
        calls = []
        class RecordingPersistence:
            def stage(self, **kwargs):
                calls.append(kwargs)
        self.pipeline.persistence = RecordingPersistence()
        result = self.pipeline.run(["AAPL"])
        self.assertTrue(result["results"][0].get("paper_order"))
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0]["symbol"], "AAPL")
        self.assertEqual(calls[0]["pending_payload"]["source"], "strategy_engine")

    def test_batch_reports_symbol_data_failure_without_hiding_prior_staging(self):
        original_reader = self.pipeline.bars_reader
        def bars(symbol):
            if symbol == "MSFT":
                return [100.0]
            return original_reader(symbol)
        self.pipeline.bars_reader = bars
        result = self.pipeline.run(["AAPL", "MSFT"])
        self.assertEqual(len(result["results"]), 2)
        self.assertEqual(result["results"][0]["symbol"], "AAPL")
        self.assertEqual(result["results"][0]["paper_order"]["status"], "PENDING_MANUAL_APPROVAL")
        self.assertEqual(result["results"][1]["symbol"], "MSFT")
        self.assertEqual(result["results"][1]["status"], "SYMBOL_REJECTED")
        self.assertIn("Historique insuffisant", result["results"][1]["error"])
        self.assertEqual(len(self.state["pending"]), 1)

    def test_pipeline_fails_closed_when_not_paper(self):
        from services.strategy_engine import StrategyPipelineError
        self.pipeline.paper_mode = False
        with self.assertRaises(StrategyPipelineError):
            self.pipeline.run(["AAPL"])
        self.assertEqual(self.state["pending"], {})

    def test_pipeline_fails_closed_when_paused(self):
        from services.strategy_engine import StrategyPipelineError
        self.state["paused"] = True
        with self.assertRaises(StrategyPipelineError):
            self.pipeline.run(["AAPL"])
        self.assertEqual(self.state["pending"], {})

    def test_pipeline_rejects_broker_blocked_account(self):
        from services.strategy_engine import StrategyPipelineError
        self.account["trading_blocked"] = True
        with self.assertRaises(StrategyPipelineError):
            self.pipeline.run(["AAPL"])
        self.assertEqual(self.state["pending"], {})

    def test_pipeline_halts_on_drawdown_before_generating_orders(self):
        from services.strategy_engine import StrategyPipelineError
        self.account["equity"] = 8500.0
        with self.assertRaises(StrategyPipelineError) as ctx:
            self.pipeline.run(["AAPL"])
        self.assertEqual(ctx.exception.status_code, 423)
        self.assertTrue(self.state["paused"])
        self.assertEqual(self.state["pending"], {})

    def test_pipeline_rejects_invalid_symbol_and_disabled_strategy(self):
        from services.strategy_engine import StrategyPipelineError
        with self.assertRaises(StrategyPipelineError):
            self.pipeline.run(["AAPL;DROP"])
        self.state["strategy"]["enabled"] = False
        with self.assertRaises(StrategyPipelineError):
            self.pipeline.run(["AAPL"])

    def test_risk_limit_rejects_without_staging(self):
        from services.strategy_engine import StrategyPipelineError
        self.state["limits"]["max_order"] = 100.0
        result = self.pipeline.run(["AAPL"])
        item = result["results"][0]
        self.assertEqual(item["proposal_status"], "REJECTED_BY_RISK")
        self.assertIn("Ordre trop gros", item["risk_rejection"])
        self.assertEqual(self.state["pending"], {})

    def test_staged_proposal_uses_existing_order_service_for_second_risk_check(self):
        import threading
        import core
        from unittest.mock import Mock
        from services.orders import OrderService, OrderServiceError
        staged = self.pipeline.run(["AAPL"])["results"][0]["paper_order"]
        order_submitter = Mock(return_value={"id": "paper-1", "status": "filled"})
        order_service = OrderService(
            state=self.state, lock=threading.RLock(), save=lambda: None,
            history=lambda *a, **k: None,
            account_reader=lambda: dict(self.account),
            positions_reader=lambda: list(self.positions),
            orders_reader=lambda *a: [], order_submitter=order_submitter,
            order_canceller=lambda _oid: None, daily_loss=core.daily_loss,
            order_checker=core.check, orders_today_reader=lambda: 0,
            system_safety_reader=lambda: {"status": "READY", "reason": None},
            instrument_reader=lambda symbol: {"symbol": str(symbol).upper(), "asset_class": "us_equity", "active": True, "tradable": True},
        )
        # Approval is a separate, explicit operation; it reruns the risk checker.
        result = order_service.approve(staged["order_id"])
        self.assertEqual(result["id"], "paper-1")
        order_submitter.assert_called_once()
        self.assertNotIn(staged["order_id"], self.state["pending"])

    def test_second_risk_check_can_block_a_previously_staged_proposal(self):
        import threading
        import core
        from unittest.mock import Mock
        from services.orders import OrderService, OrderServiceError
        staged = self.pipeline.run(["AAPL"])["results"][0]["paper_order"]
        self.account["cash"] = 100.0
        submit = Mock()
        order_service = OrderService(
            state=self.state, lock=threading.RLock(), save=lambda: None,
            history=lambda *a, **k: None,
            account_reader=lambda: dict(self.account),
            positions_reader=lambda: list(self.positions),
            orders_reader=lambda *a: [], order_submitter=submit,
            order_canceller=lambda _oid: None, daily_loss=core.daily_loss,
            order_checker=core.check, orders_today_reader=lambda: 0,
            system_safety_reader=lambda: {"status": "READY", "reason": None},
            instrument_reader=lambda symbol: {"symbol": str(symbol).upper(), "asset_class": "us_equity", "active": True, "tradable": True},
        )
        with self.assertRaises(OrderServiceError):
            order_service.approve(staged["order_id"])
        submit.assert_not_called()
        self.assertIn(staged["order_id"], self.state["pending"])
