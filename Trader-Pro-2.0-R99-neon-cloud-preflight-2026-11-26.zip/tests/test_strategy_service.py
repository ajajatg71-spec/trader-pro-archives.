import threading
import unittest
from types import SimpleNamespace
from unittest.mock import Mock

from services.strategy import StrategyService, StrategyServiceError


class StrategyServiceTests(unittest.TestCase):
    def setUp(self):
        self.state = {"strategy": {"enabled": False}}
        self.save, self.history = Mock(), Mock()
        self.service = StrategyService(state=self.state, lock=threading.RLock(),
                                       save=self.save, history=self.history, paper_mode=True)

    def config(self, **overrides):
        values = dict(enabled=True, auto_execute=True, watchlist="aapl, msft",
                      scan_minutes=30, rebalance_days=7, trade_amount=250.0)
        values.update(overrides)
        return SimpleNamespace(**values)

    def test_update_normalizes_watchlist_and_persists(self):
        result = self.service.update(self.config())
        self.assertEqual(result["watchlist"], ["AAPL", "MSFT"])
        self.assertTrue(result["enabled"])
        self.save.assert_called_once_with()
        self.history.assert_called_once()

    def test_watchlist_is_capped_at_twenty(self):
        cfg = self.config(watchlist=" ".join(f"s{i}" for i in range(25)))
        self.assertEqual(len(self.service.update(cfg)["watchlist"]), 20)

    def test_invalid_parameters_do_not_persist(self):
        with self.assertRaises(StrategyServiceError):
            self.service.update(self.config(scan_minutes=2))
        self.save.assert_not_called()

    def test_auto_execute_forbidden_outside_paper(self):
        self.service.paper_mode = False
        with self.assertRaises(StrategyServiceError):
            self.service.update(self.config(auto_execute=True))
        self.save.assert_not_called()


if __name__ == "__main__":
    unittest.main()
