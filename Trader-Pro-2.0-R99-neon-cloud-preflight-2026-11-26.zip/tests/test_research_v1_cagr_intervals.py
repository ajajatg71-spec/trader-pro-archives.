import math

from research_v1.backtesting.backtest import evaluate
from research_v1.backtesting.portfolio_backtest import _metrics


def test_single_return_interval_annualizes_over_one_trading_day():
    result = evaluate({"eq": [100.0, 110.0], "pos": [0, 1], "trades": []}, bpy=252)
    expected = ((1.1 ** 252) - 1) * 100
    assert math.isclose(result["cagr_pct"], round(expected, 2), rel_tol=1e-12)


def test_portfolio_cagr_uses_return_intervals_not_equity_observations():
    result = _metrics(
        equity_curve=[100.0, 110.0],
        daily_returns=[0.10],
        trades=1,
        exposure=[1.0, 1.0],
        fee=0.0,
        slip=0.0,
    )
    expected = ((1.1 ** 252) - 1) * 100
    assert math.isclose(result["cagr_pct"], round(expected, 3), rel_tol=1e-12)


def test_portfolio_cagr_is_consistent_for_three_equity_observations():
    result = _metrics(
        equity_curve=[100.0, 105.0, 110.25],
        daily_returns=[0.05, 0.05],
        trades=2,
        exposure=[1.0, 1.0, 1.0],
        fee=0.0,
        slip=0.0,
    )
    expected = ((1.1025 ** (252 / 2)) - 1) * 100
    assert math.isclose(result["cagr_pct"], round(expected, 3), rel_tol=1e-12)
