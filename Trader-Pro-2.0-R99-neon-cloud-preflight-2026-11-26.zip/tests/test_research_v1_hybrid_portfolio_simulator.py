import pytest

from research_v1.backtesting.hybrid_portfolio_simulator import simulate_hybrid_strategy_portfolio


def streams():
    return {
        "momentum": [
            {"timestamp": "2026-01-01", "return_pct": 1.0},
            {"timestamp": "2026-01-02", "return_pct": 2.0},
            {"timestamp": "2026-01-03", "return_pct": -1.0},
        ],
        "mean_reversion": [
            {"timestamp": "2026-01-01", "return_pct": 0.5},
            {"timestamp": "2026-01-02", "return_pct": -0.5},
            {"timestamp": "2026-01-03", "return_pct": 1.0},
        ],
    }


def test_continuous_portfolio_rebalances_and_charges_turnover_fees():
    result = simulate_hybrid_strategy_portfolio(
        streams(),
        [
            {"timestamp": "2026-01-01", "weights": {"momentum": 0.5}},
            {"timestamp": "2026-01-03", "weights": {"mean_reversion": 0.5}},
        ],
        initial_cash=10_000, fee_rate=0.001, max_gross_exposure=0.8,
    )
    assert result["periods"] == 3
    assert result["total_rebalance_fees"] > 0
    assert result["equity_curve"][1]["equity"] > result["equity_curve"][0]["equity"]
    assert result["equity_curve"][2]["gross_exposure"] == 0.5
    assert result["capital_authorized"] is False
    assert result["orders_created"] == 0
    assert result["broker_access"] is False


def test_missing_strategy_weight_means_cash_and_no_exposure():
    result = simulate_hybrid_strategy_portfolio(
        streams(), [{"timestamp": "2026-01-01", "weights": {}}],
        fee_rate=0, initial_cash=10_000,
    )
    assert result["final_equity"] == 10_000
    assert all(row["gross_exposure"] == 0 for row in result["equity_curve"])


def test_rejects_exposure_above_cap_and_unaligned_timestamps():
    with pytest.raises(ValueError, match="exceeds"):
        simulate_hybrid_strategy_portfolio(
            streams(), [{"timestamp": "2026-01-01", "weights": {"momentum": 0.9}}],
            max_gross_exposure=0.8,
        )
    bad = streams()
    bad["mean_reversion"][1]["timestamp"] = "2026-01-02T12:00"
    with pytest.raises(ValueError, match="share the same"):
        simulate_hybrid_strategy_portfolio(
            bad, [{"timestamp": "2026-01-01", "weights": {}}],
        )


def test_drawdown_halt_closes_exposure_on_following_period():
    data = {
        "momentum": [
            {"timestamp": "2026-01-01", "return_pct": -50.0},
            {"timestamp": "2026-01-02", "return_pct": 20.0},
            {"timestamp": "2026-01-03", "return_pct": 10.0},
        ]
    }
    result = simulate_hybrid_strategy_portfolio(
        data, [{"timestamp": "2026-01-01", "weights": {"momentum": 0.5}}],
        fee_rate=0, max_portfolio_drawdown_pct=20,
    )
    assert result["drawdown_halt_triggered"] is True
    assert result["equity_curve"][1]["gross_exposure"] == 0
    assert result["equity_curve"][2]["gross_exposure"] == 0


def test_rejects_duplicate_or_missing_initial_allocation():
    with pytest.raises(ValueError, match="initial allocation"):
        simulate_hybrid_strategy_portfolio(streams(), [
            {"timestamp": "2026-01-02", "weights": {}}
        ])
    with pytest.raises(ValueError, match="unique"):
        simulate_hybrid_strategy_portfolio(streams(), [
            {"timestamp": "2026-01-01", "weights": {}},
            {"timestamp": "2026-01-01", "weights": {}},
        ])
