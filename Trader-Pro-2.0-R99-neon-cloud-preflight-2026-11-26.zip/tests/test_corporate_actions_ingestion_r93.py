import tempfile
import unittest
from datetime import date, datetime, timezone
from pathlib import Path
from unittest.mock import Mock

from db.base import Base
from db.corporate_action_repository import CorporateActionRepository
from db.session import build_engine, build_session_factory
from research_v1.quant.corporate_action_ledger import CorporateActionRevision
from research_v1.quant.corporate_actions import CorporateActionEvent
from services.providers.alpaca_corporate_actions import AlpacaCorporateActionBatch, AlpacaCorporateActionRecord
from services.corporate_actions_ingestion import (
    CorporateActionIngestionError, ingest_alpaca_corporate_action_batch,
)


class CorporateActionIngestionR93Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.engine = build_engine(f"sqlite:///{Path(self.temp.name) / 'ingestion.db'}")
        Base.metadata.create_all(self.engine)
        self.sessions = build_session_factory(self.engine)
        self.repo = CorporateActionRepository(self.sessions)
        self.now = datetime(2026, 11, 26, 12, tzinfo=timezone.utc)

    def tearDown(self):
        self.engine.dispose()
        self.temp.cleanup()

    def record(self, *, amount="0.27", currency="USD", event_id="div-1"):
        return AlpacaCorporateActionRecord(
            provider_id=event_id, symbol="AAPL", action_type="dividend",
            ex_date=date(2026, 11, 12), process_date=date(2026, 11, 16),
            source="alpaca", retrieved_at=self.now,
            cash_amount=__import__('decimal').Decimal(amount), currency=currency,
        )

    def batch(self, records=None, complete=True):
        return AlpacaCorporateActionBatch(
            records=tuple(records if records is not None else [self.record()]),
            requested_symbols=("AAPL",), start_date=date(2026, 1, 1),
            end_date=date(2026, 11, 26), retrieved_at=self.now,
            pages_fetched=1, pagination_complete=complete,
        )

    def test_first_observation_is_persisted_with_retrieval_time(self):
        result = ingest_alpaca_corporate_action_batch(self.batch(), self.repo)
        self.assertEqual((result.received, result.inserted, result.unchanged, result.revised), (1, 1, 0, 0))
        latest = self.repo.latest_revision(source="alpaca", event_id="div-1")
        self.assertEqual(latest.revision, 1)
        self.assertEqual(latest.event.available_at, self.now)
        self.assertEqual(latest.recorded_at, self.now)

    def test_repeat_batch_is_idempotent_even_when_retrieved_later(self):
        ingest_alpaca_corporate_action_batch(self.batch(), self.repo)
        later = datetime(2026, 11, 27, 12, tzinfo=timezone.utc)
        record = self.record()
        batch = AlpacaCorporateActionBatch((record,), ("AAPL",), date(2026,1,1), date(2026,11,26), later, 1, True)
        result = ingest_alpaca_corporate_action_batch(batch, self.repo)
        self.assertEqual(result.unchanged, 1)
        self.assertEqual(self.repo.count_revisions(), 1)

    def test_changed_economics_creates_next_immutable_revision(self):
        ingest_alpaca_corporate_action_batch(self.batch(), self.repo)
        later = datetime(2026, 11, 27, 12, tzinfo=timezone.utc)
        changed = self.record(amount="0.30")
        batch = AlpacaCorporateActionBatch((changed,), ("AAPL",), date(2026,1,1), date(2026,11,26), later, 1, True)
        result = ingest_alpaca_corporate_action_batch(batch, self.repo)
        self.assertEqual(result.revised, 1)
        self.assertEqual(self.repo.count_revisions(), 2)
        self.assertEqual(self.repo.latest_revision(source="alpaca", event_id="div-1").revision, 2)

    def test_missing_currency_requires_explicit_resolver(self):
        with self.assertRaisesRegex(CorporateActionIngestionError, "résolution explicite"):
            ingest_alpaca_corporate_action_batch(self.batch([self.record(currency=None)]), self.repo)
        result = ingest_alpaca_corporate_action_batch(
            self.batch([self.record(currency=None)]), self.repo,
            currency_resolver=lambda symbol: "USD" if symbol == "AAPL" else None,
        )
        self.assertEqual(result.inserted, 1)

    def test_incomplete_batch_is_never_persisted(self):
        with self.assertRaisesRegex(CorporateActionIngestionError, "incomplet"):
            ingest_alpaca_corporate_action_batch(self.batch(complete=False), self.repo)
        self.assertEqual(self.repo.count_revisions(), 0)

    def test_invalid_currency_resolver_fails_closed(self):
        with self.assertRaisesRegex(CorporateActionIngestionError, "Résolveur"):
            ingest_alpaca_corporate_action_batch(
                self.batch([self.record(currency=None)]), self.repo,
                currency_resolver=lambda symbol: "usd",
            )
        self.assertEqual(self.repo.count_revisions(), 0)


if __name__ == "__main__":
    unittest.main()
