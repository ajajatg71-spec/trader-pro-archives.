import unittest

from services.portfolio import PortfolioService


class PortfolioServiceTests(unittest.TestCase):
    def setUp(self):
        self.fills = [
            {"symbol": "ABC", "side": "buy", "qty": 2, "price": 10, "time": "2026-01-01T10:00:00"},
            {"symbol": "ABC", "side": "sell", "qty": 1, "price": 15, "time": "2026-02-01T10:00:00"},
        ]
        self.positions = [{"symbol": "ABC", "current_price": 12.0}]
        self.service = PortfolioService(lambda: self.fills, lambda: self.positions, 0, 0)

    def test_snapshot_preserves_fifo_domain_result(self):
        lots, realized, fees, invested, prices = self.service.snapshot()
        self.assertAlmostEqual(realized[0]["pnl"], 5.0)
        self.assertAlmostEqual(lots["ABC"][0][0], 1.0)
        self.assertEqual(fees, 0.0)
        self.assertEqual(invested, 20.0)
        self.assertEqual(prices, {"ABC": 12.0})

    def test_summary_uses_existing_domain_calculation(self):
        result = self.service.summary()
        self.assertEqual(result["realized"], 5.0)
        self.assertEqual(result["unrealized"], 2.0)
        self.assertEqual(result["invested"], 20.0)

    def test_tax_delegates_to_domain_function(self):
        result = self.service.tax(self.service.realized(), 2026, 30.0, 0.0)
        self.assertEqual(result["impôt"], 1.5)

    def test_empty_positions_are_supported(self):
        service = PortfolioService(lambda: [], lambda: [])
        self.assertEqual(service.summary()["realized"], 0.0)


if __name__ == "__main__":
    unittest.main()
