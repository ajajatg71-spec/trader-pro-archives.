import unittest
from unittest.mock import patch
import broker


class AlpacaHistoricalBarsPaginationTests(unittest.TestCase):
    def _bar(self, day, close):
        return {"t": f"2026-01-{day:02d}T00:00:00Z", "c": close, "v": 100 + close}

    def test_bars2_follows_next_page_token_and_preserves_order(self):
        responses = [
            {"bars": [self._bar(1, 10), self._bar(2, 11)], "next_page_token": "page-2"},
            {"bars": [self._bar(3, 12)], "next_page_token": None},
        ]
        with patch.object(broker, "_r", side_effect=responses) as request:
            closes, volumes = broker.bars2("AAPL", 3)
        self.assertEqual(closes, [10, 11, 12])
        self.assertEqual(volumes, [110, 111, 112])
        self.assertEqual(request.call_count, 2)
        self.assertEqual(request.call_args_list[1].kwargs["params"]["page_token"], "page-2")

    def test_rejects_repeated_page_token(self):
        response = {"bars": [self._bar(1, 10)], "next_page_token": "same"}
        with patch.object(broker, "_r", return_value=response):
            with self.assertRaises(broker.BrokerError):
                broker.bars2("AAPL", 3)

    def test_rejects_non_monotonic_timestamps(self):
        response = {"bars": [self._bar(2, 11), self._bar(1, 10)], "next_page_token": None}
        with patch.object(broker, "_r", return_value=response):
            with self.assertRaises(broker.BrokerError):
                broker.bars2("AAPL", 2)

    def test_rejects_invalid_history_count(self):
        with self.assertRaises(ValueError):
            broker.bars2("AAPL", 0)


if __name__ == "__main__":
    unittest.main()
