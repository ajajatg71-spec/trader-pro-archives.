import unittest
from datetime import date, datetime, timezone
from research_v1.quant.corporate_actions import (
    CorporateActionError, CorporateActionEvent, validate_corporate_action_batch,
)

class CorporateActionBatchTests(unittest.TestCase):
    def setUp(self): self.when=datetime(2025,1,1,tzinfo=timezone.utc)
    def event(self, event_id=None, amount="0.25", source="provider"):
        return CorporateActionEvent("AAPL","dividend",date(2025,1,2),self.when,source,
                                    cash_amount=amount,currency="USD",event_id=event_id)
    def test_rejects_duplicate_source_event_id(self):
        with self.assertRaisesRegex(CorporateActionError,"(?i)identifiant.*dupliqué"):
            validate_corporate_action_batch([self.event("id-1"),self.event("id-1",amount="0.5")])
    def test_allows_same_id_from_distinct_sources(self):
        result=validate_corporate_action_batch([self.event("id-1",source="a"),self.event("id-1",source="b")])
        self.assertEqual(len(result),2)
    def test_rejects_identical_anonymous_duplicate(self):
        with self.assertRaisesRegex(CorporateActionError,"dupliqué sans identifiant"):
            validate_corporate_action_batch([self.event(),self.event()])
    def test_allows_distinct_provider_ids_for_same_date_amount(self):
        result=validate_corporate_action_batch([self.event("id-1"),self.event("id-2")])
        self.assertEqual(len(result),2)
    def test_rejects_untyped_batch(self):
        with self.assertRaises(CorporateActionError): validate_corporate_action_batch([{}])

if __name__=="__main__": unittest.main()
