import unittest
from datetime import date, datetime, timezone, timedelta
from research_v1.quant.corporate_actions import CorporateActionError, CorporateActionEvent, split_adjusted_closes

class SplitAdjustmentTests(unittest.TestCase):
    def setUp(self):
        self.stamps = tuple(datetime(2025, 1, d, 21, tzinfo=timezone.utc) for d in (2, 3, 6, 7))
        self.as_of = datetime(2025, 2, 1, tzinfo=timezone.utc)
    def event(self, ex_date=date(2025,1,6), ratio=2, available=None):
        return CorporateActionEvent("AAPL", "split", ex_date, available or self.as_of, "verified-provider", split_ratio=ratio)
    def test_two_for_one_split_restates_only_pre_ex_date_prices(self):
        result = split_adjusted_closes([100, 102, 51, 52], self.stamps, [self.event()], as_of=self.as_of, price_basis="raw")
        self.assertEqual(result, (50.0, 51.0, 51.0, 52.0))
    def test_multiple_splits_compound(self):
        events = [self.event(date(2025,1,6),2), self.event(date(2025,1,7),3)]
        result = split_adjusted_closes([120, 120, 60, 20], self.stamps, events, as_of=self.as_of, price_basis="raw")
        self.assertEqual(result, (20.0, 20.0, 20.0, 20.0))
    def test_split_not_yet_known_is_not_applied(self):
        late = self.event(available=self.as_of + timedelta(days=1))
        result = split_adjusted_closes([100,102,51,52], self.stamps,[late],as_of=self.as_of, price_basis="raw")
        self.assertEqual(result,(100.0,102.0,51.0,52.0))
    def test_non_split_event_rejected(self):
        div=CorporateActionEvent("AAPL","dividend",date(2025,1,6),self.as_of,"provider",cash_amount="1",currency="USD")
        with self.assertRaisesRegex(CorporateActionError,"uniquement les splits"):
            split_adjusted_closes([100,102,51,52],self.stamps,[div],as_of=self.as_of, price_basis="raw")
    def test_split_ex_date_missing_from_history_rejected_by_policy(self):
        event=self.event(date(2025,1,5))
        with self.assertRaisesRegex(CorporateActionError,"(?i)date ex-date"):
            # The function is amended below to enforce missing in-range ex dates.
            split_adjusted_closes([100,102,51,52],self.stamps,[event],as_of=self.as_of, price_basis="raw")
    def test_rejects_naive_timestamps(self):
        with self.assertRaises(CorporateActionError):
            split_adjusted_closes([100,102],[datetime(2025,1,2),datetime(2025,1,3)],[],as_of=self.as_of, price_basis="raw")
