import threading
import unittest
from unittest.mock import Mock
from fastapi import HTTPException
from routers.strategy import StrategyConfig, create_strategy_router
from services.strategy import StrategyService


class StrategyRouterTests(unittest.TestCase):
    def setUp(self):
        self.state = {"strategy": {"enabled": False}}
        self.analyzer = Mock(return_value=[{"symbol": "AAPL", "action": "garder"}])
        self.save, self.history = Mock(), Mock()
        self.service = StrategyService(state=self.state, lock=threading.RLock(),
                                        save=self.save, history=self.history, paper_mode=True)
        router = create_strategy_router(lambda: None, self.analyzer, self.service)
        self.endpoints = {route.path: route.endpoint for route in router.routes}

    def test_signals_normalize_and_limit_symbols(self):
        result = self.endpoints["/api/signals"]("aapl, msft googl " + " ".join(f"S{i}" for i in range(10)))
        self.assertEqual(result, [{"symbol": "AAPL", "action": "garder"}])
        self.analyzer.assert_called_once()
        self.assertEqual(len(self.analyzer.call_args.args[0]), 10)
        self.assertEqual(self.analyzer.call_args.args[0][:3], ["AAPL", "MSFT", "GOOGL"])

    def test_strategy_updates_state_and_audit_log(self):
        result = self.endpoints["/api/strategy"](StrategyConfig(enabled=True, auto_execute=True, watchlist="aapl, msft", scan_minutes=30, trade_amount=250))
        self.assertEqual(result["watchlist"], ["AAPL", "MSFT"])
        self.assertTrue(result["enabled"])
        self.save.assert_called_once_with()
        self.history.assert_called_once()

    def test_strategy_rejects_out_of_range_parameters(self):
        with self.assertRaises(HTTPException) as ctx:
            self.endpoints["/api/strategy"](StrategyConfig(scan_minutes=2))
        self.assertEqual(ctx.exception.status_code, 400)
        self.save.assert_not_called()

    def test_auto_execute_rejected_outside_paper_mode(self):
        service = StrategyService(state=self.state, lock=threading.RLock(), save=self.save,
                                  history=self.history, paper_mode=False)
        endpoint = {r.path: r.endpoint for r in create_strategy_router(lambda: None, self.analyzer, service).routes}["/api/strategy"]
        with self.assertRaises(HTTPException) as ctx:
            endpoint(StrategyConfig(auto_execute=True))
        self.assertEqual(ctx.exception.status_code, 400)
        self.save.assert_not_called()


if __name__ == "__main__":
    unittest.main()
