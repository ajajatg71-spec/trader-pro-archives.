import tempfile
import unittest
from pathlib import Path
from sqlalchemy import create_engine, select
from db.base import Base
from db.models import StrategyProposalRecord, AuditEventRecord
from db.session import build_session_factory
from services.strategy_engine.persistence import StrategyPersistence, StrategyPersistenceError


class StrategyPersistenceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.engine = create_engine(f"sqlite:///{Path(self.temp.name) / 'persist.db'}")
        Base.metadata.create_all(self.engine)
        self.sessions = build_session_factory(self.engine)
        self.repo = StrategyPersistence(self.sessions)
        self.payload = {"sym": "AAPL", "side": "buy", "amt": 125.5,
                        "why": "", "source": "strategy_engine", "strategies": ["momentum"]}

    def tearDown(self):
        self.engine.dispose()
        self.temp.cleanup()

    def stage(self, proposal_id="p-1"):
        self.repo.stage(proposal_id=proposal_id, symbol="AAPL", notional=125.5,
                        allocation_pct=2.5, confidence=.8, regime="TRENDING",
                        source_strategies=["momentum"], signals=[{"direction": "BUY"}],
                        pending_payload=self.payload)

    def test_stage_is_transactional_and_restores_pending(self):
        self.stage()
        self.assertEqual(self.repo.restore_pending(), {"p-1": self.payload})
        with self.sessions() as session:
            record = session.get(StrategyProposalRecord, "p-1")
            self.assertEqual(record.status, "PENDING_APPROVAL")
            self.assertEqual(record.notional, 125.5)
            self.assertEqual(session.scalar(select(AuditEventRecord)).correlation_id, "p-1")

    def test_in_flight_submission_is_never_restored_as_pending_approval(self):
        self.stage()
        self.repo.update_status("p-1", "SUBMITTING")
        self.assertEqual(self.repo.restore_pending(), {})
        self.repo.update_status("p-1", "SUBMITTED", broker_order_id="broker-1")
        self.assertEqual(self.repo.restore_pending(), {})
        with self.sessions() as session:
            record = session.get(StrategyProposalRecord, "p-1")
            self.assertEqual(record.broker_order_id, "broker-1")

    def test_broker_reconciliation_closes_restored_proposal(self):
        self.stage()
        self.repo.update_status("p-1", "SUBMITTING")
        self.assertTrue(self.repo.sync_broker_status("p-1", "filled", broker_order_id="b-1"))
        self.assertEqual(self.repo.restore_pending(), {})
        with self.sessions() as session:
            self.assertEqual(session.get(StrategyProposalRecord, "p-1").status, "SUBMITTED")

    def test_rejected_proposal_is_not_restored(self):
        self.stage()
        self.repo.update_status("p-1", "REJECTED")
        self.assertEqual(self.repo.restore_pending(), {})

    def test_unknown_submission_is_persisted_but_never_restored_for_reapproval(self):
        self.stage()
        self.repo.update_status("p-1", "SUBMITTING")
        self.repo.update_status("p-1", "SUBMISSION_UNKNOWN", reason="TimeoutError")
        self.assertEqual(self.repo.restore_pending(), {})
        with self.sessions() as session:
            record = session.get(StrategyProposalRecord, "p-1")
            self.assertEqual(record.status, "SUBMISSION_UNKNOWN")
            self.assertEqual(record.risk_reason, "TimeoutError")

    def test_unknown_status_transition_is_rejected(self):
        with self.assertRaises(StrategyPersistenceError):
            self.repo.update_status("p-1", "LIVE_EXECUTED")

    def test_duplicate_id_is_not_overwritten(self):
        self.stage()
        with self.assertRaises(StrategyPersistenceError):
            self.repo.stage(proposal_id="p-1", symbol="MSFT", notional=10,
                            allocation_pct=1, confidence=.5, regime="TRENDING",
                            source_strategies=["breakout"], signals=[], pending_payload={})


if __name__ == "__main__":
    unittest.main()
