import os, random, tempfile, time, unittest
import anomaly, auth, core, portfolio, store
import thirteen_f as F
import security

class Auth(unittest.TestCase):
    SEC = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ"
    def test_totp_rfc6238(s):
        s.assertEqual(auth.totp(s.SEC, t=59), "287082"); s.assertEqual(auth.totp(s.SEC, t=59, digits=8), "94287082")
        s.assertTrue(auth.verify_totp(s.SEC, "287082", t=59)); s.assertTrue(auth.verify_totp(s.SEC, "287082", t=89))
        s.assertFalse(auth.verify_totp(s.SEC, "287082", t=179)); s.assertFalse(auth.verify_totp(s.SEC, "000000", t=59))
        s.assertEqual(auth.matching_totp_counter(s.SEC, "287082", window=0, t=59), 1)
        s.assertIsNone(auth.matching_totp_counter(s.SEC, "000000", window=0, t=59))
    def test_tokens(s):
        k = b"k" * 32; t = auth.make_token(k, now=1000)
        s.assertTrue(auth.check_token(k, t, now=1001)); s.assertFalse(auth.check_token(k, t, now=1000 + 43201))
        s.assertFalse(auth.check_token(b"x" * 32, t, now=1001)); s.assertFalse(auth.check_token(k, t, revoke_before=1500, now=1001))
        iat, exp, sig = t.split("."); s.assertFalse(auth.check_token(k, f"{iat}.{int(exp) + 999}.{sig}", now=1001))
        s.assertFalse(auth.check_token(k, "n'importe quoi", now=1001))

class ProxySecurity(unittest.TestCase):
    class Client:
        def __init__(self, host): self.host = host
    class URL:
        def __init__(self, scheme): self.scheme = scheme
    class Request:
        def __init__(self, host, scheme="http", headers=None):
            self.client = ProxySecurity.Client(host)
            self.url = ProxySecurity.URL(scheme)
            self.headers = headers or {}
    def test_untrusted_forwarded_headers_ignored(s):
        r = s.Request("203.0.113.9", headers={"x-forwarded-for": "127.0.0.1", "x-forwarded-proto": "https"})
        s.assertEqual(security.client_ip(r), "203.0.113.9")
        s.assertFalse(security.is_https(r, "10.0.0.0/8"))
    def test_trusted_proxy_must_assert_https(s):
        r = s.Request("10.1.2.3", headers={"x-forwarded-proto": "https"})
        s.assertTrue(security.is_https(r, "10.0.0.0/8"))
        r.headers["x-forwarded-proto"] = "http"
        s.assertFalse(security.is_https(r, "10.0.0.0/8"))
    def test_direct_https(s):
        s.assertTrue(security.is_https(s.Request("203.0.113.9", scheme="https"), "10.0.0.0/8"))

class Store(unittest.TestCase):
    def test_restore_after_corruption(s):
        with tempfile.TemporaryDirectory() as d:
            p, bd = os.path.join(d, "state.json"), os.path.join(d, "bk")
            store.save_json(p, {"a": 1}); store.backup([p], bd, now=1000)
            with open(p, "w", encoding="utf-8") as f: f.write("{corrompu")
            s.assertEqual(store.load_json(p, {}, bd), {"a": 1})
    def test_default_when_nothing(s): s.assertEqual(store.load_json("/inexistant/x.json", {"d": 1}, "/inexistant/bk"), {"d": 1})
    def test_rotation(s):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "s.json"); store.save_json(p, {})
            for i in range(20): store.backup([p], os.path.join(d, "bk"), keep=5, now=1000 + i * 60)
            s.assertEqual(len(os.listdir(os.path.join(d, "bk"))), 5)

class Anom(unittest.TestCase):
    CALM = [100 + (i % 3) * 0.1 for i in range(80)]
    def test_jump(s): s.assertTrue(any("inhabituel" in x for x in anomaly.unusual(s.CALM + [110])))
    def test_calm(s): s.assertEqual(anomaly.unusual(s.CALM), [])
    def test_volume(s): s.assertTrue(any("volume" in x for x in anomaly.unusual([1] * 5, [100] * 20 + [400])))

class Stress(unittest.TestCase):
    def test_many_fills_fast(s):
        t0, fills = time.time(), []
        for i in range(10000):
            fills.append({"symbol": f"S{i % 50}", "side": "buy", "qty": 1, "price": 100 + i % 7, "time": f"2026-01-01T{i:05d}"})
            fills.append({"symbol": f"S{i % 50}", "side": "sell", "qty": 1, "price": 101 + i % 7, "time": f"2026-01-02T{i:05d}"})
        s.assertEqual(len(portfolio.process(fills)[1]), 10000); s.assertLess(time.time() - t0, 5)
    def test_size_many_targets(s):
        random.seed(2); a, _ = core.size([(f"T{i}", random.random() + .1) for i in range(500)], 100000, 10, 5)
        s.assertLessEqual(sum(a.values()), 90000.5); s.assertTrue(all(v <= 5000.01 for v in a.values()))
    def test_check_fuzz_never_raises(s):
        random.seed(1); L = {"max_order": 1500, "max_pos": 25, "min_cash": 10, "max_daily_loss": 3}
        for _ in range(2000):
            eq = random.uniform(100, 1e6)
            a = {"equity": str(eq), "cash": str(random.uniform(0, eq)), "last_equity": str(eq * random.uniform(.8, 1.2))}
            r = core.check((random.choice("AB"), random.choice(["buy", "sell"]), random.uniform(1, 5000)), a,
                           [{"symbol": "A", "market_value": str(random.uniform(0, eq))}], L, [], random.uniform(0, eq))
            s.assertIsInstance(r, str)
    def test_compare(s):
        inst = {"1": {"weights": [("AAPL", 20.0), ("KO", 10.0)]}, "2": {"weights": [("AAPL", 30.0), ("BAC", 5.0)]}}
        s.assertEqual(F.compare(inst)[0], ("AAPL", 2, 25.0))
if __name__ == "__main__": unittest.main()
