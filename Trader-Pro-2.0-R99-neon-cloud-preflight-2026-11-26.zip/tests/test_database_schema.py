import tempfile
import unittest
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from sqlalchemy import create_engine, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from db.base import Base
from db.models import OrderRecord, FillRecord, StrategyConfigRecord, AuditEventRecord
from db.session import build_engine, build_session_factory


class DatabaseSchemaTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.url = f"sqlite:///{Path(self.temp.name) / 'test.db'}"
        self.engine = build_engine(self.url)
        Base.metadata.create_all(self.engine)
        self.Session = build_session_factory(self.engine)

    def tearDown(self):
        self.engine.dispose()
        self.temp.cleanup()

    def test_order_fill_and_audit_round_trip(self):
        with self.Session() as session:
            order = OrderRecord(client_order_id="pending-123", symbol="AAPL", side="buy",
                                notional=Decimal("1250.00"), status="accepted")
            session.add(order)
            session.flush()
            session.add(FillRecord(broker_fill_id="fill-1", order_id=order.id, symbol="AAPL",
                                   quantity=Decimal("5"), price=Decimal("250"), fee=Decimal("0"),
                                   executed_at=datetime.now(timezone.utc)))
            session.add(AuditEventRecord(event_type="order", message="paper fill", details={"source": "test"}))
            session.commit()
        with self.Session() as session:
            stored = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "pending-123"))
            self.assertEqual(stored.fills[0].price, Decimal("250.00000000"))
            event = session.scalar(select(AuditEventRecord))
            self.assertEqual(event.details["source"], "test")

    def test_client_order_id_is_unique(self):
        with self.Session() as session:
            session.add_all([
                OrderRecord(client_order_id="same-id", symbol="AAPL", side="buy", status="new"),
                OrderRecord(client_order_id="same-id", symbol="MSFT", side="buy", status="new"),
            ])
            with self.assertRaises(IntegrityError):
                session.commit()

    def test_strategy_parameters_are_json_persisted(self):
        with self.Session() as session:
            session.add(StrategyConfigRecord(name="momentum", enabled=False, auto_execute=False,
                                             parameters={"lookback": 20, "threshold": 1.5}))
            session.commit()
            record = session.scalar(select(StrategyConfigRecord))
            self.assertEqual(record.parameters["lookback"], 20)

    def test_database_url_is_required(self):
        with self.assertRaises(RuntimeError):
            build_engine("")


if __name__ == "__main__":
    unittest.main()
