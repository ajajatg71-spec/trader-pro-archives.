import pytest

from research_v1.backtesting.hybrid_scoreboard_simulation import simulate_hybrid_scoreboard_portfolio


def scoreboard():
    return {
        "mode": "WALK_FORWARD_OOS_RESEARCH",
        "execution": "NONE",
        "broker_access": False,
        "oos_return_streams": {
            "momentum": [
                {"timestamp": "2026-01-01", "return_pct": 1.0},
                {"timestamp": "2026-01-02", "return_pct": -0.5},
            ],
            "trend": [
                {"timestamp": "2026-01-01", "return_pct": 0.5},
                {"timestamp": "2026-01-02", "return_pct": 1.0},
            ],
        },
        "oos_return_streams_metadata": {"observations": 2},
    }


def test_scoreboard_adapter_simulates_explicit_allocation_only():
    result = simulate_hybrid_scoreboard_portfolio(
        scoreboard(),
        [{"timestamp": "2026-01-01", "weights": {"momentum": 0.4, "trend": 0.2}}],
        initial_cash=10_000, fee_rate=0,
    )
    assert result["oos_observations"] == 2
    assert result["source"] == "walk_forward_common_oos_scoreboard"
    assert result["final_equity"] > 10_000
    assert result["capital_authorized"] is False
    assert result["orders_created"] == 0
    assert result["broker_access"] is False


def test_rejects_scoreboard_without_common_oos_streams():
    data = scoreboard()
    del data["oos_return_streams"]
    with pytest.raises(ValueError, match="no dated"):
        simulate_hybrid_scoreboard_portfolio(data, [
            {"timestamp": "2026-01-01", "weights": {}}
        ])


def test_rejects_stream_count_mismatch():
    data = scoreboard()
    data["oos_return_streams"]["trend"].pop()
    with pytest.raises(ValueError, match="observation count"):
        simulate_hybrid_scoreboard_portfolio(data, [
            {"timestamp": "2026-01-01", "weights": {}}
        ])


def test_rejects_non_research_scoreboard():
    data = scoreboard()
    data["execution"] = "PAPER"
    with pytest.raises(ValueError, match="execution boundary"):
        simulate_hybrid_scoreboard_portfolio(data, [
            {"timestamp": "2026-01-01", "weights": {}}
        ])
