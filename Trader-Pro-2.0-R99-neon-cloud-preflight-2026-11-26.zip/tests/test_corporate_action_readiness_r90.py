import unittest
from research_v1.quant.corporate_action_readiness import assess_corporate_action_readiness
class CorporateActionReadinessTests(unittest.TestCase):
 def evidence(self):return {"source_batch_complete":True,"raw_price_basis_verified":True,"cross_source_reconciliation":True,"provider_history_verified":True,"event_revision_ledger_persisted":True,"currency_and_calendar_verified":True,"postgresql_validation_passed":True}
 def test_all_evidence_required(self):self.assertTrue(assess_corporate_action_readiness(self.evidence())["ready"])
 def test_missing_evidence_blocks(self):
  evidence=self.evidence();evidence.pop("provider_history_verified")
  result=assess_corporate_action_readiness(evidence);self.assertFalse(result["ready"]);self.assertIn("provider_history_verified",result["blockers"][0])
 def test_false_evidence_blocks(self):
  evidence=self.evidence();evidence["postgresql_validation_passed"]=False
  result=assess_corporate_action_readiness(evidence);self.assertEqual(result["status"],"BLOCKED")
 def test_never_authorizes_live(self):
  result=assess_corporate_action_readiness(self.evidence());self.assertFalse(result["live_authorized"]);self.assertEqual(result["orders_created"],0)
 def test_rejects_non_mapping(self):
  with self.assertRaises(ValueError):assess_corporate_action_readiness([])
if __name__=="__main__":unittest.main()
