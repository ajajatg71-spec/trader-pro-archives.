from types import SimpleNamespace
import pytest

from services import candle_research_adapter as adapter


def _manifest(hypotheses):
    return {"study": "candle_confluence", "hypotheses": hypotheses,
            "metadata": {"horizons": [3], "min_observations": 5}}


def test_adapter_maps_backend_paired_p_values(monkeypatch):
    def fake_evaluate(bars, **kwargs):
        assert len(bars) == 60
        assert kwargs["horizons"] == (3,)
        return {"results": [
            {"pattern": "HAMMER", "horizon_bars": 3, "policy": "candle_rsi",
             "paired_candle_only_comparison": {"p_value_raw": 0.012}},
            {"pattern": "HAMMER", "horizon_bars": 3, "policy": "candle_only",
             "paired_candle_only_comparison": {"p_value_raw": None}},
        ]}
    monkeypatch.setattr(adapter, "evaluate_candle_confluence", fake_evaluate)
    snapshot = {"bars": [{"o": 1, "h": 2, "l": 0.5, "c": 1.5, "v": 100} for _ in range(60)]}
    result = adapter.evaluate_preregistered_candle_family(
        _manifest(["HAMMER|3|candle_rsi"]), snapshot)
    assert result == {"HAMMER|3|candle_rsi": 0.012}


def test_adapter_refuses_missing_paired_result(monkeypatch):
    monkeypatch.setattr(adapter, "evaluate_candle_confluence", lambda *a, **k: {"results": []})
    snapshot = {"bars": [{"o": 1, "h": 2, "l": 0.5, "c": 1.5, "v": 100} for _ in range(60)]}
    with pytest.raises(adapter.CandleResearchAdapterError, match="Famille incomplète"):
        adapter.evaluate_preregistered_candle_family(
            _manifest(["HAMMER|3|candle_rsi"]), snapshot)


def test_adapter_rejects_wrong_study_and_invalid_ohlcv():
    with pytest.raises(adapter.CandleResearchAdapterError, match="non compatible"):
        adapter.evaluate_preregistered_candle_family({"study": "other"}, {"bars": []})
    with pytest.raises(adapter.CandleResearchAdapterError, match="Barre OHLCV"):
        adapter.evaluate_preregistered_candle_family(_manifest(["x"]), {"bars": [{"o": 1}]})


def test_candle_adapter_can_be_used_by_provenance_executor(monkeypatch, tmp_path):
    from db.base import Base
    from db.session import build_engine, build_session_factory
    from db.hypothesis_registry import HypothesisRegistry
    from services.research_execution import ResearchExecutionService

    monkeypatch.setattr(adapter, "evaluate_candle_confluence", lambda *a, **k: {"results": [
        {"pattern": "HAMMER", "horizon_bars": 3, "policy": "candle_rsi",
         "paired_candle_only_comparison": {"p_value_raw": 0.012}},
    ]})
    engine = build_engine(f"sqlite:///{tmp_path / 'end_to_end.db'}")
    Base.metadata.create_all(engine)
    registry = HypothesisRegistry(build_session_factory(engine))
    family = registry.preregister(
        study="candle_confluence", universe=["SPY"],
        hypotheses=["HAMMER|3|candle_rsi"], protocol_version="v1",
        metadata={"horizons": [3], "min_observations": 5})
    snapshot = {"bars": [{"o": 1, "h": 2, "l": 0.5, "c": 1.5, "v": 100} for _ in range(60)]}
    saved = ResearchExecutionService(registry).execute(
        family_id=family["family_id"], market_data_snapshot=snapshot,
        code_version="test-candle-adapter-v1",
        evaluator=adapter.evaluate_preregistered_candle_family)
    assert saved["status"] == "RESULTS_LOCKED"
    assert saved["p_values"] == {"HAMMER|3|candle_rsi": 0.012}
    assert saved["execution_provenance"]["execution_origin"] == "BACKEND_RESEARCH_EXECUTOR"
    assert saved["selection_authorized"] is False
    engine.dispose()
