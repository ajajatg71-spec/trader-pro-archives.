import unittest
from datetime import date, datetime, timezone
from research_v1.backtesting.backtest import evaluate_total_return_history
from research_v1.quant.corporate_actions import CorporateActionEvent

class TotalReturnBacktestTests(unittest.TestCase):
    def setUp(self):
        self.stamps=tuple(datetime(2025,1,d,21,tzinfo=timezone.utc) for d in (2,3,6,7))
    def test_returns_metrics_and_declares_policy(self):
        event=CorporateActionEvent("AAPL","dividend",date(2025,1,6),self.stamps[0],"provider",cash_amount="1",currency="USD")
        result=evaluate_total_return_history([100,100,99,99],self.stamps,[event],symbol="AAPL",currency="USD",price_basis="raw")
        self.assertEqual(result["mode"],"TOTAL_RETURN_RESEARCH")
        self.assertEqual(result["total_return_index"],[100.0,100.0,100.0,100.0])
        self.assertFalse(result["broker_access"])
        self.assertEqual(result["orders_created"],0)
    def test_empty_actions_matches_price_only_curve(self):
        result=evaluate_total_return_history([100,101,99,102],self.stamps,[],symbol="AAPL",currency="USD",price_basis="raw")
        self.assertEqual(result["total_return_index"],[100.0,101.0,99.0,102.0])
    def test_rejects_event_for_another_symbol(self):
        event=CorporateActionEvent("MSFT","dividend",date(2025,1,6),self.stamps[0],"provider",cash_amount="1",currency="USD")
        with self.assertRaisesRegex(ValueError,"appartenir au symbole"):
            evaluate_total_return_history([100,100,99,99],self.stamps,[event],symbol="AAPL",currency="USD",price_basis="raw")
    def test_rejects_invalid_bpy(self):
        with self.assertRaises((ValueError,TypeError)):
            evaluate_total_return_history([100,101],self.stamps[:2],[],symbol="AAPL",currency="USD",bpy=0)

if __name__=="__main__": unittest.main()
