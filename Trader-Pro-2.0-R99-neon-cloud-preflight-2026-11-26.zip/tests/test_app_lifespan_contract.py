"""FastAPI lifespan contract: startup and shutdown manage background work."""
import asyncio

import app as trader_app


def test_app_uses_explicit_lifespan_context():
    assert callable(trader_app.app.router.lifespan_context)


def test_lifespan_invokes_startup_and_shutdown_hooks(monkeypatch):
    calls = []
    monkeypatch.setattr(trader_app, "_start", lambda: calls.append("started"))
    monkeypatch.setattr(trader_app, "_stop_scheduler", lambda: calls.append("stopped"))

    async def exercise():
        async with trader_app.app.router.lifespan_context(trader_app.app):
            assert calls == ["started"]

    asyncio.run(exercise())
    assert calls == ["started", "stopped"]


def test_scheduler_stop_event_interrupts_wait():
    trader_app.SCHEDULER_STOP.clear()
    trader_app._start_scheduler()
    thread = trader_app.SCHEDULER_THREAD
    assert thread is not None and thread.is_alive()
    trader_app._stop_scheduler()
    assert trader_app.SCHEDULER_STOP.is_set()
    assert not thread.is_alive()
