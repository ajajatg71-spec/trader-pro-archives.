from dataclasses import replace

import pytest

from trading_mandate import DEFAULT_TRADING_MANDATE


def test_default_mandate_is_full_autonomy_within_risk_limits_and_cash_only():
    mandate = DEFAULT_TRADING_MANDATE
    assert mandate.autonomy == "full_within_risk_limits"
    assert mandate.allow_margin is False
    assert mandate.allow_borrowed_funds is False
    assert mandate.require_risk_governor is True
    assert mandate.fail_closed_on_unknown_buying_power is True


def test_cash_covered_order_is_allowed_by_funding_policy():
    assert DEFAULT_TRADING_MANDATE.order_funding_allowed(
        order_notional=250, available_cash=300
    ) is True


@pytest.mark.parametrize("notional,cash", [(301, 300), (1, 0), (0, 100), (-1, 100)])
def test_order_not_fully_covered_by_cash_is_rejected(notional, cash):
    assert DEFAULT_TRADING_MANDATE.order_funding_allowed(
        order_notional=notional, available_cash=cash
    ) is False


def test_unknown_buying_power_fails_closed():
    assert DEFAULT_TRADING_MANDATE.order_funding_allowed(
        order_notional=10, available_cash=100, buying_power_known=False
    ) is False


def test_margin_or_borrowed_funds_cannot_be_enabled():
    with pytest.raises(ValueError, match="interdit marge"):
        replace(DEFAULT_TRADING_MANDATE, allow_margin=True).validate()
    with pytest.raises(ValueError, match="interdit marge"):
        replace(DEFAULT_TRADING_MANDATE, allow_borrowed_funds=True).validate()


def test_risk_governor_cannot_be_disabled():
    with pytest.raises(ValueError, match="Risk Governor"):
        replace(DEFAULT_TRADING_MANDATE, require_risk_governor=False).validate()



def test_initial_market_universe_is_us_equities_and_etfs_only():
    mandate = DEFAULT_TRADING_MANDATE
    assert mandate.allowed_asset_classes == ("us_equity",)
    assert mandate.allow_options is False
    assert mandate.allow_crypto is False
    assert mandate.allow_forex is False
    assert mandate.allow_futures is False


@pytest.mark.parametrize("asset_class", ["us_equity", " US_EQUITY "])
def test_supported_stock_and_etf_assets_are_allowed(asset_class):
    assert DEFAULT_TRADING_MANDATE.instrument_allowed(asset_class=asset_class)


@pytest.mark.parametrize("asset_class", [
    "crypto", "forex", "option", "future", "index", "bond", "unknown", None, ""
])
def test_out_of_scope_or_unknown_asset_classes_fail_closed(asset_class):
    assert not DEFAULT_TRADING_MANDATE.instrument_allowed(asset_class=asset_class)


def test_non_tradable_or_inactive_assets_are_rejected():
    assert not DEFAULT_TRADING_MANDATE.instrument_allowed(
        asset_class="us_equity", tradable=False
    )
    assert not DEFAULT_TRADING_MANDATE.instrument_allowed(
        asset_class="us_etf", active=False
    )


def test_expanding_market_universe_requires_explicit_architecture_change():
    from dataclasses import replace
    with pytest.raises(ValueError, match="Univers autorisé"):
        replace(
            DEFAULT_TRADING_MANDATE,
            allowed_asset_classes=("us_equity", "crypto"),
        ).validate()
