import unittest, portfolio as P
L = {"max_daily_loss": 3, "max_drawdown": 10, "max_pos": 25}
F = lambda s, q, p, t: {"symbol": "A", "side": s, "qty": q, "price": p, "time": t}

class Fifo(unittest.TestCase):
    def test_fifo_realized_and_unrealized(self):
        lots, real, fees, inv = P.process([F("buy", 10, 100, "2026-01-01"), F("buy", 10, 110, "2026-01-02"), F("sell", 15, 120, "2026-02-01")])
        self.assertAlmostEqual(sum(r["pnl"] for r in real), 250.0); self.assertEqual(inv, 2100)
        s = P.summary(lots, real, fees, inv, {"A": 130.0}); self.assertEqual(s["unrealized"], 100.0); self.assertEqual(s["by_year"], {"2026": 250.0})
        self.assertAlmostEqual(s["return_pct"], 350 / 2100 * 100, places=2)
    def test_fees_reduce_pnl(self):
        _, real, fees, _ = P.process([F("buy", 10, 100, "2026-01-01"), F("sell", 10, 110, "2026-01-02")], pct=1)
        self.assertAlmostEqual(real[0]["pnl"], 79.0); self.assertAlmostEqual(fees, 21.0)
    def test_order_by_time(self):
        _, real, _, _ = P.process([F("sell", 5, 120, "2026-02-01"), F("buy", 5, 100, "2026-01-01")]); self.assertAlmostEqual(real[0]["pnl"], 100.0)

class Tax(unittest.TestCase):
    R = [{"pnl": 1000.0, "sold": "2026-05-01"}, {"pnl": 50.0, "sold": "2025-05-01"}]
    def test_plain(self): self.assertEqual(P.tax(self.R, 2026)["impôt"], 314.0)
    def test_carry_used(self):
        t = P.tax(self.R, 2026, carry=400); self.assertEqual((t["imposable"], t["impôt"], t["moins_values_restantes"]), (600.0, 188.4, 0.0))
    def test_loss_adds_carry(self): self.assertEqual(P.tax([{"pnl": -300.0, "sold": "2026-01-01"}], 2026, carry=100)["moins_values_restantes"], 400.0)

class Alerts(unittest.TestCase):
    def test_none(self): self.assertEqual(P.risk_alerts(10000, 10000, 10000, [], L), [])
    def test_daily(self): self.assertTrue(P.risk_alerts(9600, 10000, 10000, [], L)[0].startswith("Perte"))
    def test_drawdown(self): self.assertTrue(any(m.startswith("Drawdown") for m in P.risk_alerts(8800, 8800, 10000, [], L)))
    def test_concentration(self): self.assertTrue(any(m.startswith("Concentration") for m in P.risk_alerts(10000, 10000, 10000, [{"symbol": "X", "market_value": "3000"}], L)))
if __name__ == "__main__": unittest.main()
