import tempfile
import unittest
from datetime import date, datetime, timezone
from pathlib import Path
from unittest.mock import Mock

from db.base import Base
from db.corporate_action_repository import CorporateActionRepository
from db.session import build_engine, build_session_factory
from services.providers.alpaca_corporate_actions import AlpacaCorporateActionsReader
from services.corporate_actions_ingestion import (
    CorporateActionIngestionError, ingest_alpaca_corporate_action_batch,
)


class AlpacaLivePayloadR94Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.engine = build_engine(f"sqlite:///{Path(self.temp.name) / 'live-payload.db'}")
        Base.metadata.create_all(self.engine)
        self.repo = CorporateActionRepository(build_session_factory(self.engine))
        self.observed_at = datetime(2026, 11, 26, 2, 5, tzinfo=timezone.utc)

    def tearDown(self):
        self.engine.dispose()
        self.temp.cleanup()

    def build_batch(self):
        # Exact shape observed from the connected Alpaca corporate-actions
        # endpoint: cash_dividends rows include id/rate/dates/symbol but
        # may omit currency.
        payload = {
            "corporate_actions": {
                "forward_splits": [],
                "reverse_splits": [],
                "cash_dividends": [
                    {"id": "a0630261-f185-4ef9-acf0-643ee1cfb8ad",
                     "symbol": "AAPL", "ex_date": "2026-11-12",
                     "process_date": "2026-11-16", "rate": 0.27},
                    {"id": "d8002a63-ba52-4a4c-83e6-0710b31d29b2",
                     "symbol": "MSFT", "ex_date": "2026-08-20",
                     "process_date": "2026-09-10", "rate": 0.91},
                ],
            },
            "next_page_token": None,
        }
        session = Mock()
        response = Mock()
        response.json.return_value = payload
        response.raise_for_status.return_value = None
        session.get.return_value = response
        reader = AlpacaCorporateActionsReader(
            "test-key", "test-secret", session=session,
            utc_clock=lambda: self.observed_at,
        )
        return reader.fetch(
            ["AAPL", "MSFT"], date(2025, 1, 1), date(2026, 11, 26)
        )

    def test_live_provider_shape_requires_explicit_currency_mapping_then_persists(self):
        batch = self.build_batch()
        self.assertTrue(batch.pagination_complete)
        self.assertEqual(len(batch.records), 2)
        self.assertTrue(all(record.currency is None for record in batch.records))

        with self.assertRaisesRegex(CorporateActionIngestionError, "résolution explicite"):
            ingest_alpaca_corporate_action_batch(batch, self.repo)
        self.assertEqual(self.repo.count_revisions(), 0)

        mapping = {"AAPL": "USD", "MSFT": "USD"}
        result = ingest_alpaca_corporate_action_batch(
            batch, self.repo, currency_resolver=mapping.__getitem__
        )
        self.assertEqual((result.received, result.inserted, result.unchanged, result.revised),
                         (2, 2, 0, 0))
        self.assertEqual(self.repo.count_revisions(), 2)
        for event_id in (
            "a0630261-f185-4ef9-acf0-643ee1cfb8ad",
            "d8002a63-ba52-4a4c-83e6-0710b31d29b2",
        ):
            revision = self.repo.latest_revision(source="alpaca", event_id=event_id)
            self.assertEqual(revision.revision, 1)
            self.assertEqual(revision.event.available_at, self.observed_at)
            self.assertEqual(revision.event.currency, "USD")

    def test_live_provider_batch_replay_is_idempotent(self):
        batch = self.build_batch()
        resolver = lambda symbol: "USD" if symbol in {"AAPL", "MSFT"} else None
        first = ingest_alpaca_corporate_action_batch(batch, self.repo, currency_resolver=resolver)
        second = ingest_alpaca_corporate_action_batch(batch, self.repo, currency_resolver=resolver)
        self.assertEqual(first.inserted, 2)
        self.assertEqual(second.unchanged, 2)
        self.assertEqual(self.repo.count_revisions(), 2)


if __name__ == "__main__":
    unittest.main()
