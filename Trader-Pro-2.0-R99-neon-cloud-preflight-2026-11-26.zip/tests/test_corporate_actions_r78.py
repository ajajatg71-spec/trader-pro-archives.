import unittest
from datetime import date, datetime, timezone, timedelta
from research_v1.quant.corporate_actions import CorporateActionError, CorporateActionEvent, dividend_total_return_index

class DividendTotalReturnTests(unittest.TestCase):
    def setUp(self):
        self.stamps=tuple(datetime(2025,1,d,21,tzinfo=timezone.utc) for d in (2,3,6,7))
        self.asof=self.stamps[-1]
    def split(self):
        return CorporateActionEvent("AAPL","split",date(2025,1,6),self.stamps[0],"provider",split_ratio=2)
    def div(self, amount="0.5", currency="USD", available=None):
        return CorporateActionEvent("AAPL","dividend",date(2025,1,6),available or self.stamps[0],"provider",cash_amount=amount,currency=currency)
    def test_split_does_not_create_artificial_loss(self):
        result=dividend_total_return_index([100,100,50,50],self.stamps,[self.split()],currency="USD", price_basis="raw")
        self.assertEqual(result,(100.0,100.0,100.0,100.0))
    def test_dividend_reinvestment_total_return(self):
        result=dividend_total_return_index([100,100,99,99],self.stamps,[self.div("1")],currency="USD", price_basis="raw")
        self.assertAlmostEqual(result[2],100.0)
        self.assertAlmostEqual(result[3],100.0)
    def test_split_and_dividend_same_ex_date(self):
        result=dividend_total_return_index([100,100,49.75,49.75],self.stamps,[self.split(),self.div("0.25")],currency="USD", price_basis="raw")
        self.assertAlmostEqual(result[2],100.0)
    def test_wrong_dividend_currency_rejected(self):
        with self.assertRaisesRegex(CorporateActionError,"Devise du dividende"):
            dividend_total_return_index([100,100,99,99],self.stamps,[self.div(currency="EUR")],currency="USD", price_basis="raw")
    def test_late_event_rejected_to_prevent_lookahead(self):
        late=self.div(available=self.stamps[2]+timedelta(days=1))
        with self.assertRaisesRegex(CorporateActionError,"lookahead"):
            dividend_total_return_index([100,100,99,99],self.stamps,[late],currency="USD", price_basis="raw")
    def test_event_ex_date_must_exist_in_series(self):
        missing=CorporateActionEvent("AAPL","dividend",date(2025,1,5),self.stamps[0],"provider",cash_amount="1",currency="USD")
        with self.assertRaisesRegex(CorporateActionError,"ex-date absente"):
            dividend_total_return_index([100,100,99,99],self.stamps,[missing],currency="USD", price_basis="raw")
    def test_requires_explicit_currency(self):
        with self.assertRaises(CorporateActionError):
            dividend_total_return_index([100,100,99,99],self.stamps,[],currency="", price_basis="raw")
    def test_no_action_matches_price_index(self):
        result=dividend_total_return_index([100,101,99,102],self.stamps,[],currency="USD", price_basis="raw")
        self.assertEqual(result,(100.0,101.0,99.0,102.0))

if __name__=="__main__": unittest.main()
