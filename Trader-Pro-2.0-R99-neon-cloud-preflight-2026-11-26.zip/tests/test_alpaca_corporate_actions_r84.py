import unittest
from datetime import date, datetime, timezone
from unittest.mock import Mock
from services.providers.alpaca_corporate_actions import AlpacaCorporateActionsReader, AlpacaCorporateActionsError

class AlpacaCorporateActionsAdapterTests(unittest.TestCase):
 def reader(self, payloads):
  session=Mock(); session.get.side_effect=[Mock(status_code=200,json=Mock(return_value=p),raise_for_status=Mock()) for p in payloads]
  reader=AlpacaCorporateActionsReader("key","secret",session=session,utc_clock=lambda:datetime(2025,2,1,tzinfo=timezone.utc))
  return reader,session
 def test_maps_splits_and_cash_dividends_without_inventing_knowledge_time(self):
  payload={"corporate_actions":{"forward_splits":[{"id":"s1","symbol":"AAPL","ex_date":"2025-01-15","process_date":"2025-01-16","new_rate":2,"old_rate":1}],"reverse_splits":[],"cash_dividends":[{"id":"d1","symbol":"AAPL","ex_date":"2025-01-20","process_date":"2025-01-21","rate":0.5,"currency":"USD"}]},"next_page_token":None}
  reader,_=self.reader([payload]); batch=reader.fetch(["AAPL"],date(2025,1,1),date(2025,1,31))
  self.assertTrue(batch.pagination_complete); self.assertEqual(len(batch.records),2)
  with self.assertRaisesRegex(ValueError,"available_at explicite"):
   batch.records[0].to_event(available_at=datetime(2025,1,1))
  split=batch.records[0].to_event(available_at=datetime(2025,2,1,tzinfo=timezone.utc))
  self.assertEqual(str(split.split_ratio),"2")
 def test_follows_page_token(self):
  p1={"corporate_actions":{"forward_splits":[],"reverse_splits":[],"cash_dividends":[]},"next_page_token":"p2"}
  p2={"corporate_actions":{"forward_splits":[],"reverse_splits":[],"cash_dividends":[]},"next_page_token":None}
  reader,session=self.reader([p1,p2]); batch=reader.fetch(["AAPL"],date(2025,1,1),date(2025,1,31))
  self.assertEqual(batch.pages_fetched,2); self.assertEqual(session.get.call_count,2)
  self.assertEqual(session.get.call_args_list[1].kwargs["params"]["page_token"],"p2")
 def test_preserves_missing_dividend_currency_for_explicit_ingestion_resolution(self):
  p={"corporate_actions":{"forward_splits":[],"reverse_splits":[],"cash_dividends":[{"id":"d1","symbol":"AAPL","ex_date":"2025-01-20","process_date":"2025-01-21","rate":0.5}]},"next_page_token":None}
  reader,_=self.reader([p])
  batch=reader.fetch(["AAPL"],date(2025,1,1),date(2025,1,31))
  self.assertEqual(len(batch.records),1)
  self.assertIsNone(batch.records[0].currency)
  with self.assertRaisesRegex(ValueError,"Devise"):
   batch.records[0].to_event(available_at=datetime(2025,2,1,tzinfo=timezone.utc))
 def test_rejects_repeated_page_token(self):
  p={"corporate_actions":{"forward_splits":[],"reverse_splits":[],"cash_dividends":[]},"next_page_token":"p1"}
  reader,_=self.reader([p,p])
  with self.assertRaisesRegex(AlpacaCorporateActionsError,"Pagination incomplète"):
   reader.fetch(["AAPL"],date(2025,1,1),date(2025,1,31),max_pages=1)
 def test_rejects_duplicate_provider_id(self):
  row={"id":"d1","symbol":"AAPL","ex_date":"2025-01-20","process_date":"2025-01-21","rate":0.5,"currency":"USD"}
  p={"corporate_actions":{"forward_splits":[],"reverse_splits":[],"cash_dividends":[row,row]},"next_page_token":None}
  reader,_=self.reader([p])
  with self.assertRaisesRegex(AlpacaCorporateActionsError,"dupliqué"):
   reader.fetch(["AAPL"],date(2025,1,1),date(2025,1,31))

if __name__=="__main__": unittest.main()
