import tempfile
from pathlib import Path
import pytest
from db.base import Base
from db.session import build_engine, build_session_factory
from db.hypothesis_registry import HypothesisRegistry, HypothesisRegistryError
from services.research_execution import ResearchExecutionService, ResearchExecutionError

@pytest.fixture
def registry():
    tmp = tempfile.TemporaryDirectory()
    engine = build_engine(f"sqlite:///{Path(tmp.name) / 'registry.db'}")
    Base.metadata.create_all(engine)
    service = HypothesisRegistry(build_session_factory(engine))
    yield service
    engine.dispose()
    tmp.cleanup()

def test_preregister_is_persisted_and_idempotent(registry):
    payload = dict(study="candles", universe=["aapl", "msft"], hypotheses=["a", "b"], protocol_version="v1")
    first = registry.preregister(**payload)
    second = registry.preregister(**payload)
    assert first["family_id"] == second["family_id"]
    assert first["status"] == "PRE_REGISTERED"
    assert first["selection_authorized"] is False
    assert len(registry.list_families()) == 1

def test_results_are_generated_backend_side_and_provenance_is_persisted(registry):
    item = registry.preregister(study="s", universe=["SPY"], hypotheses=["a", "b"], protocol_version="1")
    service = ResearchExecutionService(registry)
    saved = service.execute(
        family_id=item["family_id"], market_data_snapshot={"SPY": [[1, 2, 3]]},
        code_version="git:abc123", evaluator=lambda manifest, snapshot: {"a": .01, "b": .04})
    assert saved["status"] == "RESULTS_LOCKED"
    assert saved["adjusted_results"]["family_complete"] is True
    assert saved["selection_authorized"] is False
    provenance = saved["execution_provenance"]
    assert provenance["execution_origin"] == "BACKEND_RESEARCH_EXECUTOR"
    assert len(provenance["market_data_snapshot_hash"]) == 64
    assert len(provenance["protocol_hash"]) == 64
    assert len(provenance["code_hash"]) == 64
    assert len(provenance["results_hash"]) == 64
    assert provenance["run_id"]

def test_backend_execution_rejects_unknown_family_and_non_callable(registry):
    service = ResearchExecutionService(registry)
    with pytest.raises(ResearchExecutionError, match="inconnue"):
        service.execute(family_id="missing", market_data_snapshot={}, code_version="x", evaluator=lambda *_: {})
    item = registry.preregister(study="s", universe=["SPY"], hypotheses=["a"], protocol_version="1")
    with pytest.raises(ResearchExecutionError, match="Evaluateur"):
        service.execute(family_id=item["family_id"], market_data_snapshot={}, code_version="x", evaluator=None)

def test_locked_results_cannot_be_overwritten(registry):
    item = registry.preregister(study="s", universe=["SPY"], hypotheses=["a", "b"], protocol_version="1")
    service = ResearchExecutionService(registry)
    saved = service.execute(family_id=item["family_id"], market_data_snapshot={"x": 1},
                            code_version="v1", evaluator=lambda *_: {"a": .01, "b": .04})
    with pytest.raises(HypothesisRegistryError, match="immuables"):
        registry._record_execution_results(item["family_id"], {"a": .02, "b": .04},
            {**saved["execution_provenance"], "run_id": "different-run"})
    assert registry.list_families()[0]["p_values"] == {"a": .01, "b": .04}


def test_registry_recomputes_protocol_and_result_hashes(registry):
    item = registry.preregister(study="s", universe=["SPY"], hypotheses=["a"], protocol_version="1")
    saved = ResearchExecutionService(registry).execute(
        family_id=item["family_id"], market_data_snapshot={"SPY": [1, 2]},
        code_version="git:abc", evaluator=lambda *_: {"a": 0.05})
    provenance = dict(saved["execution_provenance"])
    provenance["results_hash"] = "0" * 64
    other = registry.preregister(study="s2", universe=["SPY"], hypotheses=["a"], protocol_version="1")
    other_manifest = registry.list_families()[0]["manifest"]
    # Same protocol content is needed for the protocol hash to pass; use a fresh registry row
    # with a distinct hypothesis family below and recalculate its protocol fingerprint.
    from services.research_execution import _canonical_hash
    provenance["protocol_hash"] = _canonical_hash(next(
        row["manifest"] for row in registry.list_families() if row["family_id"] == other["family_id"]))
    with pytest.raises(HypothesisRegistryError, match="Empreinte des résultats"):
        registry._record_execution_results(other["family_id"], {"a": 0.05}, provenance)


def test_execution_rejects_non_probability_values(registry):
    item = registry.preregister(study="s", universe=["SPY"], hypotheses=["a"], protocol_version="1")
    service = ResearchExecutionService(registry)
    for bad in (float("nan"), float("inf"), -0.1, 1.1):
        with pytest.raises(ResearchExecutionError, match="P-values hors domaine"):
            service.execute(family_id=item["family_id"], market_data_snapshot={"x": 1},
                            code_version="v1", evaluator=lambda *_: {"a": bad})
    assert registry.list_families()[0]["status"] == "PRE_REGISTERED"


def test_execution_rejects_noncanonical_snapshot_objects(registry):
    item = registry.preregister(study="s", universe=["SPY"], hypotheses=["a"], protocol_version="1")
    with pytest.raises(ResearchExecutionError):
        ResearchExecutionService(registry).execute(
            family_id=item["family_id"], market_data_snapshot={"x": object()},
            code_version="v1", evaluator=lambda *_: {"a": 0.05})
