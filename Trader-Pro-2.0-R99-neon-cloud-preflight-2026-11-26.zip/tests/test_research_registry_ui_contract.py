from pathlib import Path

def test_research_registry_ui_is_preregister_and_read_only():
    source = (Path(__file__).parents[1] / "frontend" / "src" / "ResearchRegistry.tsx").read_text()
    assert "'/api/research/registry/families?limit=100'" in source
    assert "'/api/research/registry/families'" in source
    assert "selection_authorized" in source
    assert "JSON.parse" not in source
    assert "/results" not in source
    assert "submit_order" not in source
    assert "broker" not in source.lower()


def test_research_registry_api_serialization_matches_frontend_family_contract():
    from types import SimpleNamespace
    from db.hypothesis_registry import HypothesisRegistry

    record = SimpleNamespace(
        family_id="family-1", study="candle-confluence", protocol_version="v1",
        manifest={"universe": ["AAPL"], "hypotheses": ["candle_only"]},
        expected_ids=["candle_only"], status="PRE_REGISTERED",
        p_values=None, adjusted_results=None, created_at=None, results_locked_at=None,
        execution_provenance=None,
    )
    payload = HypothesisRegistry._serialize(record)
    ui = (Path(__file__).parents[1] / "frontend" / "src" / "ResearchRegistry.tsx").read_text()

    for field in ("family_id", "study", "protocol_version", "manifest", "expected_ids",
                  "status", "adjusted_results", "created_at", "selection_authorized"):
        assert field in payload
        assert field in ui
    assert payload["manifest"]["universe"] == ["AAPL"]
    assert payload["manifest"]["hypotheses"] == ["candle_only"]
    assert payload["selection_authorized"] is False
