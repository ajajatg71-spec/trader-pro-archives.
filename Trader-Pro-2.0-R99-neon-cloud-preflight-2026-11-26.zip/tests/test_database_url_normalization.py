import unittest
from db.session import normalize_database_url


class DatabaseURLNormalizationTests(unittest.TestCase):
    def test_legacy_postgres_scheme_uses_psycopg3(self):
        self.assertEqual(
            normalize_database_url("postgres://user:pass@host/db?sslmode=require"),
            "postgresql+psycopg://user:pass@host/db?sslmode=require",
        )

    def test_standard_postgresql_scheme_uses_psycopg3(self):
        self.assertEqual(
            normalize_database_url("postgresql://user:pass@host/db"),
            "postgresql+psycopg://user:pass@host/db",
        )

    def test_explicit_driver_and_sqlite_are_unchanged(self):
        explicit = "postgresql+psycopg://user:pass@host/db"
        sqlite = "sqlite:////tmp/trader-pro.db"
        self.assertEqual(normalize_database_url(explicit), explicit)
        self.assertEqual(normalize_database_url(sqlite), sqlite)


if __name__ == "__main__":
    unittest.main()
