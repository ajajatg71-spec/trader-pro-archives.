import importlib.util, unittest, os, subprocess, sys
from unittest.mock import patch, Mock

@unittest.skipUnless(importlib.util.find_spec("requests"), "requests absent")
class Broker(unittest.TestCase):
    def setUp(s):
        import broker; s.b = broker
        s.p = patch("broker.time.sleep"); s.p.start()
        s.ready = patch.object(broker, "_ensure_paper_ready", return_value={"id":"test-account", "equity":"100000", "cash":"100000"})
        s.ready.start()
        s.credentials = [patch.object(broker, "KEY", "unit-test-key"), patch.object(broker, "SECRET", "unit-test-secret"),
                         patch.object(broker, "H", {"APCA-API-KEY-ID":"unit-test-key", "APCA-API-SECRET-KEY":"unit-test-secret"})]
        for item in s.credentials: item.start()
    def tearDown(s):
        for item in s.credentials: item.stop()
        s.ready.stop(); s.p.stop()
    def resp(s, code, js=None):
        r = Mock(); r.ok, r.status_code, r.content, r.text = code < 400, code, b"x", "err"
        r.json.return_value = js if js is not None else {}; return r
    def test_live_and_allow_live_override_fail_closed(s):
        env = os.environ.copy()
        env["ALPACA_BASE_URL"] = "https://evil.example/paper-api.alpaca.markets"
        env["ALLOW_LIVE"] = "yes"
        result = subprocess.run([sys.executable, "-c", "import broker"], env=env,
                                capture_output=True, text=True, timeout=10)
        s.assertNotEqual(result.returncode, 0)
        s.assertIn("seule l'URL officielle", result.stderr)
    def test_paper_url_allowlist(s):
        good = "https://paper-api.alpaca.markets"
        s.assertTrue(s.b.is_approved_paper_url(good))
        for bad in (
            "http://paper-api.alpaca.markets",
            "https://evil.example/paper-api.alpaca.markets",
            "https://paper-api.alpaca.markets.evil.example",
            "https://user@paper-api.alpaca.markets",
            "https://paper-api.alpaca.markets:8443",
            "https://paper-api.alpaca.markets/path",
            "https://api.alpaca.markets",
        ):
            s.assertFalse(s.b.is_approved_paper_url(bad), bad)
    def test_retry_then_ok(s):
        import requests
        with patch("requests.request", side_effect=[requests.Timeout(), s.resp(503), s.resp(200, {"ok": 1})]) as m:
            s.assertEqual(s.b._request_with_retry("GET", "/v2/account"), {"ok": 1}); s.assertEqual(m.call_count, 3)
    def test_no_retry_on_4xx(s):
        with patch("requests.request", return_value=s.resp(403)) as m:
            with s.assertRaises(s.b.BrokerError): s.b._request_with_retry("GET", "/v2/account")
            s.assertEqual(m.call_count, 1)
    def test_gives_up_after_retries(s):
        with patch("requests.request", return_value=s.resp(503)) as m:
            with s.assertRaises(s.b.BrokerError): s.b._request_with_retry("GET", "/v2/account")
            s.assertEqual(m.call_count, 3)
    def test_orders_fetches_all_pages_with_last_order_token(s):
        first = [{"id": f"order-{i}"} for i in range(500)]
        second = [{"id": "order-500"}]
        with patch("requests.request", side_effect=[s.resp(200, first), s.resp(200, second)]) as m:
            result = s.b.orders(status="open", limit=1000)
        s.assertEqual(len(result), 501)
        s.assertEqual(m.call_count, 2)
        first_params = m.call_args_list[0].kwargs["params"]
        second_params = m.call_args_list[1].kwargs["params"]
        s.assertEqual(first_params["limit"], 500)
        s.assertEqual(second_params["page_token"], "order-499")
        s.assertEqual(second_params["limit"], 500)

    def test_orders_rejects_duplicate_ids_across_pages(s):
        first = [{"id": f"order-{i}"} for i in range(500)]
        second = [{"id": "order-499"}]
        with patch("requests.request", side_effect=[s.resp(200, first), s.resp(200, second)]):
            with s.assertRaises(s.b.BrokerError):
                s.b.orders(status="open", limit=1000)

    def test_orders_rejects_invalid_page_payload(s):
        with patch("requests.request", return_value=s.resp(200, {"orders": []})):
            with s.assertRaises(s.b.BrokerError):
                s.b.orders(status="open", limit=1000)

    def test_fills_rejects_non_list_page(s):
        with patch.object(s.b, "_r", return_value={"activities": []}):
            with s.assertRaises(s.b.BrokerError):
                s.b.fills()

    def test_fills_rejects_incomplete_fill_instead_of_silently_skipping(s):
        malformed = {"id": "fill-1", "order_id": "order-1", "symbol": "AAPL",
                     "side": "buy", "qty": "1", "price": "100"}
        with patch.object(s.b, "_r", return_value=[malformed]):
            with s.assertRaises(s.b.BrokerError):
                s.b.fills()

    def test_fills_rejects_invalid_side(s):
        activity = {"id": "fill-1", "order_id": "order-1", "symbol": "AAPL",
                    "side": "unknown", "qty": "1", "price": "100",
                    "transaction_time": "2026-11-15T10:00:00Z"}
        with patch.object(s.b, "_r", return_value=[activity]):
            with s.assertRaises(s.b.BrokerError):
                s.b.fills()

    def test_fills_normalizes_complete_activity(s):
        activity = {"id": "fill-1", "order_id": "order-1", "symbol": "AAPL",
                    "side": "buy", "qty": "1.25", "price": "100.10",
                    "transaction_time": "2026-11-15T10:00:00Z", "fee": "0.01"}
        with patch.object(s.b, "_r", return_value=[activity]):
            result = s.b.fills()
        s.assertEqual(result, [{"id": "fill-1", "order_id": "order-1", "symbol": "AAPL",
                                "side": "buy", "qty": "1.25", "price": "100.10",
                                "time": "2026-11-15T10:00:00Z", "fee": "0.01"}])

    def test_fills_rejects_duplicate_ids_across_pages(s):
        first = [{"id": f"fill-{i}", "order_id": f"order-{i}", "symbol": "AAPL",
                  "side": "buy", "qty": "1", "price": "100",
                  "transaction_time": "2026-11-15T10:00:00Z"} for i in range(100)]
        second = [dict(first[-1])]
        with patch.object(s.b, "_r", side_effect=[first, second]):
            with s.assertRaises(s.b.BrokerError):
                s.b.fills(pages=2)

    def test_fills_rejects_full_final_page_when_page_cap_is_reached(s):
        full_page = [{"id": f"fill-{i}", "order_id": f"order-{i}", "symbol": "AAPL",
                      "side": "buy", "qty": "1", "price": "100",
                      "transaction_time": "2026-11-15T10:00:00Z"} for i in range(100)]
        with patch.object(s.b, "_r", return_value=full_page) as request:
            with s.assertRaisesRegex(s.b.BrokerError, "plafond de pages atteint"):
                s.b.fills(pages=1)
        s.assertEqual(request.call_count, 1)

    def test_fills_accepts_partial_final_page_at_page_cap(s):
        partial_page = [{"id": "fill-1", "order_id": "order-1", "symbol": "AAPL",
                         "side": "buy", "qty": "1", "price": "100",
                         "transaction_time": "2026-11-15T10:00:00Z"}]
        with patch.object(s.b, "_r", return_value=partial_page):
            s.assertEqual(len(s.b.fills(pages=1)), 1)

    def test_fills_rejects_invalid_page_count(s):
        for value in (0, 101, True, 1.5):
            with s.subTest(value=value), s.assertRaises(s.b.BrokerError):
                s.b.fills(pages=value)

    def test_orders_rejects_unbounded_limit(s):
        with s.assertRaises(s.b.BrokerError):
            s.b.orders(status="open", limit=10001)

    def test_duplicate_order_returns_existing_only_when_intent_matches(s):
        existing = {"id": "X", "symbol": "AAPL", "side": "buy", "type": "market",
                    "time_in_force": "day", "notional": "1.00"}
        with patch("requests.request", side_effect=[s.resp(422), s.resp(200, existing)]):
            s.assertEqual(s.b.order("AAPL", "buy", 1, "cid")["id"], "X")

    def test_duplicate_order_rejects_mismatched_existing_intent(s):
        existing = {"id": "X", "symbol": "MSFT", "side": "buy", "type": "market",
                    "time_in_force": "day", "notional": "1.00"}
        with patch("requests.request", side_effect=[s.resp(422), s.resp(200, existing)]):
            with s.assertRaisesRegex(s.b.BrokerError, "ordre au marché différent") as caught:
                s.b.order("AAPL", "buy", 1, "cid")
            s.assertEqual(caught.exception.status, 409)

    def test_duplicate_order_rejects_incomplete_existing_intent(s):
        with patch("requests.request", side_effect=[s.resp(422), s.resp(200, {"id": "X"})]):
            with s.assertRaisesRegex(s.b.BrokerError, "ordre au marché différent"):
                s.b.order("AAPL", "buy", 1, "cid")

    def test_market_order_rejects_invalid_intent_before_network(s):
        with patch("requests.request") as request:
            for amount in (0, -1, "NaN", "Infinity"):
                with s.subTest(amount=amount), s.assertRaises(s.b.BrokerError):
                    s.b.order("AAPL", "buy", amount, "cid")
            request.assert_not_called()
if __name__ == "__main__": unittest.main()
