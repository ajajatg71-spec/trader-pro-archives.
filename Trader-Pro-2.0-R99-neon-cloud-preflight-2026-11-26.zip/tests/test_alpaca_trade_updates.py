import json
import logging
import threading
import unittest
from scripts.run_alpaca_trade_updates_listener import validate_environment, serve_connection
from services.alpaca_trade_updates import (
    AlpacaTradeUpdatesError, persist_trade_update, stable_event_id,
)


class _Processor:
    def __init__(self):
        self.calls = []
    def receive(self, *, event_id, event):
        self.calls.append((event_id, event))
        return True


class AlpacaTradeUpdatesAdapterTests(unittest.TestCase):
    def base(self):
        return {
            "BROKER": "alpaca",
            "DATABASE_URL": "postgresql+psycopg://user:password@localhost/trader_test",
            "ALPACA_BASE_URL": "https://paper-api.alpaca.markets",
            "ALPACA_TRADE_UPDATES_URL": "wss://paper-api.alpaca.markets/stream",
            "APCA_API_KEY_ID": "paper-key",
            "APCA_API_SECRET_KEY": "paper-secret",
        }

    def test_environment_requires_postgres_and_exact_paper_websocket(self):
        self.assertEqual(validate_environment(self.base())[1],
                         "wss://paper-api.alpaca.markets/stream")
        for key, value in (("BROKER", "sim"), ("DATABASE_URL", "sqlite:///x.db"),
                           ("ALPACA_BASE_URL", "https://api.alpaca.markets"),
                           ("ALPACA_TRADE_UPDATES_URL", "wss://api.alpaca.markets/stream"),
                           ("APCA_API_SECRET_KEY", "")):
            env = self.base(); env[key] = value
            with self.assertRaises(ValueError):
                validate_environment(env)

    def test_stable_id_prefers_provider_event_and_execution_ids(self):
        self.assertEqual(stable_event_id({"event_id": "evt-1"}), "alpaca:evt-1")
        self.assertEqual(stable_event_id({"execution_id": "fill-1"}), "alpaca:fill-1")

    def test_stable_id_hashes_canonical_payload_when_no_provider_id(self):
        a = {"event": "new", "order": {"id": "o1", "status": "new"}}
        b = {"order": {"status": "new", "id": "o1"}, "event": "new"}
        self.assertEqual(stable_event_id(a), stable_event_id(b))
        self.assertTrue(stable_event_id(a).startswith("alpaca:sha256:"))

    def test_persists_trade_update_and_accepts_bytes_frame(self):
        processor = _Processor()
        payload = {"stream": "trade_updates", "data": {
            "event": "fill", "execution_id": "fill-123", "timestamp": "2026-11-13T10:00:00Z",
            "order": {"id": "order-1", "client_order_id": "client-1"},
        }}
        self.assertTrue(persist_trade_update(json.dumps(payload).encode(), processor))
        self.assertEqual(processor.calls[0][0], "alpaca:fill-123")
        self.assertEqual(processor.calls[0][1]["event"], "fill")

    def test_rejects_other_stream_and_malformed_envelope(self):
        processor = _Processor()
        with self.assertRaises(AlpacaTradeUpdatesError):
            persist_trade_update({"stream": "authorization", "data": {}}, processor)
        with self.assertRaises(AlpacaTradeUpdatesError):
            persist_trade_update({"stream": "trade_updates", "data": {"order": {}}}, processor)

    def test_does_not_accept_non_utf8_binary_frames(self):
        with self.assertRaises(AlpacaTradeUpdatesError):
            persist_trade_update(b"\xff\xfe", _Processor())

    def test_websocket_handshake_subscribes_and_persists_only_trade_updates(self):
        class FakeSocket:
            def __init__(self):
                self.sent = []
                self.frames = iter([
                    json.dumps({"stream": "authorization", "data": {"status": "authorized"}}),
                    json.dumps({"stream": "listening", "data": {"streams": ["trade_updates"]}}),
                    json.dumps({"stream": "trade_updates", "data": {
                        "event": "new", "event_id": "event-77",
                        "order": {"id": "order-77", "client_order_id": "client-77"}}}),
                ])
            def settimeout(self, value): self.timeout = value
            def send(self, value): self.sent.append(json.loads(value))
            def recv(self):
                frame = next(self.frames)
                if '"stream": "trade_updates"' in frame:
                    stop.set()
                return frame
        ws = FakeSocket()
        processor = _Processor()
        stop = threading.Event()
        serve_connection(ws, processor, "key", "secret", stop,
                         logging.getLogger("test.alpaca.stream"))
        self.assertEqual(ws.sent[0]["action"], "auth")
        self.assertEqual(ws.sent[0]["key"], "key")
        self.assertEqual(ws.sent[1], {"action": "listen", "data": {"streams": ["trade_updates"]}})
        self.assertEqual(processor.calls[0][0], "alpaca:event-77")


if __name__ == "__main__":
    unittest.main()
