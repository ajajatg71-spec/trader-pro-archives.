import unittest
import sim_broker as S
from broker import BrokerError

class Sim(unittest.TestCase):
    def setUp(s): S.reset()
    def test_buy_updates_cash_and_position(s):
        eq0 = float(S.account()["equity"]); o = S.order("AAPL", "buy", 5000, "c1")
        s.assertEqual(o["status"], "filled"); s.assertAlmostEqual(float(S.account()["cash"]), 95000.0, places=2)
        p = S.positions()[0]; s.assertEqual(p["symbol"], "AAPL"); s.assertAlmostEqual(float(S.account()["equity"]), eq0, delta=60)
    def test_idempotent(s):
        a, b = S.order("AAPL", "buy", 1000, "same"), S.order("AAPL", "buy", 1000, "same")
        s.assertEqual(a["id"], b["id"]); s.assertEqual(len(S.fills()), 1)
    def test_errors(s):
        with s.assertRaises(BrokerError): S.order("AAPL", "buy", 1e9, "x1")
        with s.assertRaises(BrokerError): S.order("AAPL", "sell", 100, "x2")
        with s.assertRaises(BrokerError): S.order("AAPL", "buy", 0.5, "x3")
        with s.assertRaises(BrokerError): S.order("AA PL", "buy", 100, "x4")
    def test_sell_closes_position(s):
        S.order("KO", "buy", 2000, "b"); S.order("KO", "sell", float(S.positions()[0]["market_value"]), "s"); s.assertEqual(S.positions(), [])
    def test_cancel_filled_refused(s):
        o = S.order("KO", "buy", 1000, "k")
        with s.assertRaises(BrokerError): S.cancel(o["id"])
        s.assertEqual(S.order_get(o["id"])["status"], "filled")
    def test_orders_and_fills_shape(s):
        S.order("BAC", "buy", 1000, "z"); f = S.fills()[0]
        s.assertEqual(set(f), {"id", "order_id", "symbol", "side", "qty", "price", "time", "fee"}); s.assertEqual(len(S.orders("all", 5)), 1); s.assertEqual(S.orders("open"), [])
    def test_market_data(s):
        c, v = S.bars2("MSFT"); s.assertEqual(len(c), 250); s.assertEqual(len(v), 250); s.assertEqual(S.bars("MSFT"), c)
        s.assertEqual(len(S.closes_long("MSFT")), 1800); s.assertTrue(all(isinstance(h, str) for h in S.news("MSFT")))
        e = S.equity_curve("1M"); s.assertEqual(len(e), 30); s.assertAlmostEqual(e[-1][1], float(S.account()["equity"]), delta=1)
    def test_average_entry(s):
        S.order("KO", "buy", 1000, "a"); S.order("KO", "buy", 1000, "b"); p = S.positions()[0]; s.assertAlmostEqual(float(p["avg_entry_price"]), S._px("KO"), delta=1)
if __name__ == "__main__": unittest.main()
