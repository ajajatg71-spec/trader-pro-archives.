import unittest
from datetime import datetime
from zoneinfo import ZoneInfo
from unittest.mock import Mock
import requests

from services.providers.twelvedata import TwelveDataDailyBars, TwelveDataError
from services.market_data import MarketDataService, ProviderChain


class TwelveDataAdapterTests(unittest.TestCase):
    def make_session(self, payload):
        session = Mock()
        response = Mock()
        response.json.return_value = payload
        response.raise_for_status.return_value = None
        session.get.return_value = response
        return session

    def test_normalizes_daily_bars_to_exchange_session_timestamps(self):
        session = self.make_session({"values": [
            {"datetime": "2026-01-06", "close": "102.5", "volume": "1200"},
            {"datetime": "2026-01-05", "close": "101.5", "volume": "1100"},
        ]})
        adapter = TwelveDataDailyBars("unit-test-secret", session=session)
        stamps, closes, volumes = adapter("AAPL", 2)
        self.assertEqual(closes, [101.5, 102.5])
        self.assertEqual(volumes, [1100.0, 1200.0])
        self.assertEqual(stamps[0], datetime(2026, 1, 5, tzinfo=ZoneInfo("America/New_York")))
        self.assertEqual(session.get.call_args.kwargs["params"]["apikey"], "unit-test-secret")
        self.assertEqual(session.get.call_args.kwargs["params"]["order"], "ASC")

    def test_requires_api_key(self):
        with self.assertRaises(ValueError):
            TwelveDataDailyBars("")

    def test_validates_limit(self):
        adapter = TwelveDataDailyBars("key", session=self.make_session({"values": []}))
        for limit in (1, 5001, True, 2.5):
            with self.subTest(limit=limit), self.assertRaises(ValueError):
                adapter("AAPL", limit)

    def test_rejects_provider_error_without_leaking_message_or_key(self):
        session = self.make_session({"status": "error", "code": 401, "message": "key=SECRET"})
        adapter = TwelveDataDailyBars("SECRET", session=session)
        with self.assertRaises(TwelveDataError) as caught:
            adapter("AAPL", 2)
        self.assertNotIn("SECRET", str(caught.exception))

    def test_rejects_http_failure_without_leaking_request_details(self):
        session = Mock()
        session.get.side_effect = requests.Timeout("https://host?apikey=SECRET")
        adapter = TwelveDataDailyBars("SECRET", session=session)
        with self.assertRaises(TwelveDataError) as caught:
            adapter("AAPL", 2)
        self.assertNotIn("SECRET", str(caught.exception))

    def test_rejects_short_history(self):
        adapter = TwelveDataDailyBars("key", session=self.make_session({"values": [
            {"datetime": "2026-01-05", "close": "10", "volume": "1"}
        ]}))
        with self.assertRaisesRegex(TwelveDataError, "insuffisant"):
            adapter("AAPL", 2)

    def test_rejects_duplicate_dates(self):
        adapter = TwelveDataDailyBars("key", session=self.make_session({"values": [
            {"datetime": "2026-01-05", "close": "10", "volume": "1"},
            {"datetime": "2026-01-05", "close": "11", "volume": "2"},
        ]}))
        with self.assertRaisesRegex(TwelveDataError, "dupliquées"):
            adapter("AAPL", 2)

    def test_rejects_invalid_price_and_volume(self):
        for row in (
            {"datetime": "2026-01-05", "close": "nan", "volume": "1"},
            {"datetime": "2026-01-05", "close": "10", "volume": "-1"},
        ):
            adapter = TwelveDataDailyBars("key", session=self.make_session({"values": [row, {**row, "datetime": "2026-01-06"}]}))
            with self.assertRaises(TwelveDataError):
                adapter("AAPL", 2)

    def test_provider_chain_falls_back_from_alpaca_to_twelve_data_adapter(self):
        session = self.make_session({"values": [
            {"datetime": "2026-01-05", "close": "10", "volume": "100"},
            {"datetime": "2026-01-06", "close": "11", "volume": "110"},
        ]})
        secondary = TwelveDataDailyBars("key", session=session)
        chain = ProviderChain([
            ("alpaca", lambda symbol, limit: (_ for _ in ()).throw(TimeoutError())),
            ("twelvedata", secondary),
        ])
        result = MarketDataService(chain).daily_bars("AAPL", 2)
        self.assertEqual(result.source, "twelvedata")
        self.assertEqual(result.closes, (10.0, 11.0))
        self.assertEqual(result.adjustment_mode, "unknown")
        self.assertEqual(chain.health_snapshot()["providers"]["twelvedata"]["successes"], 1)

    def test_full_ohlcv_mode_returns_open_high_low_close_volume(self):
        session = self.make_session({"values": [
            {"datetime": "2026-01-05", "open": "10", "high": "12", "low": "9", "close": "11", "volume": "100"},
            {"datetime": "2026-01-06", "open": "11", "high": "13", "low": "10", "close": "12", "volume": "110"},
        ]})
        adapter = TwelveDataDailyBars("key", session=session, include_ohlc=True)
        stamps, opens, highs, lows, closes, volumes = adapter("AAPL", 2)
        self.assertEqual(opens, [10.0, 11.0])
        self.assertEqual(highs, [12.0, 13.0])
        self.assertEqual(lows, [9.0, 10.0])
        self.assertEqual(closes, [11.0, 12.0])
        self.assertEqual(volumes, [100.0, 110.0])
        self.assertEqual(len(stamps), 2)

    def test_full_ohlcv_adapter_integrates_with_market_data_service(self):
        session = self.make_session({"values": [
            {"datetime": "2026-01-05", "open": "10", "high": "12", "low": "9", "close": "11", "volume": "100"},
            {"datetime": "2026-01-06", "open": "11", "high": "13", "low": "10", "close": "12", "volume": "110"},
        ]})
        adapter = TwelveDataDailyBars("key", session=session, include_ohlc=True)
        service = MarketDataService(lambda symbol, limit: ([10, 11], [100, 110]),
                                    ohlcv_reader=adapter)
        bars = service.daily_ohlcv("AAPL", 2)
        self.assertEqual(bars.opens, (10.0, 11.0))
        self.assertEqual(bars.closes, (11.0, 12.0))
        self.assertEqual(bars.source, "twelvedata")

    def test_full_ohlcv_mode_rejects_incoherent_candle(self):
        row = {"datetime": "2026-01-05", "open": "10", "high": "9", "low": "8", "close": "10", "volume": "100"}
        other = {**row, "datetime": "2026-01-06", "high": "11"}
        adapter = TwelveDataDailyBars("key", session=self.make_session({"values": [row, other]}), include_ohlc=True)
        with self.assertRaisesRegex(TwelveDataError, "Géométrie"):
            adapter("AAPL", 2)

    def test_invalid_json_payload_is_rejected(self):
        session = Mock()
        response = Mock()
        response.raise_for_status.return_value = None
        response.json.side_effect = ValueError("bad json")
        session.get.return_value = response
        with self.assertRaisesRegex(TwelveDataError, "JSON invalide"):
            TwelveDataDailyBars("key", session=session)("AAPL", 2)


if __name__ == "__main__":
    unittest.main()
