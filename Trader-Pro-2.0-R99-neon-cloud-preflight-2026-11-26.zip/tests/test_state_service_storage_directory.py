"""The configured state directory is also the recovery source for backups."""
import json
from pathlib import Path

from services.state import StateService


def test_state_service_restores_from_its_configured_backup_directory(tmp_path):
    data_dir = tmp_path / "persistent-data"
    backup_dir = data_dir / "backups"
    snapshot_dir = backup_dir / "20261123-1200"
    snapshot_dir.mkdir(parents=True)
    (snapshot_dir / "state.json").write_text(
        json.dumps({"paused": True, "targets": [{"symbol": "SPY"}]}),
        encoding="utf-8",
    )
    service = StateService(
        limits={}, strategy_defaults={},
        state_path=str(data_dir / "state.json"),
        history_path=str(data_dir / "history.jsonl"),
        backup_dir=str(backup_dir),
    )

    loaded = service.load()

    assert loaded["paused"] is True
    assert loaded["targets"] == [{"symbol": "SPY"}]
