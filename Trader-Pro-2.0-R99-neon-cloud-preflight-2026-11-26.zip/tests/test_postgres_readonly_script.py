"""Safety tests for the non-mutating Neon PostgreSQL probe."""
from __future__ import annotations

import contextlib
import io
import os
import runpy
import sys
import unittest
from unittest.mock import Mock, patch

SCRIPT = "scripts/verify_postgres_readonly.py"
GOOD_URL = "postgresql+psycopg://tester:secret@ep-test.eu-central-1.aws.neon.tech/trader_pro_test?sslmode=require"


class PostgresReadonlyScriptTests(unittest.TestCase):
    def test_target_url_requires_neon_tls_and_known_database(self):
        namespace = runpy.run_path(SCRIPT, run_name="readonly_probe_test_module")
        validate = namespace["validate_target_url"]
        self.assertEqual(validate(GOOD_URL).database, "trader_pro_test")
        for bad in (
            "postgresql+psycopg://u:p@localhost/trader_pro_test?sslmode=require",
            "postgresql+psycopg://u:p@ep-test.neon.tech/production?sslmode=require",
            "postgresql+psycopg://u:p@ep-test.neon.tech/trader_pro_test",
            "sqlite:///trader_pro_test",
        ):
            with self.subTest(url=bad), self.assertRaises(ValueError):
                validate(bad)

    def test_missing_url_refused_before_database_engine(self):
        stdout, stderr = io.StringIO(), io.StringIO()
        with patch.dict(os.environ, {}, clear=True), contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            result = runpy.run_path(SCRIPT, run_name="readonly_probe_missing")
            code = result["main"]()
        self.assertEqual(code, 2)
        self.assertIn("TRADER_PRO_READONLY_DATABASE_URL", stderr.getvalue())

    def test_probe_sets_read_only_and_performs_selects_only(self):
        namespace = runpy.run_path(SCRIPT, run_name="readonly_probe_success")
        calls = []

        class FakeResult:
            def __init__(self, value=None, values=None):
                self.value, self.values = value, values
            def one(self):
                return self.value
            def scalars(self):
                return self
            def __iter__(self):
                return iter(self.values or [])
            def scalar_one_or_none(self):
                return "abc123"

        class FakeConnection:
            def __enter__(self): return self
            def __exit__(self, *args): return False
            def begin(self): return self
            def exec_driver_sql(self, statement):
                calls.append(statement)
                return FakeResult()
            def execute(self, statement):
                sql = str(statement)
                calls.append(sql)
                if "current_database()" in sql:
                    return FakeResult(("trader_pro_test", "160003", "on"))
                if "information_schema.tables" in sql:
                    return FakeResult(values=namespace["REQUIRED_TABLES"] | {"audit_events"})
                if "alembic_version" in sql:
                    return FakeResult()
                raise AssertionError("Unexpected SQL")

        class FakeEngine:
            def connect(self): return FakeConnection()
            def dispose(self): calls.append("DISPOSE")

        create_engine = Mock(return_value=FakeEngine())
        stdout, stderr = io.StringIO(), io.StringIO()
        namespace["main"].__globals__["create_engine"] = create_engine
        with patch.dict(os.environ, {"TRADER_PRO_READONLY_DATABASE_URL": GOOD_URL}), \
             contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            code = namespace["main"]()
        self.assertEqual(code, 0, stderr.getvalue())
        self.assertIn("POSTGRES_NEON_READ_ONLY_OK", stdout.getvalue())
        self.assertIn("writes_performed=0", stdout.getvalue())
        self.assertEqual(create_engine.call_args.kwargs["connect_args"], {"options": "-c default_transaction_read_only=on"})
        self.assertTrue(calls[0].startswith("SET TRANSACTION READ ONLY"))
        self.assertFalse(any(word in sql.upper() for sql in calls for word in ("INSERT ", "UPDATE ", "DELETE ", "CREATE ", "DROP ", "ALTER ")))

    def test_error_output_does_not_echo_connection_secret(self):
        namespace = runpy.run_path(SCRIPT, run_name="readonly_probe_error")
        stdout, stderr = io.StringIO(), io.StringIO()
        namespace["main"].__globals__["create_engine"] = Mock(side_effect=RuntimeError("secret=should-not-leak"))
        with patch.dict(os.environ, {"TRADER_PRO_READONLY_DATABASE_URL": GOOD_URL}), \
             contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            code = namespace["main"]()
        self.assertEqual(code, 1)
        self.assertNotIn("should-not-leak", stderr.getvalue())


if __name__ == "__main__":
    unittest.main()
