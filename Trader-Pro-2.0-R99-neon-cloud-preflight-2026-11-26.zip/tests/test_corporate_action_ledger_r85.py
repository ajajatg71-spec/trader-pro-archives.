import unittest
from datetime import date,datetime,timezone,timedelta
from research_v1.quant.corporate_actions import CorporateActionError,CorporateActionEvent
from research_v1.quant.corporate_action_ledger import CorporateActionRevision,corporate_action_snapshot
class CorporateActionLedgerTests(unittest.TestCase):
 def setUp(self):
  self.t1=datetime(2025,1,1,tzinfo=timezone.utc);self.t2=self.t1+timedelta(days=2);self.asof=self.t2+timedelta(days=2)
 def event(self,amount="0.5",available=None):return CorporateActionEvent("AAPL","dividend",date(2025,1,3),available or self.t1,"alpaca",cash_amount=amount,currency="USD",event_id="e1")
 def rev(self,n,status="active",event=None,at=None):return CorporateActionRevision("alpaca","e1",n,at or self.t1,status,event)
 def test_latest_known_revision_selected(self):
  result=corporate_action_snapshot([self.rev(1,event=self.event()),self.rev(2,event=self.event("0.75",self.t2),at=self.t2)],as_of=self.asof)
  self.assertEqual(str(result[0].cash_amount),"0.75")
 def test_future_revision_does_not_leak(self):
  result=corporate_action_snapshot([self.rev(1,event=self.event()),self.rev(2,event=self.event("0.75",self.t2),at=self.t2)],as_of=self.t1+timedelta(days=1))
  self.assertEqual(str(result[0].cash_amount),"0.5")
 def test_cancellation_removes_event_only_after_known(self):
  cancel=self.rev(2,"cancelled",at=self.t2)
  revisions=[self.rev(1,event=self.event()),cancel]
  self.assertEqual(len(corporate_action_snapshot(revisions,as_of=self.t1+timedelta(days=1))),1)
  self.assertEqual(corporate_action_snapshot(revisions,as_of=self.asof),())
 def test_rejects_duplicate_revision(self):
  rev=self.rev(1,event=self.event())
  with self.assertRaisesRegex(CorporateActionError,"dupliquée"):
   corporate_action_snapshot([rev,rev],as_of=self.asof)
 def test_rejects_cancel_with_payload(self):
  with self.assertRaisesRegex(CorporateActionError,"annulation"):
   self.rev(2,"cancelled",event=self.event(),at=self.t2)
if __name__=="__main__":unittest.main()
