import tempfile
import unittest
from datetime import date, datetime, timezone
from decimal import Decimal
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from db.base import Base
from db.corporate_action_repository import CorporateActionRepository, CorporateActionRepositoryError
from db.models import CorporateActionRevisionRecord
from db.session import build_engine, build_session_factory
from research_v1.quant.corporate_action_ledger import CorporateActionRevision
from research_v1.quant.corporate_actions import CorporateActionEvent


class CorporateActionRepositoryR91Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.engine = build_engine(f"sqlite:///{Path(self.temp.name) / 'corporate-actions.db'}")
        Base.metadata.create_all(self.engine)
        self.sessions = build_session_factory(self.engine)
        self.repo = CorporateActionRepository(self.sessions)
        self.now = datetime(2026, 11, 26, 12, tzinfo=timezone.utc)

    def tearDown(self):
        self.engine.dispose()
        self.temp.cleanup()

    def event(self, *, amount="0.25", available_at=None):
        return CorporateActionEvent(
            symbol="AAPL", action_type="dividend", ex_date=date(2026, 11, 20),
            available_at=available_at or datetime(2026, 11, 1, tzinfo=timezone.utc),
            source="alpaca", cash_amount=Decimal(amount), currency="USD", event_id="evt-1",
        )

    def revision(self, number=1, *, status="active", event=None, recorded_at=None):
        return CorporateActionRevision(
            source="alpaca", event_id="evt-1", revision=number,
            recorded_at=recorded_at or self.now, status=status,
            event=(self.event() if status == "active" and event is None else event),
        )

    def test_round_trip_preserves_decimal_event_and_timezone(self):
        self.assertTrue(self.repo.append_revision(self.revision()))
        result = self.repo.snapshot(as_of=self.now)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].cash_amount, Decimal("0.25"))
        self.assertEqual(result[0].available_at, datetime(2026, 11, 1, tzinfo=timezone.utc))

    def test_exact_duplicate_is_idempotent(self):
        revision = self.revision()
        self.assertTrue(self.repo.append_revision(revision))
        self.assertFalse(self.repo.append_revision(revision))
        self.assertEqual(self.repo.count_revisions(), 1)

    def test_same_revision_with_changed_payload_is_rejected(self):
        self.repo.append_revision(self.revision())
        changed = self.revision(event=self.event(amount="0.30"))
        with self.assertRaisesRegex(CorporateActionRepositoryError, "immuable"):
            self.repo.append_revision(changed)

    def test_later_revision_replaces_earlier_revision_in_snapshot(self):
        first = self.revision(1, recorded_at=datetime(2026, 11, 2, tzinfo=timezone.utc))
        second = self.revision(2, event=self.event(amount="0.30"),
                               recorded_at=datetime(2026, 11, 3, tzinfo=timezone.utc))
        self.repo.append_revision(first)
        self.repo.append_revision(second)
        result = self.repo.snapshot(as_of=datetime(2026, 11, 2, 12, tzinfo=timezone.utc))
        self.assertEqual(result[0].cash_amount, Decimal("0.25"))
        result = self.repo.snapshot(as_of=self.now)
        self.assertEqual(result[0].cash_amount, Decimal("0.30"))

    def test_revision_sequence_must_be_contiguous(self):
        with self.assertRaisesRegex(CorporateActionRepositoryError, "attendu 1"):
            self.repo.append_revision(self.revision(2))

    def test_revision_recorded_at_cannot_move_backwards(self):
        self.repo.append_revision(self.revision(1, recorded_at=datetime(2026, 11, 3, tzinfo=timezone.utc)))
        with self.assertRaisesRegex(CorporateActionRepositoryError, "antérieur"):
            self.repo.append_revision(self.revision(2, recorded_at=datetime(2026, 11, 2, tzinfo=timezone.utc)))

    def test_cancellation_is_durable_and_removes_event_from_snapshot(self):
        self.repo.append_revision(self.revision(1, recorded_at=datetime(2026, 11, 2, tzinfo=timezone.utc)))
        cancelled = self.revision(2, status="cancelled", event=None,
                                  recorded_at=datetime(2026, 11, 3, tzinfo=timezone.utc))
        self.repo.append_revision(cancelled)
        self.assertEqual(self.repo.snapshot(as_of=self.now), ())
        self.assertEqual(self.repo.count_revisions(), 2)

    def test_future_recorded_revision_is_not_visible(self):
        self.repo.append_revision(self.revision(recorded_at=datetime(2026, 11, 27, tzinfo=timezone.utc)))
        self.assertEqual(self.repo.snapshot(as_of=self.now), ())

    def test_naive_as_of_is_rejected(self):
        with self.assertRaisesRegex(CorporateActionRepositoryError, "fuseau"):
            self.repo.snapshot(as_of=datetime(2026, 11, 26, 12))

    def test_database_unique_constraint_blocks_duplicate_identity(self):
        self.repo.append_revision(self.revision())
        with self.assertRaises(IntegrityError):
            with self.sessions.begin() as session:
                session.add(CorporateActionRevisionRecord(
                    source="alpaca", event_id="evt-1", revision=1,
                    recorded_at=self.now, status="active", event_payload={"bad": "duplicate"},
                ))
                session.flush()

    def test_database_check_constraint_rejects_invalid_status_payload(self):
        with self.assertRaises(IntegrityError):
            with self.sessions.begin() as session:
                session.add(CorporateActionRevisionRecord(
                    source="alpaca", event_id="evt-2", revision=1,
                    recorded_at=self.now, status="cancelled", event_payload={"unexpected": True},
                ))
                session.flush()


if __name__ == "__main__":
    unittest.main()
