import unittest
from datetime import date,datetime,timezone
from research_v1.quant.corporate_actions import CorporateActionEvent,dividend_total_return_index
class CorporateActionReturnInvariantTests(unittest.TestCase):
 def setUp(self):self.ts=[datetime(2025,1,d,21,tzinfo=timezone.utc) for d in (2,3,6,7)]
 def split(self,ratio):return CorporateActionEvent("AAPL","split",date(2025,1,6),self.ts[0],"source",split_ratio=ratio,event_id="s1")
 def div(self,amount,event_id):return CorporateActionEvent("AAPL","dividend",date(2025,1,6),self.ts[0],"source",cash_amount=amount,currency="USD",event_id=event_id)
 def test_two_same_day_dividend_legs_are_summed_once(self):
  events=[self.div("0.4","d1"),self.div("0.6","d2")]
  curve=dividend_total_return_index([100,100,99,99],self.ts,events,currency="USD",price_basis="raw")
  self.assertEqual(curve,(100.0,100.0,100.0,100.0))
 def test_reverse_split_maintains_economic_value(self):
  curve=dividend_total_return_index([100,100,1000,1000],self.ts,[self.split("0.1")],currency="USD",price_basis="raw")
  self.assertEqual(curve,(100.0,100.0,100.0,100.0))
 def test_split_and_dividend_combination_is_neutral_when_cash_compensates_price(self):
  events=[self.split("0.5"),self.div("2","d1")]
  curve=dividend_total_return_index([100,100,198,198],self.ts,events,currency="USD",price_basis="raw")
  self.assertEqual(curve,(100.0,100.0,100.0,100.0))
 def test_distinct_dividend_ids_are_not_deduplicated(self):
  events=[self.div("0.25","d1"),self.div("0.25","d2")]
  curve=dividend_total_return_index([100,100,99.5,99.5],self.ts,events,currency="USD",price_basis="raw")
  self.assertAlmostEqual(curve[2],100.0)
if __name__=="__main__":unittest.main()
