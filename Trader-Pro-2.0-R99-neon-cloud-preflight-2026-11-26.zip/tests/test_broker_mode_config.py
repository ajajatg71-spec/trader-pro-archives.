"""Broker mode selection must be opt-in for any external provider."""
from __future__ import annotations

import os
import subprocess
import sys
import unittest


class BrokerModeConfigTests(unittest.TestCase):
    def run_config(self, broker_value=None):
        env = os.environ.copy()
        env.pop("BROKER", None)
        if broker_value is not None:
            env["BROKER"] = broker_value
        result = subprocess.run(
            [sys.executable, "-c", "import config; print(config.BROKER_MODE, config.SIM)"],
            env=env, text=True, capture_output=True, check=False,
        )
        return result

    def test_simulator_is_default_without_broker_configuration(self):
        result = self.run_config()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip(), "sim True")

    def test_alpaca_requires_explicit_opt_in(self):
        result = self.run_config("alpaca")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip(), "alpaca False")

    def test_unknown_broker_value_fails_closed(self):
        result = self.run_config("live")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("BROKER invalide", result.stderr)

    def test_broker_value_is_normalized(self):
        result = self.run_config(" SIM ")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip(), "sim True")


if __name__ == "__main__":
    unittest.main()
