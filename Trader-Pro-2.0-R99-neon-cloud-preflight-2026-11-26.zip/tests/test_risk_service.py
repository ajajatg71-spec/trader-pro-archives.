import unittest
from datetime import datetime, timedelta, timezone

from services.risk import RiskService
from services.market_data import DailyBars


class FakeBrokerError(Exception):
    pass


class RiskServiceTests(unittest.TestCase):
    def setUp(self):
        self.account = {"equity": 900.0, "last_equity": 1000.0, "cash": 300.0}
        self.positions = [{
            "symbol": "ABC", "market_value": 600.0,
            "avg_entry_price": 50.0, "current_price": 45.0,
        }]
        self.state = {
            "limits": {
                "max_orders_day": 20,
                "max_daily_loss": 5,
                "max_drawdown": 20,
                "max_pos": 50,
                "stop_loss_pct": 8,
                "trailing_pct": 12,
                "take_profit_pct": 0,
            },
            "peak": 1000.0,
            "paused": False,
            "highs": {"ABC": 60.0},
        }

    def make_service(self, market_reader=None, history_reader=None):
        return RiskService(
            account_reader=lambda: self.account,
            positions_reader=lambda: self.positions,
            state_reader=lambda: self.state,
            market_bars_reader=market_reader or (lambda symbol: (_ for _ in ()).throw(FakeBrokerError())),
            orders_today_reader=lambda: 3,
            broker_error_type=FakeBrokerError,
            market_history_reader=history_reader,
        )

    def test_snapshot_preserves_existing_risk_summary_and_market_error(self):
        result = self.make_service().snapshot()
        self.assertAlmostEqual(result["daily"], -10.0)
        self.assertAlmostEqual(result["drawdown"], -10.0)
        self.assertEqual(result["cash_pct"], 33.3)
        self.assertFalse(result["paused"])
        self.assertEqual(result["positions"], [{"symbol": "ABC", "pct": 66.7}])
        self.assertTrue(any("Perte journalière" in alert for alert in result["alerts"]))
        self.assertEqual(result["adv"]["orders_today"], 3)
        self.assertEqual(result["adv"]["error"], "données de marché indisponibles")

    def test_advanced_risk_uses_injected_market_data(self):
        closes = [100.0 + i * 0.2 for i in range(220)]
        def market_reader(symbol):
            return closes if symbol in {"SPY", "ABC"} else []

        result = self.make_service(market_reader).snapshot()
        self.assertEqual(result["adv"]["regime"], "haussier")
        self.assertIn("stops", result["adv"])
        self.assertIn("vol_ann_pct", result["adv"])
        self.assertIn("stress", result["adv"])
        self.assertIn("avg_corr", result["adv"])
        self.assertIn("eff_n", result["adv"])
        self.assertEqual(result["adv"]["orders_today"], 3)

    def test_institutional_snapshot_includes_var_cvar_and_stress_market_metrics(self):
        closes = [100.0 + ((i % 7) - 3) * 0.35 + i * 0.03 for i in range(240)]
        def market_reader(symbol):
            return closes if symbol in {"SPY", "ABC"} else []
        result = self.make_service(market_reader).snapshot()
        self.assertIn("var95_pct", result["adv"])
        self.assertIn("cvar95_pct", result["adv"])
        self.assertIn("sector_exposure_pct", result["institutional"]["metrics"])
        self.assertNotEqual(result["institutional"]["status"], "UNAVAILABLE")
        self.assertIn("as_of", self.state["market_risk"])

    def test_zero_equity_does_not_divide_by_zero(self):
        self.account = {"equity": 0.0, "last_equity": 0.0, "cash": 0.0}
        self.positions = []
        result = self.make_service().snapshot()
        self.assertEqual(result["cash_pct"], 0)
        self.assertEqual(result["positions"], [])


if __name__ == "__main__":
    unittest.main()


    def test_advanced_risk_fails_closed_when_one_held_symbol_has_no_history(self):
        self.positions = [
            {"symbol": "ABC", "market_value": 400.0, "avg_entry_price": 50.0},
            {"symbol": "XYZ", "market_value": 200.0, "avg_entry_price": 20.0},
        ]
        closes = [100.0 + i * 0.1 for i in range(220)]
        def market_reader(symbol):
            if symbol == "SPY" or symbol == "ABC":
                return closes
            return []
        result = self.make_service(market_reader).snapshot()
        self.assertEqual(result["adv"]["error"], "historique insuffisant pour toutes les positions")
        self.assertEqual(result["adv"]["missing_symbols"], ["XYZ"])
        self.assertNotIn("var95_pct", result["adv"])
        self.assertNotIn("market_risk", self.state)

    def test_advanced_risk_fails_closed_when_series_lengths_differ(self):
        self.positions = [
            {"symbol": "ABC", "market_value": 400.0, "avg_entry_price": 50.0},
            {"symbol": "XYZ", "market_value": 200.0, "avg_entry_price": 20.0},
        ]
        base = [100.0 + i * 0.1 for i in range(220)]
        def market_reader(symbol):
            if symbol == "SPY" or symbol == "ABC":
                return base
            if symbol == "XYZ":
                return base[:-1]
            return []
        result = self.make_service(market_reader).snapshot()
        self.assertEqual(result["adv"]["error"], "historiques de marché désalignés en longueur")
        self.assertEqual(result["adv"]["alignment"], "unverified")
        self.assertNotIn("var95_pct", result["adv"])
        self.assertNotIn("market_risk", self.state)

    def test_advanced_risk_reports_legacy_timestamp_alignment_limitation(self):
        closes = [100.0 + i * 0.2 for i in range(220)]
        result = self.make_service(lambda symbol: closes if symbol in {"SPY", "ABC"} else []).snapshot()
        self.assertEqual(result["adv"]["risk_data_coverage"]["held_symbols"], 1)
        self.assertEqual(result["adv"]["risk_data_coverage"]["covered_symbols"], 1)
        self.assertEqual(result["adv"]["risk_data_coverage"]["lengths_aligned"], True)
        self.assertEqual(
            result["adv"]["risk_data_coverage"]["timestamp_alignment"],
            "not_verifiable_with_legacy_close_reader")


    def test_timestamped_risk_reader_requires_exact_session_alignment(self):
        stamps = tuple(datetime(2025, 1, 2, tzinfo=timezone.utc) + timedelta(days=i)
                       for i in range(220))
        closes = tuple(100.0 + i * 0.1 for i in range(220))
        def reader(symbol):
            return DailyBars(symbol=symbol, closes=closes, volumes=(1000.0,) * 220,
                             fetched_at=datetime.now(timezone.utc), source="test",
                             timestamps=stamps)
        result = self.make_service(history_reader=reader).snapshot()
        self.assertEqual(
            result["adv"]["risk_data_coverage"]["timestamp_alignment"],
            "verified_exact_session_timestamps")
        self.assertIn("var95_pct", result["adv"])

    def test_timestamped_risk_reader_rejects_one_session_offset(self):
        stamps = tuple(datetime(2025, 1, 2, tzinfo=timezone.utc) + timedelta(days=i)
                       for i in range(220))
        shifted = stamps[:-1] + (stamps[-1] + timedelta(days=1),)
        closes = tuple(100.0 + i * 0.1 for i in range(220))
        def reader(symbol):
            selected = shifted if symbol == "ABC" else stamps
            return DailyBars(symbol=symbol, closes=closes, volumes=(1000.0,) * 220,
                             fetched_at=datetime.now(timezone.utc), source="test",
                             timestamps=selected)
        result = self.make_service(history_reader=reader).snapshot()
        self.assertEqual(result["adv"]["error"], "séances de marché désalignées")
        self.assertEqual(result["adv"]["misaligned_symbols"], ["ABC"])
        self.assertNotIn("var95_pct", result["adv"])
        self.assertNotIn("market_risk", self.state)

    def test_timestamped_risk_reader_rejects_missing_timestamp_series(self):
        stamps = tuple(datetime(2025, 1, 2, tzinfo=timezone.utc) + timedelta(days=i)
                       for i in range(220))
        closes = tuple(100.0 + i * 0.1 for i in range(220))
        def reader(symbol):
            selected = () if symbol == "ABC" else stamps
            return DailyBars(symbol=symbol, closes=closes, volumes=(1000.0,) * 220,
                             fetched_at=datetime.now(timezone.utc), source="test",
                             timestamps=selected)
        result = self.make_service(history_reader=reader).snapshot()
        self.assertEqual(result["adv"]["error"], "historique insuffisant pour toutes les positions")
        self.assertNotIn("var95_pct", result["adv"])


    def test_timestamped_reader_falls_back_explicitly_for_simulated_untimestamped_bars(self):
        closes = [100.0 + ((i % 7) - 3) * 0.35 + i * 0.03 for i in range(240)]
        def history_reader(symbol):
            return DailyBars(symbol=symbol, closes=tuple(closes), volumes=(1000.0,) * 240,
                             fetched_at=datetime.now(timezone.utc), source="sim",
                             timestamps=())
        result = self.make_service(lambda symbol: closes, history_reader).snapshot()
        self.assertIn("var95_pct", result["adv"])
        self.assertEqual(
            result["adv"]["risk_data_coverage"]["timestamp_alignment"],
            "not_available_simulation_or_legacy")
