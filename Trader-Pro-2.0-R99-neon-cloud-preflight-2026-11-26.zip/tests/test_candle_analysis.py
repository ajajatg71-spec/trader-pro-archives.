import unittest
from datetime import datetime, timedelta, timezone

from candle_analysis import CandleAnalysisError, analyze_candles, validate_bars


def bar(o, h, low, c, v=100):
    return {"open": o, "high": h, "low": low, "close": c, "volume": v}


class CandleAnalysisTests(unittest.TestCase):
    def test_bullish_engulfing_detected_by_body_not_range(self):
        result = analyze_candles([bar(10, 10.5, 8.8, 9), bar(8.8, 11.2, 8.5, 10.8)])
        self.assertIn("BULLISH_ENGULFING", [p.name for p in result.patterns])

    def test_inside_bar_and_doji_detected(self):
        result = analyze_candles([bar(10, 12, 9, 11), bar(10.5, 11.5, 9.5, 10.51)])
        names = {p.name for p in result.patterns}
        self.assertIn("INSIDE_BAR", names)
        self.assertIn("DOJI", names)

    def test_hammer_like_requires_long_lower_wick_and_small_upper_wick(self):
        result = analyze_candles([bar(11, 11.5, 10.5, 10.8), bar(10, 10.2, 7, 10.1)])
        self.assertIn("HAMMER_OR_HANGING_MAN", [p.name for p in result.patterns])

    def test_volume_confirmation_compares_with_prior_complete_window(self):
        bars = [bar(10+i*.01, 10.5+i*.01, 9.5+i*.01, 10.2+i*.01, 100) for i in range(20)]
        bars.append(bar(10.4, 11.5, 10.1, 11.4, 150))
        result = analyze_candles(bars)
        self.assertAlmostEqual(result.relative_volume, 1.5)
        self.assertTrue(all(p.volume_confirmed for p in result.patterns))

    def test_atr_and_trend_warmup(self):
        bars = [bar(10+i, 11+i, 9+i, 10.5+i) for i in range(22)]
        result = analyze_candles(bars)
        self.assertEqual(result.trend, "UPTREND")
        self.assertIsNotNone(result.atr_pct)

    def test_rejects_bad_geometry_and_non_finite_values(self):
        with self.assertRaises(CandleAnalysisError):
            validate_bars([bar(10, 9, 8, 9), bar(9, 10, 8, 9)])
        with self.assertRaises(CandleAnalysisError):
            validate_bars([bar(10, 11, 9, 10), bar(10, float("nan"), 9, 10)])

    def test_rejects_mixed_or_non_monotonic_timestamps(self):
        now = datetime.now(timezone.utc)
        a, b = bar(10, 11, 9, 10), bar(10, 11, 9, 10)
        a["timestamp"] = now
        b["timestamp"] = now - timedelta(minutes=1)
        with self.assertRaises(CandleAnalysisError):
            validate_bars([a, b])
        b["timestamp"] = None
        with self.assertRaises(CandleAnalysisError):
            validate_bars([a, b])

    def test_rejects_bool_as_price_or_period(self):
        with self.assertRaises(CandleAnalysisError):
            validate_bars([bar(10, 11, 9, True), bar(10, 11, 9, 10)])
        with self.assertRaises(CandleAnalysisError):
            analyze_candles([bar(10, 11, 9, 10), bar(10, 11, 9, 10)], atr_period=True)

    def test_no_pattern_is_fabricated_when_candle_is_flat(self):
        result = analyze_candles([bar(10, 10, 10, 10), bar(10, 10, 10, 10)])
        self.assertEqual(result.last_direction, "DOJI")
        self.assertEqual(result.close_location_pct, 50.0)


if __name__ == "__main__":
    unittest.main()
