import math
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

from research_v1.adapter import (
    RULE_STRATEGIES, UNIVERSE_STRATEGIES, ResearchInputError,
    catalog_summary, evaluate_rule, evaluate_universe, to_research_bars,
)
from services.market_data import OHLCVDailyBars


def make_bars(symbol="AAPL", n=320, offset=0.0):
    stamps = tuple(datetime(2025, 1, 1, tzinfo=timezone.utc) + timedelta(days=i) for i in range(n))
    closes = tuple(100 + offset + i * 0.08 + math.sin(i / 7) * 2 for i in range(n))
    opens = tuple(c - 0.25 for c in closes)
    highs = tuple(c + 1.0 for c in closes)
    lows = tuple(c - 1.0 for c in closes)
    volumes = tuple(100_000 + (i % 13) * 1_000 for i in range(n))
    return OHLCVDailyBars(symbol, opens, highs, lows, closes, volumes,
                          datetime.now(timezone.utc), source="fixture", timestamps=stamps, adjustment_mode="split")


class ResearchV1AdapterTests(unittest.TestCase):
    def test_catalog_contains_43_rules_and_7_portfolio_strategies(self):
        summary = catalog_summary()
        self.assertEqual(summary["total"], 50)
        self.assertEqual(summary["per_symbol"], 43)
        self.assertEqual(summary["portfolio"], 7)

    def test_requires_real_timestamps(self):
        bars = make_bars()
        untimed = OHLCVDailyBars(bars.symbol, bars.opens, bars.highs, bars.lows,
                                 bars.closes, bars.volumes, bars.fetched_at)
        with self.assertRaisesRegex(ResearchInputError, "horodatage"):
            to_research_bars(untimed)

    def test_rejects_unknown_adjustment_provenance(self):
        bars = make_bars()
        unknown = OHLCVDailyBars(bars.symbol, bars.opens, bars.highs, bars.lows,
                                 bars.closes, bars.volumes, bars.fetched_at,
                                 source="fixture", timestamps=bars.timestamps)
        with self.assertRaisesRegex(ResearchInputError, "ajustement"):
            to_research_bars(unknown)

    def test_rule_requires_same_adjustment_mode_for_benchmark(self):
        bars = make_bars()
        benchmark = make_bars("SPY", offset=4)
        from dataclasses import replace
        benchmark = replace(benchmark, adjustment_mode="raw")
        with self.assertRaisesRegex(ResearchInputError, "benchmark"):
            evaluate_rule("golden_cross", "AAPL", bars, benchmark=benchmark)

    def test_all_43_rule_types_evaluate_without_runtime_errors(self):
        bars = make_bars()
        benchmark = make_bars("SPY", offset=4)
        for kind in sorted(RULE_STRATEGIES):
            result = evaluate_rule(kind, "AAPL", bars, benchmark=benchmark)
            self.assertEqual(result["mode"], "RESEARCH_DRY_RUN", kind)
            self.assertFalse(result["broker_access"], kind)
            self.assertEqual(result["orders_created"], 0, kind)
            self.assertIsInstance(result["intents"], list, kind)

    def test_portfolio_strategy_requires_synchronised_universe(self):
        a, b = make_bars("AAPL"), make_bars("MSFT", offset=5)
        result = evaluate_universe("dual_momentum", {"AAPL": a, "MSFT": b}, equity=100_000)
        self.assertEqual(result["orders_created"], 0)
        self.assertFalse(result["broker_access"])
        with self.assertRaisesRegex(ResearchInputError, "au moins deux"):
            evaluate_universe("dual_momentum", {"AAPL": a}, equity=100_000)

    def test_rebalancing_needs_explicit_targets(self):
        a, b = make_bars("AAPL"), make_bars("MSFT", offset=5)
        with self.assertRaisesRegex(ValueError, "targets requis"):
            evaluate_universe("rebalancing", {"AAPL": a, "MSFT": b}, equity=100_000)


if __name__ == "__main__":
    unittest.main()
