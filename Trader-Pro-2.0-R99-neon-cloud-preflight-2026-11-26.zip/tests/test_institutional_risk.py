import unittest
import time

from services.institutional_risk import InstitutionalRiskEngine, RiskInputError


class InstitutionalRiskTests(unittest.TestCase):
    def setUp(self):
        self.engine = InstitutionalRiskEngine()
        self.state = {"peak": 12_000, "limits": {
            "max_gross": 90, "max_pos": 25, "max_positions": 4,
            "max_order_pct": 20, "min_cash": 10, "risk_per_trade": 1,
        }}
        self.account = {"equity": 10_000, "cash": 4_000}
        self.positions = [{"symbol": "AAPL", "market_value": 2_000},
                          {"symbol": "MSFT", "market_value": 1_000}]

    def test_portfolio_snapshot_reports_exposure_and_drawdown(self):
        result = self.engine.portfolio_snapshot(self.account, self.positions, self.state,
                                                pending_buy_notional=500)
        self.assertEqual(result["status"], "WITHIN_LIMITS")
        self.assertEqual(result["metrics"]["gross_exposure_pct"], 30.0)
        self.assertEqual(result["metrics"]["reserved_gross_exposure_pct"], 35.0)
        self.assertEqual(result["metrics"]["drawdown_pct"], -16.6667)

    def test_portfolio_snapshot_flags_concentration_and_reserved_gross(self):
        result = self.engine.portfolio_snapshot(
            self.account, [{"symbol": "AAPL", "market_value": 8_500}], self.state,
            pending_buy_notional=1_000)
        self.assertEqual(result["status"], "BREACH")
        self.assertIn("Exposition brute maximale dépassée", result["breaches"])
        self.assertIn("Concentration d'une position dépassée", result["breaches"])

    def test_pretrade_counts_reserved_orders_and_respects_cash_buffer(self):
        reason = self.engine.pre_trade_check(
            symbol="NVDA", side="buy", notional=2_000, account=self.account,
            positions=self.positions, state=self.state, reserved_buy_notional=1_500)
        self.assertEqual(reason, "Réserve minimale de liquidités non respectée")

    def test_pretrade_rejects_gross_exposure_breach(self):
        reason = self.engine.pre_trade_check(
            symbol="NVDA", side="buy", notional=6_000, account=self.account,
            positions=self.positions, state=self.state)
        self.assertEqual(reason, "Ordre trop gros selon la limite de risque institutionnelle")

    def test_pretrade_checks_stop_loss_risk_budget_when_stop_is_supplied(self):
        reason = self.engine.pre_trade_check(
            symbol="NVDA", side="buy", notional=2_000, account=self.account,
            positions=self.positions, state=self.state, entry_price=100, stop_price=90)
        self.assertEqual(reason, "Budget de risque par transaction dépassé")

    def test_position_sizing_is_capped_by_risk_and_concentration(self):
        self.assertEqual(self.engine.position_size(
            equity=10_000, entry_price=100, stop_price=95,
            risk_pct=1, max_position_pct=25), 2_000.0)

    def test_position_sizing_rejects_invalid_stop(self):
        with self.assertRaises(RiskInputError):
            self.engine.position_size(equity=10_000, entry_price=100, stop_price=100,
                                      risk_pct=1, max_position_pct=25)

    def test_boolean_financial_inputs_are_rejected(self):
        result = self.engine.pre_trade_check(
            symbol="NVDA", side="buy", notional=True, account=self.account,
            positions=self.positions, state=self.state)
        self.assertEqual(result, "Contrôle de risque impossible : données financières invalides")

    def test_sector_and_issuer_exposure_are_aggregated(self):
        state = {**self.state, "limits": {**self.state["limits"],
                  "max_sector_pct": 25, "max_issuer_pct": 25},
                 "risk_metadata": {
                     "AAPL": {"sector": "Technology", "issuer": "Apple"},
                     "MSFT": {"sector": "Technology", "issuer": "Microsoft"},
                 }}
        result = self.engine.portfolio_snapshot(self.account, self.positions, state)
        self.assertEqual(result["status"], "BREACH")
        self.assertIn("Limite de concentration sectorielle dépassée", result["breaches"])
        self.assertEqual(result["metrics"]["sector_exposure_pct"]["technology"], 30.0)

    def test_sector_cap_blocks_order_without_trusted_classification(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_sector_pct": 40},
                 "risk_metadata": {"AAPL": {"sector": "Technology"},
                                   "MSFT": {"sector": "Technology"}}}
        reason = self.engine.pre_trade_check(
            symbol="NVDA", side="buy", notional=500, account=self.account,
            positions=self.positions, state=state)
        self.assertEqual(reason, "Classification sectorielle manquante : ordre bloqué")

    def test_sector_cap_blocks_order_that_would_concentrate_sector(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_sector_pct": 35},
                 "risk_metadata": {"AAPL": {"sector": "Technology"},
                                   "MSFT": {"sector": "Technology"},
                                   "NVDA": {"sector": "Technology"}}}
        reason = self.engine.pre_trade_check(
            symbol="NVDA", side="buy", notional=600, account=self.account,
            positions=self.positions, state=state)
        self.assertEqual(reason, "Limite de concentration sectorielle dépassée")

    def test_var_and_cvar_thresholds_fail_closed_when_metrics_missing(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_var95_pct": 2.0}}
        result = self.engine.portfolio_snapshot(self.account, self.positions, state)
        self.assertEqual(result["status"], "BREACH")
        self.assertIn("Mesure VaR 95 % indisponible : contrôle bloqué", result["breaches"])

    def test_var_and_cvar_thresholds_detect_breach(self):
        state = {**self.state, "limits": {**self.state["limits"],
                  "max_var95_pct": 2.0, "max_cvar95_pct": 3.0}}
        result = self.engine.portfolio_snapshot(
            self.account, self.positions, state,
            market_risk={"var95_pct": 2.5, "cvar95_pct": 4.0})
        self.assertIn("Limite VaR 95 % dépassée", result["breaches"])
        self.assertIn("Limite CVaR 95 % dépassée", result["breaches"])

    def test_market_risk_metrics_reject_boolean_values(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_var95_pct": 2.0}}
        result = self.engine.portfolio_snapshot(
            self.account, self.positions, state, market_risk={"var95_pct": True})
        self.assertEqual(result["status"], "BREACH")
        self.assertIn("Mesure VaR 95 % invalide : contrôle bloqué", result["breaches"])

    def test_var_gate_blocks_stale_snapshot(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_var95_pct": 2.0},
                 "market_risk": {"var95_pct": 1.0, "as_of": 1.0}}
        reason = self.engine.pre_trade_check(
            symbol="NVDA", side="buy", notional=500, account=self.account,
            positions=self.positions, state=state)
        self.assertEqual(reason, "Mesure VaR 95 % périmée : ordre bloqué")

    def test_var_gate_accepts_fresh_snapshot_within_limit(self):
        import time
        state = {**self.state, "limits": {**self.state["limits"], "max_var95_pct": 2.0},
                 "market_risk": {"var95_pct": 1.0, "as_of": time.time()}}
        reason = self.engine.pre_trade_check(
            symbol="NVDA", side="buy", notional=500, account=self.account,
            positions=self.positions, state=state)
        self.assertIsNone(reason)


    def test_correlation_limit_flags_concentrated_portfolio(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_avg_correlation": 0.65}}
        result = self.engine.portfolio_snapshot(
            self.account, self.positions, state, market_risk={"avg_corr": 0.82})
        self.assertIn("Limite de corrélation moyenne dépassée", result["breaches"])

    def test_effective_diversification_floor_is_enforced(self):
        state = {**self.state, "limits": {**self.state["limits"], "min_effective_n": 2.0}}
        result = self.engine.portfolio_snapshot(
            self.account, self.positions, state, market_risk={"eff_n": 1.4})
        self.assertIn("Diversification effective insuffisante", result["breaches"])

    def test_factor_exposure_is_weighted_and_capped(self):
        state = {**self.state, "limits": {**self.state["limits"],
                 "max_factor_exposure": {"market": 0.35}},
                 "risk_metadata": {
                     "AAPL": {"factor_loadings": {"market": 1.2}},
                     "MSFT": {"factor_loadings": {"market": 0.8}},
                 }}
        result = self.engine.portfolio_snapshot(self.account, self.positions, state)
        self.assertAlmostEqual(result["metrics"]["factor_exposure"]["market"], 0.32)
        self.assertEqual(result["status"], "WITHIN_LIMITS")

    def test_factor_exposure_limit_blocks_order(self):
        state = {**self.state, "limits": {**self.state["limits"],
                 "max_factor_exposure": {"market": 0.35}},
                 "risk_metadata": {
                     "AAPL": {"factor_loadings": {"market": 1.2}},
                     "MSFT": {"factor_loadings": {"market": 0.8}},
                     "NVDA": {"factor_loadings": {"market": 1.5}},
                 }}
        reason = self.engine.pre_trade_check(
            symbol="NVDA", side="buy", notional=500, account=self.account,
            positions=self.positions, state=state)
        self.assertEqual(reason, "Limite d'exposition au facteur market dépassée")

    def test_factor_exposure_fails_closed_when_loadings_missing(self):
        state = {**self.state, "limits": {**self.state["limits"],
                 "max_factor_exposure": {"market": 0.5}}}
        result = self.engine.portfolio_snapshot(self.account, self.positions, state)
        self.assertEqual(result["status"], "BREACH")
        self.assertTrue(any("Expositions factorielles manquantes" in item for item in result["breaches"]))

    def test_correlation_gate_requires_fresh_market_snapshot(self):
        import time
        state = {**self.state, "limits": {**self.state["limits"], "max_avg_correlation": 0.8},
                 "market_risk": {"avg_corr": 0.4, "as_of": time.time() - 3600}}
        reason = self.engine.pre_trade_check(
            symbol="NVDA", side="buy", notional=500, account=self.account,
            positions=self.positions, state=state)
        self.assertEqual(reason, "Mesure corrélation périmée : ordre bloqué")

    def test_liquidity_participation_limit_uses_trusted_adv(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_participation_pct": 1.0},
                 "risk_metadata": {"NVDA": {"avg_daily_dollar_volume": 100_000, "source": "test-feed", "as_of": time.time()}}}
        reason = self.engine.pre_trade_check(symbol="NVDA", side="buy", notional=2_000,
            account=self.account, positions=self.positions, state=state)
        self.assertEqual(reason, "Participation au volume quotidien maximale dépassée")

    def test_liquidity_participation_fails_closed_without_adv(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_participation_pct": 1.0},
                 "risk_metadata": {"NVDA": {"source": "test-feed", "as_of": time.time()}}}
        reason = self.engine.pre_trade_check(symbol="NVDA", side="buy", notional=100,
            account=self.account, positions=self.positions, state=state)
        self.assertEqual(reason, "Liquidité indisponible ou invalide : ordre bloqué")

    def test_spread_limit_rejects_wide_market(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_spread_pct": 0.2},
                 "risk_metadata": {"NVDA": {"bid": 99.0, "ask": 101.0, "source": "test-feed", "as_of": time.time()}}}
        reason = self.engine.pre_trade_check(symbol="NVDA", side="buy", notional=100,
            account=self.account, positions=self.positions, state=state)
        self.assertEqual(reason, "Spread maximal autorisé dépassé")

    def test_market_impact_limit_uses_square_root_screening_estimate(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_estimated_impact_pct": 0.1},
                 "risk_metadata": {"NVDA": {"avg_daily_dollar_volume": 100_000,
                                               "impact_coefficient": 0.5, "source": "test-feed", "as_of": time.time()}}}
        reason = self.engine.pre_trade_check(symbol="NVDA", side="buy", notional=1_000,
            account=self.account, positions=self.positions, state=state)
        self.assertEqual(reason, "Impact de marché estimé maximal dépassé")

    def test_liquidity_controls_reject_invalid_quote(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_spread_pct": 0.5},
                 "risk_metadata": {"NVDA": {"bid": 101.0, "ask": 99.0, "source": "test-feed", "as_of": time.time()}}}
        reason = self.engine.pre_trade_check(symbol="NVDA", side="buy", notional=100,
            account=self.account, positions=self.positions, state=state)
        self.assertEqual(reason, "Spread indisponible ou invalide : ordre bloqué")

    def test_liquidity_controls_reject_stale_snapshot(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_participation_pct": 5.0},
                 "risk_metadata": {"NVDA": {"avg_daily_dollar_volume": 100_000, "source": "test-feed",
                                               "as_of": time.time() - 600}}}
        reason = self.engine.pre_trade_check(symbol="NVDA", side="buy", notional=100,
            account=self.account, positions=self.positions, state=state)
        self.assertEqual(reason, "Données de liquidité périmées : ordre bloqué")

    def test_liquidity_controls_reject_missing_timestamp(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_spread_pct": 0.5},
                 "risk_metadata": {"NVDA": {"bid": 99.0, "ask": 100.0, "source": "test-feed"}}}
        reason = self.engine.pre_trade_check(symbol="NVDA", side="buy", notional=100,
            account=self.account, positions=self.positions, state=state)
        self.assertEqual(reason, "Horodatage de liquidité absent ou invalide : ordre bloqué")

    def test_sell_side_remains_under_existing_quantity_checker(self):
        self.assertIsNone(self.engine.pre_trade_check(
            symbol="AAPL", side="sell", notional=100, account=self.account,
            positions=self.positions, state=self.state))


    def test_liquidity_controls_reject_missing_provider_provenance(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_spread_pct": 0.5},
                 "risk_metadata": {"NVDA": {"bid": 99.0, "ask": 100.0, "as_of": time.time()}}}
        reason = self.engine.pre_trade_check(symbol="NVDA", side="buy", notional=100,
            account=self.account, positions=[], state=state)
        self.assertIn("Provenance", reason)


    def test_portfolio_snapshot_enforces_minimum_cash_reserve(self):
        state = {**self.state, "limits": {**self.state["limits"], "min_cash": 45}}
        result = self.engine.portfolio_snapshot(self.account, self.positions, state)
        self.assertEqual(result["status"], "BREACH")
        self.assertIn("Réserve minimale de liquidités non respectée", result["breaches"])

    def test_sector_and_issuer_hhi_are_reported_and_limited(self):
        state = {**self.state, "limits": {**self.state["limits"],
                  "max_sector_hhi": 0.80, "max_issuer_hhi": 0.80},
                 "risk_metadata": {
                     "AAPL": {"sector": "Technology", "issuer": "Apple"},
                     "MSFT": {"sector": "Technology", "issuer": "Microsoft"},
                 }}
        result = self.engine.portfolio_snapshot(self.account, self.positions, state)
        self.assertAlmostEqual(result["metrics"]["sector_exposure_hhi"], 1.0)
        self.assertAlmostEqual(result["metrics"]["issuer_exposure_hhi"], 5 / 9, places=5)
        self.assertEqual(result["metrics"]["sector_classification_coverage_pct"], 100.0)
        self.assertIn("Indice HHI de concentration sectorielle dépassé", result["breaches"])
        self.assertNotIn("Indice HHI de concentration par émetteur dépassé", result["breaches"])

    def test_hhi_gate_fails_closed_when_classification_is_missing(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_sector_hhi": 0.8},
                 "risk_metadata": {"AAPL": {"sector": "Technology"}}}
        result = self.engine.portfolio_snapshot(self.account, self.positions, state)
        self.assertIn("Classification sectorielle incomplète : contrôle HHI bloqué", result["breaches"])

    def test_pretrade_hhi_checks_projected_sector_concentration(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_sector_hhi": 0.70},
                 "risk_metadata": {
                     "AAPL": {"sector": "Technology"},
                     "MSFT": {"sector": "Technology"},
                     "NVDA": {"sector": "Utilities"},
                 }}
        reason = self.engine.pre_trade_check(
            symbol="NVDA", side="buy", notional=500, account=self.account,
            positions=self.positions, state=state)
        self.assertEqual(reason, "Indice HHI de concentration sectorielle dépassé")

    def test_market_risk_breaches_are_not_duplicated(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_var95_pct": 2.0}}
        result = self.engine.portfolio_snapshot(
            self.account, self.positions, state, market_risk={"var95_pct": 2.5})
        self.assertEqual(result["breaches"].count("Limite VaR 95 % dépassée"), 1)

    def test_hhi_limit_above_one_is_rejected(self):
        state = {**self.state, "limits": {**self.state["limits"], "max_sector_hhi": 1.2},
                 "risk_metadata": {"AAPL": {"sector": "Technology"},
                                   "MSFT": {"sector": "Software"}}}
        with self.assertRaises(RiskInputError):
            self.engine.portfolio_snapshot(self.account, self.positions, state)


if __name__ == "__main__":
    unittest.main()
