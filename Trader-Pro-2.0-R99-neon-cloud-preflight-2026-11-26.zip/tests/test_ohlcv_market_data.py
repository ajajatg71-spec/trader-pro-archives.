import unittest
from datetime import datetime, timedelta, timezone

from services.market_data import (MarketDataError, MarketDataService, OHLCVDailyBars,
                                   inspect_ohlcv_daily_bar_coverage)


class OHLCVMarketDataTests(unittest.TestCase):
    def setUp(self):
        self.stamps = [datetime(2026, 1, 5, tzinfo=timezone.utc) + timedelta(days=i) for i in range(3)]
        self.payload = (
            self.stamps,
            [10.0, 11.0, 12.0],
            [12.0, 13.0, 14.0],
            [9.0, 10.5, 11.5],
            [11.0, 12.0, 13.5],
            [100.0, 110.0, 120.0],
        )

    def service(self, payload=None, **kwargs):
        return MarketDataService(lambda s, n: ([10, 11], [1, 2]),
                                 ohlcv_reader=lambda s, n: self.payload if payload is None else payload,
                                 **kwargs)

    def test_returns_full_ohlcv_and_utc_timestamps(self):
        result = self.service().daily_ohlcv("aapl")
        self.assertIsInstance(result, OHLCVDailyBars)
        self.assertEqual(result.symbol, "AAPL")
        self.assertEqual(result.opens, (10.0, 11.0, 12.0))
        self.assertEqual(result.highs, (12.0, 13.0, 14.0))
        self.assertEqual(result.lows, (9.0, 10.5, 11.5))
        self.assertEqual(result.closes, (11.0, 12.0, 13.5))
        self.assertEqual(result.volumes, (100.0, 110.0, 120.0))
        self.assertEqual(result.count, 3)
        self.assertTrue(all(stamp.utcoffset() == timedelta(0) for stamp in result.timestamps))

    def test_legacy_reader_remains_unchanged(self):
        service = self.service()
        legacy = service.daily_bars("AAPL")
        self.assertEqual(legacy.closes, (10.0, 11.0))
        self.assertEqual(legacy.volumes, (1.0, 2.0))

    def test_ohlcv_reader_is_explicitly_required(self):
        service = MarketDataService(lambda s, n: ([10, 11], [1, 2]))
        with self.assertRaisesRegex(MarketDataError, "non configuré"):
            service.daily_ohlcv("AAPL")

    def test_rejects_bad_geometry(self):
        bad = (self.stamps, [10, 11, 12], [12, 13, 14], [9, 10.5, 11.5],
               [13, 12, 13.5], [100, 110, 120])
        with self.assertRaisesRegex(MarketDataError, "Géométrie"):
            self.service(bad).daily_ohlcv("AAPL")

    def test_rejects_non_finite_values(self):
        bad = (self.stamps, [10, 11, float("nan")], [12, 13, 14],
               [9, 10.5, 11.5], [11, 12, 13.5], [100, 110, 120])
        with self.assertRaisesRegex(MarketDataError, "non finie"):
            self.service(bad).daily_ohlcv("AAPL")

    def test_rejects_misaligned_series(self):
        bad = (self.stamps, [10, 11], [12, 13, 14], [9, 10.5, 11.5],
               [11, 12, 13.5], [100, 110, 120])
        with self.assertRaisesRegex(MarketDataError, "désalignées"):
            self.service(bad).daily_ohlcv("AAPL")

    def test_rejects_naive_or_duplicate_timestamps(self):
        naive = ([datetime(2026, 1, 5), *self.stamps[1:]], *self.payload[1:])
        with self.assertRaisesRegex(MarketDataError, "sans fuseau"):
            self.service(naive).daily_ohlcv("AAPL")
        duplicate = ([self.stamps[0], self.stamps[0], self.stamps[2]], *self.payload[1:])
        with self.assertRaisesRegex(MarketDataError, "strictement croissants"):
            self.service(duplicate).daily_ohlcv("AAPL")

    def test_cache_and_invalidation(self):
        calls = []
        service = MarketDataService(lambda s, n: ([10, 11], [1, 2]),
                                    ohlcv_reader=lambda s, n: (calls.append(1) or self.payload))
        first = service.daily_ohlcv("AAPL")
        self.assertIs(first, service.daily_ohlcv("AAPL"))
        self.assertEqual(len(calls), 1)
        service.invalidate("AAPL")
        service.daily_ohlcv("AAPL")
        self.assertEqual(len(calls), 2)

    def test_global_invalidation_clears_ohlcv_cache(self):
        calls = []
        service = MarketDataService(lambda s, n: ([10, 11], [1, 2]),
                                    ohlcv_reader=lambda s, n: (calls.append(1) or self.payload))
        service.daily_ohlcv("AAPL")
        service.invalidate()
        service.daily_ohlcv("AAPL")
        self.assertEqual(len(calls), 2)

    def test_ohlcv_coverage_reports_missing_exchange_sessions(self):
        stamps = [datetime(2026, 1, 5, 16, tzinfo=timezone.utc),
                  datetime(2026, 1, 7, 16, tzinfo=timezone.utc)]
        payload = (stamps, [10, 12], [12, 14], [9, 11], [11, 13], [100, 120])
        bars = self.service(payload).daily_ohlcv("AAPL")
        report = inspect_ohlcv_daily_bar_coverage(bars, calendar_name="XNYS")
        self.assertEqual(report.expected_sessions, 3)
        self.assertEqual(report.observed_sessions, 2)
        self.assertEqual(report.missing_sessions, ("2026-01-06",))
        self.assertFalse(report.complete)

    def test_ohlcv_coverage_can_fail_closed_on_gaps(self):
        stamps = [datetime(2026, 1, 5, 16, tzinfo=timezone.utc),
                  datetime(2026, 1, 7, 16, tzinfo=timezone.utc)]
        payload = (stamps, [10, 12], [12, 14], [9, 11], [11, 13], [100, 120])
        bars = self.service(payload).daily_ohlcv("AAPL")
        with self.assertRaisesRegex(MarketDataError, r"séance\(s\) manquante\(s\)"):
            inspect_ohlcv_daily_bar_coverage(
                bars, calendar_name="XNYS", max_missing_sessions=0
            )

    def test_ohlcv_coverage_requires_timestamps(self):
        payload = ([10, 11], [12, 13], [9, 10], [11, 12], [100, 110])
        bars = self.service(payload).daily_ohlcv("AAPL")
        with self.assertRaisesRegex(MarketDataError, "sans horodatages"):
            inspect_ohlcv_daily_bar_coverage(bars)

    def test_rejects_bool_limit(self):
        with self.assertRaises(MarketDataError):
            self.service().daily_ohlcv("AAPL", True)


if __name__ == "__main__":
    unittest.main()
