from unittest.mock import patch
import unittest


class AlpacaLimitOrderTests(unittest.TestCase):
    def setUp(self):
        import broker
        self.broker = broker

    def test_limit_order_sends_day_limit_and_stable_client_id(self):
        expected = {"id": "broker-1", "client_order_id": "cid-1"}
        with patch("broker._r", return_value=expected) as request:
            result = self.broker.limit_order("spy", "buy", "1", "1.00", "cid-1")
        self.assertEqual(result, expected)
        args, kwargs = request.call_args
        self.assertEqual(args, ("POST", "/v2/orders"))
        self.assertEqual(kwargs["json"], {
            "symbol": "SPY", "side": "buy", "type": "limit", "time_in_force": "day",
            "qty": "1", "limit_price": "1", "client_order_id": "cid-1",
        })

    def test_duplicate_client_id_returns_same_matching_order(self):
        from broker import BrokerError
        existing = {"id": "broker-1", "client_order_id": "cid-1", "symbol": "SPY",
                    "side": "buy", "type": "limit", "time_in_force": "day",
                    "qty": "1", "limit_price": "1.00"}
        with patch("broker._r", side_effect=[BrokerError("duplicate", 422), existing]) as request:
            result = self.broker.limit_order("SPY", "buy", 1, 1, "cid-1")
        self.assertEqual(result, existing)
        self.assertEqual(request.call_count, 2)

    def test_duplicate_client_id_with_different_payload_is_rejected(self):
        from broker import BrokerError
        existing = {"id": "broker-1", "symbol": "SPY", "side": "buy", "type": "limit",
                    "time_in_force": "day", "qty": "2", "limit_price": "1.00"}
        with patch("broker._r", side_effect=[BrokerError("duplicate", 422), existing]):
            with self.assertRaises(BrokerError) as caught:
                self.broker.limit_order("SPY", "buy", 1, 1, "cid-1")
        self.assertEqual(caught.exception.status, 409)

    def test_invalid_values_are_rejected_before_network(self):
        with patch("broker._r") as request:
            for qty, price in [(0, 1), (1, 0), ("NaN", 1), (1, "Infinity"),
                               ("1.0000000001", 10), (1, "10.001")]:
                with self.assertRaises(self.broker.BrokerError):
                    self.broker.limit_order("SPY", "buy", qty, price, "cid-1")
            request.assert_not_called()

    def test_cancel_and_confirm_requires_canceled_zero_fill(self):
        from scripts import verify_alpaca_paper_orders as smoke
        with patch.object(smoke, "cancel") as cancel_order, \
             patch.object(smoke, "order_get", return_value={"status": "canceled", "filled_qty": "0"}):
            result = smoke.cancel_and_confirm("order-1", attempts=1)
        cancel_order.assert_called_once_with("order-1")
        self.assertEqual(result["status"], "canceled")

    def test_cancel_and_confirm_rejects_partial_fill(self):
        from scripts import verify_alpaca_paper_orders as smoke
        with patch.object(smoke, "cancel"), \
             patch.object(smoke, "order_get", return_value={"status": "canceled", "filled_qty": "0.25"}):
            with self.assertRaisesRegex(RuntimeError, "quantité exécutée"):
                smoke.cancel_and_confirm("order-1", attempts=1)

    def test_cancel_and_confirm_rejects_filled_terminal_state(self):
        from scripts import verify_alpaca_paper_orders as smoke
        with patch.object(smoke, "cancel"), \
             patch.object(smoke, "order_get", return_value={"status": "filled", "filled_qty": "1"}):
            with self.assertRaisesRegex(RuntimeError, "Annulation non confirmée"):
                smoke.cancel_and_confirm("order-1", attempts=1)

    def test_paper_test_script_requires_explicit_opt_in(self):
        import os
        from pathlib import Path
        import subprocess
        import sys
        env = os.environ.copy()
        env.pop("TRADER_PRO_ENABLE_PAPER_ORDER_TEST", None)
        env["BROKER"] = "alpaca"
        env["ALPACA_BASE_URL"] = "https://paper-api.alpaca.markets"
        result = subprocess.run([sys.executable, str(Path(__file__).parents[1] / "scripts" / "verify_alpaca_paper_orders.py")],
                                env=env, capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 2)
        self.assertIn("REFUS", result.stderr)


if __name__ == "__main__":
    unittest.main()
