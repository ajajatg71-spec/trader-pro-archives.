import unittest
from fastapi import HTTPException
from routers.portfolio import create_portfolio_router


def allow_request():
    return None


class PortfolioRouterTests(unittest.TestCase):
    def setUp(self):
        self.calls = []
        self.router = create_portfolio_router(
            allow_request,
            lambda: {"realized": 12.5},
            lambda: [{"sold": "2026-01-02", "pnl": 12.5}],
            self.tax,
        )
        self.endpoints = {r.path: r.endpoint for r in self.router.routes}

    def tax(self, realized, year, rate, carry):
        self.calls.append((realized, year, rate, carry))
        return {"year": year, "rate": rate, "carry": carry}

    def test_performance_delegates_to_service(self):
        self.assertEqual(self.endpoints["/api/performance"](), {"realized": 12.5})

    def test_tax_uses_defaults_and_injected_services(self):
        result = self.endpoints["/api/tax"](year=2026)
        self.assertEqual(result, {"year": 2026, "rate": 31.4, "carry": 0.0})
        self.assertEqual(self.calls[0][1:], (2026, 31.4, 0.0))

    def test_tax_rejects_invalid_year(self):
        with self.assertRaises(HTTPException) as ctx:
            self.endpoints["/api/tax"](year=1999)
        self.assertEqual(ctx.exception.status_code, 400)

    def test_tax_rejects_negative_carry(self):
        with self.assertRaises(HTTPException):
            self.endpoints["/api/tax"](year=2026, carry=-1)

    def test_tax_rejects_rate_out_of_range(self):
        with self.assertRaises(HTTPException):
            self.endpoints["/api/tax"](year=2026, rate=101)


if __name__ == "__main__":
    unittest.main()
