from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_windows_postgres_verification_uses_full_read_only_restore_comparator():
    for name in ("scripts/verify_postgres.ps1", "scripts/run_postgres_full_validation.ps1"):
        source = (ROOT / name).read_text(encoding="utf-8")
        assert "scripts/verify_postgres_restore.py" in source
        assert "base restaurée ne correspond pas" in source
        assert "information_schema.tables WHERE table_schema='public' AND table_name IN" not in source


def test_restore_comparator_checks_every_public_table_row_count_and_alembic_revision():
    source = (ROOT / "scripts/verify_postgres_restore.py").read_text(encoding="utf-8")
    assert 'inspector.get_table_names(schema="public")' in source
    assert "SELECT count(*) FROM public." in source
    assert "alembic_version" in source
    assert "source_tables != restored_tables" in source
    assert "source_counts[table] != restored_counts[table]" in source
    assert "source_versions != restored_versions" in source



def test_linux_postgres_validation_rejects_skipped_or_empty_integration_suite():
    source = (ROOT / "scripts/verify_postgres.sh").read_text(encoding="utf-8")
    assert "pytest -q -rs tests/test_postgres_integration.py" in source
    assert "[0-9]+ skipped" in source
    assert "[0-9]+ passed" in source
    assert "validation réelle incomplète" in source
