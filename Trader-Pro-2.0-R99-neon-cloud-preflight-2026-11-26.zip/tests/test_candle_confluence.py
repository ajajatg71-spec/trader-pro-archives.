import math
import unittest
from types import SimpleNamespace
from research_v1.validation.candle_confluence import evaluate_candle_confluence, evaluate_multi_asset_regimes, _purged_segment, _holm_adjust, _non_overlapping_append, _paired_block_inference


def bars(n=180):
    out=[]
    for i in range(n):
        c=100+0.08*i+2*math.sin(i/4)
        o=c-0.25
        out.append(SimpleNamespace(o=o,h=c+0.8,l=o-0.8,c=c,v=100000+(i%7)*1000))
    return out

class CandleConfluenceTests(unittest.TestCase):
    def test_purged_split_excludes_boundary_and_embargo(self):
        self.assertEqual(_purged_segment(60, 70, 5), "development")
        self.assertIsNone(_purged_segment(65, 70, 5))
        self.assertIsNone(_purged_segment(74, 70, 5))
        self.assertEqual(_purged_segment(75, 70, 5), "holdout")
    def test_returns_read_only_policy_comparison(self):
        result=evaluate_candle_confluence(bars(),horizons=(1,3),min_observations=1)
        self.assertEqual(result['status'],'DESCRIPTIVE_RESEARCH_ONLY')
        self.assertIn('candle_rsi_macd',result['policies'])
        self.assertEqual(result['costs']['round_trip_total_bps'],20.0)
        self.assertEqual(result['purge_embargo_bars'], 3)
        self.assertEqual(result['split_policy'], 'development_exit_before_split_holdout_after_embargo')
        self.assertFalse(result['automatic_strategy_activation'])
        self.assertEqual(result['orders_created'],0)
        self.assertEqual(result['lookahead_policy'],'features_at_signal_close_enter_next_open_exit_at_horizon_close')
    def test_rejects_short_history_and_invalid_horizon(self):
        with self.assertRaisesRegex(ValueError,'60 barres'):
            evaluate_candle_confluence(bars(50))
        with self.assertRaisesRegex(ValueError,'horizons'):
            evaluate_candle_confluence(bars(),horizons=(0,))
    def test_multi_asset_regime_panel_is_read_only(self):
        result=evaluate_multi_asset_regimes({'AAA': bars(260), 'BBB': bars(260)}, horizons=(1,), min_observations=1)
        self.assertEqual(result['assets'], ['AAA', 'BBB'])
        self.assertIn('regime_results', result)
        self.assertIn('inference_scope', result)
        self.assertFalse(result['inference_scope']['cross_run_family_correction'])
        for row in result['regime_results']:
            self.assertIn('paired_candle_only_comparison', row)
            self.assertIn('matched_events', row['paired_candle_only_comparison'])
        self.assertFalse(result['automatic_strategy_activation'])
        self.assertEqual(result['orders_created'], 0)
    def test_multi_asset_rejects_empty_mapping(self):
        with self.assertRaisesRegex(ValueError, 'mapping non vide'):
            evaluate_multi_asset_regimes({})
    def test_holm_adjustment_is_monotonic_and_conservative(self):
        adjusted = _holm_adjust({"a": 0.001, "b": 0.02, "c": 0.04})
        self.assertAlmostEqual(adjusted["a"], 0.003)
        self.assertAlmostEqual(adjusted["b"], 0.04)
        self.assertAlmostEqual(adjusted["c"], 0.04)
    def test_overlapping_outcome_windows_are_deduplicated(self):
        stats = {}
        last_exit = {}
        key = ("hammer", 3, "candle_only")
        self.assertTrue(_non_overlapping_append(stats, last_exit, key, "holdout", 100, 103, 0.01))
        self.assertFalse(_non_overlapping_append(stats, last_exit, key, "holdout", 102, 105, -0.02))
        self.assertTrue(_non_overlapping_append(stats, last_exit, key, "holdout", 104, 107, 0.03))
        self.assertEqual(stats[key]["holdout"], [0.01, 0.03])
    def test_paired_block_inference_is_reproducible_and_adjustable(self):
        deltas = [0.002, 0.003, -0.001, 0.004, 0.002, 0.001, 0.003, -0.001, 0.002, 0.004]
        first = _paired_block_inference(deltas, 3, repetitions=300, seed=123)
        second = _paired_block_inference(deltas, 3, repetitions=300, seed=123)
        self.assertEqual(first, second)
        self.assertEqual(first['matched_events'], 10)
        self.assertIsNotNone(first['ci_95_lower_pct'])
        self.assertIsNotNone(first['p_value_raw'])
        self.assertEqual(first['inference_status'], 'EXPLORATORY_BLOCKED_INFERENCE')

    def test_paired_block_inference_rejects_tiny_samples_for_inference(self):
        result = _paired_block_inference([0.01, -0.01, 0.02, 0.0], 2)
        self.assertIsNone(result['p_value_raw'])
        self.assertEqual(result['inference_status'], 'INSUFFICIENT_PAIRED_EVENTS')

    def test_rejects_bad_ohlcv(self):
        data=bars(); data[80]=SimpleNamespace(o=10,h=9,l=8,c=10,v=1)
        with self.assertRaisesRegex(ValueError,'OHLCV invalide'):
            evaluate_candle_confluence(data)

if __name__=='__main__': unittest.main()
