"""End-to-end Phase 6 -> manual approval -> Paper broker -> reconciliation.

Uses the deterministic local simulator and SQLite. It does NOT claim Alpaca Paper
or PostgreSQL server validation; those remain opt-in external checks.
"""
from __future__ import annotations

import tempfile
import threading
import unittest
from unittest.mock import Mock
from pathlib import Path

from sqlalchemy import create_engine, select, func

import core
import sim_broker
from db.base import Base
from db.models import FillRecord, StrategyProposalRecord, RiskControlStateRecord, SystemSafetyStateRecord
from db.order_repository import OrderRepository
from db.session import build_session_factory
from services.orders import OrderService, OrderServiceError
from services.reconciliation import ReconciliationService
from services.strategy_engine import (
    BreakoutStrategy, MeanReversionStrategy, MomentumStrategy,
    StrategyExecutionPipeline, StrategyManager, TrendFollowingStrategy,
)
from services.strategy_engine.persistence import StrategyPersistence


class Phase6PaperIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.engine = create_engine(f"sqlite:///{Path(self.tmp.name) / 'phase6.db'}")
        Base.metadata.create_all(self.engine)
        self.sessions = build_session_factory(self.engine)
        # Production migrations seed the singleton operational pause row.
        # Mirror that schema invariant in this create_all-based integration test.
        with self.sessions.begin() as session:
            session.add(RiskControlStateRecord(id=1, paused=False, reason=None, actor="system"))
            session.add(SystemSafetyStateRecord(id=1, status="READY", reason=None, actor="test", generation=1))
        self.order_repo = OrderRepository(self.sessions)
        self.strategy_repo = StrategyPersistence(self.sessions)
        sim_broker.S.clear()
        sim_broker.S.update(cash=10_000.0, pos={}, orders=[], fills=[], cids={}, day="", day_eq=10_000.0)
        self.state = {
            "paused": False, "blocked": [], "pending": {}, "peak": 10_000.0,
            "week": {"eq": 10_000.0}, "strategy": {"enabled": True},
            "limits": {
                "max_order": 1_500.0, "max_order_pct": 25.0, "max_positions": 12,
                "max_gross": 90.0, "max_daily_loss": 3.0, "max_pos": 25.0,
                "min_cash": 10.0, "max_orders_day": 20, "max_drawdown": 10.0,
                "max_weekly_loss": 6.0,
            },
        }
        self.lock = threading.RLock()
        self.events = []
        manager = StrategyManager()
        for strategy in (MomentumStrategy(), TrendFollowingStrategy(),
                         MeanReversionStrategy(), BreakoutStrategy()):
            manager.register(strategy)
            manager.activate(strategy.get_metadata().strategy_id)
        self.pipeline = StrategyExecutionPipeline(
            manager=manager, state=self.state, lock=self.lock,
            save=lambda: None,
            history=lambda *args, **kwargs: self.events.append((args, kwargs)),
            account_reader=sim_broker.account,
            positions_reader=sim_broker.positions,
            bars_reader=lambda symbol: [100.0 + i for i in range(250 if symbol == "SPY" else 80)],
            orders_today_reader=lambda: 0, paper_mode=True,
            persistence=self.strategy_repo,
            system_safety_reader=self.order_repo.get_system_safety_state,
        )

    def tearDown(self):
        self.engine.dispose()
        self.tmp.cleanup()

    def _order_service(self, *, account_reader=None):
        return OrderService(
            state=self.state, lock=self.lock, save=lambda: None,
            history=lambda *args, **kwargs: self.events.append((args, kwargs)),
            account_reader=account_reader or sim_broker.account,
            positions_reader=sim_broker.positions,
            orders_reader=sim_broker.orders,
            order_submitter=sim_broker.order,
            order_canceller=sim_broker.cancel,
            daily_loss=lambda _account: 0.0,
            order_checker=core.check,
            orders_today_reader=lambda: 0,
            status_writer=lambda oid, status, **kw: self.strategy_repo.update_status(
                oid, status, reason=kw.get("reason"), broker_order_id=kw.get("broker_order_id")),
            order_persistence=self.order_repo,
            system_safety_reader=self.order_repo.get_system_safety_state,
            instrument_reader=lambda symbol: {"symbol": str(symbol).upper(), "asset_class": "us_equity", "active": True, "tradable": True},
        )

    def test_strategy_pipeline_reads_durable_pause_before_generating_signals(self):
        self.pipeline.operational_pause_reader = lambda: {
            "paused": True, "reason": "Pause déclenchée par un autre worker"
        }
        with self.assertRaises(Exception) as ctx:
            self.pipeline.run(["AAPL"])
        self.assertEqual(getattr(ctx.exception, "status_code", None), 423)
        self.assertTrue(self.state["paused"])
        self.assertEqual(self.state["pause_reason"], "Pause déclenchée par un autre worker")
        self.assertEqual(self.strategy_repo.restore_pending(), {})

    def test_strategy_pipeline_fails_closed_when_durable_pause_cannot_be_read(self):
        self.pipeline.operational_pause_reader = Mock(side_effect=RuntimeError("database unavailable"))
        with self.assertRaises(Exception) as ctx:
            self.pipeline.run(["AAPL"])
        self.assertEqual(getattr(ctx.exception, "status_code", None), 423)
        self.assertTrue(self.state["paused"])
        self.assertIn("indisponible", self.state["pause_reason"])
        self.assertEqual(self.strategy_repo.restore_pending(), {})

    def test_strategy_to_manual_paper_fill_restart_and_reconciliation(self):
        result = self.pipeline.run(["AAPL"])
        proposal = result["results"][0]["paper_order"]
        proposal_id = proposal["order_id"]
        self.assertEqual(proposal["status"], "PENDING_MANUAL_APPROVAL")

        # Simulate process restart: pending approval is recovered from SQL storage.
        restored_pending = self.strategy_repo.restore_pending()
        self.assertIn(proposal_id, restored_pending)
        self.state["pending"] = restored_pending

        submitted = self._order_service().approve(proposal_id)
        self.assertEqual(submitted["status"], "filled")
        self.assertNotIn(proposal_id, self.state["pending"])

        report = ReconciliationService(
            self.order_repo, sim_broker, self.strategy_repo
        ).run(opening_cash="10000.00", cash_tolerance="2.00")
        self.assertEqual(report["fills_recorded"], 1)
        self.assertEqual(report["financial_reconciliation"]["status"], "consistent")
        self.assertEqual(self.strategy_repo.restore_pending(), {})
        repeated = ReconciliationService(
            self.order_repo, sim_broker, self.strategy_repo
        ).run(opening_cash="10000.00", cash_tolerance="2.00")
        self.assertEqual(repeated["fills_duplicate"], 1)
        self.assertEqual(repeated["financial_reconciliation"]["status"], "consistent")

        with self.sessions() as session:
            proposal_record = session.get(StrategyProposalRecord, proposal_id)
            self.assertEqual(proposal_record.status, "SUBMITTED")
            self.assertIsNotNone(proposal_record.broker_order_id)
            self.assertEqual(session.scalar(select(func.count()).select_from(FillRecord)), 1)

    def test_emergency_loss_halt_blocks_manual_approval_before_broker_call(self):
        result = self.pipeline.run(["AAPL"])
        proposal_id = result["results"][0]["paper_order"]["order_id"]
        self.state["pending"] = self.strategy_repo.restore_pending()
        degraded_account = dict(sim_broker.account())
        degraded_account["equity"] = "9500.00"
        service = self._order_service(account_reader=lambda: degraded_account)
        before = len(sim_broker.orders("all", 100))
        with self.assertRaises(OrderServiceError) as ctx:
            service.approve(proposal_id)
        self.assertEqual(ctx.exception.status_code, 423)
        self.assertTrue(self.state["paused"])
        self.assertEqual(len(sim_broker.orders("all", 100)), before)
        self.assertIn(proposal_id, self.state["pending"])


if __name__ == "__main__":
    unittest.main()
