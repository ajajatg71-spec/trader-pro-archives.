import json
import unittest
from types import SimpleNamespace
from unittest.mock import patch
from routers.health import health


class HealthRouterTests(unittest.TestCase):
    def request(self, timestamp):
        return SimpleNamespace(app=SimpleNamespace(state=SimpleNamespace(beat={"t": timestamp})))

    @patch("routers.health.time.time", return_value=1000)
    def test_live_heartbeat_returns_ok(self, _):
        response = health(self.request(900))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(json.loads(response.body), {"ok": True, "beat_age_s": 100})

    @patch("routers.health.time.time", return_value=1000)
    def test_stale_heartbeat_returns_503(self, _):
        response = health(self.request(700))
        self.assertEqual(response.status_code, 503)
        self.assertEqual(json.loads(response.body), {"ok": False, "beat_age_s": 300})


if __name__ == "__main__":
    unittest.main()
