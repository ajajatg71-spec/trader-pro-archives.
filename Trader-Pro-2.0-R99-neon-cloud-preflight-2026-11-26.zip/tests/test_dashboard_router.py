from fastapi import FastAPI
from fastapi.testclient import TestClient
from types import SimpleNamespace

from routers.dashboard import create_dashboard_router


class Broker:
    def account(self):
        return {"equity": "1000", "cash": "500"}

    def clock(self):
        return {"is_open": True}

    def positions(self):
        return []


class Congress:
    @staticmethod
    def parse(text):
        return [text] if text else []

    @staticmethod
    def net(rows):
        return {"loaded": len(rows)}


class ThirteenF:
    @staticmethod
    def latest_two(cik):
        return ([1], [0])

    @staticmethod
    def diff(previous, current):
        return {"new": [], "sold": [], "increased": [], "decreased": []}

    @staticmethod
    def to_ticker(value):
        return None

    @staticmethod
    def weights(current, limit):
        return []


def test_dashboard_routes_are_modular_and_preserve_behavior():
    state = {"paused": False, "limits": {"buffer": 10}, "targets": [],
             "blocked": [], "inst": {}, "congress": {}}
    history, saved = [], []
    router = create_dashboard_router(
        guard_dependency=lambda request=None: None, page_html="<main>Trader Pro</main>",
        broker=Broker(), state=state, history_reader=lambda n: history[-n:],
        state_lock=__import__("threading").RLock(), state_saver=lambda: saved.append(True),
        history_writer=lambda *args, **kwargs: history.append({"kind": args[0], "msg": args[1], "t": "2026-01-01T00:00:00"}),
        limits={"buffer": 10}, base_url="https://paper-api.alpaca.markets",
        simulation=False, core_module=SimpleNamespace(daily_loss=lambda account: 2),
        congress_module=Congress, thirteen_f_module=ThirteenF,
    )
    app = FastAPI()
    app.include_router(router)
    client = TestClient(app)
    assert "Trader Pro" in client.get("/").text
    response = client.get("/api/state")
    assert response.status_code == 200 and response.json()["mode"] == "paper"
    assert client.post("/api/config", json={"targets": "aapl 40", "blocked": "msft", "limits": {"buffer": 12}}).json() == {"ok": True}
    assert state["targets"] == [("AAPL", 40.0)] and state["blocked"] == ["MSFT"]
    assert client.post("/api/congress", json={"text": "sample"}).json() == {"n": 1}
    assert client.post("/api/follow?cik=123").json()["weights"] == []
    assert len(saved) == 3


def test_dashboard_config_rejects_invalid_limits_and_cik():
    router = create_dashboard_router(
        guard_dependency=lambda request=None: None, page_html="", broker=Broker(),
        state={"paused": False, "limits": {}, "targets": [], "blocked": [], "inst": {}, "congress": {}},
        history_reader=lambda n: [], state_lock=__import__("threading").RLock(),
        state_saver=lambda: None, history_writer=lambda *a, **k: None,
        limits={"buffer": 10}, base_url="https://paper-api.alpaca.markets", simulation=False,
        core_module=SimpleNamespace(daily_loss=lambda account: 0), congress_module=Congress,
        thirteen_f_module=ThirteenF,
    )
    app = FastAPI(); app.include_router(router); client = TestClient(app)
    assert client.post("/api/config", json={"limits": {"buffer": 1e9}}).status_code == 400
    assert client.post("/api/follow?cik=bad").status_code == 400
