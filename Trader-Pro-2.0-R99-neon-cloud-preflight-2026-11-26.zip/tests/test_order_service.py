import threading
import unittest
from unittest.mock import Mock

from services.orders import OrderService, OrderServiceError


class OrderServiceTests(unittest.TestCase):
    def setUp(self):
        self.state = {
            "pending": {"cid-1": {"sym": "AAPL", "side": "buy", "amt": 100.0}},
            "paused": False,
            "limits": {"max_daily_loss": 3.0, "max_drawdown": 10.0, "max_weekly_loss": 6.0},
            "peak": 10000.0, "week": {"eq": 10000.0},
            "blocked": [],
        }
        self.account = Mock(return_value={"equity": "10000", "cash": "10000", "trading_blocked": False})
        self.positions = Mock(return_value=[])
        self.orders = Mock(return_value=[])
        self.submit = Mock(return_value={"id": "broker-1", "status": "accepted"})
        self.cancel = Mock()
        self.daily_loss = Mock(return_value=0.0)
        self.check = Mock(return_value=None)
        self.save, self.history = Mock(), Mock()
        self.service = OrderService(
            state=self.state, lock=threading.RLock(), save=self.save, history=self.history,
            account_reader=self.account, positions_reader=self.positions,
            orders_reader=self.orders, order_submitter=self.submit,
            order_canceller=self.cancel, daily_loss=self.daily_loss,
            order_checker=self.check, orders_today_reader=lambda: 2,
            system_safety_reader=lambda: {"status": "READY", "reason": None},
            instrument_reader=lambda symbol: {"symbol": str(symbol).upper(), "asset_class": "us_equity", "active": True, "tradable": True},
        )

    def test_approval_fails_closed_when_global_state_is_not_ready(self):
        self.service.system_safety_reader = lambda: {"status": "DEGRADED", "reason": "broker unavailable"}
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 423)
        self.submit.assert_not_called()

    def test_approval_uses_all_open_orders_not_only_first_fifty(self):
        captured = {}
        class Risk:
            def pre_trade_check(self, **kwargs):
                captured.update(kwargs)
                return None
        self.service.risk_engine = Risk()
        self.orders.return_value = [
            {"id": f"broker-{index}", "symbol": "AAPL", "side": "buy", "notional": "10.00"}
            for index in range(75)
        ]
        self.service.approve("cid-1")
        self.assertEqual(captured["reserved_buy_notional"], 750.0)
        self.orders.assert_called_once_with("open", 10000)

    def test_approval_blocks_when_open_order_snapshot_may_be_truncated(self):
        self.orders.return_value = [
            {"id": f"broker-{index}", "symbol": "AAPL", "side": "buy", "notional": "1.00"}
            for index in range(10000)
        ]
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 423)
        self.assertIn("approbation bloquée", ctx.exception.detail)
        self.submit.assert_not_called()

    def test_approval_blocks_when_open_buy_order_has_no_notional(self):
        self.orders.return_value = [{"side": "buy", "qty": "10", "status": "new"}]
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 423)
        self.submit.assert_not_called()

    def test_pretrade_approval_is_audited_before_broker_submission(self):
        events = []
        self.service.risk_decision_writer = lambda **kw: events.append(("audit", kw))
        self.submit.side_effect = lambda *args: (events.append(("broker", args)) or {"id": "b", "status": "accepted"})
        self.service.approve("cid-1")
        self.assertEqual([event[0] for event in events], ["audit", "broker"])
        self.assertEqual(events[0][1]["decision"], "approved")
        self.assertEqual(events[0][1]["client_order_id"], "cid-1")

    def test_pretrade_audit_failure_blocks_broker_submission(self):
        self.service.risk_decision_writer = Mock(side_effect=RuntimeError("audit unavailable"))
        with self.assertRaises(RuntimeError):
            self.service.approve("cid-1")
        self.submit.assert_not_called()

    def test_blocked_institutional_decision_is_audited(self):
        events = []
        self.service.risk_engine = type("Risk", (), {"pre_trade_check": lambda self, **kw: "cap breach"})()
        self.service.risk_decision_writer = lambda **kw: events.append(kw)
        with self.assertRaises(OrderServiceError):
            self.service.approve("cid-1")
        self.assertEqual(events[0]["decision"], "blocked")
        self.assertEqual(events[0]["gate"], "INSTITUTIONAL_RISK")
        self.submit.assert_not_called()

    def test_order_persistence_is_written_before_broker_submission(self):
        events = []
        class Persistence:
            def stage_order(self, **kwargs): events.append(("stage", kwargs))
            def update_order(self, oid, **kwargs): events.append(("update", oid, kwargs))
        self.service.order_persistence = Persistence()
        self.service.approve("cid-1")
        self.assertEqual([event[0] for event in events], ["stage", "update"])
        self.assertEqual(events[0][1]["client_order_id"], "cid-1")
        self.assertEqual(events[1][2]["status"], "accepted")

    def test_atomic_claim_receives_portfolio_and_symbol_reservation_ceilings(self):
        captured = {}
        class Persistence:
            def stage_order_if_trading_enabled(self, **kwargs):
                captured.update(kwargs)
                return True
            def update_order(self, oid, **kwargs): pass
        self.service.order_persistence = Persistence()
        self.state["limits"].update({"max_gross": 80.0, "max_pos": 20.0, "min_cash": 10.0})
        self.account.return_value = {"equity": "10000", "cash": "6000", "trading_blocked": False}
        self.positions.return_value = [{"symbol": "AAPL", "market_value": "500"}]
        self.orders.return_value = [{"id": "broker-open-1", "symbol": "MSFT",
                                     "side": "buy", "notional": "250"}]
        self.service.approve("cid-1")
        self.assertEqual(captured["max_total_buy_reservations"], 5000.0)
        self.assertEqual(captured["max_symbol_buy_reservation"], 1500.0)
        self.assertEqual(captured["external_open_buy_orders"], [
            {"broker_order_id": "broker-open-1", "symbol": "MSFT", "notional": 250.0}])

    def test_atomic_durable_claim_blocks_submission_when_pause_wins_race(self):
        class Persistence:
            def stage_order_if_trading_enabled(self, **kwargs):
                raise PermissionError("Pause activée avant réservation")
        self.service.order_persistence = Persistence()
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 423)
        self.assertTrue(self.state["paused"])
        self.assertEqual(self.state["pause_reason"], "Pause activée avant réservation")
        self.submit.assert_not_called()

    def test_existing_durable_intent_blocks_second_broker_submission(self):
        class ExistingIntent:
            def stage_order(self, **kwargs): return False
        self.service.order_persistence = ExistingIntent()
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 409)
        self.submit.assert_not_called()

    def test_order_persistence_failure_blocks_broker_submission(self):
        class BrokenPersistence:
            def stage_order(self, **kwargs): raise RuntimeError("database down")
        self.service.order_persistence = BrokenPersistence()
        with self.assertRaises(RuntimeError): self.service.approve("cid-1")
        self.submit.assert_not_called()

    def test_broker_timeout_is_recorded_as_unknown_not_definite_failure(self):
        events = []
        class Persistence:
            def stage_order(self, **kwargs): events.append(("stage", kwargs))
            def update_order(self, oid, **kwargs): events.append(("update", kwargs))
        self.service.order_persistence = Persistence()
        self.submit.side_effect = TimeoutError("network timeout")
        with self.assertRaises(TimeoutError): self.service.approve("cid-1")
        self.assertEqual(events[-1][1]["status"], "submission_unknown")
        self.assertIn("cid-1", self.state["pending"])

    def test_malformed_broker_success_response_is_recorded_as_unknown(self):
        events = []
        class Persistence:
            def stage_order(self, **kwargs): events.append(("stage", kwargs))
            def update_order(self, oid, **kwargs): events.append(("update", kwargs))
        self.service.order_persistence = Persistence()
        self.submit.return_value = {"status": "accepted"}  # broker ID missing
        with self.assertRaisesRegex(ValueError, "Identifiant broker absent"):
            self.service.approve("cid-1")
        self.assertEqual(events[-1][1]["status"], "submission_unknown")
        self.assertIn("cid-1", self.state["pending"])

    def test_non_mapping_broker_success_response_is_recorded_as_unknown(self):
        events = []
        class Persistence:
            def stage_order(self, **kwargs): events.append(("stage", kwargs))
            def update_order(self, oid, **kwargs): events.append(("update", kwargs))
        self.service.order_persistence = Persistence()
        self.submit.return_value = None
        with self.assertRaisesRegex(ValueError, "Réponse de soumission broker invalide"):
            self.service.approve("cid-1")
        self.assertEqual(events[-1][1]["status"], "submission_unknown")
        self.assertIn("cid-1", self.state["pending"])

    def test_invalid_broker_quantity_is_recorded_as_unknown(self):
        events = []
        class Persistence:
            def stage_order(self, **kwargs): events.append(("stage", kwargs))
            def update_order(self, oid, **kwargs): events.append(("update", kwargs))
        self.service.order_persistence = Persistence()
        self.submit.return_value = {"id": "broker-1", "status": "accepted", "qty": "NaN"}
        with self.assertRaisesRegex(ValueError, "Quantité broker invalide"):
            self.service.approve("cid-1")
        self.assertEqual(events[-1][1]["status"], "submission_unknown")
        self.assertIn("cid-1", self.state["pending"])

    def test_strategy_broker_timeout_persists_submission_unknown_not_failed(self):
        events = []
        self.state["pending"]["cid-1"]["source"] = "strategy_engine"
        class Persistence:
            def stage_order(self, **kwargs): pass
            def update_order(self, oid, **kwargs): pass
        self.service.order_persistence = Persistence()
        self.service.status_writer = lambda oid, status, **kw: events.append((status, kw))
        self.submit.side_effect = TimeoutError("network timeout")
        with self.assertRaises(TimeoutError):
            self.service.approve("cid-1")
        self.assertEqual([status for status, _ in events], ["SUBMITTING", "SUBMISSION_UNKNOWN"])
        self.assertEqual(events[-1][1]["reason"], "TimeoutError")

    def test_approve_preserves_client_order_id_and_removes_pending(self):
        result = self.service.approve("cid-1")
        self.assertEqual(result["id"], "broker-1")
        self.submit.assert_called_once_with("AAPL", "buy", 100.0, "cid-1")
        self.assertNotIn("cid-1", self.state["pending"])
        self.history.assert_called_once()

    def test_strategy_approval_persists_submitting_then_submitted(self):
        events = []
        self.state["pending"]["cid-1"]["source"] = "strategy_engine"
        self.service.status_writer = lambda oid, status, **kw: events.append((oid, status, kw))
        self.service.approve("cid-1")
        self.assertEqual([event[1] for event in events], ["SUBMITTING", "SUBMITTED"])
        self.assertEqual(events[-1][2]["broker_order_id"], "broker-1")

    def test_strategy_rejection_is_persisted_before_pending_removal(self):
        events = []
        self.state["pending"]["cid-1"]["source"] = "strategy_engine"
        self.service.status_writer = lambda oid, status, **kw: events.append((oid, status))
        self.service.reject("cid-1")
        self.assertEqual(events, [("cid-1", "REJECTED")])
        self.assertNotIn("cid-1", self.state["pending"])

    def test_approve_rejects_when_paused(self):
        self.state["paused"] = True
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 423)
        self.submit.assert_not_called()


    def test_approve_rechecks_durable_pause_from_another_process(self):
        self.service.operational_pause_reader = lambda: {
            "paused": True, "reason": "Pause déclenchée par un autre worker", "actor": "operator"
        }
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 423)
        self.assertTrue(self.state["paused"])
        self.assertEqual(self.state["pause_reason"], "Pause déclenchée par un autre worker")
        self.submit.assert_not_called()

    def test_approve_fails_closed_when_durable_pause_read_fails(self):
        self.service.operational_pause_reader = Mock(side_effect=RuntimeError("database unavailable"))
        events = []
        self.service.risk_decision_writer = lambda **kw: events.append(kw)
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 423)
        self.assertIn("indisponible", ctx.exception.detail)
        self.assertTrue(self.state["paused"])
        self.assertEqual(events[0]["gate"], "PAUSE_STATE_UNAVAILABLE")
        self.submit.assert_not_called()

    def test_approve_fails_closed_on_malformed_durable_pause_state(self):
        self.service.operational_pause_reader = lambda: {"paused": "false"}
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 423)
        self.submit.assert_not_called()

    def test_manual_pause_persists_before_in_memory_state_changes(self):
        events = []
        self.service.operational_pause_writer = lambda **kw: events.append(kw)
        result = self.service.toggle_pause()
        self.assertTrue(result["paused"])
        self.assertEqual(events[0], {"paused": True, "reason": "Pause manuelle", "actor": "operator"})

    def test_pause_persistence_failure_keeps_existing_state(self):
        self.service.operational_pause_writer = Mock(side_effect=RuntimeError("database down"))
        with self.assertRaises(OrderServiceError):
            self.service.toggle_pause()
        self.assertTrue(self.state["paused"])
        self.save.assert_not_called()

    def test_pause_requests_cancellation_for_open_broker_orders_after_durable_pause(self):
        events = []
        class Persistence:
            def record_order_cancel_event(inner, **kwargs): events.append(("audit", kwargs))
        self.service.order_persistence = Persistence()
        self.orders.return_value = [
            {"id": "broker-open-1", "client_order_id": "cid-open", "status": "new"},
            {"id": "broker-filled", "client_order_id": "cid-filled", "status": "filled"},
        ]
        self.cancel.side_effect = lambda oid: events.append(("cancel", oid))
        self.service.operational_pause_writer = lambda **kw: events.append(("pause", kw))
        result = self.service.toggle_pause()
        self.assertTrue(result["paused"])
        self.assertEqual(result["cancellation"]["open_orders_seen"], 2)
        self.assertEqual(result["cancellation"]["cancel_requests"], 1)
        self.assertEqual(self.cancel.call_args_list[0].args, ("broker-open-1",))
        self.assertEqual([e[0] for e in events], ["pause", "audit", "cancel"])
        self.assertEqual(events[1][1]["outcome"], "requested")

    def test_pause_uses_bounded_paginated_snapshot_limit(self):
        self.service.orders_reader = Mock(return_value=[])
        self.service.operational_pause_writer = lambda **kw: None
        result = self.service.toggle_pause()
        self.assertTrue(result["paused"])
        self.service.orders_reader.assert_called_once_with("open", 10000)

    def test_pause_keeps_pending_cancel_when_broker_cancel_request_fails(self):
        events = []
        class Persistence:
            def record_order_cancel_event(inner, **kwargs): events.append(kwargs)
        self.service.order_persistence = Persistence()
        self.orders.return_value = [{"id": "broker-open-2", "client_order_id": "cid-open", "status": "partially_filled"}]
        self.cancel.side_effect = TimeoutError("timeout")
        result = self.service.toggle_pause()
        self.assertTrue(result["paused"])
        self.assertEqual(result["cancellation"]["cancel_requests"], 0)
        self.assertEqual(result["cancellation"]["cancel_request_failures"][0]["reason"], "TimeoutError")
        self.assertEqual([e["outcome"] for e in events], ["requested", "request_failed"])

    def test_pause_remains_active_when_open_order_snapshot_fails(self):
        self.orders.side_effect = RuntimeError("broker unavailable")
        result = self.service.toggle_pause()
        self.assertTrue(result["paused"])
        self.assertEqual(result["cancellation"]["snapshot_error"], "RuntimeError")
        self.assertTrue(self.state["paused"])

    def test_pause_reader_failure_never_toggles_to_resume(self):
        self.service.operational_pause_reader = Mock(side_effect=RuntimeError("db down"))
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.toggle_pause()
        self.assertEqual(ctx.exception.status_code, 503)
        self.assertTrue(self.state["paused"])
        self.assertNotIn("pause", [call.args[0] for call in self.history.call_args_list if call.args])

    def test_automatic_emergency_halt_is_persisted(self):
        self.account.return_value = {"equity": "9000", "last_equity": "10000", "trading_blocked": False}
        events = []
        self.service.operational_pause_writer = lambda **kw: events.append(kw)
        with self.assertRaises(OrderServiceError):
            self.service.approve("cid-1")
        self.assertTrue(self.state["paused"])
        self.assertEqual(events[0]["actor"], "risk_engine")
        self.assertTrue(events[0]["paused"])

    def test_approve_triggers_daily_loss_halt(self):
        self.account.return_value = {"equity": "9300", "last_equity": "10000", "trading_blocked": False}
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 423)
        self.assertTrue(self.state["paused"])
        self.submit.assert_not_called()

    def test_approve_triggers_drawdown_halt(self):
        self.state["peak"] = 12000.0
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 423)
        self.assertTrue(self.state["paused"])
        self.submit.assert_not_called()

    def test_approve_triggers_weekly_loss_halt(self):
        self.state["week"] = {"eq": 12000.0}
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 423)
        self.assertTrue(self.state["paused"])
        self.submit.assert_not_called()

    def test_approve_rechecks_risk_and_blocks_order(self):
        self.check.return_value = "exposition maximale dépassée"
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 409)
        self.assertEqual(self.state["pending"]["cid-1"]["why"], "exposition maximale dépassée")
        self.submit.assert_not_called()

    def test_institutional_risk_engine_blocks_before_broker_submission(self):
        class RiskEngine:
            def pre_trade_check(self, **kwargs):
                return "Limite de concentration dépassée"
        self.service.risk_engine = RiskEngine()
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 409)
        self.submit.assert_not_called()
        self.assertEqual(self.state["pending"]["cid-1"]["why"], "Limite de concentration dépassée")

    def test_approve_rejects_missing_order(self):
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("missing")
        self.assertEqual(ctx.exception.status_code, 404)

    def test_cancel_persists_pending_cancel_after_broker_accepts_request(self):
        events = []
        class Persistence:
            def list_orders_for_reconciliation(self):
                return [{"client_order_id": "cid-1", "broker_order_id": "broker-1"}]
            def record_order_cancel_event(self, **kwargs): events.append(kwargs)
        self.service.order_persistence = Persistence()
        self.assertEqual(self.service.cancel("broker-1"), {"ok": True})
        self.assertEqual(events, [{"client_order_id": "cid-1", "broker_order_id": "broker-1", "outcome": "requested"}])
        self.cancel.assert_called_once_with("broker-1")

    def test_cancel_failure_is_audited_and_reported_as_gateway_error(self):
        events = []
        class Persistence:
            def list_orders_for_reconciliation(self): return []
            def record_order_cancel_event(self, **kwargs): events.append(kwargs)
        self.service.order_persistence = Persistence()
        self.cancel.side_effect = TimeoutError("timeout")
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.cancel("broker-unknown")
        self.assertEqual(ctx.exception.status_code, 502)
        self.assertEqual(events[0]["outcome"], "request_failed")
        self.assertIsNone(events[0]["client_order_id"])

    def test_cancel_refuses_to_call_broker_when_local_order_snapshot_unavailable(self):
        class Persistence:
            def list_orders_for_reconciliation(self): raise RuntimeError("database unavailable")
        self.service.order_persistence = Persistence()
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.cancel("broker-1")
        self.assertEqual(ctx.exception.status_code, 503)
        self.cancel.assert_not_called()

    def test_reject_cancel_pause_and_order_listing(self):
        self.assertEqual(self.service.reject("cid-1"), {"ok": True})
        self.assertNotIn("cid-1", self.state["pending"])
        self.assertEqual(self.service.cancel("broker-1"), {"ok": True})
        self.cancel.assert_called_once_with("broker-1")
        self.assertEqual(self.service.toggle_pause(), {"paused": True, "cancellation": {
            "open_orders_seen": 0, "cancel_requests": 0, "cancel_request_failures": [],
            "snapshot_error": None, "snapshot_may_be_truncated": False}})
        self.assertEqual(self.service.toggle_pause(), {"paused": False, "cancellation": None})
        self.orders.return_value = [{"id": "x", "symbol": "AAPL", "secret": "omit"}]
        self.assertEqual(self.service.list_orders(), [{"id": "x", "symbol": "AAPL", "side": None,
            "notional": None, "qty": None, "status": None, "filled_avg_price": None, "submitted_at": None}])


    def test_liquidity_reader_refreshes_market_fields_before_risk_gate(self):
        self.state["limits"]["max_spread_pct"] = 0.5
        self.state["risk_metadata"] = {"AAPL": {"sector": "Technology", "bid": 1, "ask": 2}}
        captured = {}
        class Risk:
            def pre_trade_check(inner, **kwargs):
                captured.update(kwargs["state"]["risk_metadata"]["AAPL"])
                return None
        self.service.risk_engine = Risk()
        self.service.liquidity_reader = lambda symbol: {
            "source": "alpaca_iex", "as_of": 1790000000.0,
            "bid": 99.9, "ask": 100.0, "avg_daily_dollar_volume": 500000.0,
        }
        self.service.approve("cid-1")
        self.assertEqual(captured["sector"], "Technology")
        self.assertEqual(captured["source"], "alpaca_iex")
        self.assertEqual(captured["bid"], 99.9)

    def test_liquidity_controls_block_without_configured_provider(self):
        self.state["limits"]["max_spread_pct"] = 0.5
        self.service.risk_engine = type("Risk", (), {"pre_trade_check": lambda self, **kw: None})()
        events = []
        self.service.risk_decision_writer = lambda **kw: events.append(kw)
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 409)
        self.assertEqual(events[0]["gate"], "LIQUIDITY_DATA")
        self.submit.assert_not_called()

    def test_liquidity_provider_failure_blocks_before_broker(self):
        self.state["limits"]["max_spread_pct"] = 0.5
        self.service.risk_engine = type("Risk", (), {"pre_trade_check": lambda self, **kw: None})()
        self.service.liquidity_reader = Mock(side_effect=TimeoutError("private provider detail"))
        with self.assertRaisesRegex(OrderServiceError, "TimeoutError"):
            self.service.approve("cid-1")
        self.submit.assert_not_called()


if __name__ == "__main__":
    unittest.main()
    def test_liquidity_reader_refreshes_market_fields_before_risk_gate(self):
        self.state["limits"]["max_spread_pct"] = 0.5
        self.state["risk_metadata"] = {"AAPL": {"sector": "Technology", "bid": 1, "ask": 2}}
        captured = {}
        class Risk:
            def pre_trade_check(inner, **kwargs):
                captured.update(kwargs["state"]["risk_metadata"]["AAPL"])
                return None
        self.service.risk_engine = Risk()
        self.service.liquidity_reader = lambda symbol: {
            "source": "alpaca_iex", "as_of": 1790000000.0,
            "bid": 99.9, "ask": 100.0, "avg_daily_dollar_volume": 500000.0,
        }
        # The fake risk gate only inspects the merged payload; the production gate
        # independently validates timestamp, provenance, spread and ADV.
        self.service.approve("cid-1")
        self.assertEqual(captured["sector"], "Technology")
        self.assertEqual(captured["source"], "alpaca_iex")
        self.assertEqual(captured["bid"], 99.9)

    def test_liquidity_controls_block_without_configured_provider(self):
        self.state["limits"]["max_spread_pct"] = 0.5
        self.service.risk_engine = type("Risk", (), {"pre_trade_check": lambda self, **kw: None})()
        events = []
        self.service.risk_decision_writer = lambda **kw: events.append(kw)
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 409)
        self.assertEqual(events[0]["gate"], "LIQUIDITY_DATA")
        self.submit.assert_not_called()

    def test_liquidity_provider_failure_blocks_before_broker(self):
        self.state["limits"]["max_spread_pct"] = 0.5
        self.service.risk_engine = type("Risk", (), {"pre_trade_check": lambda self, **kw: None})()
        self.service.liquidity_reader = Mock(side_effect=TimeoutError("private provider detail"))
        with self.assertRaisesRegex(OrderServiceError, "TimeoutError"):
            self.service.approve("cid-1")
        self.submit.assert_not_called()



    def test_approval_blocks_when_instrument_metadata_is_missing(self):
        self.service.instrument_reader = None
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 423)
        self.submit.assert_not_called()

    def test_approval_blocks_non_equity_asset_class(self):
        self.service.instrument_reader = lambda symbol: {
            "symbol": symbol, "asset_class": "crypto", "active": True, "tradable": True
        }
        with self.assertRaises(OrderServiceError) as ctx:
            self.service.approve("cid-1")
        self.assertEqual(ctx.exception.status_code, 423)
        self.submit.assert_not_called()

    def test_approval_blocks_inactive_or_non_tradable_instrument(self):
        for metadata in (
            {"symbol": "AAPL", "asset_class": "us_equity", "active": False, "tradable": True},
            {"symbol": "AAPL", "asset_class": "us_equity", "active": True, "tradable": False},
        ):
            self.service.instrument_reader = lambda _symbol, data=metadata: data
            with self.assertRaises(OrderServiceError):
                self.service.approve("cid-1")
            self.submit.assert_not_called()

    def test_approval_blocks_mismatched_symbol_metadata(self):
        self.service.instrument_reader = lambda _symbol: {
            "symbol": "MSFT", "asset_class": "us_equity", "active": True, "tradable": True
        }
        with self.assertRaises(OrderServiceError):
            self.service.approve("cid-1")
        self.submit.assert_not_called()


    def test_partially_filled_buy_reserves_only_remaining_quantity_at_limit(self):
        self.orders.return_value = [{
            "id": "broker-partial-1", "symbol": "AAPL", "side": "buy",
            "status": "partially_filled", "qty": "10", "filled_qty": "4",
            "limit_price": "100", "notional": "1000",
        }]
        total, rows = self.service._open_buy_reservations()
        self.assertEqual(total, 600.0)
        self.assertEqual(rows[0]["notional"], 600.0)

    def test_partially_filled_buy_can_use_remaining_fraction_of_notional(self):
        self.orders.return_value = [{
            "id": "broker-partial-2", "symbol": "MSFT", "side": "buy",
            "status": "partially_filled", "qty": "8", "filled_qty": "2",
            "notional": "800",
        }]
        total, rows = self.service._open_buy_reservations()
        self.assertEqual(total, 600.0)
        self.assertEqual(rows[0]["notional"], 600.0)

    def test_partially_filled_buy_without_filled_quantity_fails_closed(self):
        self.orders.return_value = [{
            "id": "broker-partial-3", "symbol": "AAPL", "side": "buy",
            "status": "partially_filled", "qty": "10", "notional": "1000",
        }]
        with self.assertRaises(OrderServiceError):
            self.service._open_buy_reservations()

    def test_open_buy_without_notional_can_use_quantity_times_limit_price(self):
        self.orders.return_value = [{
            "id": "broker-limit-1", "symbol": "NVDA", "side": "buy",
            "status": "new", "qty": "3", "limit_price": "50",
        }]
        total, rows = self.service._open_buy_reservations()
        self.assertEqual(total, 150.0)
        self.assertEqual(rows[0]["notional"], 150.0)

    def test_open_buy_with_invalid_remaining_quantity_fails_closed(self):
        self.orders.return_value = [{
            "id": "broker-partial-4", "symbol": "AAPL", "side": "buy",
            "status": "partially_filled", "qty": "10", "filled_qty": "11",
            "limit_price": "100",
        }]
        with self.assertRaises(OrderServiceError):
            self.service._open_buy_reservations()
