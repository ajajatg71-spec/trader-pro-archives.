import tempfile
import unittest
from datetime import date, datetime, timezone
from decimal import Decimal
from pathlib import Path

from db.base import Base
from db.corporate_action_repository import CorporateActionRepository
from db.session import build_engine, build_session_factory
from research_v1.quant.corporate_action_readiness import (
    assess_corporate_action_readiness,
    assess_corporate_action_readiness_with_repository,
)


class CorporateActionStorageReadinessR92Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.engine = build_engine(f"sqlite:///{Path(self.temp.name) / 'storage-readiness.db'}")
        self.sessions = build_session_factory(self.engine)
        self.repo = CorporateActionRepository(self.sessions)

    def tearDown(self):
        self.engine.dispose()
        self.temp.cleanup()

    def evidence(self):
        return {
            "source_batch_complete": True,
            "raw_price_basis_verified": True,
            "cross_source_reconciliation": True,
            "provider_history_verified": True,
            "event_revision_ledger_persisted": True,
            "currency_and_calendar_verified": True,
            "postgresql_validation_passed": True,
        }

    def test_missing_table_is_not_reported_ready(self):
        result = self.repo.storage_readiness()
        self.assertFalse(result["ready"])
        self.assertIn("table corporate_action_revisions absente", result["issues"])

    def test_sqlite_schema_is_not_mistaken_for_postgres_append_only_validation(self):
        Base.metadata.create_all(self.engine)
        result = self.repo.storage_readiness()
        self.assertFalse(result["ready"])
        self.assertFalse(result["append_only_enforced"])
        self.assertIn("dialecte non PostgreSQL : immutabilité DB non vérifiée", result["issues"])

    def test_repository_evidence_overrides_unverified_boolean_claim(self):
        Base.metadata.create_all(self.engine)
        result = assess_corporate_action_readiness_with_repository(self.evidence(), self.repo)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertFalse(result["corporate_action_storage"]["ready"])
        self.assertTrue(any("event_revision_ledger_persisted" in item for item in result["blockers"]))

    def test_plain_readiness_gate_remains_fail_closed(self):
        evidence = self.evidence()
        evidence["event_revision_ledger_persisted"] = None
        result = assess_corporate_action_readiness(evidence)
        self.assertFalse(result["ready"])

    def test_storage_readiness_requires_all_constraints_and_unique_identity(self):
        Base.metadata.create_all(self.engine)
        result = self.repo.storage_readiness()
        # SQLite can verify table shape and constraints, but not the required PG trigger.
        self.assertTrue(all("incomplètes" not in issue for issue in result["issues"]))


if __name__ == "__main__":
    unittest.main()
