import unittest
from datetime import date,datetime,timezone
from research_v1.quant.corporate_actions import CorporateActionEvent,reconcile_corporate_action_sources
class CorporateActionSourceReconciliationTests(unittest.TestCase):
 def event(self,source,amount="0.5",symbol="AAPL"):
  return CorporateActionEvent(symbol,"dividend",date(2025,1,6),datetime(2025,1,1,tzinfo=timezone.utc),source,cash_amount=amount,currency="USD")
 def test_equal_independent_events_match_without_matching_ids(self):
  r=reconcile_corporate_action_sources([self.event("alpaca")],[self.event("other")]);self.assertTrue(r.consistent);self.assertEqual(len(r.matched),1)
 def test_amount_conflict_is_not_silently_merged(self):
  r=reconcile_corporate_action_sources([self.event("alpaca","0.5")],[self.event("other","0.6")]);self.assertFalse(r.consistent);self.assertEqual(len(r.economic_conflicts),1)
 def test_missing_event_is_reported(self):
  r=reconcile_corporate_action_sources([self.event("alpaca")],[]);self.assertEqual(len(r.primary_only),1)
 def test_universe_difference_is_reported(self):
  r=reconcile_corporate_action_sources([self.event("alpaca")],[self.event("other",symbol="MSFT")]);self.assertEqual(len(r.primary_only),1);self.assertEqual(len(r.secondary_only),1)
if __name__=="__main__":unittest.main()
