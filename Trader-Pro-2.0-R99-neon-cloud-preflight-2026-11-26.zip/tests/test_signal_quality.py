from research_v1.quant.signal import make_signal
from research_v1.quant.signal_quality import assess
import pytest


NOW = "2026-11-26T10:00:00+00:00"


def _signal(**overrides):
    values = dict(
        symbol="AAPL", name="momentum", value=0.4,
        as_of="2026-11-26T09:55:00+00:00",
        computed_at="2026-11-26T09:56:00+00:00",
        source="unit-test", inputs={"return_20d": 0.08},
        rationale="Momentum positif observé",
    )
    values.update(overrides)
    return values


def test_valid_signal_is_reported_without_changing_value():
    signal = _signal()
    report = assess([signal], assessed_at=NOW)
    assert report["status"] == "valid"
    assert report["counts"] == {"valid": 1, "degraded": 0, "rejected": 0}
    assert report["execution_authorized"] is False
    assert report["signals"][0]["status"] == "valid"
    assert signal["value"] == 0.4


def test_stale_signal_is_degraded_not_silently_removed():
    report = assess(
        [_signal(as_of="2026-11-24T09:00:00+00:00")],
        assessed_at=NOW, max_age_seconds=3600,
    )
    assert report["status"] == "degraded"
    assert report["counts"]["degraded"] == 1
    assert "donnée ancienne au regard du seuil de fraîcheur" in report["signals"][0]["warnings"]


def test_future_or_incoherent_timestamps_are_rejected():
    report = assess(
        [_signal(as_of="2026-11-26T10:01:00+00:00")],
        assessed_at=NOW,
    )
    assert report["status"] == "rejected"
    assert any("après le calcul" in issue or "futur" in issue
               for issue in report["signals"][0]["issues"])


def test_missing_provenance_and_nonfinite_value_are_rejected():
    report = assess(
        [_signal(source="", inputs={}, value=float("nan"))],
        assessed_at=NOW,
    )
    issues = report["signals"][0]["issues"]
    assert report["status"] == "rejected"
    assert "source manquante" in issues
    assert "données sources manquantes" in issues
    assert "valeur non numérique ou non finie" in issues


def test_duplicate_signal_is_flagged_without_rewriting_it():
    first, second = _signal(), _signal()
    report = assess([first, second], assessed_at=NOW)
    assert report["status"] == "degraded"
    assert "signal dupliqué pour ce symbole et ce nom" in report["signals"][1]["warnings"]
    assert first == second


def test_signal_dataclass_is_supported():
    signal = make_signal(
        "AAPL", "trend", 0.5,
        "2026-11-26T09:55:00+00:00",
        "2026-11-26T09:56:00+00:00",
        "unit-test", {"close": 210.0}, "Cours au-dessus de la moyenne",
    )
    assert assess([signal], assessed_at=NOW)["status"] == "valid"


def test_naive_timestamp_and_invalid_freshness_threshold_are_rejected():
    report = assess([_signal(as_of="2026-11-26T09:55:00")], assessed_at=NOW)
    assert report["status"] == "rejected"
    assert any("fuseau horaire" in issue for issue in report["signals"][0]["issues"])
    with pytest.raises(ValueError, match="max_age_seconds"):
        assess([_signal()], assessed_at=NOW, max_age_seconds=-1)
