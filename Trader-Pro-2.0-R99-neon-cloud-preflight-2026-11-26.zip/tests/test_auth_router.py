import unittest
from threading import RLock
from unittest.mock import Mock
from fastapi import HTTPException
from starlette.requests import Request
from routers.authentication import create_auth_router


def make_request(headers=None, method="POST"):
    raw_headers = [(k.lower().encode(), v.encode()) for k, v in (headers or {}).items()]
    return Request({"type": "http", "method": method, "path": "/api/login", "headers": raw_headers, "query_string": b"", "server": ("test", 443), "client": ("127.0.0.1", 1234), "scheme": "https"})


class AuthenticationRouterTests(unittest.TestCase):
    def setUp(self):
        self.failures = {}
        self.state = {}
        self.history = Mock()
        self.notify = Mock()
        self.saved = Mock()
        self.totp = Mock(return_value=True)
        self.router = create_auth_router(
            guard_dependency=lambda: None,
            app_password="a-long-test-password",
            totp_secret="TOTP",
            session_key=b"test-key",
            failures=self.failures,
            client_ip=lambda request: "127.0.0.1",
            history_writer=self.history,
            notifier=self.notify,
            token_factory=lambda key, now=None: "signed-token",
            state=self.state,
            state_lock=RLock(),
            save_state=self.saved,
            login_page_renderer=lambda: "existing-login-page",
            totp_verifier=self.totp,
        )
        self.endpoints = {route.path: route.endpoint for route in self.router.routes}

    def test_login_page_keeps_existing_content(self):
        self.assertEqual(self.endpoints["/login"](), "existing-login-page")

    def test_login_rejects_missing_csrf_header(self):
        from routers.authentication import LoginRequest
        with self.assertRaises(HTTPException) as ctx:
            self.endpoints["/api/login"](LoginRequest(password="a-long-test-password", code="123456"), make_request())
        self.assertEqual(ctx.exception.status_code, 403)

    def test_login_sets_secure_session_cookie(self):
        from routers.authentication import LoginRequest
        response = self.endpoints["/api/login"](
            LoginRequest(password="a-long-test-password", code="123456"),
            make_request({"x-trader": "1"}),
        )
        self.assertEqual(response.status_code, 200)
        cookie = response.headers["set-cookie"].lower()
        self.assertIn("httponly", cookie)
        self.assertIn("secure", cookie)
        self.assertIn("samesite=strict", cookie)

    def test_failed_login_is_rate_limited(self):
        from routers.authentication import LoginRequest
        self.totp.return_value = False
        for _ in range(5):
            with self.assertRaises(HTTPException) as ctx:
                self.endpoints["/api/login"](LoginRequest(password="a-long-test-password", code="000000"), make_request({"x-trader": "1"}))
            self.assertEqual(ctx.exception.status_code, 401)
        with self.assertRaises(HTTPException) as ctx:
            self.endpoints["/api/login"](LoginRequest(password="a-long-test-password", code="000000"), make_request({"x-trader": "1"}))
        self.assertEqual(ctx.exception.status_code, 429)

    def test_logout_all_revokes_sessions_and_persists(self):
        result = self.endpoints["/api/logout_all"]()
        self.assertEqual(result, {"ok": True})
        self.assertIn("revoke_before", self.state)
        self.saved.assert_called_once()


if __name__ == "__main__":
    unittest.main()
