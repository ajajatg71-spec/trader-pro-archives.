import unittest
from research_v1.backtesting.sector_risk import audit_sector_exposure

class SectorRiskTests(unittest.TestCase):
    def test_missing_metadata_fails_closed(self):
        result = audit_sector_exposure([{"A": .3, "B": .2}], {"A": "Tech"})
        self.assertEqual(result["status"], "REVIEW_REQUIRED")
        self.assertFalse(result["capital_authorized"])

    def test_sector_aggregation_catches_hidden_concentration(self):
        result = audit_sector_exposure([{"A": .2, "B": .2, "C": .1}], {"A": "Tech", "B": "Tech", "C": "Health"})
        self.assertEqual(result["sector_peak_pct"]["Tech"], 40)
        self.assertEqual(result["breach_days"], 1)

    def test_diversified_research_still_never_authorizes(self):
        result = audit_sector_exposure([{"A": .2, "B": .2}], {"A": "Tech", "B": "Health"})
        self.assertEqual(result["status"], "WITHIN_RESEARCH_LIMITS")
        self.assertFalse(result["capital_authorized"])

    def test_invalid_exposure_rejected(self):
        with self.assertRaises(ValueError):
            audit_sector_exposure([{"A": .8, "B": .5}], {"A": "Tech", "B": "Health"})
