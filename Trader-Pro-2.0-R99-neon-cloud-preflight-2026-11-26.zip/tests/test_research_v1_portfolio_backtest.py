import math
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

from research_v1.backtesting.portfolio_backtest import simulate_portfolio


def series(symbol, n=180, drift=0.18, phase=0.0):
    out = []
    for i in range(n):
        close = 80 + drift * i + math.sin(i / 5 + phase) * 1.8
        op = close - 0.15
        out.append(SimpleNamespace(
            o=op, h=close + 1.0, l=close - 1.0, c=close,
            v=100_000 + (i % 11) * 500,
            ts=(datetime(2025, 1, 1, tzinfo=timezone.utc) + timedelta(days=i)).isoformat(),
        ))
    return out


class PortfolioBacktestTests(unittest.TestCase):
    def setUp(self):
        self.data = {"AAA": series("AAA", drift=.22), "BBB": series("BBB", drift=.12, phase=1.2),
                     "CCC": series("CCC", drift=.08, phase=2.1)}

    def test_dual_momentum_is_a_pure_next_open_simulation(self):
        result = simulate_portfolio("dual_momentum", self.data,
                                    params={"lookback": 60, "top_n": 1, "exit_rank": 2,
                                            "position_pct": .8, "abs_min": -0.2},
                                    initial_cash=50_000, warmup=70)
        self.assertEqual(result["mode"], "RESEARCH_BACKTEST")
        self.assertFalse(result["broker_access"])
        self.assertEqual(result["orders_created"], 0)
        self.assertGreater(len(result["equity_curve"]), 100)
        self.assertEqual(len(result["asset_weights_curve"]), len(result["equity_curve"]))
        self.assertEqual(len(result["cash_weights_curve"]), len(result["equity_curve"]))
        for asset_weights, cash_weight in zip(result["asset_weights_curve"], result["cash_weights_curve"]):
            self.assertGreaterEqual(cash_weight, -1e-8)
            self.assertLessEqual(sum(asset_weights.values()) + cash_weight, 1.000001)
        self.assertTrue(all(x["index"] > 70 for x in result["fills"]))
        self.assertLessEqual(result["final_equity"], 100_000_000)

    def test_inverse_volatility_and_rebalancing_run(self):
        inv = simulate_portfolio("inverse_volatility", self.data,
                                 params={"vol_n": 20, "band": 1.0, "min_trade": 10}, warmup=30)
        self.assertEqual(inv["orders_created"], 0)
        reb = simulate_portfolio("rebalancing", self.data,
                                 params={"targets": {"AAA": .4, "BBB": .3, "CCC": .2},
                                         "band": 1.0, "min_trade": 10}, warmup=30)
        self.assertEqual(reb["orders_created"], 0)
        self.assertTrue(reb["fills"])

    def test_six_market_price_strategies_can_be_simulated(self):
        configs = {
            "momentum": {}, "dual_momentum": {}, "low_volatility": {},
            "rs_rotation": {},
            "rebalancing": {"targets": {"AAA": .4, "BBB": .3, "CCC": .2}},
            "inverse_volatility": {},
        }
        long_data = {"AAA": series("AAA", 320, .22), "BBB": series("BBB", 320, .12, 1.2),
                     "CCC": series("CCC", 320, .08, 2.1)}
        for kind, params in configs.items():
            result = simulate_portfolio(kind, long_data, params=params, warmup=60)
            self.assertEqual(result["strategy"], kind)
            self.assertFalse(result["broker_access"])
            self.assertEqual(result["orders_created"], 0)
            self.assertEqual(len(result["benchmark"]["equity_curve"]), 320)

    def test_multi_factor_uses_only_fundamentals_available_at_the_time(self):
        long_data = {"AAA": series("AAA", 320, .22), "BBB": series("BBB", 320, .12, 1.2),
                     "CCC": series("CCC", 320, .08, 2.1)}
        snapshots = {
            "AAA": [{"available_at": long_data["AAA"][200].ts, "as_of": "2024-Q4", "eps": 2, "growth_pct": 15, "margin_pct": 12}],
            "BBB": [{"available_at": long_data["BBB"][200].ts, "as_of": "2024-Q4", "eps": 3, "growth_pct": 8, "margin_pct": 18}],
            "CCC": [{"available_at": long_data["CCC"][200].ts, "as_of": "2024-Q4", "eps": 1, "growth_pct": 24, "margin_pct": 6}],
        }
        result = simulate_portfolio("multi_factor", long_data,
            params={"top_n": 3, "exit_rank": 3, "position_pct": .25,
                    "min_coverage": .75, "min_score": -3},
            fundamentals=snapshots, warmup=130)
        buys = [fill for fill in result["fills"] if fill["side"] == "buy"]
        self.assertTrue(buys)
        self.assertTrue(all(fill["index"] >= 201 for fill in buys))
        self.assertFalse(result["broker_access"])
        self.assertEqual(result["orders_created"], 0)

    def test_multi_factor_rejects_reporting_period_after_public_availability(self):
        long_data = {"AAA": series("AAA", 320, .22), "BBB": series("BBB", 320, .12, 1.2),
                     "CCC": series("CCC", 320, .08, 2.1)}
        snapshots = {
            symbol: [{"available_at": long_data[symbol][100].ts, "as_of": "2025-Q4",
                      "eps": 2, "growth_pct": 10, "margin_pct": 5}]
            for symbol in long_data
        }
        with self.assertRaisesRegex(ValueError, "postérieur à available_at"):
            simulate_portfolio("multi_factor", long_data, fundamentals=snapshots, warmup=130)

    def test_multi_factor_rejects_ambiguous_reporting_period(self):
        long_data = {"AAA": series("AAA", 320, .22), "BBB": series("BBB", 320, .12, 1.2),
                     "CCC": series("CCC", 320, .08, 2.1)}
        snapshots = {
            symbol: [{"available_at": long_data[symbol][100].ts, "as_of": "FY-end-ish",
                      "eps": 2, "growth_pct": 10, "margin_pct": 5}]
            for symbol in long_data
        }
        with self.assertRaisesRegex(ValueError, "as_of invalide"):
            simulate_portfolio("multi_factor", long_data, fundamentals=snapshots, warmup=130)

    def test_multi_factor_rejects_missing_or_invalid_point_in_time_data(self):
        long_data = {"AAA": series("AAA", 320, .22), "BBB": series("BBB", 320, .12, 1.2),
                     "CCC": series("CCC", 320, .08, 2.1)}
        with self.assertRaisesRegex(ValueError, "point-in-time"):
            simulate_portfolio("multi_factor", long_data, warmup=130)
        bad = {
            symbol: [{"available_at": long_data[symbol][100].ts, "eps": True,
                      "growth_pct": 10, "margin_pct": 5}]
            for symbol in long_data
        }
        with self.assertRaisesRegex(ValueError, "Valeur eps"):
            simulate_portfolio("multi_factor", long_data, fundamentals=bad, warmup=130)

    def test_rejects_unsynchronised_and_unknown_universe(self):
        broken = dict(self.data)
        broken["BBB"] = broken["BBB"][:-1]
        with self.assertRaisesRegex(ValueError, "longueurs"):
            simulate_portfolio("momentum", broken)
        with self.assertRaisesRegex(ValueError, "inconnue"):
            simulate_portfolio("fake", self.data)


    def test_rejects_non_increasing_or_timezone_naive_timestamps(self):
        duplicate = {"AAA": series("AAA"), "BBB": series("BBB", phase=1.0)}
        duplicate["AAA"][10].ts = duplicate["AAA"][9].ts
        duplicate["BBB"][10].ts = duplicate["BBB"][9].ts
        with self.assertRaisesRegex(ValueError, "non croissants"):
            simulate_portfolio("dual_momentum", duplicate, params={"lookback": 60}, warmup=70)

        naive = {"AAA": series("AAA"), "BBB": series("BBB", phase=1.0)}
        naive["AAA"][0].ts = "2025-01-01T00:00:00"
        naive["BBB"][0].ts = "2025-01-01T00:00:00"
        with self.assertRaisesRegex(ValueError, "sans fuseau"):
            simulate_portfolio("dual_momentum", naive, params={"lookback": 60}, warmup=70)

    def test_rejects_negative_volume(self):
        broken = {"AAA": series("AAA"), "BBB": series("BBB", phase=1.0)}
        broken["AAA"][50].v = -1
        with self.assertRaisesRegex(ValueError, "Volume"):
            simulate_portfolio("dual_momentum", broken, params={"lookback": 60}, warmup=70)

    def test_segmented_resume_matches_monolithic_portfolio_state(self):
        params = {"lookback": 60, "top_n": 1, "exit_rank": 2,
                  "position_pct": .8, "abs_min": -0.2}
        mono = simulate_portfolio("dual_momentum", self.data, params=params,
                                  initial_cash=50_000, warmup=70)
        first = simulate_portfolio("dual_momentum", self.data, params=params,
                                   initial_cash=50_000, warmup=70,
                                   start_index=0, end_index=95)
        second = simulate_portfolio("dual_momentum", self.data, params=params,
                                    initial_cash=50_000, warmup=70,
                                    state=first["portfolio_state"],
                                    start_index=95, end_index=len(self.data["AAA"]))
        joined_curve = first["equity_curve"] + second["equity_curve"]
        self.assertEqual(joined_curve, mono["equity_curve"])
        self.assertEqual(second["portfolio_state"]["cash"], mono["portfolio_state"]["cash"])
        self.assertEqual(second["portfolio_state"]["positions"], mono["portfolio_state"]["positions"])
        self.assertEqual(second["portfolio_state"]["pending_intents"], mono["portfolio_state"]["pending_intents"])
        self.assertEqual(second["portfolio_state"]["fills"], mono["portfolio_state"]["fills"])
        self.assertEqual(second["portfolio_state"]["closed_trades"], mono["portfolio_state"]["closed_trades"])

    def test_execution_costs_are_accounted_and_accumulate_across_segments(self):
        params = {"lookback": 60, "top_n": 1, "exit_rank": 2,
                  "position_pct": .8, "abs_min": -0.2}
        mono = simulate_portfolio("dual_momentum", self.data, params=params,
                                  initial_cash=50_000, warmup=70, fee=0.001, slip=0.002)
        first = simulate_portfolio("dual_momentum", self.data, params=params,
                                   initial_cash=50_000, warmup=70, fee=0.001, slip=0.002,
                                   end_index=95)
        second = simulate_portfolio("dual_momentum", self.data, params=params,
                                    initial_cash=50_000, warmup=70, fee=0.001, slip=0.002,
                                    state=first["portfolio_state"], start_index=95)
        self.assertGreater(mono["costs"]["fees"], 0)
        self.assertGreater(mono["costs"]["slippage"], 0)
        self.assertAlmostEqual(second["costs"]["cumulative_fees"], mono["costs"]["fees"], places=7)
        self.assertAlmostEqual(second["costs"]["cumulative_slippage"], mono["costs"]["slippage"], places=7)
        self.assertAlmostEqual(
            first["costs"]["fees"] + second["costs"]["fees"], mono["costs"]["fees"], places=7)
        self.assertAlmostEqual(
            first["costs"]["slippage"] + second["costs"]["slippage"], mono["costs"]["slippage"], places=7)
        self.assertTrue(all("fees" in fill and "slippage_cost" in fill for fill in mono["fills"]))

    def test_segment_resume_rejects_missing_or_misaligned_state(self):
        with self.assertRaisesRegex(ValueError, "state is required"):
            simulate_portfolio("dual_momentum", self.data, params={"lookback": 60},
                               warmup=70, start_index=80)
        first = simulate_portfolio("dual_momentum", self.data, params={"lookback": 60},
                                   warmup=70, end_index=90)
        with self.assertRaisesRegex(ValueError, "index"):
            simulate_portfolio("dual_momentum", self.data, params={"lookback": 60},
                               warmup=70, state=first["portfolio_state"], start_index=91)

    def test_no_future_open_or_close_is_used_for_decision(self):
        # The last bar can execute a previously scheduled trade but cannot create a new fill.
        result = simulate_portfolio("dual_momentum", self.data,
                                    params={"lookback": 60, "top_n": 1, "exit_rank": 2,
                                            "position_pct": .8, "abs_min": -0.2}, warmup=70)
        self.assertTrue(all(fill["index"] < len(self.data["AAA"]) for fill in result["fills"]))
        self.assertEqual(len(result["equity_curve"]), len(self.data["AAA"]))


if __name__ == "__main__":
    unittest.main()
