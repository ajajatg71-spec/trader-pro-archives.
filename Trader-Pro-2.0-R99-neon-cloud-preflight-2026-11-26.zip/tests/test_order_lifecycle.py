import unittest
from services.order_lifecycle import evaluate_transition


class OrderLifecyclePolicyTests(unittest.TestCase):
    def test_submission_can_be_acknowledged(self):
        self.assertTrue(evaluate_transition("submitting", "accepted").allowed)

    def test_partial_fill_can_be_cancelled(self):
        self.assertTrue(evaluate_transition("partially_filled", "canceled").allowed)

    def test_cancel_request_can_race_with_fill(self):
        self.assertTrue(evaluate_transition("pending_cancel", "filled").allowed)

    def test_stale_active_snapshot_cannot_regress_filled(self):
        decision = evaluate_transition("filled", "new")
        self.assertFalse(decision.allowed)
        self.assertEqual(decision.reason, "stale_or_invalid_transition")

    def test_unknown_status_fails_closed(self):
        self.assertFalse(evaluate_transition("new", "mystery_status").allowed)

    def test_cancelled_to_filled_allowed_for_broker_confirmed_race(self):
        self.assertTrue(evaluate_transition("canceled", "filled").allowed)

    def test_rejected_is_terminal(self):
        self.assertFalse(evaluate_transition("rejected", "new").allowed)


if __name__ == "__main__":
    unittest.main()
