import tempfile
import unittest
from decimal import Decimal
from pathlib import Path
from sqlalchemy import create_engine, select, func
from db.base import Base
from db.models import OrderRecord, FillRecord, AccountSnapshotRecord, PositionSnapshotRecord, ReconciliationRunRecord, StrategyProposalRecord
from db.order_repository import OrderRepository
from db.session import build_session_factory
from services.reconciliation import ReconciliationService, ReconciliationError
from services.strategy_engine.persistence import StrategyPersistence


class FakeBroker:
    def __init__(self):
        self.remote_orders = []
        self.remote_fills = []
        self.fail = False
    def orders(self, status="all", limit=500):
        if self.fail: raise TimeoutError()
        return self.remote_orders[:limit]
    def fills(self, pages=10): return self.remote_fills
    def account(self): return {"equity": "10000", "cash": "5000", "buying_power": "8000"}
    def positions(self): return getattr(self, "remote_positions", [{"symbol": "AAPL", "qty": "2", "market_value": "400", "avg_entry_price": "190", "unrealized_pl": "20"}])


class ReconciliationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.engine = create_engine(f"sqlite:///{Path(self.tmp.name) / 'recon.db'}")
        Base.metadata.create_all(self.engine)
        self.sessions = build_session_factory(self.engine)
        self.repo = OrderRepository(self.sessions)
        self.broker = FakeBroker()
        self.service = ReconciliationService(self.repo, self.broker)
        self.repo.stage_order(client_order_id="cid-1", symbol="AAPL", side="buy", notional=400)
    def tearDown(self):
        self.engine.dispose(); self.tmp.cleanup()

    def test_matches_order_and_records_fill_once(self):
        self.broker.remote_orders = [{"id": "bid-1", "client_order_id": "cid-1", "symbol": "AAPL", "side": "buy", "status": "filled", "qty": "2"}]
        self.broker.remote_fills = [{"id": "fill-1", "order_id": "bid-1", "symbol": "AAPL", "side": "buy", "qty": "2", "price": "190", "fee": "0", "time": "2026-11-11T02:00:00Z"}]
        first = self.service.run()
        second = self.service.run()
        self.assertEqual(first["orders_updated"], 1)
        self.assertEqual(first["fills_recorded"], 1)
        self.assertEqual(second["fills_duplicate"], 1)
        with self.sessions() as s:
            order = s.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            self.assertEqual(order.status, "filled"); self.assertEqual(order.broker_order_id, "bid-1")
            self.assertEqual(s.scalar(select(func.count()).select_from(FillRecord)), 1)
            self.assertEqual(s.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 2)
            self.assertEqual(s.scalar(select(func.count()).select_from(PositionSnapshotRecord)), 2)
            runs = s.scalars(select(ReconciliationRunRecord)).all()
            self.assertEqual(len(runs), 2)
            self.assertTrue(all(len(run.evidence_hash) == 64 for run in runs))
            self.assertTrue(all(run.status == "succeeded" for run in runs))
            self.assertEqual(first["reconciliation_evidence"]["status"], "succeeded")

    def test_missing_remote_order_is_not_marked_failed_or_retryable(self):
        report = self.service.run()
        self.assertEqual(report["orders_missing_remote"], ["cid-1"])
        self.assertEqual(report["safe_to_retry"], [])
        self.assertEqual(report["reconciliation_evidence"]["status"], "inconclusive")
        self.assertFalse(report["reconciliation_evidence"]["snapshot_complete"])
        with self.sessions() as s:
            row = s.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            self.assertEqual(row.status, "submitting")

    def test_reconciliation_recovers_stale_submission_as_unknown_without_retry(self):
        from datetime import datetime, timezone, timedelta
        with self.sessions.begin() as session:
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            row.updated_at = datetime.now(timezone.utc) - timedelta(minutes=10)
        report = self.service.run()
        self.assertEqual(report["stale_submissions_recovered"], ["cid-1"])
        self.assertEqual(report["orders_missing_remote"], ["cid-1"])
        self.assertEqual(report["safe_to_retry"], [])
        with self.sessions() as session:
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            self.assertEqual(row.status, "submission_unknown")

    def test_stale_strategy_submission_is_marked_unknown_and_not_restored(self):
        from datetime import datetime, timezone, timedelta
        strategy = StrategyPersistence(self.sessions)
        strategy.stage(proposal_id="cid-1", symbol="AAPL", notional=400,
            allocation_pct=4, confidence=.8, regime="TRENDING",
            source_strategies=["momentum"], signals=[],
            pending_payload={"sym": "AAPL", "side": "buy", "amt": 400,
                             "source": "strategy_engine"})
        strategy.update_status("cid-1", "SUBMITTING")
        self.service = ReconciliationService(self.repo, self.broker, strategy)
        with self.sessions.begin() as session:
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            row.updated_at = datetime.now(timezone.utc) - timedelta(minutes=10)
        report = self.service.run()
        self.assertEqual(report["stale_submissions_recovered"], ["cid-1"])
        self.assertEqual(strategy.restore_pending(), {})
        with self.sessions() as session:
            proposal = session.get(StrategyProposalRecord, "cid-1")
            order = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            self.assertEqual(proposal.status, "SUBMISSION_UNKNOWN")
            self.assertEqual(order.status, "submission_unknown")

    def test_snapshot_persistence_failure_does_not_recover_stale_submission(self):
        from datetime import datetime, timezone, timedelta
        with self.sessions.begin() as session:
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            row.updated_at = datetime.now(timezone.utc) - timedelta(minutes=10)
        original = self.repo.record_reconciliation_snapshot
        def fail_snapshot(**kwargs):
            raise RuntimeError("simulated durable snapshot failure")
        self.repo.record_reconciliation_snapshot = fail_snapshot
        try:
            with self.assertRaisesRegex(RuntimeError, "durable snapshot failure"):
                self.service.run()
        finally:
            self.repo.record_reconciliation_snapshot = original
        with self.sessions() as session:
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            self.assertEqual(row.status, "submitting")
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)

    def test_broker_id_match_with_different_client_id_is_rejected_before_recovery(self):
        from datetime import datetime, timezone, timedelta
        with self.sessions.begin() as session:
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            row.broker_order_id = "bid-1"
            row.updated_at = datetime.now(timezone.utc) - timedelta(minutes=10)
        self.broker.remote_orders = [{"id": "bid-1", "client_order_id": "other-client",
            "symbol": "AAPL", "side": "buy", "status": "new", "qty": "2"}]
        with self.assertRaisesRegex(ReconciliationError, "client_order_id différent"):
            self.service.run()
        with self.sessions() as session:
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            self.assertEqual(row.status, "submitting")
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)

    def test_duplicate_remote_client_ids_with_whitespace_are_rejected(self):
        self.broker.remote_orders = [
            {"id": "bid-1", "client_order_id": "cid-1", "symbol": "AAPL", "side": "buy", "status": "new"},
            {"id": "bid-2", "client_order_id": " cid-1 ", "symbol": "AAPL", "side": "buy", "status": "new"},
        ]
        with self.assertRaisesRegex(ReconciliationError, "client_order_id dupliqué"):
            self.service.run()
        with self.sessions() as session:
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)

    def test_fill_without_timestamp_aborts_before_any_database_write(self):
        self.broker.remote_fills = [{"id": "fill-no-time", "order_id": "bid-1",
            "symbol": "AAPL", "side": "buy", "qty": "1", "price": "190", "fee": "0"}]
        with self.assertRaisesRegex(ReconciliationError, "Historique des exécutions contient des données invalides"):
            self.service.run()
        with self.sessions() as session:
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(PositionSnapshotRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(FillRecord)), 0)
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            self.assertEqual(row.status, "submitting")

    def test_broker_read_failure_does_not_write_snapshot(self):
        self.broker.fail = True
        with self.assertRaises(ReconciliationError): self.service.run()
        with self.sessions() as s:
            self.assertEqual(s.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)

    def test_malformed_remote_order_record_aborts_before_any_database_write(self):
        self.broker.remote_orders = [None]
        with self.assertRaisesRegex(ReconciliationError, "ordres contient un enregistrement mal formé"):
            self.service.run()
        with self.sessions() as session:
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(ReconciliationRunRecord)), 0)
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            self.assertEqual(row.status, "submitting")

    def test_malformed_remote_fill_record_aborts_before_any_database_write(self):
        self.broker.remote_orders = [{"id": "bid-1", "client_order_id": "cid-1",
            "symbol": "AAPL", "side": "buy", "status": "new", "qty": "2"}]
        self.broker.remote_fills = [None]
        with self.assertRaisesRegex(ReconciliationError, "exécutions contient un enregistrement mal formé"):
            self.service.run()
        with self.sessions() as session:
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(FillRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(ReconciliationRunRecord)), 0)

    def test_fill_with_invalid_numeric_fields_aborts_before_any_database_write(self):
        self.broker.remote_fills = [{"id": "fill-bad", "order_id": "unknown",
            "symbol": "AAPL", "side": "buy", "qty": "NaN", "price": "100",
            "time": "2026-11-15T10:00:00Z"}]
        with self.assertRaisesRegex(ReconciliationError, "exécutions contient des données invalides"):
            self.service.run()
        with self.sessions() as session:
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(FillRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(ReconciliationRunRecord)), 0)

    def test_fill_without_side_aborts_before_any_database_write(self):
        self.broker.remote_fills = [{"id": "fill-no-side", "order_id": "unknown",
            "symbol": "AAPL", "qty": "1", "price": "100", "time": "2026-11-15T10:00:00Z"}]
        with self.assertRaisesRegex(ReconciliationError, "sens invalide"):
            self.service.run()
        with self.sessions() as session:
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(FillRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(ReconciliationRunRecord)), 0)

    def test_duplicate_fill_ids_abort_before_any_database_write(self):
        base = {"id": "fill-duplicate", "order_id": "unknown", "symbol": "AAPL",
            "side": "buy", "qty": "1", "price": "100", "time": "2026-11-15T10:00:00Z"}
        self.broker.remote_fills = [base, dict(base)]
        with self.assertRaisesRegex(ReconciliationError, "Identifiant d'exécution dupliqué"):
            self.service.run()
        with self.sessions() as session:
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(FillRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(ReconciliationRunRecord)), 0)

    def test_malformed_remote_position_record_aborts_before_any_database_write(self):
        self.broker.remote_orders = []
        self.broker.remote_positions = [None]
        with self.assertRaisesRegex(ReconciliationError, "positions contient un enregistrement mal formé"):
            self.service.run()
        with self.sessions() as session:
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(ReconciliationRunRecord)), 0)

    def test_unrelated_remote_order_with_nonfinite_quantity_aborts_before_writes(self):
        self.broker.remote_orders = [{"id": "bid-unrelated", "client_order_id": "other-cid",
            "symbol": "MSFT", "side": "buy", "status": "new", "qty": "NaN", "filled_qty": "0"}]
        with self.assertRaisesRegex(ReconciliationError, "ordres contient des quantités invalides"):
            self.service.run()
        with self.sessions() as session:
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(ReconciliationRunRecord)), 0)
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            self.assertEqual(row.status, "submitting")

    def test_unrelated_remote_order_with_filled_qty_above_requested_aborts_before_writes(self):
        self.broker.remote_orders = [{"id": "bid-unrelated", "client_order_id": "other-cid",
            "symbol": "MSFT", "side": "sell", "status": "new", "qty": "1", "filled_qty": "2"}]
        with self.assertRaisesRegex(ReconciliationError, "ordres contient des quantités invalides"):
            self.service.run()
        with self.sessions() as session:
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)

    def test_order_dict_missing_identity_fields_aborts_before_writes(self):
        self.broker.remote_orders = [{"id": "bid-incomplete", "client_order_id": "cid-1",
            "symbol": "AAPL", "side": "buy"}]
        with self.assertRaisesRegex(ReconciliationError, "Snapshot des ordres incomplet"):
            self.service.run()
        with self.sessions() as session:
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(ReconciliationRunRecord)), 0)

    def test_position_with_invalid_or_duplicate_quantity_aborts_before_writes(self):
        for positions in (
            [{"symbol": "AAPL", "qty": "NaN"}],
            [{"symbol": "AAPL", "qty": "1"}, {"symbol": "AAPL", "qty": "2"}],
            [{"symbol": "AAPL", "qty": "0"}],
        ):
            with self.subTest(positions=positions):
                self.broker.remote_positions = positions
                with self.assertRaises(ReconciliationError):
                    self.service.run()
                with self.sessions() as session:
                    self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)
                    self.assertEqual(session.scalar(select(func.count()).select_from(ReconciliationRunRecord)), 0)

    def test_short_position_with_negative_quantity_and_market_value_is_persisted(self):
        self.broker.remote_orders = []
        self.broker.remote_positions = [{"symbol": "TSLA", "qty": "-2", "market_value": "-500",
            "avg_entry_price": "250", "unrealized_pl": "25"}]
        report = self.service.run()
        self.assertEqual(report["position_snapshot_count"], 1)
        with self.sessions() as session:
            row = session.scalar(select(PositionSnapshotRecord).where(PositionSnapshotRecord.symbol == "TSLA"))
            self.assertEqual(row.quantity, Decimal("-2"))
            self.assertEqual(row.market_value, Decimal("-500"))

    def test_nonfinite_position_market_value_aborts_before_stale_recovery(self):
        from datetime import datetime, timezone, timedelta
        with self.sessions.begin() as session:
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            row.updated_at = datetime.now(timezone.utc) - timedelta(minutes=10)
        self.broker.remote_positions = [{"symbol": "AAPL", "qty": "2", "market_value": "NaN"}]
        with self.assertRaisesRegex(ReconciliationError, "données numériques invalides"):
            self.service.run()
        with self.sessions() as session:
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            self.assertEqual(row.status, "submitting")
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)

    def test_nonfinite_account_equity_aborts_before_stale_recovery(self):
        from datetime import datetime, timezone, timedelta
        with self.sessions.begin() as session:
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            row.updated_at = datetime.now(timezone.utc) - timedelta(minutes=10)
        self.broker.account = lambda: {"equity": "Infinity", "cash": "5000", "buying_power": "8000"}
        with self.assertRaisesRegex(ReconciliationError, "Snapshot du compte"):
            self.service.run()
        with self.sessions() as session:
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            self.assertEqual(row.status, "submitting")
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)

    def test_duplicate_remote_client_ids_abort_before_writes(self):
        self.broker.remote_orders = [
            {"id": "b1", "client_order_id": "cid-1", "symbol": "AAPL", "side": "buy", "status": "new"},
            {"id": "b2", "client_order_id": "cid-1", "symbol": "AAPL", "side": "buy", "status": "new"},
        ]
        with self.assertRaises(ReconciliationError): self.service.run()
        with self.sessions() as s:
            self.assertEqual(s.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)

    def test_symbol_or_side_mismatch_aborts_without_snapshot(self):
        self.broker.remote_orders = [{"id": "bid-x", "client_order_id": "cid-1",
            "symbol": "MSFT", "side": "buy", "status": "filled", "qty": "2"}]
        with self.assertRaises(ReconciliationError): self.service.run()
        with self.sessions() as s:
            self.assertEqual(s.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)

    def test_truncated_order_snapshot_is_explicit_warning(self):
        self.broker.remote_orders = [{"id": "b1", "client_order_id": "x1", "symbol": "X", "side": "buy", "status": "new"}]
        report = self.service.run(order_limit=1)
        self.assertTrue(report["truncated_order_snapshot"])
        self.assertTrue(any("tronqué" in item for item in report["warnings"]))

    def test_partial_fill_during_cancel_is_recorded_and_quantity_reconciled(self):
        self.broker.remote_orders = [{"id": "bid-partial", "client_order_id": "cid-1",
            "symbol": "AAPL", "side": "buy", "status": "canceled",
            "qty": "2", "filled_qty": "0.75"}]
        self.broker.remote_fills = [
            {"id": "fill-partial-1", "order_id": "bid-partial", "symbol": "AAPL",
             "side": "buy", "qty": "0.5", "price": "190", "time": "2026-11-11T02:00:00Z"},
            {"id": "fill-partial-2", "order_id": "bid-partial", "symbol": "AAPL",
             "side": "buy", "qty": "0.25", "price": "191", "time": "2026-11-11T02:01:00Z"},
        ]
        report = self.service.run()
        self.assertEqual(report["fills_recorded"], 2)
        self.assertEqual(report["fill_quantity_checks"][0]["status"], "consistent")
        self.assertEqual(report["fill_quantity_checks"][0]["broker_filled_qty"], "0.75")
        with self.sessions() as session:
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            self.assertEqual(row.status, "canceled")
            self.assertEqual(session.scalar(select(func.count()).select_from(FillRecord)), 2)

    def test_partial_fill_missing_activity_is_reported_as_quantity_mismatch(self):
        self.broker.remote_orders = [{"id": "bid-partial", "client_order_id": "cid-1",
            "symbol": "AAPL", "side": "buy", "status": "canceled",
            "qty": "2", "filled_qty": "0.75"}]
        self.broker.remote_fills = []
        report = self.service.run()
        check = report["fill_quantity_checks"][0]
        self.assertEqual(check["status"], "mismatch")
        self.assertEqual(check["difference"], "0.75")
        self.assertTrue(any("Quantité exécutée différente" in warning for warning in report["warnings"]))

    def test_late_fill_after_cancellation_is_ingested_on_next_reconciliation(self):
        self.broker.remote_orders = [{"id": "bid-late", "client_order_id": "cid-1",
            "symbol": "AAPL", "side": "buy", "status": "canceled",
            "qty": "2", "filled_qty": "0.5"}]
        first = self.service.run()
        self.assertEqual(first["fill_quantity_checks"][0]["status"], "mismatch")
        self.broker.remote_fills = [{"id": "fill-late", "order_id": "bid-late", "symbol": "AAPL",
            "side": "buy", "qty": "0.5", "price": "190", "time": "2026-11-11T02:00:00Z"}]
        second = self.service.run()
        self.assertEqual(second["fills_recorded"], 1)
        self.assertEqual(second["fill_quantity_checks"][0]["status"], "consistent")
        with self.sessions() as session:
            self.assertEqual(session.scalar(select(func.count()).select_from(FillRecord)), 1)

    def test_fill_quantity_mismatch_makes_financial_reconciliation_inconclusive(self):
        self.broker.remote_orders = [{"id": "bid-fin-partial", "client_order_id": "cid-1",
            "symbol": "AAPL", "side": "buy", "status": "canceled",
            "qty": "2", "filled_qty": "0.5"}]
        self.broker.remote_fills = []
        report = self.service.run(opening_cash="10000")
        self.assertEqual(report["financial_reconciliation"]["status"], "inconclusive")
        self.assertEqual(report["financial_reconciliation"]["reason"], "fill_history_incomplete_or_unmatched")

    def test_remote_filled_status_with_incomplete_filled_qty_aborts_before_writes(self):
        self.broker.remote_orders = [{"id": "bid-bad", "client_order_id": "cid-1",
            "symbol": "AAPL", "side": "buy", "status": "filled",
            "qty": "2", "filled_qty": "1.5"}]
        with self.assertRaises(ReconciliationError):
            self.service.run()
        with self.sessions() as session:
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)

    def test_fill_symbol_mismatch_is_not_ingested(self):
        self.broker.remote_orders = [{"id": "bid-symbol", "client_order_id": "cid-1",
            "symbol": "AAPL", "side": "buy", "status": "partially_filled",
            "qty": "2", "filled_qty": "0.5"}]
        self.broker.remote_fills = [{"id": "fill-wrong-symbol", "order_id": "bid-symbol",
            "symbol": "MSFT", "side": "buy", "qty": "0.5", "price": "190",
            "time": "2026-11-11T02:00:00Z"}]
        report = self.service.run()
        self.assertEqual(report["fills_invalid"], 1)
        self.assertEqual(report["fills_recorded"], 0)
        self.assertEqual(report["fill_quantity_checks"][0]["status"], "mismatch")
        with self.sessions() as session:
            self.assertEqual(session.scalar(select(func.count()).select_from(FillRecord)), 0)

    def test_fill_side_mismatch_is_not_ingested(self):
        self.broker.remote_orders = [{"id": "bid-side", "client_order_id": "cid-1",
            "symbol": "AAPL", "side": "buy", "status": "partially_filled",
            "qty": "2", "filled_qty": "0.5"}]
        self.broker.remote_fills = [{"id": "fill-wrong-side", "order_id": "bid-side",
            "symbol": "AAPL", "side": "sell", "qty": "0.5", "price": "190",
            "time": "2026-11-11T02:00:00Z"}]
        report = self.service.run()
        self.assertEqual(report["fills_invalid"], 1)
        self.assertEqual(report["fills_recorded"], 0)
        self.assertEqual(report["fill_quantity_checks"][0]["status"], "mismatch")

    def test_strategy_proposal_is_closed_when_broker_order_is_confirmed(self):
        strategy_repo = StrategyPersistence(self.sessions)
        payload = {"sym": "AAPL", "side": "buy", "amt": 400, "source": "strategy_engine"}
        strategy_repo.stage(proposal_id="cid-1", symbol="AAPL", notional=400, allocation_pct=4,
            confidence=.8, regime="TRENDING", source_strategies=["momentum"], signals=[], pending_payload=payload)
        strategy_repo.update_status("cid-1", "SUBMITTING")
        self.broker.remote_orders = [{"id": "bid-1", "client_order_id": "cid-1", "symbol": "AAPL",
            "side": "buy", "status": "filled", "qty": "2"}]
        report = ReconciliationService(self.repo, self.broker, strategy_repo).run()
        self.assertEqual(report["orders_matched"], 1)
        self.assertEqual(strategy_repo.restore_pending(), {})

    def test_fill_without_execution_timestamp_aborts_before_any_database_write(self):
        self.broker.remote_orders = [{"id": "bid-no-time", "client_order_id": "cid-1",
            "symbol": "AAPL", "side": "buy", "status": "filled", "qty": "1", "filled_qty": "1"}]
        self.broker.remote_fills = [{"id": "fill-no-time", "order_id": "bid-no-time",
            "symbol": "AAPL", "side": "buy", "qty": "1", "price": "100"}]
        with self.assertRaisesRegex(ReconciliationError, "Historique des exécutions contient des données invalides"):
            self.service.run()
        with self.sessions() as session:
            self.assertEqual(session.scalar(select(func.count()).select_from(AccountSnapshotRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(PositionSnapshotRecord)), 0)
            self.assertEqual(session.scalar(select(func.count()).select_from(FillRecord)), 0)
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == "cid-1"))
            self.assertEqual(row.status, "submitting")

    def test_unmatched_fill_is_reported_not_guessed(self):
        self.broker.remote_fills = [{"id": "f-x", "order_id": "unknown", "symbol": "AAPL", "side": "buy", "qty": "1", "price": "10", "time": "2026-11-11T02:00:00Z"}]
        report = self.service.run()
        self.assertEqual(len(report["fills_unmatched"]), 1)
        self.assertEqual(report["fills_recorded"], 0)

    def test_financial_ledger_matches_cash_positions_and_equity(self):
        self.broker.remote_orders = [{"id": "bid-1", "client_order_id": "cid-1", "symbol": "AAPL",
            "side": "buy", "status": "filled", "qty": "2"}]
        self.broker.remote_fills = [{"id": "fill-1", "order_id": "bid-1", "symbol": "AAPL",
            "side": "buy", "qty": "2", "price": "190", "fee": "0", "time": "2026-11-11T02:00:00Z"}]
        self.broker.account = lambda: {"equity": "5400", "cash": "5000", "buying_power": "5000"}
        self.broker.positions = lambda: [{"symbol": "AAPL", "qty": "2", "market_value": "400",
            "avg_entry_price": "190", "unrealized_pl": "20"}]
        report = self.service.run(opening_cash="5380")
        self.assertEqual(report["financial_reconciliation"]["status"], "consistent")
        self.assertEqual(report["financial_reconciliation"]["ledger_cash"], "5000")
        self.assertEqual(report["financial_reconciliation"]["discrepancies"], [])

    def test_financial_reconciliation_flags_cash_and_position_mismatch(self):
        self.broker.remote_orders = [{"id": "bid-1", "client_order_id": "cid-1", "symbol": "AAPL",
            "side": "buy", "status": "filled", "qty": "2"}]
        self.broker.remote_fills = [{"id": "fill-1", "order_id": "bid-1", "symbol": "AAPL",
            "side": "buy", "qty": "2", "price": "190", "fee": "0", "time": "2026-11-11T02:00:00Z"}]
        self.broker.account = lambda: {"equity": "5500", "cash": "5100", "buying_power": "5100"}
        self.broker.positions = lambda: [{"symbol": "AAPL", "qty": "1", "market_value": "200"}]
        report = self.service.run(opening_cash="5380")
        result = report["financial_reconciliation"]
        self.assertEqual(result["status"], "mismatch")
        self.assertEqual({x["type"] for x in result["discrepancies"]}, {"position_quantity", "cash", "equity"})

    def test_financial_reconciliation_refuses_incomplete_fill_history(self):
        self.broker.remote_fills = [{"id": "fill-x", "order_id": "unknown", "symbol": "AAPL", "side": "buy", "qty": "1", "price": "10", "time": "2026-11-11T02:00:00Z"}]
        report = self.service.run(opening_cash="10000")
        self.assertEqual(report["financial_reconciliation"]["status"], "inconclusive")
        self.assertEqual(report["financial_reconciliation"]["reason"], "fill_history_incomplete_or_unmatched")

    def test_financial_reconciliation_rejects_nonfinite_opening_cash(self):
        result = self.service._reconcile_financials(
            opening_cash="NaN",
            broker_account={"cash": "1000", "equity": "1000"},
            broker_positions=[], cash_tolerance="0.01",
            quantity_tolerance="0.00000001", fills_complete=True)
        self.assertEqual(result["status"], "inconclusive")
        self.assertEqual(result["reason"], "invalid_tolerance_or_opening_cash")

    def test_financial_reconciliation_rejects_infinite_tolerance(self):
        result = self.service._reconcile_financials(
            opening_cash="1000",
            broker_account={"cash": "1000", "equity": "1000"},
            broker_positions=[], cash_tolerance="Infinity",
            quantity_tolerance="0.00000001", fills_complete=True)
        self.assertEqual(result["status"], "inconclusive")
        self.assertEqual(result["reason"], "invalid_tolerance_or_opening_cash")

    def test_financial_reconciliation_is_opt_in_without_opening_cash(self):
        report = self.service.run()
        self.assertEqual(report["financial_reconciliation"]["status"], "not_run")

    def test_sim_broker_full_financial_reconciliation(self):
        import sim_broker
        sim_broker.reset()
        order = sim_broker.order("AAPL", "buy", 1000, "paper-ledger-e2e")
        self.repo.stage_order(client_order_id="paper-ledger-e2e", symbol="AAPL", side="buy", notional=1000)
        sim_broker_service = ReconciliationService(self.repo, sim_broker)
        report = sim_broker_service.run(opening_cash=sim_broker.START, cash_tolerance="2.00")
        self.assertEqual(order["status"], "filled")
        self.assertEqual(report["financial_reconciliation"]["status"], "consistent")
        self.assertEqual(report["fills_recorded"], 1)
        self.assertEqual(report["financial_reconciliation"]["symbols_compared"], 1)

    def test_previously_recorded_fill_missing_from_broker_history_is_inconclusive(self):
        self.broker.remote_orders = [{"id": "bid-1", "client_order_id": "cid-1", "symbol": "AAPL",
            "side": "buy", "status": "filled", "qty": "2"}]
        self.broker.remote_fills = [{"id": "fill-1", "order_id": "bid-1", "symbol": "AAPL",
            "side": "buy", "qty": "2", "price": "190", "fee": "0", "time": "2026-11-11T02:00:00Z"}]
        self.service.run()
        self.broker.remote_fills = []
        report = self.service.run(opening_cash="5380")
        self.assertEqual(report["financial_reconciliation"]["status"], "inconclusive")


    def test_stale_broker_snapshot_cannot_regress_terminal_order(self):
        self.repo.update_order("cid-1", status="filled", broker_order_id="bid-1", quantity=2)
        self.broker.remote_orders = [{"id": "bid-1", "client_order_id": "cid-1",
            "symbol": "AAPL", "side": "buy", "status": "new", "qty": "2", "filled_qty": "2"}]
        report = self.service.run()
        local = self.repo.list_orders_for_reconciliation()
        self.assertEqual(local[0]["status"], "filled")
        self.assertEqual(report["orders_updated"], 0)
        self.assertTrue(any("Transition de statut refusée" in warning for warning in report["warnings"]))

    def test_cancelled_order_can_become_filled_when_broker_confirms_race(self):
        self.repo.update_order("cid-1", status="canceled", broker_order_id="bid-1", quantity=2)
        self.broker.remote_orders = [{"id": "bid-1", "client_order_id": "cid-1",
            "symbol": "AAPL", "side": "buy", "status": "filled", "qty": "2", "filled_qty": "2"}]
        report = self.service.run()
        local = self.repo.list_orders_for_reconciliation()
        self.assertEqual(local[0]["status"], "filled")
        self.assertEqual(report["orders_updated"], 1)


if __name__ == "__main__": unittest.main()
