import unittest
from datetime import date, datetime, timezone, timedelta
from decimal import Decimal
from research_v1.quant.corporate_actions import (
    CorporateActionError, CorporateActionEvent, point_in_time_events,
)

class CorporateActionContractTests(unittest.TestCase):
    def setUp(self):
        self.known = datetime(2025, 2, 1, tzinfo=timezone.utc)

    def test_valid_split_uses_new_shares_per_old_share(self):
        event = CorporateActionEvent("AAPL", "split", date(2025, 1, 15), self.known,
                                     "provider", split_ratio="2")
        self.assertEqual(event.split_ratio, Decimal("2"))

    def test_valid_dividend_requires_amount_and_currency(self):
        event = CorporateActionEvent("AAPL", "dividend", date(2025, 1, 15), self.known,
                                     "provider", cash_amount="0.25", currency="USD")
        self.assertEqual(event.cash_amount, Decimal("0.25"))

    def test_rejects_naive_availability(self):
        with self.assertRaises(CorporateActionError):
            CorporateActionEvent("AAPL", "split", date(2025, 1, 1), datetime(2025, 1, 2),
                                 "provider", split_ratio=2)

    def test_rejects_mixed_split_payload(self):
        with self.assertRaises(CorporateActionError):
            CorporateActionEvent("AAPL", "split", date(2025, 1, 1), self.known,
                                 "provider", split_ratio=2, currency="USD")

    def test_rejects_negative_dividend_and_invalid_currency(self):
        for amount, currency in ((-0.1, "USD"), (0.1, "US"), (0.1, "usd")):
            with self.subTest(amount=amount, currency=currency), self.assertRaises(CorporateActionError):
                CorporateActionEvent("AAPL", "dividend", date(2025, 1, 1), self.known,
                                     "provider", cash_amount=amount, currency=currency)

    def test_point_in_time_excludes_late_announcements(self):
        late = CorporateActionEvent("AAPL", "dividend", date(2025, 1, 10),
                                    self.known + timedelta(days=1), "provider",
                                    cash_amount="0.2", currency="USD")
        result = point_in_time_events([late], as_of=self.known)
        self.assertEqual(result, ())

    def test_point_in_time_excludes_future_ex_dates(self):
        future = CorporateActionEvent("AAPL", "split", date(2025, 2, 2), self.known,
                                      "provider", split_ratio=2)
        self.assertEqual(point_in_time_events([future], as_of=self.known), ())

    def test_point_in_time_selects_only_known_matching_symbol(self):
        a = CorporateActionEvent("AAPL", "split", date(2025, 1, 10), self.known,
                                 "provider", split_ratio=2)
        b = CorporateActionEvent("MSFT", "split", date(2025, 1, 10), self.known,
                                 "provider", split_ratio=2)
        self.assertEqual(point_in_time_events([b, a], as_of=self.known, symbol="AAPL"), (a,))

    def test_rejects_untyped_items(self):
        with self.assertRaises(CorporateActionError):
            point_in_time_events([{"symbol": "AAPL"}], as_of=self.known)

if __name__ == "__main__":
    unittest.main()
