import unittest, indicators as I, sentiment, thirteen_f as F, congress, scoring as S

XML = """<?xml version="1.0" encoding="UTF-8"?><informationTable xmlns="http://www.sec.gov/edgar/document/thirteenf/informationtable">
<infoTable><nameOfIssuer>APPLE INC</nameOfIssuer><cusip>037833100</cusip><value>1000</value><shrsOrPrnAmt><sshPrnamt>100</sshPrnamt></shrsOrPrnAmt></infoTable>
<infoTable><nameOfIssuer>APPLE INC</nameOfIssuer><cusip>037833100</cusip><value>500</value><shrsOrPrnAmt><sshPrnamt>50</sshPrnamt></shrsOrPrnAmt></infoTable>
<infoTable><nameOfIssuer>COCA COLA CO</nameOfIssuer><cusip>191216100</cusip><value>500</value><shrsOrPrnAmt><sshPrnamt>10</sshPrnamt></shrsOrPrnAmt></infoTable></informationTable>"""
UP = [x * x / 10 + x for x in range(1, 61)]
DOWN = [1000 - x * x / 10 - x for x in range(1, 61)]

class Ind(unittest.TestCase):
    def test_rsi_extremes(self): self.assertEqual(I.rsi(UP), 100.0); self.assertEqual(I.rsi(DOWN), 0.0)
    def test_rsi_flat_and_short(self): self.assertEqual(I.rsi([5] * 30), 50.0); self.assertIsNone(I.rsi([1, 2, 3]))
    def test_sma(self): self.assertEqual(I.sma([1, 2, 3, 4], 2), 3.5); self.assertIsNone(I.sma([1], 2))
    def test_macd(self):
        self.assertAlmostEqual(I.macd([10.0] * 40)[2], 0.0); self.assertGreater(I.macd(UP)[2], 0); self.assertLess(I.macd(DOWN)[2], 0)
        self.assertIsNone(I.macd([1] * 10))

class Sent(unittest.TestCase):
    def test_signs(self):
        self.assertGreater(sentiment.score(["Apple beats estimates, shares surge"]), 0)
        self.assertLess(sentiment.score(["Firm misses and plunges after probe"]), 0)
        self.assertLess(sentiment.score(["Company does not beat estimates"]), 0)
    def test_empty_and_neutral(self): self.assertIsNone(sentiment.score([])); self.assertEqual(sentiment.score(["Company holds meeting"]), 0.0)

class Thirteen(unittest.TestCase):
    def test_parse_aggregates(self):
        h = F.parse_infotable(XML); self.assertEqual(h["037833100"]["shares"], 150); self.assertEqual(h["037833100"]["value"], 1500)
    def test_diff(self):
        cur, prev = F.parse_infotable(XML), {"037833100": {"name": "APPLE INC", "shares": 100.0, "value": 1}, "999": {"name": "OLD CO", "shares": 5.0, "value": 1}}
        d = F.diff(prev, cur)
        self.assertEqual(d["increased"], [("037833100", "APPLE INC", 50.0)]); self.assertEqual(d["new"], [("191216100", "COCA COLA CO")]); self.assertEqual(d["sold"], [("999", "OLD CO")])
    def test_weights_and_tickers(self):
        self.assertAlmostEqual(F.weights(F.parse_infotable(XML))[0][1], 75.0)
        self.assertEqual(F.to_ticker("APPLE INC"), "AAPL"); self.assertEqual(F.to_ticker("Alphabet Inc."), "GOOGL"); self.assertIsNone(F.to_ticker("UNKNOWN CO"))

class Cong(unittest.TestCase):
    def test_net(self):
        rows = congress.parse("date,politician,ticker,type,amount\n2026-01-02,A,nvda,Purchase,1\n2026-01-03,B,NVDA,Sale,1\n2026-01-04,C,KO,Purchase,1\n2026-01-05,D,,Purchase,1")
        self.assertEqual(len(rows), 3); n = congress.net(rows); self.assertEqual(n["NVDA"], 0.0); self.assertEqual(n["KO"], 1.0)

class Score(unittest.TestCase):
    def test_tech(self): self.assertAlmostEqual(S.tech_signal(UP), 0.4); self.assertAlmostEqual(S.tech_signal(DOWN), -0.4); self.assertIsNone(S.tech_signal([1] * 10))
    def test_inst(self): self.assertEqual(S.inst_signal("A", {"A": {"new": 1}}), 1.0); self.assertIsNone(S.inst_signal("B", {}))
    def test_fund_val(self):
        self.assertEqual(S.fund_signal(15, 12), 1.0); self.assertEqual(S.fund_signal(5, 12), 0.0); self.assertIsNone(S.fund_signal(None, 1))
        self.assertEqual(S.valuation(10, 20), "sous-évalué"); self.assertEqual(S.valuation(30, 20), "surévalué"); self.assertIsNone(S.valuation(None, 20))
    def test_combine(self):
        sc, cov = S.combine({"tech": 1, "news": 1, "inst": 1, "congress": None, "fund": None}); self.assertEqual(sc, 100.0); self.assertAlmostEqual(cov, 0.85)
        self.assertIsNone(S.combine({"tech": None}))
    def test_decide(self):
        self.assertEqual(S.decide(70, 50, False, .9)[0], "acheter"); self.assertEqual(S.decide(70, 50, True, .9)[0], "garder")
        self.assertEqual(S.decide(70, 75, False, .9)[0], "garder"); self.assertEqual(S.decide(30, 50, True, .9)[0], "vendre")
        self.assertEqual(S.decide(30, 50, False, .9)[0], "garder"); self.assertEqual(S.decide(90, 50, False, .3)[0], "garder")
if __name__ == "__main__": unittest.main()
