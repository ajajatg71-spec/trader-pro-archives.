import math
import random
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

from research_v1.backtesting import scoreboard


def random_walk_bars(seed: int, n: int = 1000):
    rng = random.Random(seed)
    price = 100.0
    out = []
    for i in range(n):
        price *= math.exp(rng.gauss(0.0, 0.012))
        spread = price * rng.uniform(0.002, 0.018)
        out.append(SimpleNamespace(
            o=price * (1 + rng.uniform(-0.004, 0.004)),
            h=price + spread,
            l=max(0.01, price - spread),
            c=price,
            v=100_000 + rng.randrange(50_000),
            ts=(datetime(2020, 1, 1, tzinfo=timezone.utc) + timedelta(days=i)).isoformat(),
        ))
    # Ensure OHLC geometry includes open and close for every bar.
    for b in out:
        b.h = max(b.h, b.o, b.c)
        b.l = min(b.l, b.o, b.c)
    return out


class ResearchScoreboardTests(unittest.TestCase):
    def test_multiple_testing_threshold_increases_with_catalog_size(self):
        self.assertAlmostEqual(scoreboard.bonferroni_z(1), 1.96, places=2)
        self.assertAlmostEqual(scoreboard.bonferroni_z(50), 3.29, places=2)
        self.assertGreater(scoreboard.bonferroni_z(43), scoreboard.bonferroni_z(10))

    def test_verdict_ladder_never_claims_reliability(self):
        base = {"oos_trades": 60, "expectancy_pct": 0.8, "test_sharpe": 1.2,
                "bh_sharpe": 0.6, "t_stat": 4.0, "worst_dd_pct": -12.0,
                "degradation": 0.2}
        self.assertEqual(scoreboard.verdict(base, 3.2)[0], "prometteuse")
        self.assertEqual(scoreboard.verdict({**base, "oos_trades": 10}, 3.2)[0], "non démontrée")
        self.assertEqual(scoreboard.verdict({**base, "expectancy_pct": -0.1}, 3.2)[0], "rejetée")
        self.assertEqual(scoreboard.verdict({**base, "t_stat": 2.5}, 3.2)[0], "à surveiller")
        self.assertFalse(any("fiable" in item for item in scoreboard.VERDICTS))

    def test_oos_trade_count_excludes_trades_opened_before_split(self):
        closed = [
            {"entry_index": 50, "exit_index": 80, "return": 0.10},
            {"entry_index": 100, "exit_index": 120, "return": 0.05},
            {"entry_index": 130, "exit_index": 140, "return": -0.02},
            {"exit_index": 150, "return": 0.03},
        ]
        selected = scoreboard._fully_oos_closed_trades(closed, 100)
        self.assertEqual([item["exit_index"] for item in selected], [120, 140])

    def test_hac_statistic_is_conservative_for_short_or_constant_series(self):
        self.assertEqual(scoreboard._hac_t_stat([0.001] * 20), 0.0)
        self.assertEqual(scoreboard._hac_t_stat([0.001] * 100), 0.0)

    def test_multi_symbol_scoreboard_rejects_unsynchronised_sessions(self):
        first = random_walk_bars(5, n=150)
        second = random_walk_bars(6, n=150)
        second[-1].ts = (datetime(2021, 1, 1, tzinfo=timezone.utc) + timedelta(days=999)).isoformat()
        with self.assertRaisesRegex(ValueError, "synchronisés"):
            scoreboard.evaluate_catalog({"AAA": first, "BBB": second})

    def test_multi_symbol_scoreboard_rejects_unsynchronised_benchmark(self):
        bars = random_walk_bars(10, n=150)
        benchmark = random_walk_bars(11, n=150)
        benchmark[50].ts = (datetime.fromisoformat(benchmark[50].ts) + timedelta(hours=1)).isoformat()
        with self.assertRaisesRegex(ValueError, "Benchmark non synchronisé"):
            scoreboard.evaluate_catalog({"AAA": bars}, benches={"AAA": benchmark})

    def test_catalog_rejects_invalid_statistical_and_cost_parameters(self):
        bars = random_walk_bars(12, n=150)
        with self.assertRaisesRegex(ValueError, "split"):
            scoreboard.evaluate_catalog({"AAA": bars}, split=1.0)
        with self.assertRaisesRegex(ValueError, "alpha"):
            scoreboard.evaluate_catalog({"AAA": bars}, alpha=0.0)
        with self.assertRaisesRegex(ValueError, "fee"):
            scoreboard.evaluate_catalog({"AAA": bars}, fee=float("nan"))

    def test_random_walk_universe_does_not_produce_promising_strategies(self):
        data = {f"R{i}": random_walk_bars(100 + i) for i in range(6)}
        report = scoreboard.evaluate_catalog(data)
        self.assertEqual(report["tested"], 43)
        self.assertEqual(report["family_size"], 50)
        self.assertEqual(report["multiple_testing_method"], "Bonferroni two-sided across 43 per-symbol + 7 portfolio strategies")
        self.assertEqual(report["counts"]["prometteuse"], 0)
        self.assertEqual(sum(report["counts"].values()), 43)
        self.assertAlmostEqual(report["z_threshold"], scoreboard.bonferroni_z(50), places=2)
        self.assertGreater(report["z_threshold"], 3.0)
        self.assertTrue(report["caveats"])
        row = report["results"][0]
        self.assertEqual(row["t_stat_method"], "Newey-West HAC on daily equal-capital portfolio excess returns")
        self.assertIn("trade_t_stat", row)
        self.assertGreater(row["oos_daily_observations"], 0)


if __name__ == "__main__":
    unittest.main()
