import tempfile
import unittest
from datetime import datetime, timezone, timedelta
from pathlib import Path
from sqlalchemy import create_engine, select

from db.base import Base
from db.models import BrokerEventRecord
from db.session import build_session_factory
from services.broker_events import BrokerEventError, BrokerEventProcessor


class _Reconciliation:
    def __init__(self, error=None):
        self.error = error
        self.calls = 0

    def run(self):
        self.calls += 1
        if self.error:
            raise self.error
        return {"account_snapshot_saved": True,
                "truncated_order_snapshot": False,
                "truncated_fill_snapshot": False,
                "execution_health": {"status": "healthy"}}


class BrokerEventProcessorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.engine = create_engine(f"sqlite:///{Path(self.tmp.name) / 'events.db'}")
        Base.metadata.create_all(self.engine)
        self.sessions = build_session_factory(self.engine)
        self.reconciliation = _Reconciliation()
        self.processor = BrokerEventProcessor(self.sessions, self.reconciliation)

    def tearDown(self):
        self.engine.dispose()
        self.tmp.cleanup()

    def event(self, status="filled"):
        return {"event": status, "timestamp": "2026-11-13T10:00:00Z", "order": {
            "id": "broker-1", "client_order_id": "client-1", "symbol": "AAPL",
            "side": "buy", "status": status, "filled_qty": "1",
            "api_key": "MUST_NOT_BE_STORED"}, "secret": "MUST_NOT_BE_STORED"}

    def test_receive_persists_only_allowlisted_fields_and_deduplicates(self):
        self.assertTrue(self.processor.receive(event_id="evt-1", event=self.event()))
        self.assertFalse(self.processor.receive(event_id="evt-1", event=self.event()))
        with self.sessions() as session:
            row = session.scalar(select(BrokerEventRecord))
            self.assertEqual(row.status, "pending")
            self.assertEqual(row.client_order_id, "client-1")
            self.assertNotIn("secret", str(row.payload))
            self.assertNotIn("api_key", str(row.payload))

    def test_event_id_collision_with_different_payload_is_rejected(self):
        self.processor.receive(event_id="evt-2", event=self.event())
        with self.assertRaises(BrokerEventError):
            self.processor.receive(event_id="evt-2", event=self.event("canceled"))

    def test_receive_rejects_invalid_envelopes(self):
        with self.assertRaises(BrokerEventError):
            self.processor.receive(event_id="evt-3", event={"event": "fill", "order": "bad"})
        with self.assertRaises(BrokerEventError):
            self.processor.receive(event_id="", event=self.event())

    def test_pending_batch_triggers_one_reconciliation_and_marks_processed(self):
        self.processor.receive(event_id="evt-4", event=self.event())
        self.processor.receive(event_id="evt-5", event=self.event("canceled"))
        result = self.processor.process_pending()
        self.assertEqual(result["processed"], 2)
        self.assertEqual(self.reconciliation.calls, 1)
        with self.sessions() as session:
            rows = session.scalars(select(BrokerEventRecord).order_by(BrokerEventRecord.id)).all()
            self.assertTrue(all(row.status == "processed" and row.processed_at for row in rows))
            self.assertTrue(all(row.processing_at is None for row in rows))

    def test_reconciliation_failure_marks_batch_failed_for_retry(self):
        self.processor.receive(event_id="evt-6", event=self.event())
        self.reconciliation.error = TimeoutError()
        result = self.processor.process_pending()
        self.assertEqual(result["failed"], 1)
        with self.sessions() as session:
            row = session.scalar(select(BrokerEventRecord))
            self.assertEqual(row.status, "failed")
            self.assertEqual(row.attempts, 1)
            self.assertEqual(row.last_error, "TimeoutError")
            self.assertIsNone(row.processing_at)

    def test_abandoned_processing_event_is_reclaimed_only_after_timeout(self):
        self.processor.receive(event_id="evt-7", event=self.event())
        with self.sessions.begin() as session:
            row = session.scalar(select(BrokerEventRecord))
            row.status = "processing"
            row.processing_at = datetime.now(timezone.utc) - timedelta(minutes=10)
        result = self.processor.process_pending(stale_after_seconds=60)
        self.assertEqual(result["processed"], 1)
        self.assertEqual(self.reconciliation.calls, 1)

    def test_invalid_limits_fail_closed(self):
        with self.assertRaises(BrokerEventError):
            self.processor.process_pending(limit=0)
        with self.assertRaises(BrokerEventError):
            self.processor.process_pending(stale_after_seconds=1)


    def test_failed_event_uses_exponential_backoff_and_is_not_immediately_retried(self):
        self.processor.receive(event_id="evt-backoff", event=self.event())
        self.reconciliation.error = TimeoutError()
        first = self.processor.process_pending()
        self.assertEqual(first["failed"], 1)
        with self.sessions() as session:
            row = session.scalar(select(BrokerEventRecord))
            self.assertEqual(row.status, "failed")
            self.assertIsNotNone(row.next_attempt_at)
            retry_at = row.next_attempt_at
            if retry_at.tzinfo is None:  # SQLite drops timezone metadata.
                retry_at = retry_at.replace(tzinfo=timezone.utc)
            self.assertGreaterEqual((retry_at - datetime.now(timezone.utc)).total_seconds(), 25)
        second = self.processor.process_pending()
        self.assertEqual(second["claimed"], 0)
        self.assertEqual(self.reconciliation.calls, 1)

    def test_event_moves_to_dead_letter_after_max_attempts(self):
        processor = BrokerEventProcessor(self.sessions, self.reconciliation, max_attempts=1)
        processor.receive(event_id="evt-dead", event=self.event())
        self.reconciliation.error = TimeoutError()
        result = processor.process_pending()
        self.assertTrue(result["dead_letter"])
        with self.sessions() as session:
            row = session.scalar(select(BrokerEventRecord))
            self.assertEqual(row.status, "dead_letter")
            self.assertIsNone(row.next_attempt_at)
        self.assertEqual(processor.process_pending()["claimed"], 0)


    def test_incomplete_or_truncated_reconciliation_is_not_acknowledged(self):
        self.processor.receive(event_id="evt-incomplete", event=self.event())
        self.reconciliation.run = lambda: {
            "account_snapshot_saved": True,
            "truncated_order_snapshot": True,
            "truncated_fill_snapshot": False,
            "execution_health": {"status": "warning"},
        }
        result = self.processor.process_pending()
        self.assertEqual(result["processed"], 0)
        self.assertEqual(result["failed"], 1)
        with self.sessions() as session:
            row = session.scalar(select(BrokerEventRecord))
            self.assertEqual(row.status, "failed")
            self.assertIsNotNone(row.next_attempt_at)
            self.assertIsNone(row.processed_at)

    def test_reconciliation_without_durable_account_snapshot_is_not_acknowledged(self):
        self.processor.receive(event_id="evt-no-snapshot", event=self.event())
        self.reconciliation.run = lambda: {
            "account_snapshot_saved": False,
            "truncated_order_snapshot": False,
            "truncated_fill_snapshot": False,
            "execution_health": {"status": "healthy"},
        }
        result = self.processor.process_pending()
        self.assertEqual(result["failed"], 1)
        with self.sessions() as session:
            row = session.scalar(select(BrokerEventRecord))
            self.assertEqual(row.status, "failed")
            self.assertIsNone(row.processed_at)

    def test_stale_worker_cannot_acknowledge_event_after_lease_was_reclaimed(self):
        self.processor.receive(event_id="evt-fenced-success", event=self.event())

        class ReclaimDuringReconciliation(_Reconciliation):
            def run(inner_self):
                inner_self.calls += 1
                with self.sessions.begin() as session:
                    row = session.scalar(select(BrokerEventRecord).where(
                        BrokerEventRecord.event_id == "evt-fenced-success"))
                    row.processing_token = "new-owner-token"
                    row.processing_at = datetime.now(timezone.utc)
                return {"account_snapshot_saved": True,
                        "truncated_order_snapshot": False,
                        "truncated_fill_snapshot": False,
                        "execution_health": {"status": "healthy"}}

        self.processor.reconciliation = ReclaimDuringReconciliation()
        result = self.processor.process_pending()
        self.assertEqual(result["processed"], 0)
        self.assertEqual(result["superseded"], 1)
        with self.sessions() as session:
            row = session.scalar(select(BrokerEventRecord))
            self.assertEqual(row.status, "processing")
            self.assertEqual(row.processing_token, "new-owner-token")
            self.assertIsNone(row.processed_at)

    def test_stale_worker_failure_cannot_overwrite_reclaimed_lease(self):
        self.processor.receive(event_id="evt-fenced-failure", event=self.event())

        class ReclaimThenFail(_Reconciliation):
            def run(inner_self):
                inner_self.calls += 1
                with self.sessions.begin() as session:
                    row = session.scalar(select(BrokerEventRecord).where(
                        BrokerEventRecord.event_id == "evt-fenced-failure"))
                    row.processing_token = "new-owner-token"
                    row.processing_at = datetime.now(timezone.utc)
                raise TimeoutError()

        self.processor.reconciliation = ReclaimThenFail()
        result = self.processor.process_pending()
        self.assertEqual(result["failed"], 0)
        self.assertEqual(result["superseded"], 1)
        with self.sessions() as session:
            row = session.scalar(select(BrokerEventRecord))
            self.assertEqual(row.status, "processing")
            self.assertEqual(row.processing_token, "new-owner-token")
            self.assertIsNone(row.last_error)

    def test_retry_policy_configuration_is_validated(self):
        with self.assertRaises(ValueError):
            BrokerEventProcessor(self.sessions, self.reconciliation, max_attempts=0)
        with self.assertRaises(ValueError):
            BrokerEventProcessor(self.sessions, self.reconciliation, retry_base_seconds=60, retry_max_seconds=30)


if __name__ == "__main__":
    unittest.main()
