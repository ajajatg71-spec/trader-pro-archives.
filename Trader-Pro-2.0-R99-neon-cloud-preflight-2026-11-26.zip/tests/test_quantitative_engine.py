import math
import random
import unittest

import risklib
import scoring
from indicators import macd, rsi, sma
from services.quantitative import QuantitativeEngine, QuantitativeError


class QuantitativeEngineTests(unittest.TestCase):
    def setUp(self):
        self.engine = QuantitativeEngine()

    def test_snapshot_matches_original_v1_formulas_exactly(self):
        rng = random.Random(20261110)
        for length in (2, 14, 15, 34, 35, 50, 120, 250):
            closes = []
            price = 100.0
            for _ in range(length):
                price *= 1 + rng.uniform(-0.025, 0.025)
                closes.append(price)
            with self.subTest(length=length):
                result = self.engine.snapshot(closes)
                self.assertEqual(result.observations, len(closes))
                self.assertEqual(result.last_price, closes[-1])
                self.assertEqual(result.rsi, rsi(closes) if len(closes) > 14 else None)
                self.assertEqual(result.macd, macd(closes))
                self.assertEqual(result.sma, sma(closes, min(50, len(closes))))
                self.assertEqual(result.technical_signal, scoring.tech_signal(closes))
                self.assertEqual(result.daily_volatility, risklib.daily_vol(closes))
                expected_var = risklib.var_cvar(risklib.returns(closes)) or (None, None)
                self.assertEqual((result.historical_var, result.historical_cvar), expected_var)

    def test_evaluation_preserves_score_and_decision(self):
        closes = [100 + i * 0.7 + math.sin(i / 3) for i in range(100)]
        signals = {"tech": scoring.tech_signal(closes), "news": 0.2,
                   "inst": -0.1, "congress": None}
        expected_score, expected_coverage = scoring.combine(signals)
        expected_action, expected_reasons = scoring.decide(
            expected_score, rsi(closes), False, expected_coverage
        )
        result = self.engine.evaluate(closes, signals, held=False)
        self.assertEqual(result.score, expected_score)
        self.assertEqual(result.coverage, expected_coverage)
        self.assertEqual(result.action, expected_action)
        self.assertEqual(result.reasons, tuple(expected_reasons))

    def test_no_signals_returns_neutral_without_fabricating_score(self):
        result = self.engine.evaluate([10, 11, 12], {"tech": None}, held=False)
        self.assertIsNone(result.score)
        self.assertEqual(result.coverage, 0.0)
        self.assertEqual(result.action, "garder")

    def test_short_history_keeps_indicators_unavailable(self):
        result = self.engine.snapshot([10, 11, 12])
        self.assertIsNone(result.rsi)
        self.assertIsNone(result.macd)
        self.assertIsNone(result.technical_signal)
        self.assertIsNone(result.daily_volatility)

    def test_rejects_invalid_price_histories(self):
        invalid = ([], [1], [1, 0], [1, -1], [1, float("nan")],
                   [1, float("inf")], [1, "bad"])
        for closes in invalid:
            with self.subTest(closes=closes), self.assertRaises(QuantitativeError):
                self.engine.snapshot(closes)

    def test_rejects_wrong_input_shapes(self):
        for closes in (None, "123", b"123", 123):
            with self.subTest(closes=closes), self.assertRaises(QuantitativeError):
                self.engine.snapshot(closes)
        with self.assertRaises(QuantitativeError):
            self.engine.evaluate([1, 2], [], held=False)
        with self.assertRaises(QuantitativeError):
            self.engine.evaluate([1, 2], {}, held="no")

    def test_path_risk_metrics_are_reported_without_changing_v1_indicators(self):
        result = self.engine.snapshot([100, 120, 90, 110])
        self.assertAlmostEqual(result.cumulative_return_pct, 10.0)
        self.assertAlmostEqual(result.max_drawdown_pct, -25.0)
        self.assertAlmostEqual(result.best_day_pct, (110 / 90 - 1) * 100)
        self.assertAlmostEqual(result.worst_day_pct, (90 / 120 - 1) * 100)
        self.assertIsNone(result.annualized_volatility_pct)

    def test_annualized_volatility_uses_252_trading_days(self):
        closes = [100 + i * 0.4 + math.sin(i * 0.7) for i in range(30)]
        result = self.engine.snapshot(closes)
        self.assertAlmostEqual(
            result.annualized_volatility_pct,
            result.daily_volatility * math.sqrt(252) * 100,
        )

    def test_evaluation_rejects_non_finite_or_out_of_range_known_signals(self):
        for invalid in (float("nan"), float("inf"), -1.01, 1.01, "bad"):
            with self.subTest(invalid=invalid), self.assertRaises(QuantitativeError):
                self.engine.evaluate([10, 11, 12], {"tech": invalid}, held=False)

    def test_unknown_signals_do_not_affect_validation_or_score(self):
        base = self.engine.evaluate([10, 11, 12], {"tech": 0.25}, held=False)
        extended = self.engine.evaluate(
            [10, 11, 12], {"tech": 0.25, "future_factor": float("nan")}, held=False
        )
        self.assertEqual(base.score, extended.score)
        self.assertEqual(base.coverage, extended.coverage)

    def test_snapshot_is_immutable(self):
        result = self.engine.snapshot([10, 11, 12])
        with self.assertRaises((AttributeError, TypeError)):
            result.last_price = 99

    def test_rejects_boolean_values_in_numeric_price_and_scale_inputs(self):
        with self.assertRaises(QuantitativeError):
            self.engine.snapshot([100, True, 102])
        with self.assertRaises(QuantitativeError):
            self.engine.strategy_signals([100, 101, 102], momentum_scale_pct=True)
        with self.assertRaises(QuantitativeError):
            self.engine.strategy_signals([100, False, 102])

    def test_multi_asset_rejects_boolean_prices_and_weights(self):
        prices = [100, 101, 102]
        with self.assertRaises(QuantitativeError):
            self.engine.multi_asset_snapshot({"A": [100, True, 102]}, {"A": 1.0}, prices)
        with self.assertRaises(QuantitativeError):
            self.engine.multi_asset_snapshot({"A": prices}, {"A": True}, prices)
        with self.assertRaises(QuantitativeError):
            self.engine.multi_asset_snapshot({"A": prices}, {"A": 1.0}, [100, False, 102])

    def test_performance_rejects_boolean_returns_and_numeric_overflow(self):
        with self.assertRaises(QuantitativeError):
            self.engine.strategy_performance([0.01, True])
        with self.assertRaises(QuantitativeError):
            self.engine.strategy_performance([0.01, 0.02], risk_free_daily=True)
        with self.assertRaises(QuantitativeError):
            self.engine.strategy_performance([1e308, 1e308])

    def test_factor_attribution_rejects_boolean_and_impossible_factor_returns(self):
        closes = [100 + i for i in range(10)]
        with self.assertRaises(QuantitativeError):
            self.engine.factor_attribution(closes, {"market": [0.01, True] + [0.02] * 7})
        with self.assertRaises(QuantitativeError):
            self.engine.factor_attribution(closes, {"market": [-1.0] + [0.02] * 8})


if __name__ == "__main__":
    unittest.main()

class MultiAssetQuantitativeTests(unittest.TestCase):
    def setUp(self):
        self.engine = QuantitativeEngine()

    @staticmethod
    def prices(returns):
        values = [100.0]
        for daily_return in returns:
            values.append(values[-1] * (1.0 + daily_return))
        return values

    def test_correlations_betas_and_equal_weight_portfolio(self):
        market = [0.01, -0.02, 0.03, -0.01, 0.02, 0.015]
        asset_a = [2 * value for value in market]
        asset_b = [-value for value in market]
        result = self.engine.multi_asset_snapshot(
            {"AAA": self.prices(asset_a), "BBB": self.prices(asset_b)},
            {"AAA": 0.5, "BBB": 0.5}, self.prices(market),
        )
        self.assertAlmostEqual(result.correlation_matrix[0][0], 1.0)
        self.assertAlmostEqual(result.correlation_matrix[0][1], -1.0)
        self.assertAlmostEqual(result.correlation_matrix[1][0], -1.0)
        self.assertAlmostEqual(result.betas_vs_benchmark[0][1], 2.0)
        self.assertAlmostEqual(result.betas_vs_benchmark[1][1], -1.0)
        self.assertAlmostEqual(result.effective_number_of_positions, 2.0)
        self.assertAlmostEqual(result.daily_volatility_pct, risklib.stdev([0.5 * value for value in market]) * 100)

    def test_uncorrelated_returns_and_covariance_are_reported(self):
        a = [0.01, -0.01, 0.01, -0.01, 0.01, -0.01]
        b = [0.01, 0.01, -0.01, -0.01, 0.01, 0.01]
        result = self.engine.multi_asset_snapshot(
            {"A": self.prices(a), "B": self.prices(b)},
            {"A": 0.5, "B": 0.5}, self.prices([0.01, -0.01, 0.01, -0.01, 0.01, -0.01]),
        )
        self.assertAlmostEqual(result.correlation_matrix[0][1], 0.0, places=10)
        self.assertAlmostEqual(result.covariance_matrix[0][1], 0.0, places=10)
        self.assertIsNotNone(result.average_pairwise_correlation)

    def test_multi_asset_metrics_use_historical_var_sample_threshold(self):
        r = [0.002, -0.001, 0.003, -0.002, 0.001] * 5
        prices = self.prices(r)
        result = self.engine.multi_asset_snapshot(
            {"A": prices}, {"A": 1.0}, prices,
        )
        self.assertIsNotNone(result.historical_var_pct)
        self.assertIsNotNone(result.historical_cvar_pct)
        self.assertAlmostEqual(result.annualized_volatility_pct,
                               result.daily_volatility_pct * math.sqrt(252))
        self.assertAlmostEqual(result.betas_vs_benchmark[0][1], 1.0)

    def test_rejects_mismatched_calendar_or_weight_definitions(self):
        p = self.prices([0.01, -0.01, 0.02])
        with self.assertRaises(QuantitativeError):
            self.engine.multi_asset_snapshot({"A": p, "B": p[:-1]}, {"A": .5, "B": .5}, p)
        with self.assertRaises(QuantitativeError):
            self.engine.multi_asset_snapshot({"A": p}, {"A": .9}, p)
        with self.assertRaises(QuantitativeError):
            self.engine.multi_asset_snapshot({"A": p}, {"B": 1.0}, p)
        with self.assertRaises(QuantitativeError):
            self.engine.multi_asset_snapshot({"A": p}, {"A": 1.0}, p[:-1])

    def test_rejects_invalid_prices_and_weights(self):
        p = self.prices([0.01, -0.01, 0.02])
        for bad in (float("nan"), float("inf"), 0, -1, "bad"):
            with self.subTest(weight=bad), self.assertRaises(QuantitativeError):
                self.engine.multi_asset_snapshot({"A": p}, {"A": bad}, p)
        with self.assertRaises(QuantitativeError):
            self.engine.multi_asset_snapshot({"A": [100, 0, 102, 103]}, {"A": 1.0}, [100, 101, 102, 103])

    def test_multi_asset_snapshot_is_immutable(self):
        p = self.prices([0.01, -0.01, 0.02])
        result = self.engine.multi_asset_snapshot({"A": p}, {"A": 1.0}, p)
        with self.assertRaises((AttributeError, TypeError)):
            result.symbols = ("B",)

    def test_sector_concentration_risk_contributions_and_stress_scenarios(self):
        market = [0.01, -0.02, 0.03, -0.01, 0.02, 0.015]
        prices_a = self.prices([2 * value for value in market])
        prices_b = self.prices([value for value in market])
        result = self.engine.multi_asset_snapshot(
            {"AAA": prices_a, "BBB": prices_b},
            {"AAA": 0.6, "BBB": 0.4}, self.prices(market),
            sector_by_symbol={"AAA": "Technologie", "BBB": "Technologie"},
            stress_shocks_pct={"crise_10": 10, "crise_20": 20},
        )
        self.assertAlmostEqual(result.concentration_index, 0.52)
        self.assertAlmostEqual(result.largest_position_weight_pct, 60.0)
        self.assertEqual(result.sector_exposures_pct, (("Technologie", 100.0),))
        self.assertAlmostEqual(sum(v for _, v in result.risk_contributions_pct), 100.0)
        self.assertAlmostEqual(result.stress_scenarios[0][1], -16.0)
        self.assertAlmostEqual(result.stress_scenarios[1][1], -32.0)

    def test_stress_and_sector_inputs_are_strictly_validated(self):
        prices = self.prices([0.01, -0.01, 0.02, -0.02])
        with self.assertRaises(QuantitativeError):
            self.engine.multi_asset_snapshot(
                {"A": prices}, {"A": 1.0}, prices, sector_by_symbol={"B": "Tech"}
            )
        with self.assertRaises(QuantitativeError):
            self.engine.multi_asset_snapshot(
                {"A": prices}, {"A": 1.0}, prices, sector_by_symbol={"A": " "}
            )
        for invalid in (0, -1, 100.1, float("nan"), "bad"):
            with self.subTest(shock=invalid), self.assertRaises(QuantitativeError):
                self.engine.multi_asset_snapshot(
                    {"A": prices}, {"A": 1.0}, prices,
                    stress_shocks_pct={"crash": invalid},
                )

class FactorAttributionTests(unittest.TestCase):
    def setUp(self):
        self.engine = QuantitativeEngine()

    @staticmethod
    def prices(returns):
        values = [100.0]
        for daily_return in returns:
            values.append(values[-1] * (1.0 + daily_return))
        return values

    def test_recovers_single_factor_loading_and_alpha(self):
        factor = [((i % 7) - 3) * 0.002 for i in range(40)]
        asset = [0.0005 + 1.7 * value for value in factor]
        result = self.engine.factor_attribution(
            self.prices(asset), {"market": factor}
        )
        self.assertAlmostEqual(result.factor_loadings[0][1], 1.7, places=8)
        self.assertAlmostEqual(result.alpha_daily_pct, 0.05, places=8)
        self.assertAlmostEqual(result.r_squared, 1.0, places=10)
        self.assertAlmostEqual(result.residual_volatility_daily_pct, 0.0, places=8)

    def test_recovers_two_factor_loadings(self):
        market = [((i % 5) - 2) * 0.003 for i in range(60)]
        value = [(((i * 3) % 11) - 5) * 0.001 for i in range(60)]
        asset = [0.0002 + 1.2 * m - 0.6 * v for m, v in zip(market, value)]
        result = self.engine.factor_attribution(
            self.prices(asset), {"market": market, "value": value}
        )
        self.assertAlmostEqual(result.factor_loadings[0][1], 1.2, places=7)
        self.assertAlmostEqual(result.factor_loadings[1][1], -0.6, places=7)
        self.assertAlmostEqual(result.alpha_daily_pct, 0.02, places=7)
        self.assertGreater(result.r_squared, 0.999999)

    def test_rejects_insufficient_misaligned_nonfinite_and_collinear_factors(self):
        closes = self.prices([0.01, -0.01])
        with self.assertRaises(QuantitativeError):
            self.engine.factor_attribution(closes, {"f1": [0.1, 0.2]})
        closes_long = self.prices([((i % 9) - 4) * 0.001 for i in range(30)])
        factor = [((i % 9) - 4) * 0.001 for i in range(30)]
        with self.assertRaises(QuantitativeError):
            self.engine.factor_attribution(closes_long, {"f1": factor[:-1]})
        with self.assertRaises(QuantitativeError):
            self.engine.factor_attribution(closes_long, {"f1": [float("nan")] * 30})
        with self.assertRaises(QuantitativeError):
            self.engine.factor_attribution(closes_long, {"f1": factor, "f2": factor})

    def test_factor_snapshot_is_immutable(self):
        factor = [((i % 7) - 3) * 0.002 for i in range(40)]
        result = self.engine.factor_attribution(
            self.prices([0.0005 + 1.7 * value for value in factor]),
            {"market": factor},
        )
        with self.assertRaises((AttributeError, TypeError)):
            result.r_squared = 0.0

class StrategyPerformanceTests(unittest.TestCase):
    def setUp(self):
        self.engine = QuantitativeEngine()

    def test_strategy_performance_risk_adjusted_metrics(self):
        returns = [0.10, -0.20, 0.10, 0.05, -0.01]
        result = self.engine.strategy_performance(
            returns, benchmark_returns=returns, risk_free_daily=0.0,
        )
        self.assertEqual(result.observations, 5)
        self.assertAlmostEqual(result.cumulative_return_pct,
                               ((1.10 * 0.80 * 1.10 * 1.05 * 0.99) - 1) * 100)
        self.assertAlmostEqual(result.max_drawdown_pct, -20.0)
        self.assertAlmostEqual(result.hit_rate_pct, 60.0)
        self.assertAlmostEqual(result.profit_factor, 0.25 / 0.21)
        self.assertAlmostEqual(result.beta_vs_benchmark, 1.0)
        self.assertAlmostEqual(result.correlation_vs_benchmark, 1.0)
        self.assertIsNotNone(result.sharpe_ratio)
        self.assertIsNotNone(result.sortino_ratio)
        self.assertIsNotNone(result.calmar_ratio)

    def test_strategy_comparison_uses_common_calendar_and_correlations(self):
        market = [0.01, -0.02, 0.03, -0.01, 0.02]
        result = self.engine.compare_strategy_performance({
            "momentum": market,
            "inverse": [-value for value in market],
        }, benchmark_returns=market)
        self.assertEqual([name for name, _ in result.strategies], ["momentum", "inverse"])
        self.assertAlmostEqual(result.correlation_matrix[0][0], 1.0)
        self.assertAlmostEqual(result.correlation_matrix[0][1], -1.0)
        self.assertAlmostEqual(result.correlation_matrix[1][0], -1.0)
        self.assertAlmostEqual(result.strategies[0][1].beta_vs_benchmark, 1.0)
        self.assertAlmostEqual(result.strategies[1][1].beta_vs_benchmark, -1.0)

    def test_strategy_performance_rejects_bad_or_misaligned_inputs(self):
        for bad in (float("nan"), float("inf"), -1.0, "bad"):
            with self.subTest(value=bad), self.assertRaises(QuantitativeError):
                self.engine.strategy_performance([0.01, bad, -0.01])
        with self.assertRaises(QuantitativeError):
            self.engine.strategy_performance([0.01, -0.01], benchmark_returns=[0.01])
        with self.assertRaises(QuantitativeError):
            self.engine.strategy_performance([0.01, -0.01], risk_free_daily=float("nan"))
        with self.assertRaises(QuantitativeError):
            self.engine.compare_strategy_performance({"A": [0.01, -0.01], "B": [0.01]})

    def test_no_downside_or_no_drawdown_ratios_are_explicitly_unavailable(self):
        result = self.engine.strategy_performance([0.01, 0.02, 0.03])
        self.assertIsNone(result.sortino_ratio)
        self.assertIsNone(result.calmar_ratio)
        self.assertIsNone(result.profit_factor)


class StrategySignalModelTests(unittest.TestCase):
    def setUp(self):
        self.engine = QuantitativeEngine()

    def test_momentum_and_trend_models_are_positive_in_uptrend(self):
        closes = [100.0 + i for i in range(80)]
        result = self.engine.strategy_signals(closes)
        self.assertGreater(result.momentum, 0)
        self.assertGreater(result.trend_following, 0)
        self.assertTrue(all(ready for _, ready in result.model_readiness))
        self.assertLessEqual(abs(result.momentum), 1.0)
        self.assertLessEqual(abs(result.trend_following), 1.0)

    def test_mean_reversion_signal_is_contrarian_to_rsi(self):
        rising = [100.0 + i * 2 for i in range(40)]
        result = self.engine.strategy_signals(rising)
        self.assertEqual(result.rsi, 100.0)
        self.assertEqual(result.mean_reversion, -1.0)

    def test_warmup_windows_are_reported_as_unavailable(self):
        result = self.engine.strategy_signals([100, 101, 102, 103, 104])
        self.assertIsNone(result.momentum)
        self.assertIsNone(result.trend_following)
        self.assertIsNone(result.mean_reversion)
        self.assertEqual(result.model_readiness,
                         (("momentum", False), ("trend_following", False),
                          ("mean_reversion", False)))

    def test_signal_models_reject_invalid_prices_and_periods(self):
        for prices in ([100, 0, 101], [100, float("nan"), 101], [100, "bad"]):
            with self.subTest(prices=prices), self.assertRaises(QuantitativeError):
                self.engine.strategy_signals(prices)
        with self.assertRaises(QuantitativeError):
            self.engine.strategy_signals([100, 101, 102], fast_lookback=50, slow_lookback=20)
        with self.assertRaises(QuantitativeError):
            self.engine.strategy_signals([100, 101, 102], momentum_scale_pct=0)

    def test_signal_normalization_scales_are_configurable(self):
        prices = [100.0 + i for i in range(30)]
        default = self.engine.strategy_signals(prices)
        wider = self.engine.strategy_signals(prices, momentum_scale_pct=100)
        self.assertLess(abs(wider.momentum), abs(default.momentum))
