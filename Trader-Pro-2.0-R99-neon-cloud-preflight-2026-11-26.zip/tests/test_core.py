import unittest, core
T = [("AAPL", 22.04), ("AXP", 17.14), ("GOOGL", 12.62), ("KO", 10.86), ("BAC", 9.20)]
A = {"equity": "5000", "cash": "5000", "last_equity": "5000"}
L = {"max_order": 1500, "max_pos": 25, "min_cash": 10, "max_daily_loss": 3}

class Size(unittest.TestCase):
    def test_readme_example(self):
        a, c = core.size(T, 5000, 10, 25)
        self.assertEqual(c, {"AAPL"}); self.assertEqual(a["AAPL"], 1250.0)
        self.assertAlmostEqual(a["AXP"], 1118.13, 2); self.assertLessEqual(sum(a.values()), 4500.05)
    def test_equal_weights(self):
        a, c = core.size([("A", 1), ("B", 1)], 1000, 10, 90)
        self.assertEqual(a, {"A": 450.0, "B": 450.0}); self.assertFalse(c)
    def test_all_capped_keeps_cash(self):
        self.assertEqual(core.size([("A", 1), ("B", 1)], 1000, 0, 25)[0], {"A": 250.0, "B": 250.0})
    def test_empty(self): self.assertEqual(core.size([], 1000, 10, 25), ({}, set()))

class Risk(unittest.TestCase):
    def chk(s, o, pos=(), a=A, blocked=(), used=0): return core.check(o, a, list(pos), L, list(blocked), used)
    def test_ok(s): s.assertEqual(s.chk(("AAPL", "buy", 1000)), "")
    def test_blocked(s): s.assertEqual(s.chk(("TSLA", "buy", 100), blocked=["TSLA"]), "Ticker bloqué")
    def test_too_big(s): s.assertEqual(s.chk(("AAPL", "buy", 1600)), "Ordre trop gros")
    def test_position(s):
        s.assertEqual(s.chk(("AAPL", "buy", 300), pos=[{"symbol": "AAPL", "market_value": "1000"}]), "Position trop grosse")
    def test_cash_buffer(s): s.assertEqual(s.chk(("AAPL", "buy", 1000), a={**A, "cash": "1400"}), "Cash sous le coussin")
    def test_reserved_cash(s): s.assertEqual(s.chk(("AAPL", "buy", 1000), used=4000), "Cash sous le coussin")
    def test_sell_too_much(s): s.assertEqual(s.chk(("AAPL", "sell", 100)), "Vente supérieure à la position")
    def test_sell_ok(s): s.assertEqual(s.chk(("AAPL", "sell", 100), pos=[{"symbol": "AAPL", "market_value": "500"}]), "")
    def test_daily_loss(s):
        s.assertEqual(s.chk(("AAPL", "buy", 100), a={**A, "equity": "4800"}), "Perte journalière max atteinte")
        s.assertAlmostEqual(core.daily_loss({**A, "equity": "4800"}), -4.0)

class Rebal(unittest.TestCase):
    def test_outside_band(s):
        pos = [{"symbol": "A", "market_value": "3000"}, {"symbol": "B", "market_value": "1500"}]
        s.assertEqual(core.rebalance([("A", 1), ("B", 1)], pos, 5000, 10, 5), [("A", "sell", 750.0), ("B", "buy", 750.0)])
    def test_inside_band(s):
        pos = [{"symbol": "A", "market_value": "2300"}, {"symbol": "B", "market_value": "2200"}]
        s.assertEqual(core.rebalance([("A", 1), ("B", 1)], pos, 5000, 10, 5), [])
if __name__ == "__main__": unittest.main()
