import math, random, unittest
import backtest as B
UP = [100 + i for i in range(200)]

class Engine(unittest.TestCase):
    def test_buy_hold_no_cost(s):
        r = B.run(UP, "bh", {}, 10000); s.assertAlmostEqual(r["eq"][-1], 10000 * UP[-1] / UP[1], places=4); s.assertEqual(r["eq"][0], 10000)
    def test_executes_next_bar(s):
        B.STRATS["_t"] = lambda c, i, p, pos: 1 if i == 3 else pos
        try: r = B.run(UP, "_t", {}); s.assertEqual((r["pos"][3], r["pos"][4]), (0, 1))
        finally: del B.STRATS["_t"]
    def test_costs_hurt(s):
        s.assertLess(B.run(UP, "bh", {}, 10000, fee=.01, slip=.01)["eq"][-1], B.run(UP, "bh", {}, 10000)["eq"][-1])
    def test_sma_trades_on_cycle(s):
        s.assertGreater(len(B.run([100 + 20 * math.sin(i / 10) for i in range(400)], "sma", {"fast": 5, "slow": 40})["trades"]), 2)
    def test_no_lookahead(s):
        c = [100 + 10 * math.sin(i / 7) + i * .05 for i in range(300)]; p = {"fast": 5, "slow": 40}
        a, b = B.run(c[:200], "sma", p), B.run(c, "sma", p)
        s.assertEqual(a["pos"][:150], b["pos"][:150]); s.assertEqual(a["eq"][:150], b["eq"][:150])

class Metrics(unittest.TestCase):
    def test_drawdown(s): s.assertEqual(B.evaluate({"eq": [100, 50, 100], "trades": [], "pos": [1, 1, 1]})["max_dd_pct"], -50.0)
    def test_flat(s): s.assertEqual(B.evaluate({"eq": [100] * 10, "trades": [], "pos": [0] * 10})["sharpe"], 0.0)
    def test_winrate_and_window(s):
        res = {"eq": [100] * 10, "trades": [(2, .1), (5, -.1), (8, .2)], "pos": [1] * 10}
        s.assertEqual(B.evaluate(res)["win_rate_pct"], 66.7); s.assertEqual(B.evaluate(res, 4)["trades"], 2)
    def test_short(s): s.assertEqual(B.evaluate({"eq": [100], "trades": [], "pos": [0]})["return_pct"], 0.0)

def walk(seed, n, mu=0.0):
    random.seed(seed); c = [100.0]
    for _ in range(n): c.append(c[-1] * (1 + random.gauss(mu, .012)))
    return c

class Opt(unittest.TestCase):
    def test_structure_and_determinism(s):
        c = walk(3, 600, .0004); r1, r2 = B.optimize(c, "sma"), B.optimize(c, "sma")
        s.assertEqual(r1, r2); s.assertEqual(set(r1), {"strategy", "params", "realistic", "train", "test", "benchmark_train", "benchmark_test", "overfit", "mc", "curve"})
        s.assertLessEqual(len(r1["curve"]["strategy"]), 200); s.assertIn(r1["params"], B.GRIDS["sma"])
    def test_all_strategies_run(s):
        for n in B.STRATS: s.assertIn("sharpe", B.optimize(walk(4, 400), n)["test"])
    def test_noise_does_not_generalise(s):
        worse = 0
        for seed in range(8):
            r = B.optimize(walk(seed, 800), "rsi"); worse += r["test"]["sharpe"] <= r["train"]["sharpe"]
        s.assertGreaterEqual(worse, 4)
if __name__ == "__main__": unittest.main()

import risklib as R

class Rules(unittest.TestCase):
    CRASH = [100.0] * 20 + [100.0 - i for i in range(1, 41)]
    def setUp(s): B.STRATS["_once"] = lambda c, i, p, pos: 1 if i == 0 else pos
    def tearDown(s): B.STRATS.pop("_once", None)
    def test_stop_limits_loss(s):
        free = B.run(s.CRASH, "_once", {}, 10000)["eq"][-1]
        stopped = B.run(s.CRASH, "_once", {}, 10000, rules={"stop_loss_pct": 8})["eq"][-1]
        s.assertGreater(stopped, free); s.assertGreater(stopped, 8500)
    def test_cooldown_blocks_reentry(s):
        pos = B.run(s.CRASH, "bh", {}, 10000, rules={"stop_loss_pct": 8, "cooldown": 5})["pos"]
        first = next(i for i in range(len(pos) - 1) if pos[i] == 1 and pos[i + 1] == 0) + 1; run0 = 0
        while first + run0 < len(pos) and pos[first + run0] == 0: run0 += 1
        s.assertGreaterEqual(run0, 5)
    def test_vol_sizing_reduces_risk(s):
        c = walk(7, 500, .002)
        full = B.run(c, "bh", {}, 10000)["eq"]; sized = B.run(c, "bh", {}, 10000, sizing={"risk": 1, "k": 2, "max_frac": 0.25})["eq"]
        rf, rs = R.returns(full), R.returns(sized); s.assertLess(R.stdev(rs), R.stdev(rf))
        s.assertTrue(all(v > 0 for v in sized))
    def test_realistic_flag_and_mc(s):
        c = walk(5, 900, .0006); r = B.optimize(c, "sma", rules={"stop_loss_pct": 8, "trailing_pct": 12}, sizing={"risk": 1, "k": 2, "max_frac": .25})
        s.assertTrue(r["realistic"]); s.assertFalse(B.optimize(c, "sma")["realistic"])

class Boot(unittest.TestCase):
    def test_none_when_few(s): s.assertIsNone(B.bootstrap([.1, .2]))
    def test_order_and_determinism(s):
        t = [.05, -.03, .02, .04, -.01, .03]; a = B.bootstrap(t); s.assertEqual(a, B.bootstrap(t))
        s.assertLessEqual(a["p5"], a["p50"]); s.assertLessEqual(a["p50"], a["p95"])
    def test_all_winners_no_loss(s): s.assertEqual(B.bootstrap([.01] * 6)["prob_loss_pct"], 0.0)

class OutOfSampleIsolation(unittest.TestCase):
    def test_test_window_starts_flat_with_fresh_cash(self):
        prices = [100.0 + i for i in range(20)]
        split = 10
        result = B.run(prices, "bh", {}, cash=10000.0, start_index=split)
        self.assertTrue(all(position == 0 for position in result["pos"][:split]))
        self.assertEqual(result["eq"][:split], [10000.0] * split)
        self.assertEqual(result["pos"][split], 1)
        self.assertEqual(result["trades"], [])

    def test_out_of_sample_run_does_not_carry_pre_split_entry(self):
        B.STRATS["_early_only"] = lambda c, i, p, pos: 1 if i == 0 else pos
        try:
            prices = [100.0 + i for i in range(20)]
            result = B.run(prices, "_early_only", {}, start_index=10)
            self.assertTrue(all(position == 0 for position in result["pos"]))
            self.assertTrue(all(value == 10000.0 for value in result["eq"]))
            self.assertEqual(result["trades"], [])
        finally:
            del B.STRATS["_early_only"]

    def test_start_index_validation(self):
        for invalid in (-1, 20, True, 1.5):
            with self.subTest(start_index=invalid), self.assertRaises(ValueError):
                B.run([100.0] * 20, "bh", {}, start_index=invalid)

    def test_cagr_uses_number_of_return_intervals(self):
        equity = [100.0 + (10.0 * i / 252) for i in range(253)]
        result = B.evaluate({"eq": equity, "trades": [], "pos": [0] * len(equity)})
        self.assertAlmostEqual(result["cagr_pct"], 10.0, places=2)


    def test_optimize_includes_first_oos_entry_cost(self):
        prices = [100.0] * 40
        result = B.optimize(prices, "bh", split=0.5, fee=0.01, slip=0.0)
        self.assertAlmostEqual(result["test"]["return_pct"], -1.0, places=2)
        self.assertAlmostEqual(result["benchmark_test"]["return_pct"], -1.0, places=2)

    def test_optimize_test_metrics_equal_fresh_flat_test_run(self):
        prices = walk(21, 500, .0003)
        split = .6
        result = B.optimize(prices, "bh", split=split)
        split_index = int(len(prices) * split)
        test_run = B.run(prices, "bh", {}, 10000.0, .0005, .0005,
                         start_index=split_index)
        expected = B.evaluate(test_run, split_index - 1)
        expected["exposure_pct"] = round(
            sum(test_run["pos"][split_index:]) / (len(prices) - split_index) * 100, 1)
        self.assertEqual(result["test"], expected)

class WalkForward(unittest.TestCase):
    def test_walk_forward_windows_are_chronological_and_non_overlapping(self):
        prices = walk(101, 700, .0002)
        result = B.walk_forward(prices, "sma", train_size=200, test_size=50)
        self.assertEqual(len(result["folds"]), 10)
        for previous, current in zip(result["folds"], result["folds"][1:]):
            self.assertEqual(previous["test_end"], current["train_end"])
            self.assertGreaterEqual(current["test_start"], previous["test_end"])
        self.assertEqual(result["folds"][0]["train_start"], 0)
        self.assertEqual(result["folds"][0]["test_start"], 200)

    def test_each_fold_selects_params_from_training_only(self):
        prices = walk(102, 500, .0001)
        result = B.walk_forward(prices, "rsi", train_size=180, test_size=40)
        first = result["folds"][0]
        candidates = []
        for params in B.GRIDS["rsi"]:
            metrics = B.evaluate(B.run(prices[:first["train_end"]], "rsi", params),
                                 first["train_start"], first["train_end"])
            candidates.append((metrics["sharpe"], params))
        best_score = max(score for score, _ in candidates)
        self.assertEqual(first["params"], next(params for score, params in candidates if score == best_score))

    def test_oos_folds_start_with_fresh_cash_and_no_carried_positions(self):
        B.STRATS["_hold_after_first"] = lambda c, i, p, pos: 1 if i == 0 else pos
        B.GRIDS["_hold_after_first"] = [{}]
        try:
            prices = [100.0 + i for i in range(30)]
            result = B.walk_forward(prices, "_hold_after_first", train_size=10, test_size=5)
            self.assertTrue(all(fold["test"]["exposure_pct"] == 0.0 for fold in result["folds"]))
            self.assertEqual(result["aggregate_oos"]["return_pct"], 0.0)
        finally:
            del B.STRATS["_hold_after_first"]
            del B.GRIDS["_hold_after_first"]

    def test_rolling_training_window(self):
        result = B.walk_forward(walk(103, 450), "bh", train_size=120,
                                test_size=30, expanding=False)
        self.assertFalse(result["expanding"])
        self.assertEqual(result["folds"][1]["train_start"], 30)
        self.assertEqual(result["folds"][1]["train_end"] - result["folds"][1]["train_start"], 120)

    def test_rejects_overlapping_or_invalid_windows(self):
        prices = walk(104, 400)
        for kwargs in ({"train_size": 200, "test_size": 50, "step": 40},
                       {"train_size": 1, "test_size": 50},
                       {"train_size": 200, "test_size": 1},
                       {"train_size": 200, "test_size": 50, "step": True}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                B.walk_forward(prices, "sma", **kwargs)

    def test_requires_enough_history(self):
        with self.assertRaises(ValueError):
            B.walk_forward([100.0] * 100, "bh", train_size=80, test_size=30)

    def test_rolling_train_metrics_reset_exposure_at_window_start(self):
        # A signal that occurred before the rolling window must not create a
        # position or contribute PnL to the current training fold.
        B.STRATS["_pre_window_entry"] = lambda c, i, p, pos: 1 if i == 0 else pos
        B.GRIDS["_pre_window_entry"] = [{}]
        try:
            prices = [100.0 + i for i in range(50)]
            result = B.walk_forward(prices, "_pre_window_entry", train_size=10,
                                    test_size=5, expanding=False)
            fold = result["folds"][1]
            isolated = B.run(prices[:fold["train_end"]], "_pre_window_entry", {},
                             start_index=fold["train_start"])
            expected = B.evaluate(isolated, fold["train_start"], fold["train_end"])
            self.assertEqual(fold["train"], expected)
            self.assertEqual(fold["train"]["exposure_pct"], 0.0)
        finally:
            del B.STRATS["_pre_window_entry"]
            del B.GRIDS["_pre_window_entry"]

    def test_rolling_parameter_selection_ignores_pre_window_signals(self):
        B.STRATS["_window_sensitive"] = lambda c, i, p, pos: (
            1 if i == 0 and p["mode"] == 1 else pos
        )
        B.GRIDS["_window_sensitive"] = [{"mode": 0}, {"mode": 1}]
        try:
            prices = [100.0 + i for i in range(40)]
            result = B.walk_forward(prices, "_window_sensitive", train_size=10,
                                    test_size=5, expanding=False)
            # On the second fold, the only entry signal is before the rolling
            # training window. It must not make mode=1 appear profitable.
            self.assertEqual(result["folds"][1]["train_start"], 5)
            self.assertEqual(result["folds"][1]["params"], {"mode": 0})
        finally:
            del B.STRATS["_window_sensitive"]
            del B.GRIDS["_window_sensitive"]

class InputValidation(unittest.TestCase):
    def test_run_rejects_invalid_prices_and_costs(self):
        for prices in ([100.0], [100.0, 0.0], [100.0, float('nan')], [100.0, float('inf')]):
            with self.subTest(prices=prices), self.assertRaises(ValueError):
                B.run(prices, "bh", {})
        for kwargs in ({"fee": -0.01}, {"fee": 1.0}, {"slip": -0.01},
                       {"slip": 1.0}, {"cash": 0.0}, {"cash": float('nan')}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                B.run([100.0, 101.0], "bh", {}, **kwargs)

    def test_run_rejects_invalid_risk_configuration(self):
        for kwargs in ({"sizing": {"risk": 1, "k": 0}},
                       {"sizing": {"risk": 1, "k": 2, "max_frac": 1.1}},
                       {"sizing": {"risk": -1, "k": 2}},
                       {"rules": {"stop_loss_pct": 101}},
                       {"rules": {"cooldown": -1}}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                B.run([100.0, 101.0], "bh", {}, **kwargs)

    def test_optimize_rejects_invalid_split_and_strategy(self):
        prices = [100.0 + i for i in range(20)]
        for split in (0, 1, -0.1, 1.1, float('nan')):
            with self.subTest(split=split), self.assertRaises(ValueError):
                B.optimize(prices, "bh", split=split)
        with self.assertRaises(ValueError):
            B.optimize(prices, "unknown")

    def test_evaluate_rejects_invalid_equity_and_bounds(self):
        for result in ({"eq": [100, 0], "pos": [0, 0]},
                       {"eq": [100, float('nan')], "pos": [0, 0]},
                       {"eq": [100, 101], "pos": [0]}):
            with self.subTest(result=result), self.assertRaises(ValueError):
                B.evaluate(result)
        with self.assertRaises(ValueError):
            B.evaluate({"eq": [100, 101], "pos": [0, 0]}, lo=0, hi=3)

class WalkForwardAggregateMetrics(unittest.TestCase):

    def test_walk_forward_includes_first_oos_entry_cost_in_fold_and_aggregate(self):
        prices = [100.0] * 30
        result = B.walk_forward(prices, "bh", train_size=10, test_size=5,
                                fee=0.01, slip=0.0)
        self.assertTrue(result["folds"])
        for fold in result["folds"]:
            self.assertAlmostEqual(fold["test"]["return_pct"], -1.0, places=2)
            self.assertAlmostEqual(fold["benchmark_test"]["return_pct"], -1.0, places=2)
        self.assertLess(result["aggregate_oos"]["return_pct"], 0.0)
        self.assertLess(result["benchmark_aggregate_oos"]["return_pct"], 0.0)

    def test_aggregate_reports_real_exposure_and_completed_trades(self):
        prices = [100.0 + 20.0 * math.sin(i / 10.0) for i in range(500)]
        result = B.walk_forward(prices, "sma", train_size=150, test_size=50)
        self.assertGreater(result["aggregate_oos"]["exposure_pct"], 0.0)
        self.assertGreater(result["aggregate_oos"]["trades"], 0)
        self.assertGreater(result["benchmark_aggregate_oos"]["exposure_pct"], 90.0)

class BootstrapInputAndBlocks(unittest.TestCase):
    def test_rejects_invalid_sample_count(self):
        for n in (0, -1, 1.5, True):
            with self.subTest(n=n), self.assertRaises(ValueError):
                B.bootstrap([.01, -.01, .02, -.02, .03], n=n)

    def test_rejects_invalid_returns(self):
        for trades in ([.1, -.1, float('nan'), .2, .1],
                       [.1, -.1, float('inf'), .2, .1],
                       [.1, -.1, -1.0, .2, .1]):
            with self.subTest(trades=trades), self.assertRaises(ValueError):
                B.bootstrap(trades)

    def test_rejects_invalid_block_size(self):
        trades = [.05, -.03, .02, .04, -.01, .03]
        for size in (0, -1, 1.5, True, 7):
            with self.subTest(size=size), self.assertRaises(ValueError):
                B.bootstrap(trades, block_size=size)

    def test_block_bootstrap_is_deterministic_and_identified(self):
        trades = [.05, -.03, .02, .04, -.01, .03]
        first = B.bootstrap(trades, n=500, seed=7, block_size=2)
        self.assertEqual(first, B.bootstrap(trades, n=500, seed=7, block_size=2))
        self.assertEqual(first['method'], 'circular_block')
        self.assertEqual(first['block_size'], 2)
        self.assertEqual(first['bootstrap_samples'], 500)

    def test_default_remains_iid_compatible(self):
        result = B.bootstrap([.05, -.03, .02, .04, -.01, .03])
        self.assertEqual(result['method'], 'iid')
        self.assertEqual(result['block_size'], 1)

    def test_rejects_compounded_return_overflow(self):
        with self.assertRaises(OverflowError):
            B.bootstrap([1e308] * 5, n=10)

class StrictBacktestContracts(unittest.TestCase):
    def test_evaluate_requires_complete_result_shape(self):
        for result in (
            {"eq": [100.0, 101.0], "pos": [0, 0]},
            {"eq": [100.0, 101.0], "pos": [0, 0], "trades": None},
        ):
            with self.subTest(result=result), self.assertRaises(ValueError):
                B.evaluate(result)

    def test_evaluate_rejects_invalid_positions_and_trade_records(self):
        invalid = (
            {"eq": [100.0, 101.0], "pos": [0, 2], "trades": []},
            {"eq": [100.0, 101.0], "pos": [0, -1], "trades": []},
            {"eq": [100.0, 101.0], "pos": [0, 0], "trades": [(2, .1)]},
            {"eq": [100.0, 101.0], "pos": [0, 0], "trades": [(1, -1.0)]},
            {"eq": [100.0, 101.0], "pos": [0, 0], "trades": [(1, float('nan'))]},
            {"eq": [100.0, 101.0], "pos": [0, 0], "trades": [(1, .1, 'extra')]},
        )
        for result in invalid:
            with self.subTest(result=result), self.assertRaises(ValueError):
                B.evaluate(result)

    def test_builtin_strategy_parameters_are_validated(self):
        prices = [100.0 + i for i in range(20)]
        invalid = (
            ("bh", {"unexpected": 1}),
            ("sma", {"fast": 5, "slow": 5}),
            ("sma", {"fast": True, "slow": 10}),
            ("rsi", {"n": 14, "low": 70, "high": 30}),
            ("rsi", {"n": 1, "low": 20, "high": 70}),
            ("tech", {"buy": float('nan')}),
        )
        for strategy, params in invalid:
            with self.subTest(strategy=strategy, params=params), self.assertRaises(ValueError):
                B.run(prices, strategy, params)

    def test_builtin_strategy_parameters_accept_grid_values(self):
        prices = walk(404, 300)
        for strategy, grid in B.GRIDS.items():
            for params in grid:
                with self.subTest(strategy=strategy, params=params):
                    self.assertEqual(len(B.run(prices, strategy, params)["eq"]), len(prices))

class OhlcEngine(unittest.TestCase):
    def test_strategy_signal_executes_at_next_open(self):
        opens = [100, 101, 102, 103]
        highs = [101, 102, 103, 104]
        lows = [99, 100, 101, 102]
        closes = [100, 101, 102, 103]
        B.STRATS["_ohlc_test"] = lambda c, i, p, pos: 1 if i == 1 else pos
        try:
            result = B.run_ohlc(opens, highs, lows, closes, "_ohlc_test", {})
            self.assertEqual(result["pos"], [0, 0, 1, 1])
            self.assertEqual(result["execution_model"], "ohlc_next_open_conservative_stop_first")
        finally:
            del B.STRATS["_ohlc_test"]

    def test_gap_through_stop_fills_at_open(self):
        result = B.run_ohlc(
            [100, 100, 80], [100, 101, 85], [100, 99, 75], [100, 100, 82],
            "bh", {}, rules={"stop_loss_pct": 10})
        self.assertEqual(result["pos"], [0, 1, 0])
        self.assertAlmostEqual(result["eq"][2], 8000.0)

    def test_intrabar_stop_fills_at_stop_level(self):
        result = B.run_ohlc(
            [100, 100, 100], [100, 105, 102], [100, 95, 99], [100, 101, 100],
            "bh", {}, rules={"stop_loss_pct": 5})
        self.assertEqual(result["pos"], [0, 0, 0])
        self.assertAlmostEqual(result["eq"][1], 9500.0)

    def test_stop_wins_when_stop_and_target_hit_same_bar(self):
        result = B.run_ohlc(
            [100, 100, 100], [100, 120, 101], [100, 90, 99], [100, 105, 100],
            "bh", {}, rules={"stop_loss_pct": 5, "take_profit_pct": 10})
        self.assertEqual(result["pos"][1], 0)
        self.assertAlmostEqual(result["eq"][1], 9500.0)

    def test_rejects_inconsistent_ohlc(self):
        with self.assertRaises(ValueError):
            B.run_ohlc([100, 100], [100, 99], [100, 95], [100, 100], "bh", {})

    def test_rejects_mismatched_lengths(self):
        with self.assertRaises(ValueError):
            B.run_ohlc([100, 100], [100, 101], [99], [100, 100], "bh", {})

    def test_position_sizing_caps_ohlc_entry_and_preserves_cash(self):
        result = B.run_ohlc(
            [100, 100, 100], [100, 100, 100], [100, 100, 100],
            [100, 100, 100], "bh", {}, fee=0.01,
            sizing={"risk": 1.0, "k": 2.0, "max_frac": 0.25})
        # Volatility history is too short: max_frac is used, and entry fee
        # is reflected in marked equity without investing the unused cash.
        self.assertAlmostEqual(result["eq"][1], 9975.0)
        self.assertEqual(result["pos"][1], 1)

    def test_position_sizing_uses_pre_entry_volatility(self):
        closes = [100, 110, 95, 108, 92, 105, 105, 105]
        opens = list(closes)
        highs = [value + 1 for value in closes]
        lows = [value - 1 for value in closes]
        B.STRATS["_ohlc_sizing_test"] = lambda c, i, p, pos: 1 if i == 5 else pos
        try:
            sizing = {"risk": 1.0, "k": 2.0, "max_frac": 0.25}
            vol = B.risklib.daily_vol(closes[:6])
            expected_fraction = min(0.25, 0.01 / (2.0 * vol))
            result = B.run_ohlc(
                opens, highs, lows, closes, "_ohlc_sizing_test", {}, fee=0.01,
                sizing=sizing)
            self.assertAlmostEqual(result["eq"][6], 10000 - 10000 * expected_fraction * 0.01)
            self.assertEqual(result["pos"][6], 1)
        finally:
            del B.STRATS["_ohlc_sizing_test"]

    def test_rejects_ohlc_position_size_overflow_instead_of_returning_infinity(self):
        with self.assertRaises(OverflowError):
            B.run_ohlc(
                [1e-308, 1e-308], [1e-308, 1e-308],
                [1e-308, 1e-308], [1e-308, 1e-308],
                "bh", {}, cash=1e308)

    def test_rejects_ohlc_mark_to_market_overflow(self):
        # A finite entry can still overflow when the following close is extreme.
        with self.assertRaises(OverflowError):
            B.run_ohlc(
                [1.0, 1.0, 1e308], [1.0, 1.0, 1e308],
                [1.0, 1.0, 1e308], [1.0, 1.0, 1e308],
                "bh", {}, cash=1e100)

    def test_ohlc_sizing_rejects_invalid_configuration(self):
        with self.assertRaises(ValueError):
            B.run_ohlc(
                [100, 100], [100, 100], [100, 100], [100, 100],
                "bh", {}, sizing={"risk": 0, "k": 2, "max_frac": 0.25})

    def test_stop_cooldown_prevents_immediate_reentry(self):
        result = B.run_ohlc(
            [100, 100, 100, 100, 100, 100, 100],
            [100, 101, 101, 101, 101, 101, 101],
            [100, 95, 99, 99, 99, 99, 99],
            [100, 100, 100, 100, 100, 100, 100],
            "bh", {}, rules={"stop_loss_pct": 5, "cooldown": 2})
        self.assertEqual(result["pos"][:5], [0, 0, 0, 0, 0])
        self.assertEqual(result["pos"][5], 1)

class DownsideRiskMetrics(unittest.TestCase):
    def test_evaluate_reports_sortino_calmar_and_underwater_duration(self):
        result = B.evaluate({"eq": [100.0, 110.0, 105.0, 108.0, 112.0],
                             "trades": [], "pos": [1, 1, 1, 1, 1]})
        self.assertIsNotNone(result["sortino"])
        self.assertIsNotNone(result["calmar"])
        self.assertEqual(result["max_drawdown_duration_bars"], 2)

    def test_no_downside_or_no_drawdown_is_reported_as_not_defined(self):
        result = B.evaluate({"eq": [100.0, 101.0, 102.0],
                             "trades": [], "pos": [0, 0, 0]})
        self.assertIsNone(result["sortino"])
        self.assertIsNone(result["calmar"])
        self.assertEqual(result["max_drawdown_duration_bars"], 0)

    def test_single_observation_has_consistent_metric_schema(self):
        result = B.evaluate({"eq": [100.0], "trades": [], "pos": [0]})
        self.assertIn("sortino", result)
        self.assertIn("calmar", result)
        self.assertEqual(result["max_drawdown_duration_bars"], 0)
