import json
import tempfile
import threading
import unittest
from pathlib import Path

from services.state import StateService


class StateServiceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.service = StateService(
            limits={"max_pos": 20, "buffer": 5},
            strategy_defaults={"enabled": False, "scan_minutes": 60},
            secret="secret-token",
            state_path=str(self.root / "state.json"),
            history_path=str(self.root / "history.jsonl"),
            backup_dir=str(self.root / "backups"),
            lock=threading.RLock(),
        )

    def tearDown(self):
        self.temp.cleanup()

    def test_load_merges_defaults_and_persisted_values(self):
        (self.root / "state.json").write_text(json.dumps({"limits": {"max_pos": 10}, "strategy": {"enabled": True}}))
        state = self.service.load()
        self.assertEqual(state["limits"], {"max_pos": 10, "buffer": 5})
        self.assertEqual(state["strategy"], {"enabled": True, "scan_minutes": 60})
        self.assertEqual(state["pending"], {})

    def test_save_and_reload_round_trip(self):
        state = self.service.load()
        state["paused"] = True
        self.service.save(state)
        self.assertTrue(self.service.load()["paused"])

    def test_history_is_append_only_and_redacts_secret(self):
        self.service.append_history("auth", "bad secret-token", user="test")
        self.service.append_history("order", "paper order")
        rows = self.service.tail(10)
        self.assertEqual([row["kind"] for row in rows], ["order", "auth"])
        self.assertEqual(rows[1]["msg"], "bad ***")
        self.assertEqual(rows[1]["user"], "test")

    def test_missing_history_returns_empty_list(self):
        self.assertEqual(self.service.tail(20), [])


if __name__ == "__main__":
    unittest.main()
