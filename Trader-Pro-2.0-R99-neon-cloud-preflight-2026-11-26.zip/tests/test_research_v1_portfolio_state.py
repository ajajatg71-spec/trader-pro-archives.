import unittest

from research_v1.backtesting.portfolio_state import PortfolioState


class PortfolioStateTests(unittest.TestCase):
    def test_round_trip_preserves_positions_and_pending_intent(self):
        state = PortfolioState(
            universe=["AAA", "BBB"], cash=1250.0,
            positions={"AAA": {"qty": 2.5, "avg": 100.2, "held_since": "2025-01-02T00:00:00+00:00"}},
            pending_intents=[{
                "strategy": "momentum", "symbol": "BBB", "side": "buy",
                "kind": "entry", "reason": "ranked first", "weight": 0.2,
                "confidence": 0.8, "evidence": [], "notional": None,
                "decision_timestamp": "2025-01-03T00:00:00+00:00",
            }],
            last_index=12, last_timestamp="2025-01-03T00:00:00+00:00",
            last_equity=1500.0, cumulative_fees=1.2, cumulative_slippage=0.8,
            fills=[{"index": 3, "symbol": "AAA", "side": "buy"}],
            closed_trades=[],
        )
        restored = PortfolioState.from_dict(state.to_dict())
        self.assertEqual(restored.to_dict(), state.to_dict())

    def test_rejects_unknown_schema(self):
        with self.assertRaisesRegex(ValueError, "schema_version"):
            PortfolioState.from_dict({"universe": ["AAA"], "cash": 10, "schema_version": 9})

    def test_rejects_negative_cash_and_non_finite_position(self):
        with self.assertRaisesRegex(ValueError, "cash"):
            PortfolioState.from_dict({"universe": ["AAA"], "cash": -1})
        with self.assertRaisesRegex(ValueError, "qty"):
            PortfolioState.from_dict({
                "universe": ["AAA"], "cash": 10,
                "positions": {"AAA": {"qty": float("inf"), "avg": 1, "held_since": "2025-01-01"}},
            })

    def test_rejects_unknown_symbol_and_invalid_pending_side(self):
        with self.assertRaisesRegex(ValueError, "position symbol"):
            PortfolioState.from_dict({
                "universe": ["AAA"], "cash": 10,
                "positions": {"BBB": {"qty": 1, "avg": 1, "held_since": "2025-01-01"}},
            })
        with self.assertRaisesRegex(ValueError, "symbol or side"):
            PortfolioState.from_dict({
                "universe": ["AAA"], "cash": 10,
                "pending_intents": [{
                    "strategy": "momentum", "symbol": "AAA", "side": "short",
                    "kind": "entry", "reason": "bad",
                }],
            })

    def test_rejects_unstarted_state_with_timestamp(self):
        with self.assertRaisesRegex(ValueError, "unstarted"):
            PortfolioState.from_dict({
                "universe": ["AAA"], "cash": 10,
                "last_index": -1, "last_timestamp": "2025-01-01",
            })


if __name__ == "__main__":
    unittest.main()
