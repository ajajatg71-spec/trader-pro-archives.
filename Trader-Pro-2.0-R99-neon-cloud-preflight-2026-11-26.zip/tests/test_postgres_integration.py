"""Opt-in PostgreSQL integration checks.

Run only against a dedicated disposable database whose name contains 'test':
TRADER_PRO_TEST_DATABASE_URL='postgresql+psycopg://.../trader_pro_test' pytest -q tests/test_postgres_integration.py
"""
from __future__ import annotations

import os
import hashlib
import uuid
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier
from decimal import Decimal
from copy import deepcopy

import pytest
from sqlalchemy import create_engine, select, text, func
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import sessionmaker
from sqlalchemy.engine import make_url

TEST_DATABASE_URL = os.getenv("TRADER_PRO_TEST_DATABASE_URL", "").strip()
TEST_DATABASE_DISPOSABLE = os.getenv("TRADER_PRO_TEST_DATABASE_DISPOSABLE", "").strip().upper() == "YES"
pytestmark = pytest.mark.skipif(
    not TEST_DATABASE_URL or not TEST_DATABASE_DISPOSABLE,
    reason="Définir TRADER_PRO_TEST_DATABASE_URL et TRADER_PRO_TEST_DATABASE_DISPOSABLE=YES pour une base jetable",
)


def _engine():
    url = make_url(TEST_DATABASE_URL)
    if not url.database or "test" not in url.database.lower():
        pytest.fail("Sécurité : la base PostgreSQL de test doit avoir un nom contenant 'test'.")
    if (url.host or "").lower() not in {"localhost", "127.0.0.1", "::1"}:
        pytest.fail("Sécurité : les tests PostgreSQL destructifs sont limités à un serveur local jetable.")
    if not TEST_DATABASE_DISPOSABLE:
        pytest.fail("Sécurité : confirmer explicitement la base jetable avec TRADER_PRO_TEST_DATABASE_DISPOSABLE=YES.")
    return create_engine(TEST_DATABASE_URL, pool_pre_ping=True, pool_size=5, max_overflow=5)


@pytest.fixture(autouse=True)
def preserve_singleton_safety_state():
    """Restore singleton safety controls after each integration test.

    These tests deliberately toggle pause/safety/TOTP state to exercise row
    locking. Snapshotting the original values prevents a test run from leaving
    a persistent test database unpaused or weakening its TOTP replay fence.
    The suite still requires an explicitly disposable local PostgreSQL server.
    """
    if not TEST_DATABASE_URL or not TEST_DATABASE_DISPOSABLE:
        yield
        return

    from db.models import RiskControlStateRecord, SystemSafetyStateRecord, OperatorTotpStateRecord
    engine = _engine()
    Session = sessionmaker(engine, expire_on_commit=False)
    models = (
        (RiskControlStateRecord, 1, ("paused", "reason", "actor")),
        (SystemSafetyStateRecord, 1, ("status", "reason", "actor", "generation", "last_reconciliation_run_id")),
        (OperatorTotpStateRecord, 1, ("last_accepted_counter",)),
    )
    snapshots = []
    try:
        with Session() as session:
            for model, row_id, fields in models:
                row = session.get(model, row_id)
                if row is not None:
                    snapshots.append((model, row_id, {field: deepcopy(getattr(row, field)) for field in fields}))
        try:
            yield
        finally:
            # Restore even when an assertion or concurrent DB operation fails.
            with Session.begin() as session:
                for model, row_id, values in snapshots:
                    row = session.get(model, row_id)
                    if row is not None:
                        for field, value in values.items():
                            setattr(row, field, value)
    finally:
        engine.dispose()


def test_postgres_schema_constraints_and_fixed_precision():
    from db.models import OrderRecord, FillRecord

    engine = _engine()
    Session = sessionmaker(engine, expire_on_commit=False)
    client_id = f"pgtest-{uuid.uuid4().hex}"
    fill_id = f"pgfill-{uuid.uuid4().hex}"
    try:
        # The schema must already have been migrated explicitly; tests never
        # create/drop production tables or silently run migrations.
        with engine.connect() as connection:
            tables = set(connection.execute(text(
                "SELECT table_name FROM information_schema.tables WHERE table_schema='public'"
            )).scalars())
        required = {"orders", "fills", "account_snapshots", "risk_events", "audit_events", "strategy_proposals", "position_snapshots", "risk_control_state", "system_safety_state", "operator_auth_attempts", "operator_totp_state"}
        assert required <= tables, f"Migrations manquantes: {sorted(required - tables)}"

        with Session.begin() as session:
            order = OrderRecord(client_order_id=client_id, symbol="AAPL", side="buy",
                                notional=Decimal("1234.56789012"), status="accepted")
            session.add(order)
            session.flush()
            order_id = order.id
            session.add(FillRecord(broker_fill_id=fill_id, order_id=order_id, symbol="AAPL",
                                   quantity=Decimal("1.1234567890"), price=Decimal("123.45678901"),
                                   fee=Decimal("0.01000000"), executed_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc)))
        with Session() as session:
            row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == client_id))
            assert row is not None
            assert row.notional == Decimal("1234.56789012")
            assert row.fills[0].quantity == Decimal("1.1234567890")

        # Isolate the expected uniqueness failure so unrelated setup failures
        # cannot accidentally make this test pass.
        with pytest.raises(IntegrityError):
            with Session.begin() as session:
                session.add(FillRecord(broker_fill_id=fill_id, order_id=order_id, symbol="AAPL",
                                       quantity=Decimal("1"), price=Decimal("123"), fee=Decimal("0"),
                                       executed_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc)))
    finally:
        with Session.begin() as session:
            order = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == client_id))
            if order is not None:
                for fill in list(order.fills):
                    session.delete(fill)
                session.delete(order)
        engine.dispose()


def test_postgres_transaction_rollback_is_atomic():
    from db.models import AuditEventRecord
    engine = _engine()
    Session = sessionmaker(engine, expire_on_commit=False)
    marker = f"rollback-{uuid.uuid4().hex}"
    try:
        with pytest.raises(RuntimeError):
            with Session.begin() as session:
                session.add(AuditEventRecord(event_type="pg_test", message=marker, details={}))
                session.flush()
                raise RuntimeError("rollback probe")
        with Session() as session:
            count = session.scalar(select(AuditEventRecord.id).where(AuditEventRecord.message == marker))
            assert count is None
    finally:
        engine.dispose()


def test_postgres_concurrent_unique_client_order_id():
    from db.models import OrderRecord
    engine = _engine()
    Session = sessionmaker(engine, expire_on_commit=False)
    client_id = f"pgconcurrent-{uuid.uuid4().hex}"

    def insert_one():
        try:
            with Session.begin() as session:
                session.add(OrderRecord(client_order_id=client_id, symbol="MSFT", side="buy",
                                        notional=Decimal("100"), status="submitting"))
            return "inserted"
        except IntegrityError:
            return "duplicate"

    try:
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(lambda _: insert_one(), range(2)))
        assert sorted(results) == ["duplicate", "inserted"]
    finally:
        engine.dispose()


def test_postgres_operational_kill_switch_persists_and_audits():
    from db.order_repository import OrderRepository
    from db.models import RiskControlStateRecord, AuditEventRecord

    engine = _engine()
    Session = sessionmaker(engine, expire_on_commit=False)
    repo = OrderRepository(Session)
    marker = f"pg-kill-{uuid.uuid4().hex}"
    try:
        with Session() as session:
            initial = session.get(RiskControlStateRecord, 1)
            assert initial is not None, "La migration doit créer la ligne singleton du coupe-circuit"
            assert initial.paused is False

        repo.set_operational_pause(paused=True, reason=marker, actor="pg_integration")
        # A new repository instance and session emulate a process restart.
        restarted = OrderRepository(sessionmaker(engine, expire_on_commit=False))
        state = restarted.get_operational_pause()
        assert state["paused"] is True
        assert state["reason"] == marker
        assert state["actor"] == "pg_integration"

        with Session() as session:
            events = session.scalars(select(AuditEventRecord).where(
                AuditEventRecord.event_type == "emergency_pause"
            )).all()
            assert any(event.details.get("reason") == marker for event in events)

        restarted.set_operational_pause(paused=False, reason=None, actor="pg_integration")
        assert repo.get_operational_pause()["paused"] is False
    finally:
        # Restore the migrated default for subsequent tests; audit history remains.
        with Session.begin() as session:
            row = session.get(RiskControlStateRecord, 1)
            if row is not None:
                row.paused, row.reason, row.actor = False, None, "system"
        engine.dispose()



def test_postgres_concurrent_kill_switch_transitions_are_audited():
    from db.order_repository import OrderRepository
    from db.models import AuditEventRecord, RiskControlStateRecord

    engine = _engine()
    Session = sessionmaker(engine, expire_on_commit=False)
    repo = OrderRepository(Session)
    marker = f"pg-kill-concurrent-{uuid.uuid4().hex}"
    transitions = [True, False, True, False, True, False]

    def transition(index_and_state):
        index, paused = index_and_state
        OrderRepository(sessionmaker(engine, expire_on_commit=False)).set_operational_pause(
            paused=paused, reason=f"{marker}-{index}", actor="pg_concurrency_test"
        )
        return index

    try:
        with Session.begin() as session:
            row = session.get(RiskControlStateRecord, 1)
            assert row is not None
            row.paused, row.reason, row.actor = False, None, "system"
        with ThreadPoolExecutor(max_workers=6) as pool:
            completed = list(pool.map(transition, enumerate(transitions)))
        assert sorted(completed) == list(range(len(transitions)))
        with Session() as session:
            events = session.scalars(select(AuditEventRecord).where(
                AuditEventRecord.details["actor"].as_string() == "pg_concurrency_test",
                AuditEventRecord.message.in_(["Coupe-circuit activé", "Reprise du trading autorisée"]),
            )).all()
            matching = [event for event in events if str(event.details.get("reason", "")).startswith(marker)]
            assert len(matching) == len(transitions)
    finally:
        with Session.begin() as session:
            row = session.get(RiskControlStateRecord, 1)
            if row is not None:
                row.paused, row.reason, row.actor = False, None, "system"
        engine.dispose()


def test_postgres_atomic_order_claim_obeys_locked_durable_pause():
    from db.order_repository import OrderRepository
    from db.models import OrderRecord, RiskControlStateRecord, AuditEventRecord

    engine = _engine()
    Session = sessionmaker(engine, expire_on_commit=False)
    repo = OrderRepository(Session)
    client_id = f"pg-paused-claim-{uuid.uuid4().hex}"
    marker = f"pg-paused-claim-reason-{uuid.uuid4().hex}"
    try:
        repo.set_operational_pause(paused=True, reason=marker, actor="pg_claim_test")
        with pytest.raises(PermissionError):
            repo.stage_order_if_trading_enabled(client_order_id=client_id,
                symbol="AAPL", side="buy", notional=100, source="pg_test")
        with Session() as session:
            assert session.scalar(select(OrderRecord).where(
                OrderRecord.client_order_id == client_id)) is None
            blocked = session.scalar(select(AuditEventRecord).where(
                AuditEventRecord.event_type == "order_submission_blocked",
                AuditEventRecord.correlation_id == client_id))
            assert blocked is not None
            assert blocked.details["gate"] == "DURABLE_PAUSE_ATOMIC_CLAIM"
    finally:
        with Session.begin() as session:
            row = session.get(RiskControlStateRecord, 1)
            if row is not None:
                row.paused, row.reason, row.actor = False, None, "system"
        engine.dispose()


def test_postgres_concurrent_buy_claims_cannot_overreserve_aggregate_budget():
    """Concurrent workers serialize on the durable pause row and reserve once."""
    from db.order_repository import OrderRepository
    from db.models import OrderRecord, RiskControlStateRecord, SystemSafetyStateRecord, AuditEventRecord

    engine = _engine()
    Session = sessionmaker(engine, expire_on_commit=False)
    barrier = Barrier(2)
    ids = [f"pg-budget-race-{uuid.uuid4().hex}" for _ in range(2)]

    with Session() as session:
        terminal = {"filled", "canceled", "cancelled", "expired", "rejected", "done_for_day", "replaced"}
        existing_total = session.scalar(select(func.coalesce(func.sum(OrderRecord.notional), 0)).where(
            OrderRecord.side == "buy", OrderRecord.status.not_in(terminal)))
        existing_symbol = session.scalar(select(func.coalesce(func.sum(OrderRecord.notional), 0)).where(
            OrderRecord.side == "buy", OrderRecord.symbol == "AAPL", OrderRecord.status.not_in(terminal)))
    total_ceiling = Decimal(str(existing_total)) + Decimal("150")
    symbol_ceiling = Decimal(str(existing_symbol)) + Decimal("150")

    def claim(client_id):
        repo = OrderRepository(Session)
        barrier.wait(timeout=10)
        try:
            repo.stage_order_if_trading_enabled(client_order_id=client_id,
                symbol="AAPL", side="buy", notional=100,
                max_total_buy_reservations=total_ceiling,
                max_symbol_buy_reservation=symbol_ceiling,
                external_open_buy_orders=[])
            return "accepted"
        except PermissionError:
            return "blocked"

    try:
        with Session.begin() as session:
            pause = session.get(RiskControlStateRecord, 1)
            safety = session.get(SystemSafetyStateRecord, 1)
            assert pause is not None and safety is not None
            pause.paused, pause.reason, pause.actor = False, None, "system"
            safety.status, safety.reason = "READY", None
        with ThreadPoolExecutor(max_workers=2) as pool:
            outcomes = list(pool.map(claim, ids))
        assert sorted(outcomes) == ["accepted", "blocked"]
        with Session() as session:
            rows = session.scalars(select(OrderRecord).where(OrderRecord.client_order_id.in_(ids))).all()
            assert len(rows) == 1
            blocked = session.scalar(select(AuditEventRecord).where(
                AuditEventRecord.event_type == "order_submission_blocked",
                AuditEventRecord.correlation_id.in_(ids),
                AuditEventRecord.details["gate"].as_string() == "ATOMIC_AGGREGATE_BUY_RESERVATION"))
            assert blocked is not None
    finally:
        with Session.begin() as session:
            session.query(OrderRecord).filter(OrderRecord.client_order_id.in_(ids)).delete(synchronize_session=False)
            session.query(AuditEventRecord).filter(AuditEventRecord.correlation_id.in_(ids)).delete(synchronize_session=False)
        engine.dispose()


def test_postgres_pause_and_order_claim_are_serialized_as_one_gate():
    """The pause transition and submission claim must have one DB ordering."""
    from db.order_repository import OrderRepository
    from db.models import OrderRecord, RiskControlStateRecord

    engine = _engine()
    Session = sessionmaker(engine, expire_on_commit=False)
    client_id = f"pg-pause-race-{uuid.uuid4().hex}"
    barrier = Barrier(2)

    def claim_order():
        barrier.wait(timeout=10)
        repo = OrderRepository(sessionmaker(engine, expire_on_commit=False))
        try:
            claimed = repo.stage_order_if_trading_enabled(
                client_order_id=client_id, symbol="SPY", side="buy", notional=Decimal("10"),
                source="pg_pause_race_test",
            )
            return "claimed" if claimed else "already_claimed"
        except PermissionError:
            return "blocked"

    def activate_pause():
        barrier.wait(timeout=10)
        OrderRepository(sessionmaker(engine, expire_on_commit=False)).set_operational_pause(
            paused=True, reason=f"race-{client_id}", actor="pg_pause_race_test"
        )
        return "paused"

    try:
        with Session.begin() as session:
            row = session.get(RiskControlStateRecord, 1)
            assert row is not None
            row.paused, row.reason, row.actor = False, None, "system"
        with ThreadPoolExecutor(max_workers=2) as pool:
            claim_future = pool.submit(claim_order)
            pause_future = pool.submit(activate_pause)
            claim_result = claim_future.result(timeout=20)
            assert pause_future.result(timeout=20) == "paused"

        with Session() as session:
            state = session.get(RiskControlStateRecord, 1)
            order = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == client_id))
            assert state.paused is True
            if claim_result == "blocked":
                assert order is None
            else:
                assert claim_result in {"claimed", "already_claimed"}
                assert order is not None and order.status == "submitting"
    finally:
        with Session.begin() as session:
            row = session.get(RiskControlStateRecord, 1)
            if row is not None:
                row.paused, row.reason, row.actor = False, None, "system"
            order = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == client_id))
            if order is not None:
                session.delete(order)
        engine.dispose()


def test_postgres_concurrent_ready_transition_consumes_proof_once():
    """Two operators racing on one proof must not both authorize READY."""
    from db.order_repository import OrderRepository, OrderRepositoryError
    from db.models import SystemSafetyStateRecord, ReconciliationRunRecord
    engine = _engine()
    Session = sessionmaker(engine, expire_on_commit=False)
    run_id = f"pg-proof-once-{uuid.uuid4().hex}"
    barrier = Barrier(2)
    try:
        with Session.begin() as session:
            safety = session.get(SystemSafetyStateRecord, 1)
            assert safety is not None
            safety.status, safety.reason, safety.actor = "RECONCILING", "proof replay test", "test"
            safety.last_reconciliation_run_id = None
            safety.generation += 1
            session.add(ReconciliationRunRecord(
                run_id=run_id, source="paper", status="succeeded", snapshot_complete=True,
                unresolved_count=0, orders_seen=0, fills_seen=0, positions_seen=0,
                evidence_hash=hashlib.sha256(run_id.encode()).hexdigest(), details={}))

        def authorize(_):
            barrier.wait(timeout=10)
            repo = OrderRepository(sessionmaker(engine, expire_on_commit=False))
            try:
                repo.transition_system_safety_state(status="READY", reason="concurrency test",
                    actor="operator", reconciliation_run_id=run_id)
                return "accepted"
            except OrderRepositoryError:
                return "rejected"

        with ThreadPoolExecutor(max_workers=2) as pool:
            outcomes = list(pool.map(authorize, range(2)))
        assert sorted(outcomes) == ["accepted", "rejected"]
        with Session() as session:
            proof = session.scalar(select(ReconciliationRunRecord).where(
                ReconciliationRunRecord.run_id == run_id))
            assert proof is not None and proof.consumed_at is not None
            safety = session.get(SystemSafetyStateRecord, 1)
            assert safety.status == "READY"
    finally:
        with Session.begin() as session:
            proof = session.scalar(select(ReconciliationRunRecord).where(
                ReconciliationRunRecord.run_id == run_id))
            if proof is not None:
                session.delete(proof)
            safety = session.get(SystemSafetyStateRecord, 1)
            if safety is not None:
                safety.status, safety.reason, safety.actor = "RECONCILING", "PostgreSQL test cleanup", "test"
                safety.last_reconciliation_run_id = None
        engine.dispose()


def test_postgres_operator_attempt_reservation_is_atomic():
    """Concurrent requests cannot reserve more than the configured attempt limit."""
    from datetime import datetime, timezone
    from db.order_repository import OrderRepository
    from db.models import OperatorAuthAttemptRecord
    engine = _engine()
    Session = sessionmaker(engine, expire_on_commit=False)
    client_key = hashlib.sha256(f"operator-pg-{uuid.uuid4().hex}".encode()).hexdigest()
    barrier = Barrier(10)
    now = datetime.now(timezone.utc)
    try:
        def reserve(_):
            barrier.wait(timeout=10)
            repo = OrderRepository(sessionmaker(engine, expire_on_commit=False))
            return repo.reserve_operator_auth_attempt(client_key, now=now, limit=5, window_seconds=600)
        with ThreadPoolExecutor(max_workers=10) as pool:
            outcomes = list(pool.map(reserve, range(10)))
        assert outcomes.count(True) == 5
        assert outcomes.count(False) == 5
        with Session() as session:
            row = session.get(OperatorAuthAttemptRecord, client_key)
            assert row is not None and row.attempts == 5
    finally:
        with Session.begin() as session:
            row = session.get(OperatorAuthAttemptRecord, client_key)
            if row is not None:
                session.delete(row)
        engine.dispose()


def test_postgres_operator_totp_counter_replay_is_atomic():
    """Two processes cannot consume the same TOTP counter."""
    from db.order_repository import OrderRepository
    from db.models import OperatorTotpStateRecord
    engine = _engine()
    Session = sessionmaker(engine, expire_on_commit=False)
    counter = 987654321
    barrier = Barrier(2)
    try:
        with Session.begin() as session:
            row = session.get(OperatorTotpStateRecord, 1)
            assert row is not None
            row.last_accepted_counter = counter - 1
        def consume(_):
            barrier.wait(timeout=10)
            repo = OrderRepository(sessionmaker(engine, expire_on_commit=False))
            return repo.consume_operator_totp_counter(counter)
        with ThreadPoolExecutor(max_workers=2) as pool:
            outcomes = list(pool.map(consume, range(2)))
        assert sorted(outcomes) == [False, True]
        with Session() as session:
            row = session.get(OperatorTotpStateRecord, 1)
            assert row.last_accepted_counter == counter
    finally:
        with Session.begin() as session:
            row = session.get(OperatorTotpStateRecord, 1)
            if row is not None:
                row.last_accepted_counter = -1
        engine.dispose()
