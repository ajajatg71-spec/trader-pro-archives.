import unittest
from services.execution_health import build_execution_health


class ExecutionHealthTests(unittest.TestCase):
    def test_unknown_submission_without_broker_match_is_critical_and_never_retryable(self):
        result = build_execution_health(
            local_orders=[{"client_order_id": "c1", "status": "submission_unknown"}],
            order_by_client={}, order_by_broker={}, report={},
        )
        self.assertEqual(result["status"], "critical")
        self.assertFalse(result["automatic_retry_permitted"])
        self.assertEqual(result["exceptions"][0]["category"], "broker_order_missing")
        self.assertFalse(result["exceptions"][0]["automatic_retry"])

    def test_pending_cancel_is_reported_until_broker_confirmation(self):
        result = build_execution_health(
            local_orders=[{"client_order_id": "c2", "status": "pending_cancel"}],
            order_by_client={"c2": {"status": "pending_cancel"}},
            order_by_broker={}, report={},
        )
        self.assertEqual(result["status"], "warning")
        self.assertEqual(result["exceptions"][0]["category"], "cancel_confirmation_pending")

    def test_broker_confirmed_cancel_clears_pending_cancel_warning(self):
        result = build_execution_health(
            local_orders=[{"client_order_id": "c2b", "status": "pending_cancel"}],
            order_by_client={"c2b": {"status": "canceled"}},
            order_by_broker={}, report={},
        )
        self.assertEqual(result["status"], "healthy")
        self.assertEqual(result["exceptions_count"], 0)

    def test_fill_mismatch_is_critical_even_if_order_is_terminal(self):
        result = build_execution_health(
            local_orders=[{"client_order_id": "c3", "status": "canceled"}],
            order_by_client={"c3": {"status": "canceled"}},
            order_by_broker={},
            report={"fill_quantity_checks": [{"client_order_id": "c3", "status": "mismatch", "difference": "0.2"}]},
        )
        self.assertEqual(result["status"], "critical")
        self.assertEqual(result["exceptions"][0]["category"], "fill_ledger_mismatch")

    def test_fully_reconciled_terminal_order_is_healthy(self):
        result = build_execution_health(
            local_orders=[{"client_order_id": "c4", "status": "filled"}],
            order_by_client={"c4": {"status": "filled"}},
            order_by_broker={}, report={"fill_quantity_checks": [{"client_order_id": "c4", "status": "consistent"}]},
        )
        self.assertEqual(result["status"], "healthy")
        self.assertEqual(result["exceptions_count"], 0)

    def test_truncated_snapshot_is_warning_not_healthy(self):
        result = build_execution_health(
            local_orders=[], order_by_client={}, order_by_broker={},
            report={"truncated_order_snapshot": True},
        )
        self.assertEqual(result["status"], "warning")
        self.assertEqual(result["exceptions"][0]["category"], "incomplete_broker_snapshot")


if __name__ == "__main__":
    unittest.main()
