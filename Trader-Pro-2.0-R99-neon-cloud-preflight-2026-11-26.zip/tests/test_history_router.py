import unittest
from routers.history import create_history_router


def allow_request():
    return None


class HistoryRouterTests(unittest.TestCase):
    def setUp(self):
        self.calls = []
        self.router = create_history_router(allow_request, self.reader)
        self.endpoint = next(r.endpoint for r in self.router.routes if r.path == "/api/history")

    def reader(self, n):
        self.calls.append(n)
        return [{"n": n}]

    def test_default_limit_is_200(self):
        self.assertEqual(self.endpoint(), [{"n": 200}])
        self.assertEqual(self.calls, [200])

    def test_limit_is_clamped_to_minimum(self):
        self.assertEqual(self.endpoint(n=-50), [{"n": 1}])
        self.assertEqual(self.calls, [1])

    def test_limit_is_clamped_to_maximum(self):
        self.assertEqual(self.endpoint(n=9000), [{"n": 5000}])
        self.assertEqual(self.calls, [5000])


if __name__ == "__main__":
    unittest.main()
