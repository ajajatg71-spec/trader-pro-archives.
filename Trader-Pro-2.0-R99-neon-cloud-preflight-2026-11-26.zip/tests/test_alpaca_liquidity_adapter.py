import unittest
from datetime import datetime, timezone, timedelta
from unittest.mock import Mock
import requests

from services.providers.alpaca_liquidity import AlpacaLiquiditySnapshot, AlpacaLiquidityError


class AlpacaLiquidityAdapterTests(unittest.TestCase):
    def make_session(self, quote=None, bars=None):
        session = Mock()
        quote_response, bars_response = Mock(), Mock()
        quote_response.raise_for_status.return_value = None
        bars_response.raise_for_status.return_value = None
        quote_response.json.return_value = {"quote": quote or {
            "bp": 99.9, "ap": 100.1, "t": "2026-11-11T10:00:00Z"}}
        bars_response.json.return_value = {"bars": bars if bars is not None else [
            {"t": (datetime(2026, 11, 10, tzinfo=timezone.utc) - timedelta(days=i)).isoformat(),
             "c": 100 + i, "v": 1000} for i in range(20)]}
        session.get.side_effect = [quote_response, bars_response]
        return session

    def test_returns_timestamped_quote_and_twenty_day_dollar_adv(self):
        session = self.make_session()
        adapter = AlpacaLiquiditySnapshot("key", "secret", session=session,
            utc_clock=lambda: datetime(2026, 11, 11, 10, 1, tzinfo=timezone.utc))
        result = adapter("AAPL")
        self.assertEqual(result["source"], "alpaca_iex")
        self.assertEqual(result["bid"], 99.9)
        self.assertEqual(result["ask"], 100.1)
        self.assertEqual(result["adv_observations"], 20)
        self.assertAlmostEqual(result["avg_daily_dollar_volume"], sum((100+i)*1000 for i in range(20))/20)
        self.assertEqual(session.get.call_count, 2)
        self.assertNotIn("secret", repr(result))

    def test_requires_credentials_and_valid_symbol(self):
        with self.assertRaises(ValueError):
            AlpacaLiquiditySnapshot("", "secret")
        adapter = AlpacaLiquiditySnapshot("key", "secret", session=self.make_session())
        with self.assertRaises(AlpacaLiquidityError):
            adapter("bad symbol")

    def test_rejects_stale_quote_before_fetching_bars(self):
        session = self.make_session(quote={"bp": 99.9, "ap": 100.1, "t": "2026-11-11T09:00:00Z"})
        adapter = AlpacaLiquiditySnapshot("key", "secret", session=session,
            utc_clock=lambda: datetime(2026, 11, 11, 10, 1, tzinfo=timezone.utc))
        with self.assertRaisesRegex(AlpacaLiquidityError, "périmée"):
            adapter("AAPL")
        self.assertEqual(session.get.call_count, 1)

    def test_rejects_future_quote_timestamp(self):
        session = self.make_session(quote={"bp": 99.9, "ap": 100.1, "t": "2026-11-11T10:02:00Z"})
        adapter = AlpacaLiquiditySnapshot("key", "secret", session=session,
            utc_clock=lambda: datetime(2026, 11, 11, 10, 1, tzinfo=timezone.utc))
        with self.assertRaisesRegex(AlpacaLiquidityError, "périmée"):
            adapter("AAPL")
        self.assertEqual(session.get.call_count, 1)

    def test_rejects_crossed_quote(self):
        session = self.make_session(quote={"bp": 101, "ap": 100, "t": "2026-11-11T10:00:00Z"})
        adapter = AlpacaLiquiditySnapshot("key", "secret", session=session)
        with self.assertRaisesRegex(AlpacaLiquidityError, "cotation.*invalide"):
            adapter("AAPL")
        self.assertEqual(session.get.call_count, 1)

    def test_requires_at_least_ten_valid_dollar_volume_observations(self):
        bars = [{"t": (datetime(2026, 11, 10, tzinfo=timezone.utc) - timedelta(days=i)).isoformat(), "c": 100, "v": 1000} for i in range(9)]
        adapter = AlpacaLiquiditySnapshot("key", "secret", session=self.make_session(bars=bars),
            utc_clock=lambda: datetime(2026, 11, 11, 10, 1, tzinfo=timezone.utc))
        with self.assertRaisesRegex(AlpacaLiquidityError, "insuffisant"):
            adapter("AAPL")

    def test_rejects_stale_daily_bars(self):
        bars = [{"t": (datetime(2026, 9, 1, tzinfo=timezone.utc) - timedelta(days=i)).isoformat(),
                 "c": 100, "v": 1000} for i in range(20)]
        adapter = AlpacaLiquiditySnapshot("key", "secret", session=self.make_session(bars=bars),
            utc_clock=lambda: datetime(2026, 11, 11, 10, 1, tzinfo=timezone.utc))
        with self.assertRaisesRegex(AlpacaLiquidityError, "Historique IEX périmé"):
            adapter("AAPL")

    def test_rejects_daily_bars_without_timestamp(self):
        bars = [{"c": 100, "v": 1000} for _ in range(20)]
        adapter = AlpacaLiquiditySnapshot("key", "secret", session=self.make_session(bars=bars),
            utc_clock=lambda: datetime(2026, 11, 11, 10, 1, tzinfo=timezone.utc))
        with self.assertRaisesRegex(AlpacaLiquidityError, "horodatage valide"):
            adapter("AAPL")

    def test_excludes_in_progress_current_day_bar_from_adv(self):
        now = datetime(2026, 11, 11, 10, 1, tzinfo=timezone.utc)
        bars = [{"t": now.isoformat(), "c": 1000, "v": 1}] + [
            {"t": (datetime(2026, 11, 10, tzinfo=timezone.utc) - timedelta(days=i)).isoformat(),
             "c": 100 + i, "v": 1000} for i in range(20)
        ]
        adapter = AlpacaLiquiditySnapshot("key", "secret", session=self.make_session(bars=bars),
            utc_clock=lambda: now)
        result = adapter("AAPL")
        self.assertEqual(result["adv_observations"], 20)
        self.assertEqual(result["adv_as_of"], "2026-11-10")
        self.assertAlmostEqual(result["avg_daily_dollar_volume"], sum((100+i)*1000 for i in range(20))/20)

    def test_current_day_partial_bar_does_not_count_toward_minimum_adv_history(self):
        now = datetime(2026, 11, 11, 10, 1, tzinfo=timezone.utc)
        bars = [{"t": now.isoformat(), "c": 1000, "v": 1000000}] + [
            {"t": (datetime(2026, 11, 10, tzinfo=timezone.utc) - timedelta(days=i)).isoformat(),
             "c": 100, "v": 1000} for i in range(9)
        ]
        adapter = AlpacaLiquiditySnapshot("key", "secret", session=self.make_session(bars=bars),
            utc_clock=lambda: now)
        with self.assertRaisesRegex(AlpacaLiquidityError, "insuffisant"):
            adapter("AAPL")

    def test_zero_volume_sessions_are_included_in_adv(self):
        now = datetime(2026, 11, 11, 10, 1, tzinfo=timezone.utc)
        bars = []
        for i in range(20):
            bars.append({
                "t": (datetime(2026, 11, 10, tzinfo=timezone.utc) - timedelta(days=i)).isoformat(),
                "c": 100, "v": 0 if i < 10 else 1000,
            })
        adapter = AlpacaLiquiditySnapshot("key", "secret", session=self.make_session(bars=bars),
            utc_clock=lambda: now)
        result = adapter("AAPL")
        self.assertEqual(result["adv_observations"], 20)
        self.assertEqual(result["avg_daily_dollar_volume"], 50_000)

    def test_all_zero_volume_sessions_fail_closed(self):
        now = datetime(2026, 11, 11, 10, 1, tzinfo=timezone.utc)
        bars = [{
            "t": (datetime(2026, 11, 10, tzinfo=timezone.utc) - timedelta(days=i)).isoformat(),
            "c": 100, "v": 0,
        } for i in range(20)]
        adapter = AlpacaLiquiditySnapshot("key", "secret", session=self.make_session(bars=bars),
            utc_clock=lambda: now)
        with self.assertRaisesRegex(AlpacaLiquidityError, "ADV IEX invalide"):
            adapter("AAPL")

    def test_rejects_bar_from_future_calendar_session(self):
        now = datetime(2026, 11, 11, 10, 1, tzinfo=timezone.utc)
        bars = [{"t": "2026-11-12T00:00:00+00:00", "c": 100, "v": 1000}]
        adapter = AlpacaLiquiditySnapshot("key", "secret", session=self.make_session(bars=bars),
            utc_clock=lambda: now)
        with self.assertRaisesRegex(AlpacaLiquidityError, "futur"):
            adapter("AAPL")

    def test_rejects_duplicate_daily_sessions(self):
        stamp = datetime(2026, 11, 10, tzinfo=timezone.utc).isoformat()
        bars = [{"t": stamp, "c": 100, "v": 1000} for _ in range(20)]
        adapter = AlpacaLiquiditySnapshot("key", "secret", session=self.make_session(bars=bars),
            utc_clock=lambda: datetime(2026, 11, 11, 10, 1, tzinfo=timezone.utc))
        with self.assertRaisesRegex(AlpacaLiquidityError, "séances dupliquées"):
            adapter("AAPL")

    def test_sanitizes_network_error(self):
        session = Mock()
        session.get.side_effect = requests.Timeout("url contains secret")
        adapter = AlpacaLiquiditySnapshot("key", "secret", session=session)
        with self.assertRaises(AlpacaLiquidityError) as caught:
            adapter("AAPL")
        self.assertNotIn("secret", str(caught.exception))


    def test_retries_rate_limit_once_using_bounded_retry_after(self):
        session = self.make_session()
        limited = Mock()
        limited.status_code = 429
        limited.headers = {"Retry-After": "30"}
        limited.raise_for_status.side_effect = requests.HTTPError("rate limited")
        session.get.side_effect = [limited, *session.get.side_effect]
        sleeps = []
        adapter = AlpacaLiquiditySnapshot("key", "secret", session=session,
            sleep_fn=sleeps.append,
            utc_clock=lambda: datetime(2026, 11, 11, 10, 1, tzinfo=timezone.utc))
        result = adapter("AAPL")
        self.assertEqual(result["source"], "alpaca_iex")
        self.assertEqual(session.get.call_count, 3)
        self.assertEqual(sleeps, [2.0])

    def test_retries_transient_timeout_but_does_not_retry_bad_request(self):
        session = self.make_session()
        session.get.side_effect = [requests.Timeout("temporary"), *session.get.side_effect]
        sleeps = []
        adapter = AlpacaLiquiditySnapshot("key", "secret", session=session,
            sleep_fn=sleeps.append,
            utc_clock=lambda: datetime(2026, 11, 11, 10, 1, tzinfo=timezone.utc))
        adapter("AAPL")
        self.assertEqual(session.get.call_count, 3)
        self.assertEqual(sleeps, [0.25])

    def test_rejects_retry_configuration_outside_safe_bounds(self):
        with self.assertRaises(ValueError):
            AlpacaLiquiditySnapshot("key", "secret", max_retries=4)


if __name__ == "__main__":
    unittest.main()
