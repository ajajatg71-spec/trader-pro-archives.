import unittest
from datetime import date, datetime, timezone
from types import SimpleNamespace
from research_v1.backtesting.portfolio_scoreboard import _market_total_return_buy_hold_curve, evaluate_portfolio_catalog
from tests.test_research_v1_portfolio_scoreboard import bars
from research_v1.quant.corporate_actions import CorporateActionEvent

class PortfolioTotalReturnBenchmarkTests(unittest.TestCase):
    def setUp(self):
        self.bars=[SimpleNamespace(ts=datetime(2025,1,d,21,tzinfo=timezone.utc),o=o,h=o+1,l=o-1,c=c,v=1000)
                   for d,o,c in ((2,100,100),(3,100,100),(6,99,99),(7,99,99))]
    def test_dividend_total_return_benchmark_outperforms_price_only(self):
        event=CorporateActionEvent("SPY","dividend",date(2025,1,6),self.bars[0].ts,"provider",cash_amount="1",currency="USD")
        total=_market_total_return_buy_hold_curve(self.bars,[event],currency="USD",initial_cash=10000,fee=0,slip=0,warmup=0,price_basis="raw")
        price=_market_total_return_buy_hold_curve(self.bars,[],currency="USD",initial_cash=10000,fee=0,slip=0,warmup=0,price_basis="raw")
        self.assertAlmostEqual(total[2],price[1])
        self.assertLess(price[2], price[1])
        self.assertEqual(total[:2], [10000.0, 10000.0])
    def test_split_neutralizes_price_drop(self):
        event=CorporateActionEvent("SPY","split",date(2025,1,6),self.bars[0].ts,"provider",split_ratio=2)
        bars=[self.bars[0],self.bars[1],SimpleNamespace(**{**vars(self.bars[2]),"o":49.5,"h":50.5,"l":48.5,"c":50}),self.bars[3]]
        total=_market_total_return_buy_hold_curve(bars,[event],currency="USD",initial_cash=10000,fee=0,slip=0,warmup=0,price_basis="raw")
        self.assertAlmostEqual(total[2],total[1])
    def test_rejects_invalid_event_type(self):
        with self.assertRaises((ValueError,TypeError)):
            _market_total_return_buy_hold_curve(self.bars,[{"bad":1}],currency="USD",initial_cash=10000,fee=0,slip=0,warmup=0,price_basis="raw")
    def test_scoreboard_exposes_optional_total_return_metrics(self):
        data={"AAA":bars(340,0.12,0.0,80),"BBB":bars(340,0.07,1.1,100),"CCC":bars(340,0.04,2.2,60)}
        market=bars(340,0.075,0.3,100)
        event=CorporateActionEvent("SPY","dividend",date.fromisoformat(market[200].ts[:10]),
                                   datetime.fromisoformat(market[0].ts),"provider",cash_amount="0.1",currency="USD")
        report=evaluate_portfolio_catalog(data,benchmarks={key:market for key in data},warmup=60,
                    test_window=63,min_oos_bars=756,min_folds=6,
                    market_benchmark_corporate_actions=[event],market_benchmark_symbol="SPY",
                    market_benchmark_currency="USD",market_benchmark_price_basis="raw")
        self.assertTrue(report["market_total_return_benchmark"]["enabled"])
        self.assertEqual(report["market_total_return_benchmark"]["symbol"],"SPY")
        row=next(item for item in report["results"] if item.get("evaluated"))
        self.assertIn("market_total_return_pct",row)
        self.assertIn("excess_market_total_return_pct",row)
        self.assertEqual(row["verdict"],"non démontrée")
    def test_scoreboard_rejects_benchmark_symbol_mismatch(self):
        data={"AAA":bars(340,0.12,0.0,80),"BBB":bars(340,0.07,1.1,100),"CCC":bars(340,0.04,2.2,60)}
        market=bars(340,0.075,0.3,100)
        event=CorporateActionEvent("QQQ","dividend",date.fromisoformat(market[200].ts[:10]),
                                   datetime.fromisoformat(market[0].ts),"provider",cash_amount="0.1",currency="USD")
        with self.assertRaisesRegex(ValueError,"symbole du benchmark"):
            evaluate_portfolio_catalog(data,benchmarks={key:market for key in data},
                    market_benchmark_corporate_actions=[event],market_benchmark_symbol="SPY",
                    market_benchmark_currency="USD",market_benchmark_price_basis="raw")

if __name__=="__main__": unittest.main()
