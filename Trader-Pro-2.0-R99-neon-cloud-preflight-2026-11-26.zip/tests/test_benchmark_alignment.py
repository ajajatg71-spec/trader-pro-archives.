from types import SimpleNamespace

import pytest

from research_v1.quant.alignment import (
    AlignmentError, align_daily_sessions, daily_session_keys,
)
from research_v1.quant.features import Features


def bar(ts, close):
    return SimpleNamespace(
        ts=ts, o=close, h=close + 1, l=close - 1, c=close, v=100,
    )


def test_aligns_same_exchange_session_even_when_utc_dates_differ():
    # 2026-01-05 01:00 UTC is still the previous NY session date (Jan 4);
    # this deliberately verifies conversion is based on exchange-local date.
    asset = [bar("2026-01-05T01:00:00+00:00", 101)]
    benchmark = [bar("2026-01-04T20:00:00-05:00", 100)]
    result = align_daily_sessions(asset, benchmark)
    assert result["matched_sessions"] == ("2026-01-04",)
    assert result["benchmark_closes_by_asset_bar"] == (100.0,)
    assert result["method"] == "exchange_local_session_date"


def test_missing_benchmark_session_is_none_without_forward_fill():
    asset = [
        bar("2026-01-05T21:00:00Z", 101),
        bar("2026-01-06T21:00:00Z", 102),
        bar("2026-01-07T21:00:00Z", 103),
    ]
    benchmark = [
        bar("2026-01-05T21:00:00Z", 100),
        bar("2026-01-07T21:00:00Z", 102),
    ]
    result = align_daily_sessions(asset, benchmark)
    assert result["benchmark_closes_by_asset_bar"] == (100.0, None, 102.0)
    assert result["asset_only_sessions"] == ("2026-01-06",)
    assert result["forward_fill"] is False


def test_rejects_duplicate_exchange_session_even_if_utc_instants_differ():
    bars = [
        bar("2026-01-05T15:00:00Z", 100),
        bar("2026-01-05T21:00:00Z", 101),
    ]
    with pytest.raises(AlignmentError, match="Plusieurs barres journalières"):
        daily_session_keys(bars)


def test_rejects_naive_or_non_monotonic_timestamps():
    with pytest.raises(AlignmentError, match="sans fuseau"):
        daily_session_keys([bar("2026-01-05T16:00:00", 100)])
    with pytest.raises(AlignmentError, match="strictement croissants"):
        daily_session_keys([
            bar("2026-01-06T21:00:00Z", 101),
            bar("2026-01-05T21:00:00Z", 100),
        ])


def test_rejects_invalid_closes_and_timezone():
    with pytest.raises(AlignmentError, match="Clôture invalide"):
        daily_session_keys([bar("2026-01-05T21:00:00Z", float("nan"))])
    with pytest.raises(AlignmentError, match="Fuseau de marché invalide"):
        daily_session_keys([bar("2026-01-05T21:00:00Z", 100)], timezone_name="Invalid/Zone")


def test_features_relative_strength_uses_session_alignment():
    asset = [
        bar("2026-01-05T21:00:00Z", 110),
        bar("2026-01-06T21:00:00Z", 120),
    ]
    benchmark = [
        bar("2026-01-05T16:00:00-05:00", 100),
        bar("2026-01-07T16:00:00-05:00", 105),
    ]
    features = Features(asset, benchmark)
    assert features.v("rs", at=1) == 1.1
    assert features.v("rs", at=0) is None
    report = features.benchmark_alignment()
    assert report["matched_bars"] == 1
    assert report["asset_only_sessions"] == ("2026-01-06",)
