import math, unittest
import core, risklib as R
UP = [100 + i * .5 for i in range(260)]
DOWN = [300 - i * .5 for i in range(260)]
A = {"equity": "5000", "cash": "5000", "last_equity": "5000"}
L = {"max_order": 1500, "max_pos": 25, "min_cash": 10, "max_daily_loss": 3, "max_positions": 3, "max_gross": 50, "max_order_pct": 25, "max_orders_day": 2}

class Sizing(unittest.TestCase):
    def test_vol_size(s):
        s.assertEqual(R.vol_size(10000, 100, .02, 1, 2, 25), 2500.0); s.assertEqual(R.vol_size(10000, 100, .04, 1, 2, 25), 1250.0)
        s.assertEqual(R.vol_size(10000, 100, .005, 1, 2, 25), 2500.0); s.assertIsNone(R.vol_size(10000, 100, 0)); s.assertIsNone(R.vol_size(10000, 0, .02))
    def test_daily_vol(s): s.assertEqual(R.daily_vol([100] * 30), 0.0); s.assertIsNone(R.daily_vol([1, 2, 3]))
    def test_inverse_vol(s):
        w = R.inverse_vol_weights({"A": .01, "B": .02}); s.assertAlmostEqual(sum(w.values()), 1.0); s.assertGreater(w["A"], w["B"])

class Stats(unittest.TestCase):
    def test_var_cvar(s):
        r = [-.1] * 6 + [.01] * 94; v, c = R.var_cvar(r); s.assertAlmostEqual(v, .1); s.assertAlmostEqual(c, .1); s.assertIsNone(R.var_cvar([.01] * 5))
    def test_corr_beta(s):
        a = [.01, -.02, .03, -.01, .02]; s.assertAlmostEqual(R.corr(a, a), 1.0); s.assertAlmostEqual(R.corr(a, [-x for x in a]), -1.0)
        s.assertAlmostEqual(R.beta([2 * x for x in a], a), 2.0); s.assertIsNone(R.beta(a, [0] * 5))
    def test_effective_n(s): s.assertAlmostEqual(R.effective_n([.25] * 4), 4.0); s.assertAlmostEqual(R.effective_n([1.0]), 1.0)
    def test_portfolio_returns(s):
        r = R.portfolio_returns({"A": .5, "B": .5}, {"A": [100, 110], "B": [100, 90]}); s.assertAlmostEqual(r[0], 0.0)
    def test_avg_corr(s): s.assertIsNone(R.avg_corr({"A": [1, 2]})); s.assertAlmostEqual(R.avg_corr({"A": [.1, .2, .1], "B": [.1, .2, .1]}), 1.0)

class Protection(unittest.TestCase):
    P = {"stop_loss_pct": 8, "trailing_pct": 12, "take_profit_pct": 20}
    def test_stops(s):
        s.assertTrue(R.stops(100, 91.9, 100, s.P).startswith("stop-loss")); s.assertEqual(R.stops(100, 95, 100, s.P), "")
        s.assertTrue(R.stops(100, 130, 150, s.P).startswith("stop suiveur")); s.assertTrue(R.stops(100, 121, 121, s.P).startswith("objectif"))
        s.assertEqual(R.stops(100, 1, 100, {}), "")
    def test_stop_price(s): s.assertAlmostEqual(R.stop_price(100, 150, s.P), 132.0); s.assertIsNone(R.stop_price(100, 150, {}))
    def test_regime(s): s.assertEqual(R.regime(UP), "haussier"); s.assertEqual(R.regime(DOWN), "baissier"); s.assertIsNone(R.regime(UP[:50]))
    def test_stress(s):
        per, tot = R.stress({"A": 1000, "B": 500}, 20); s.assertAlmostEqual(tot, -300.0)
        s.assertAlmostEqual(R.stress({"A": 1000}, 20, {"A": 1.5})[1], -300.0)
    def test_streak(s): s.assertEqual(R.loss_streak([.1, -.1, -.2]), 2); s.assertEqual(R.loss_streak([-.1, .1]), 0)

class Limits(unittest.TestCase):
    def chk(s, o, pos=(), a=A, today=0): return core.check(o, a, list(pos), L, [], 0.0, today)
    def pos(s, *v): return [{"symbol": n, "market_value": str(x)} for n, x in v]
    def test_orders_per_day(s): s.assertEqual(s.chk(("A", "buy", 100), today=2), "Limite d’ordres du jour atteinte"); s.assertEqual(s.chk(("A", "buy", 100), today=1), "")
    def test_sell_not_limited_by_count(s): s.assertEqual(s.chk(("A", "sell", 100), s.pos(("A", 500)), today=99), "")
    def test_max_positions(s):
        three = s.pos(("X", 100), ("Y", 100), ("Z", 100))
        s.assertEqual(s.chk(("N", "buy", 100), three), "Nombre maximal de positions atteint"); s.assertEqual(s.chk(("X", "buy", 100), three), "")
    def test_gross(s): s.assertEqual(s.chk(("N", "buy", 1000), s.pos(("X", 1000), ("Y", 600))), "Exposition totale trop élevée")
    def test_order_pct(s): s.assertEqual(core.check(("A", "buy", 1300), A, [], {**L, "max_order": 5000}, [], 0.0, 0), "Ordre trop gros pour le portefeuille")
if __name__ == "__main__": unittest.main()
