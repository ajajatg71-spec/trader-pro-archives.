import math
import random
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

from research_v1.backtesting.walk_forward import run_walk_forward_parameter_search


def _bars(seed, count=330):
    rng = random.Random(seed)
    price = 100.0
    rows = []
    for index in range(count):
        price *= math.exp(0.0002 + rng.gauss(0, 0.008))
        open_price = price * (1 + rng.uniform(-0.002, 0.002))
        spread = price * 0.012
        rows.append(SimpleNamespace(
            o=open_price, h=max(open_price, price) + spread,
            l=min(open_price, price) - spread, c=price,
            v=100000 + rng.randrange(10000),
            ts=(datetime(2020, 1, 1, tzinfo=timezone.utc) + timedelta(days=index)).isoformat(),
        ))
    return rows


class WalkForwardParameterSearchTests(unittest.TestCase):
    def test_selects_only_on_train_and_reports_frozen_oos_folds(self):
        report = run_walk_forward_parameter_search(
            "low_volatility",
            {"AAA": _bars(1), "BBB": _bars(2)},
            [{"vol_n": 20, "top_n": 1}, {"vol_n": 40, "top_n": 2}],
            train_bars=240, test_bars=40, step_bars=40,
        )
        self.assertGreaterEqual(report["fold_count"], 2)
        self.assertFalse(report["selection_uses_test_data"])
        self.assertFalse(report["test_windows_used_for_selection"])
        self.assertTrue(all(row["capital_reset_for_fold"] for row in report["folds"]))
        self.assertTrue(all(row["test_start_index"] == row["train_end_index"] + 1
                            for row in report["folds"]))
        self.assertTrue(all(row["validation_end_index_exclusive"] == row["train_end_index"] + 1
                            for row in report["folds"]))
        self.assertTrue(all(row["validation_start_index"] < row["validation_end_index_exclusive"]
                            <= row["test_start_index"] for row in report["folds"]))
        self.assertTrue(all("validation_score" in candidate
                            for row in report["folds"]
                            for candidate in row["training_candidates"]))
        self.assertFalse(report["capital_authorized"])
        self.assertEqual(report["orders_created"], 0)
        # Paired fixed-parameter comparator uses the same OOS dates and costs.
        self.assertEqual(
            report["fixed_baseline_params"],
            report["folds"][0]["selected_params"],
        )
        self.assertEqual(
            report["folds"][0]["fixed_baseline_oos_return_pct"],
            report["folds"][0]["oos_return_pct"],
        )
        self.assertTrue(all(
            row["fixed_baseline_params"] == report["fixed_baseline_params"]
            and "adaptive_minus_fixed_return_pct_points" in row
            for row in report["folds"]
        ))
        self.assertFalse(report["selection_uses_test_data"])

    def test_oos_return_includes_first_test_session_from_prior_close(self):
        from research_v1.backtesting.walk_forward import _out_of_sample_metrics
        metrics = _out_of_sample_metrics([100.0, 110.0, 121.0])
        self.assertEqual(metrics["oos_return_pct"], 21.0)
        self.assertEqual(metrics["oos_start_equity"], 100.0)
        self.assertEqual(metrics["oos_final_equity"], 121.0)
        self.assertEqual(metrics["oos_observations"], 2)

    def test_rejects_overlapping_oos_windows(self):
        with self.assertRaisesRegex(ValueError, "éviter le chevauchement"):
            run_walk_forward_parameter_search(
                "low_volatility",
                {"AAA": _bars(7), "BBB": _bars(8)},
                [{"vol_n": 20, "top_n": 1}],
                train_bars=240, test_bars=40, step_bars=20,
            )



    def test_parameter_distance_is_normalized_on_candidate_grid(self):
        from research_v1.backtesting.walk_forward import _parameter_distance
        candidates = [{"vol_n": 20, "top_n": 1}, {"vol_n": 40, "top_n": 2}]
        self.assertEqual(
            _parameter_distance(candidates[0], candidates[1], candidates), 1.0
        )
        self.assertEqual(
            _parameter_distance(candidates[0], candidates[0], candidates), 0.0
        )

    def test_rejects_invalid_parameter_switch_penalty(self):
        with self.assertRaisesRegex(ValueError, "parameter_switch_penalty"):
            run_walk_forward_parameter_search(
                "low_volatility", {"AAA": _bars(11), "BBB": _bars(12)},
                [{"vol_n": 20, "top_n": 1}], train_bars=240,
                validation_bars=30, test_bars=40, step_bars=40,
                parameter_switch_penalty=-0.1,
            )

    def test_rejects_validation_window_not_smaller_than_training_window(self):
        with self.assertRaisesRegex(ValueError, "validation_bars doit être inférieur"):
            run_walk_forward_parameter_search(
                "low_volatility", {"AAA": _bars(9), "BBB": _bars(10)},
                [{"vol_n": 20, "top_n": 1}], train_bars=240,
                validation_bars=240, test_bars=40, step_bars=40,
            )

    def test_rejects_invalid_candidate_parameters(self):
        with self.assertRaisesRegex(ValueError, "Paramètre inconnu"):
            run_walk_forward_parameter_search(
                "low_volatility", {"AAA": _bars(3), "BBB": _bars(4)},
                [{"not_a_parameter": 3}], train_bars=240, test_bars=40,
                step_bars=40,
            )

    def test_rejects_too_short_training_window_for_strategy_warmup(self):
        with self.assertRaisesRegex(ValueError, "antérieur à la validation trop court"):
            run_walk_forward_parameter_search(
                "momentum", {"AAA": _bars(5), "BBB": _bars(6)},
                [{}], train_bars=100, test_bars=40, step_bars=40,
            )


if __name__ == "__main__":
    unittest.main()
