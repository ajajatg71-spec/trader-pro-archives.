import math
import unittest
from types import SimpleNamespace

from research_v1.validation.candle_evaluator import (
    CandleEvaluationConfig, evaluate_candle_patterns,
)


def series(n=180):
    out=[]
    for i in range(n):
        c=100 + 0.12*i + 2*math.sin(i/4)
        o=c-0.25
        out.append(SimpleNamespace(o=o,h=c+0.8,l=o-0.8,c=c,v=100_000+(i%7)*1000))
    return out


class CandleEvaluatorTests(unittest.TestCase):
    def test_returns_research_only_and_costs(self):
        result=evaluate_candle_patterns(series(), CandleEvaluationConfig(horizons=(1,3), min_observations=1))
        self.assertEqual(result['status'], 'DESCRIPTIVE_RESEARCH_ONLY')
        self.assertEqual(result['costs']['round_trip_total_bps'], 20.0)
        self.assertFalse(result['automatic_strategy_activation'])
        self.assertEqual(result['orders_created'], 0)
        self.assertFalse(result['profitability_guaranteed'])

    def test_reports_block_bootstrap_interval_without_claiming_significance(self):
        result=evaluate_candle_patterns(series(), CandleEvaluationConfig(horizons=(1,), min_observations=1))
        self.assertIn("IC bootstrap descriptif, non assimilable à une preuve de significativité", result["limitations"])
        for row in result["patterns"]:
            ci=row["holdout_excess_return_ci_95"]
            self.assertEqual(ci["method"], "moving_block_bootstrap")
            self.assertEqual(ci["repetitions"], 1000)
            self.assertIsInstance(row["statistical_support_screen"], bool)

    def test_does_not_accept_bad_ohlcv(self):
        bars=series(40); bars[10]=SimpleNamespace(o=10,h=9,l=8,c=10,v=100)
        with self.assertRaisesRegex(ValueError, 'géométrie'):
            evaluate_candle_patterns(bars)

    def test_rejects_invalid_costs_and_horizons(self):
        with self.assertRaises(ValueError):
            evaluate_candle_patterns(series(), CandleEvaluationConfig(horizons=(0,)))
        with self.assertRaises(ValueError):
            evaluate_candle_patterns(series(), CandleEvaluationConfig(slippage_bps_per_side=-1))

    def test_rejects_non_chronological_or_duplicate_timestamps(self):
        from datetime import datetime, timedelta, timezone
        bars = series(40)
        start = datetime(2024, 1, 1, tzinfo=timezone.utc)
        for i, bar in enumerate(bars):
            bar.ts = (start + timedelta(days=i)).isoformat()
        bars[12].ts = bars[11].ts
        with self.assertRaisesRegex(ValueError, "non chronologiques"):
            evaluate_candle_patterns(bars)
        bars[12].ts = (start + timedelta(days=10)).isoformat()
        with self.assertRaisesRegex(ValueError, "non chronologiques"):
            evaluate_candle_patterns(bars)

    def test_rejects_naive_and_partial_timestamps(self):
        from datetime import datetime, timedelta
        bars = series(40)
        start = datetime(2024, 1, 1)
        for i, bar in enumerate(bars):
            bar.ts = (start + timedelta(days=i)).isoformat()
        with self.assertRaisesRegex(ValueError, "sans fuseau"):
            evaluate_candle_patterns(bars)
        del bars[-1].ts
        with self.assertRaisesRegex(ValueError, "partiels"):
            evaluate_candle_patterns(bars)

    def test_too_short_history_rejected(self):
        with self.assertRaisesRegex(ValueError, 'insuffisant'):
            evaluate_candle_patterns(series(20))


if __name__ == '__main__':
    unittest.main()
