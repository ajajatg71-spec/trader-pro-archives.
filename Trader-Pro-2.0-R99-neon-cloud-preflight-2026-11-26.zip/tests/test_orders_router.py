import unittest
from unittest.mock import Mock
from fastapi import HTTPException
from routers.orders import create_orders_router


class OrdersRouterTests(unittest.TestCase):
    def setUp(self):
        self.orders = Mock(return_value=[{"id": "x"}])
        self.plan = Mock(return_value={"ok": True})
        self.rebalance = Mock(return_value={"n": 2})
        self.approve = Mock(return_value={"status": "accepted"})
        self.reject = Mock(return_value={"ok": True})
        self.cancel = Mock(return_value={"ok": True})
        self.pause = Mock(return_value={"paused": True})
        router = create_orders_router(
            guard_dependency=lambda: None,
            orders_reader=self.orders,
            plan_creator=self.plan,
            rebalance_creator=self.rebalance,
            approval_handler=self.approve,
            rejection_handler=self.reject,
            cancellation_handler=self.cancel,
            pause_handler=self.pause,
        )
        self.endpoints = {route.path: route.endpoint for route in router.routes}

    def test_list_orders_delegates_to_reader(self):
        self.assertEqual(self.endpoints["/api/orders"](), [{"id": "x"}])
        self.orders.assert_called_once_with()

    def test_plan_rejects_non_positive_budget(self):
        for budget in (0, -1, 10_000_001):
            with self.assertRaises(HTTPException) as ctx:
                self.endpoints["/api/plan"](budget)
            self.assertEqual(ctx.exception.status_code, 400)
        self.plan.assert_not_called()

    def test_plan_accepts_valid_budget(self):
        self.assertEqual(self.endpoints["/api/plan"](1000), {"ok": True})
        self.plan.assert_called_once_with(1000)

    def test_lifecycle_routes_delegate_with_order_id(self):
        self.endpoints["/api/approve/{oid}"]("order-1")
        self.endpoints["/api/reject/{oid}"]("order-2")
        self.endpoints["/api/cancel/{oid}"]("order-3")
        self.approve.assert_called_once_with("order-1")
        self.reject.assert_called_once_with("order-2")
        self.cancel.assert_called_once_with("order-3")

    def test_rebalance_and_pause_delegate(self):
        self.assertEqual(self.endpoints["/api/rebalance"](), {"n": 2})
        self.assertEqual(self.endpoints["/api/pause"](), {"paused": True})
        self.rebalance.assert_called_once_with()
        self.pause.assert_called_once_with()


if __name__ == "__main__":
    unittest.main()
