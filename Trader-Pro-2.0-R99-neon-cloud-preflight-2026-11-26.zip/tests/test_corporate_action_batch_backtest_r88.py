import unittest
from datetime import date,datetime,timezone
from research_v1.quant.corporate_actions import CorporateActionBatch,CorporateActionError,CorporateActionEvent
from research_v1.backtesting.backtest import evaluate_total_return_history_from_batch
class BatchBacktestTests(unittest.TestCase):
 def setUp(self):
  self.ts=[datetime(2025,1,d,21,tzinfo=timezone.utc) for d in (2,3,6,7)]
  self.event=CorporateActionEvent("AAPL","dividend",date(2025,1,6),self.ts[0],"alpaca",cash_amount="1",currency="USD",event_id="d1")
  self.batch=CorporateActionBatch((self.event,),("AAPL",),date(2025,1,1),date(2025,1,31),self.ts[-1],1,True,"alpaca")
 def test_uses_validated_complete_batch(self):
  result=evaluate_total_return_history_from_batch([100,100,99,99],self.ts,self.batch,as_of=self.ts[-1],symbol="AAPL",currency="USD",price_basis="raw")
  self.assertEqual(result["corporate_action_events"],1)
 def test_rejects_symbol_outside_batch_universe(self):
  with self.assertRaisesRegex(ValueError,"univers du lot"):
   evaluate_total_return_history_from_batch([100,100,99,99],self.ts,self.batch,as_of=self.ts[-1],symbol="MSFT",currency="USD",price_basis="raw")
 def test_rejects_non_batch_input(self):
  with self.assertRaisesRegex(ValueError,"CorporateActionBatch"):
   evaluate_total_return_history_from_batch([100,100,99,99],self.ts,[self.event],as_of=self.ts[-1],symbol="AAPL",currency="USD",price_basis="raw")
 def test_batch_constructor_rejects_incomplete_pages(self):
  with self.assertRaises(CorporateActionError):
   CorporateActionBatch((self.event,),("AAPL",),date(2025,1,1),date(2025,1,31),self.ts[-1],1,False,"alpaca")
if __name__=="__main__":unittest.main()
