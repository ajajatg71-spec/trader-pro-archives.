import base64
import unittest
from unittest.mock import Mock

from fastapi import FastAPI
from fastapi.testclient import TestClient

from routers.operator import create_operator_router


class FakeRepository:
    def __init__(self):
        self.state = {"status": "RECONCILING", "generation": 2}
        self.calls = []
        self.failures = {}
        self.last_counter = -1

    def operator_auth_is_rate_limited(self, key, *, now, limit, window_seconds):
        return self.failures.get(key, 0) >= limit

    def record_operator_auth_failure(self, key, *, now, window_seconds):
        self.failures[key] = self.failures.get(key, 0) + 1

    def consume_operator_totp_counter(self, counter):
        if counter <= self.last_counter:
            return False
        self.last_counter = counter
        return True

    def get_system_safety_state(self):
        return dict(self.state)

    def transition_system_safety_state(self, **kwargs):
        self.calls.append(kwargs)
        self.state.update(status=kwargs["status"], generation=self.state["generation"] + 1)
        return dict(self.state)


class OperatorRouterTests(unittest.TestCase):
    def setUp(self):
        self.repo = FakeRepository()
        self.history = Mock()
        self.counter = 100
        def counter_verifier(secret, code):
            if code != "123456":
                return None
            self.counter += 1
            return self.counter
        self.app = FastAPI()
        self.app.include_router(create_operator_router(
            repository=self.repo,
            operator_password="a-very-long-operator-secret-123",
            operator_totp_secret="JBSWY3DPEHPK3PXP",
            totp_verifier=lambda secret, code: code == "123456",
            totp_counter_verifier=counter_verifier,
            history_writer=self.history,
            client_ip=lambda request: request.client.host,
        ))
        self.client = TestClient(self.app, base_url="https://testserver")
        raw = base64.b64encode(b"operator:a-very-long-operator-secret-123").decode()
        self.headers = {"Authorization": f"Basic {raw}", "x-trader": "1", "x-operator-totp": "123456"}

    def test_requires_authenticated_operator(self):
        response = self.client.get("/api/operator/system-safety")
        self.assertEqual(response.status_code, 401)

    def test_reads_safety_state(self):
        response = self.client.get("/api/operator/system-safety", headers=self.headers)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["status"], "RECONCILING")

    def test_transition_actor_is_server_derived(self):
        response = self.client.post("/api/operator/system-safety", headers=self.headers,
                                    json={"status": "READY", "reason": "validated", "reconciliation_run_id": "proof-1", "actor": "admin"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.repo.calls[0]["actor"], "operator")

    def test_bad_totp_is_rejected(self):
        headers = dict(self.headers, **{"x-operator-totp": "000000"})
        response = self.client.get("/api/operator/system-safety", headers=headers)
        self.assertEqual(response.status_code, 401)

    def test_missing_database_fails_closed(self):
        app = FastAPI()
        app.include_router(create_operator_router(
            repository=None, operator_password="a-very-long-operator-secret-123",
            operator_totp_secret="JBSWY3DPEHPK3PXP", totp_verifier=lambda *_: True,
            totp_counter_verifier=lambda *_: 1,
            history_writer=Mock(), client_ip=lambda request: "127.0.0.1"))
        client = TestClient(app, base_url="https://testserver")
        response = client.get("/api/operator/system-safety", headers=self.headers)
        self.assertEqual(response.status_code, 503)

    def test_repeated_read_only_get_does_not_consume_totp(self):
        app = FastAPI()
        app.include_router(create_operator_router(
            repository=self.repo, operator_password="a-very-long-operator-secret-123",
            operator_totp_secret="JBSWY3DPEHPK3PXP", totp_verifier=lambda *_: True,
            totp_counter_verifier=lambda *_: 777, history_writer=self.history,
            client_ip=lambda request: request.client.host))
        client = TestClient(app, base_url="https://testserver")
        first = client.get("/api/operator/system-safety", headers=self.headers)
        second = client.get("/api/operator/system-safety", headers=self.headers)
        self.assertEqual(first.status_code, 200)
        self.assertEqual(second.status_code, 200)
        self.assertEqual(self.repo.last_counter, -1)

    def test_state_changing_post_consumes_totp_and_rejects_replay(self):
        app = FastAPI()
        app.include_router(create_operator_router(
            repository=self.repo, operator_password="a-very-long-operator-secret-123",
            operator_totp_secret="JBSWY3DPEHPK3PXP", totp_verifier=lambda *_: True,
            totp_counter_verifier=lambda *_: 777, history_writer=self.history,
            client_ip=lambda request: request.client.host))
        client = TestClient(app, base_url="https://testserver")
        body = {"status": "HALTED", "reason": "test"}
        first = client.post("/api/operator/system-safety", headers=self.headers, json=body)
        second = client.post("/api/operator/system-safety", headers=self.headers, json=body)
        self.assertEqual(first.status_code, 200)
        self.assertEqual(second.status_code, 401)

    def test_successful_requests_do_not_increment_failed_login_counter(self):
        response = self.client.get("/api/operator/system-safety", headers=self.headers)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.repo.failures, {})

    def test_invalid_credentials_increment_failed_login_counter(self):
        headers = dict(self.headers, **{"x-operator-totp": "000000"})
        response = self.client.get("/api/operator/system-safety", headers=headers)
        self.assertEqual(response.status_code, 401)
        self.assertEqual(sum(self.repo.failures.values()), 1)

    def test_five_failed_logins_trigger_throttle(self):
        headers = dict(self.headers, **{"x-operator-totp": "000000"})
        for _ in range(5):
            self.assertEqual(self.client.get("/api/operator/system-safety", headers=headers).status_code, 401)
        self.assertEqual(self.client.get("/api/operator/system-safety", headers=headers).status_code, 429)

    def test_router_refuses_non_persistent_repository(self):
        with self.assertRaises(RuntimeError):
            create_operator_router(repository=object(), operator_password="x" * 24,
                operator_totp_secret="TOTP", totp_verifier=lambda *_: True,
                totp_counter_verifier=lambda *_: 1, history_writer=self.history,
                client_ip=lambda request: "127.0.0.1")


if __name__ == "__main__":
    unittest.main()
