"""Merged broker Paper-safety regression tests (R5 fail-safe config retained)."""
import unittest
import copy
import requests
from unittest.mock import patch
import broker

ACCOUNT = {"id":"unit-account","status":"ACTIVE","equity":"100000","cash":"100000",
           "account_blocked":False,"trading_blocked":False,"trade_suspended_by_user":False}

class Response:
    def __init__(self, status, body=None, *, content=True):
        self.status_code=status; self.ok=200 <= status < 300; self._body=body
        self.content=b"response" if content else b""
    def json(self): return self._body

class PaperBrokerSafety(unittest.TestCase):
    def setUp(self):
        self.original_health = copy.deepcopy(broker._HEALTH)
        broker._HEALTH.clear()
        broker._HEALTH.update({
            "provider": "alpaca_paper",
            "paper_confirmed": False,
            "connection_health": "unavailable",
            "last_successful_check": None,
            "last_check_at": None,
            "confirmation_basis": None,
            "message": "Connexion Alpaca Paper non vérifiée.",
            "_verified_monotonic": 0.0,
            "_account": None,
        })
        self.patches = [
            patch.object(broker, "KEY", "unit-test-key"),
            patch.object(broker, "SECRET", "unit-test-secret"),
            patch.object(broker, "H", {
                "APCA-API-KEY-ID": "unit-test-key",
                "APCA-API-SECRET-KEY": "unit-test-secret",
            }),
        ]
        for item in self.patches:
            item.start()
            self.addCleanup(item.stop)
        self.addCleanup(self._restore_health)

    def _restore_health(self):
        broker._HEALTH.clear()
        broker._HEALTH.update(self.original_health)

    @staticmethod
    def paper_url(path):
        return f"https://paper-api.alpaca.markets{path}"

    def health_response(self, method, url, **kwargs):
        self.assertEqual(method, "GET")
        self.assertIn(url, {self.paper_url("/v2/account"), self.paper_url("/v2/clock")})
        self.assertFalse(kwargs["allow_redirects"])
        if url.endswith("/v2/account"):
            return Response(200, ACCOUNT)
        return Response(200, {"is_open": False})

    def test_paper_account_is_confirmed_from_the_dedicated_endpoint(self):
        with patch("broker.requests.request", side_effect=self.health_response) as request:
            status = broker.paper_status()
        self.assertEqual(status["provider"], "alpaca_paper")
        self.assertIs(status["paper_confirmed"], True)
        self.assertEqual(status["connection_health"], "healthy")
        self.assertEqual(status["confirmation_basis"], "authenticated_paper_api_endpoint")
        self.assertIsNotNone(status["last_successful_check"])
        self.assertEqual(request.call_count, 2)
        self.assertTrue(all(call.args[1].startswith("https://paper-api.alpaca.markets/") for call in request.call_args_list))

    def test_missing_credentials_fail_closed_without_a_request(self):
        with patch.object(broker, "KEY", ""), patch.object(broker, "SECRET", ""), \
                patch("broker.requests.request") as request:
            status = broker.paper_status()
        self.assertIs(status["paper_confirmed"], False)
        self.assertEqual(status["connection_health"], "unavailable")
        self.assertIsNone(status["last_successful_check"])
        request.assert_not_called()

    def test_invalid_credentials_fail_closed_without_exposing_response_body(self):
        marker = "provider-private-response"
        with patch("broker.requests.request", return_value=Response(401, {"message": marker})) as request:
            status = broker.paper_status()
        self.assertIs(status["paper_confirmed"], False)
        self.assertEqual(status["connection_health"], "unavailable")
        self.assertEqual(request.call_count, 1)
        self.assertNotIn(marker, status["message"])

    def test_inactive_account_is_identified_but_never_trade_ready(self):
        blocked = {**ACCOUNT, "trading_blocked": True}
        with patch("broker.requests.request", return_value=Response(200, blocked)) as request:
            status = broker.paper_status()
        self.assertIs(status["paper_confirmed"], True)
        self.assertEqual(status["connection_health"], "unavailable")
        self.assertEqual(request.call_count, 1)

    def test_missing_security_flags_fail_closed(self):
        incomplete = {key: value for key, value in ACCOUNT.items() if key != "trading_blocked"}
        with patch("broker.requests.request", return_value=Response(200, incomplete)):
            status = broker.paper_status()
        self.assertIs(status["paper_confirmed"], False)
        self.assertEqual(status["connection_health"], "unavailable")

    def test_live_host_and_non_read_only_data_routes_are_blocked(self):
        with patch.object(broker, "BASE", "https://api.alpaca.markets"), \
                patch("broker.requests.request") as request:
            with self.assertRaises(broker.BrokerError):
                broker._request_once("GET", "/v2/account")
        with patch("broker.requests.request") as request:
            with self.assertRaises(broker.BrokerError):
                broker._request_once("POST", "/v2/stocks/AAPL/bars", base=broker.DATA, json={})
        request.assert_not_called()

    def test_redirects_are_not_followed(self):
        with patch("broker.requests.request", return_value=Response(302, {})) as request:
            with self.assertRaises(broker.BrokerError):
                broker._request_once("GET", "/v2/clock")
        self.assertEqual(request.call_count, 1)
        self.assertFalse(request.call_args.kwargs["allow_redirects"])

    def test_uncertain_submission_uses_only_one_read_lookup_never_resubmits(self):
        with patch.object(broker, "_ensure_paper_ready", return_value=ACCOUNT), \
                patch("broker.requests.request", side_effect=[
                    requests.Timeout(),
                    Response(404, {"message": "not found"}),
                ]) as request:
            with self.assertRaises(broker.BrokerMutationUnknown):
                broker.order("AAPL", "buy", 10, "unit-client-id")
        self.assertEqual(request.call_count, 2)
        methods = [call.args[0] for call in request.call_args_list]
        self.assertEqual(methods, ["POST", "GET"])
        self.assertTrue(all(call.args[1].startswith("https://paper-api.alpaca.markets/") for call in request.call_args_list))

    def test_uncertain_submission_can_be_resolved_by_matching_paper_order(self):
        existing = {
            "id": "unit-order",
            "symbol": "AAPL",
            "side": "buy",
            "type": "market",
            "time_in_force": "day",
            "notional": "10.00",
        }
        with patch.object(broker, "_ensure_paper_ready", return_value=ACCOUNT), \
                patch("broker.requests.request", side_effect=[
                    requests.Timeout(),
                    Response(200, existing),
                ]) as request:
            result = broker.order("AAPL", "buy", 10, "unit-client-id")
        self.assertEqual(result["id"], "unit-order")
        self.assertEqual([call.args[0] for call in request.call_args_list], ["POST", "GET"])

    def test_delete_timeout_is_not_retried(self):
        with patch.object(broker, "_ensure_paper_ready", return_value=ACCOUNT), \
                patch("broker.requests.request", side_effect=requests.Timeout()) as request:
            with self.assertRaises(broker.BrokerMutationUnknown):
                broker.cancel("unit-order")
        self.assertEqual(request.call_count, 1)
        self.assertEqual(request.call_args.args[0], "DELETE")
        self.assertTrue(request.call_args.args[1].startswith("https://paper-api.alpaca.markets/"))

