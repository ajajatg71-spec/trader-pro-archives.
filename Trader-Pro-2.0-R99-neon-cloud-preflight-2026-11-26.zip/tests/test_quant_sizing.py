import math
import pytest

from services.quant_sizing import compute_atr, volatility_targeted_notional, estimate_pretrade_tca


def test_atr_and_volatility_sizing_reduce_risk_in_stress():
    highs = [102 + i * .5 for i in range(20)]
    lows = [99 + i * .5 for i in range(20)]
    closes = [100.5 + i * .5 for i in range(20)]
    atr = compute_atr(highs, lows, closes, 14)
    assert atr and atr > 0
    normal = volatility_targeted_notional(equity=100000, price=110, atr=atr, risk_budget_pct=1, regime="normal")
    stress = volatility_targeted_notional(equity=100000, price=110, atr=atr, risk_budget_pct=1, regime="high_vol")
    assert stress["risk_usd"] == normal["risk_usd"] / 2
    assert stress["recommended_notional"] <= normal["recommended_notional"]
    assert normal["research_only"] is True


def test_position_notional_respects_own_equity_cap():
    result = volatility_targeted_notional(equity=10000, price=100, risk_budget_pct=5, max_position_pct=20)
    assert result["recommended_notional"] <= 2000


def test_sizing_rejects_nonfinite_and_invalid_limits():
    for value in (float("nan"), float("inf"), 0, -1):
        with pytest.raises(ValueError):
            volatility_targeted_notional(equity=10000, price=100, annualized_vol_pct=value)
    with pytest.raises(ValueError):
        volatility_targeted_notional(equity=10000, price=100, max_position_pct=150)
    with pytest.raises(ValueError):
        volatility_targeted_notional(equity=10000, price=100, risk_budget_pct=float("nan"))


def test_atr_rejects_mismatched_or_bad_series():
    with pytest.raises(ValueError):
        compute_atr([2, 3], [1], [1, 2], 1)
    assert compute_atr([2, float("nan"), 3], [1, 1, 2], [1, 2, 2], 1) is None


def test_tca_estimate_and_validation():
    result = estimate_pretrade_tca(notional=10000, spread_pct=.04, adv_usd=20_000_000, volatility_pct=24)
    assert result["spread_cost_usd"] == 2
    assert result["total_cost_usd"] > 2
    with pytest.raises(ValueError):
        estimate_pretrade_tca(notional=1000, spread_pct=float("nan"))
    with pytest.raises(ValueError):
        estimate_pretrade_tca(notional=1000, adv_usd=0)
