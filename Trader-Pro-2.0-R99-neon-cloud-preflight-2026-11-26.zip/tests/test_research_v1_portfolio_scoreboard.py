import math
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

from research_v1.backtesting.portfolio_scoreboard import (
    evaluate_portfolio_catalog, required_warmup, _hac_t_stat, _asset_exposure_summary,
    _market_regime_breakdown, _verdict,
)


def bars(n=340, drift=0.08, phase=0.0, start=80.0):
    out = []
    for i in range(n):
        close = start + drift * i + math.sin(i / 7 + phase) * 1.7
        out.append(SimpleNamespace(
            o=close - 0.12, h=close + 0.8, l=close - 0.8, c=close,
            v=100_000 + (i % 13) * 700,
            ts=(datetime(2024, 1, 1, tzinfo=timezone.utc) + timedelta(days=i)).isoformat(),
        ))
    return out


class PortfolioScoreboardTests(unittest.TestCase):
    def setUp(self):
        n = 340
        self.data = {
            "AAA": bars(n, 0.12, 0.0, 80),
            "BBB": bars(n, 0.07, 1.1, 100),
            "CCC": bars(n, 0.04, 2.2, 60),
        }
        self.market = bars(n, 0.075, 0.3, 100)
        self.benchmarks = {symbol: self.market for symbol in self.data}

    def test_required_warmup_covers_strategy_windows(self):
        self.assertEqual(required_warmup("momentum", {}), 253)
        self.assertEqual(required_warmup("dual_momentum", {"lookback": 400}), 400)
        self.assertEqual(required_warmup("low_volatility", {"vol_n": 240}), 240)
        self.assertEqual(required_warmup("rs_rotation", {"rs_n": 230}), 230)
        self.assertEqual(required_warmup("multi_factor", {}), 130)

    def test_all_seven_strategies_are_scored_without_activation(self):
        report = evaluate_portfolio_catalog(
            self.data, benchmarks=self.benchmarks, warmup=60,
            test_window=63, min_oos_bars=756, min_folds=6,
        )
        self.assertEqual(report["mode"], "WALK_FORWARD_OOS_RESEARCH")
        self.assertEqual(len(report["results"]), 7)
        self.assertFalse(report["broker_access"])
        self.assertEqual(report["orders_created"], 0)
        self.assertEqual(report["strategies_activated"], 0)
        self.assertFalse(report["profitability_guaranteed"])
        self.assertEqual(report["selection_preview"]["cash_pct"], 100.0)
        self.assertFalse(report["selection_preview"]["capital_authorized"])
        self.assertEqual(report["selection_preview"]["orders_created"], 0)
        for result in report["results"]:
            self.assertEqual(result["verdict"], "non démontrée")
            self.assertEqual(result["effective_warmup"] >= required_warmup(result["kind"], result.get("params", {})), True)
        multi = next(row for row in report["results"] if row["kind"] == "multi_factor")
        self.assertFalse(multi["evaluated"])
        self.assertEqual(multi["blocked_by"], "point_in_time_fundamentals_missing")
        self.assertEqual(report["multiple_testing"]["evaluated_count"], 6)
        self.assertEqual(report["multiple_testing"]["family_size"], 50)
        self.assertEqual(report["multiple_testing"]["strategies_in_scoreboard"], 7)
        streams = report["oos_return_streams"]
        stream_meta = report["oos_return_streams_metadata"]
        self.assertGreater(stream_meta["observations"], 0)
        self.assertEqual(stream_meta["observations"], len(next(iter(streams.values()))))
        for rows in streams.values():
            self.assertEqual(len(rows), stream_meta["observations"])
            self.assertEqual(rows[0]["timestamp"], stream_meta["first_timestamp"])
            self.assertEqual(rows[-1]["timestamp"], stream_meta["last_timestamp"])
        corr = report["strategy_return_correlation"]
        self.assertGreater(corr["common_oos_bars"], 0)
        self.assertTrue(all(values[kind] == 1.0 for kind, values in corr["matrix"].items()))
        risk = report["portfolio_risk_review"]
        self.assertEqual(risk["status"], "NO_OOS_CANDIDATES")
        self.assertFalse(risk["capital_authorized"])
        self.assertTrue(risk["asset_level_exposure_measured"])
        self.assertFalse(risk["asset_level_exposure_validated"])
        self.assertFalse(risk["sector_concentration_validated"])
        self.assertFalse(risk["liquidity_validated"])
        for result in report["results"]:
            if result.get("evaluated"):
                self.assertEqual(result["asset_exposure"]["bars"], result["oos_bars"] + 1)
                self.assertGreaterEqual(result["asset_exposure"]["max_single_asset_weight_pct"], 0.0)
                self.assertLessEqual(result["asset_exposure"]["max_single_asset_weight_pct"], 100.0 + 1e-5)

    def test_multi_factor_is_evaluated_only_with_public_availability_snapshots(self):
        fundamentals = {
            "AAA": [{"available_at": self.data["AAA"][200].ts, "as_of": "2024-Q2", "eps": 2, "growth_pct": 15, "margin_pct": 12}],
            "BBB": [{"available_at": self.data["BBB"][200].ts, "as_of": "2024-Q2", "eps": 3, "growth_pct": 8, "margin_pct": 18}],
            "CCC": [{"available_at": self.data["CCC"][200].ts, "as_of": "2024-Q2", "eps": 1, "growth_pct": 24, "margin_pct": 6}],
        }
        report = evaluate_portfolio_catalog(
            self.data, benchmarks=self.benchmarks, fundamentals_by_symbol=fundamentals,
            warmup=60, test_window=63, min_oos_bars=756, min_folds=6)
        multi = next(row for row in report["results"] if row["kind"] == "multi_factor")
        self.assertTrue(multi["evaluated"])
        self.assertNotIn("blocked_by", multi)
        self.assertEqual(report["multiple_testing"]["evaluated_count"], 7)
        self.assertEqual(report["multiple_testing"]["family_size"], 50)

    def test_rebalancing_default_is_equal_weight_and_all_folds_are_chronological(self):
        report = evaluate_portfolio_catalog(
            self.data, benchmarks=self.benchmarks, warmup=60,
            test_window=30, min_oos_bars=252, min_folds=3,
        )
        row = next(x for x in report["results"] if x["kind"] == "rebalancing")
        self.assertEqual(set(row["params"]["targets"]), set(self.data))
        folds = row["folds"]
        self.assertGreaterEqual(len(folds), 2)
        for left, right in zip(folds, folds[1:]):
            self.assertEqual(left["end_index"], right["start_index"])
            self.assertGreater(right["end_index"], right["start_index"])

    def test_asset_exposure_summary_measures_concentration_and_time_in_position(self):
        summary = _asset_exposure_summary([
            {"AAA": 0.7, "BBB": 0.2},
            {"AAA": 0.5},
            {"BBB": 0.5},
        ])
        self.assertEqual(summary["bars"], 3)
        self.assertEqual(summary["max_single_asset_weight_pct"], 70.0)
        self.assertEqual(summary["max_simultaneous_positions"], 2)
        self.assertEqual(summary["assets"]["AAA"]["days_exposed_pct"], 66.67)
        self.assertEqual(summary["assets"]["BBB"]["days_exposed_pct"], 66.67)
        self.assertGreater(summary["average_invested_asset_hhi"], 0.8)

    def test_regime_breakdown_uses_only_information_available_at_prior_close(self):
        market = bars(100, drift=0.0, start=100.0)
        # Force a clear positive trailing market trend, then inspect an OOS day.
        for i in range(1, 100):
            close = 100.0 + i * 0.5
            market[i] = SimpleNamespace(o=close, h=close + 1, l=close - 1, c=close,
                                        v=100_000, ts=market[i].ts)
        curve = [1000.0 * (1.001 ** i) for i in range(100)]
        result = _market_regime_breakdown(curve, curve, market, start=70, lookback=63)
        self.assertEqual(result["classified_observations"], 29)
        self.assertEqual(result["regimes"]["risk_on"]["observations"], 29)
        self.assertEqual(result["regimes"]["risk_off"]["observations"], 0)
        self.assertFalse(result["all_regimes_sufficiently_sampled"])

    def test_regime_report_is_present_and_never_authorizes_allocation(self):
        report = evaluate_portfolio_catalog(
            self.data, benchmarks=self.benchmarks, warmup=60,
            test_window=63, min_oos_bars=756, min_folds=6)
        row = next(x for x in report["results"] if x.get("evaluated"))
        regime = row["market_regime_breakdown"]
        self.assertEqual(regime["lookback_sessions"], 63)
        self.assertIn("risk_on", regime["regimes"])
        self.assertIn("risk_off", regime["regimes"])
        self.assertFalse(report["portfolio_risk_review"]["market_regime_analysis_validated"])
        self.assertFalse(report["selection_preview"]["capital_authorized"])

    def test_hac_t_stat_is_zero_for_constant_zero_excess(self):
        self.assertEqual(_hac_t_stat([0.0] * 100), 0.0)

    def test_unsynchronised_market_proxy_is_rejected(self):
        bad_market = bars(339)
        bad = {symbol: bad_market for symbol in self.data}
        with self.assertRaisesRegex(ValueError, "synchronisé"):
            evaluate_portfolio_catalog(self.data, benchmarks=bad)


if __name__ == "__main__":
    unittest.main()


def test_concentration_guard_rejects_single_asset_dominance():
    metrics = {
        "oos_bars": 900, "fold_count": 8, "oos_return_pct": 25.0,
        "max_drawdown_pct": -10.0, "stress_return_pct": 20.0,
        "sharpe": 2.0, "equal_weight_sharpe": 1.0,
        "excess_equal_weight_pct": 12.0, "hac_t_stat": 4.0,
        "positive_fold_ratio": 0.875, "median_fold_excess_pct": 2.5,
        "stress_excess_equal_weight_pct": 8.0,
        "strategies_tested": 50, "max_single_asset_weight_pct": 60.0,
        "average_invested_asset_hhi": 0.35,
    }
    kwargs = dict(min_oos_bars=756, min_folds=6, min_positive_fold_ratio=0.6, z_threshold=3.29)
    verdict, reason = _verdict(metrics, **kwargs)
    assert verdict == "à surveiller" and "concentration" in reason
    metrics["max_single_asset_weight_pct"] = 35.0
    metrics["average_invested_asset_hhi"] = 0.65
    verdict, reason = _verdict(metrics, **kwargs)
    assert verdict == "à surveiller" and "HHI" in reason
    metrics["average_invested_asset_hhi"] = 0.35
    verdict, _ = _verdict(metrics, **kwargs)
    assert verdict == "prometteuse"


def test_allocation_preview_fails_closed_until_all_portfolio_gates_are_validated():
    from research_v1.backtesting.portfolio_scoreboard import build_allocation_model_preview

    candidates = [
        {"kind": "alpha", "verdict": "prometteuse", "evaluated": True,
         "sharpe": 2.0, "volatility_pct": 20.0},
        {"kind": "beta", "verdict": "prometteuse", "evaluated": True,
         "sharpe": 1.0, "volatility_pct": 20.0},
    ]
    review = {
        "asset_level_exposure_validated": True,
        "market_regime_analysis_validated": False,
        "sector_concentration_validated": True,
        "liquidity_validated": True,
        "highly_correlated_pairs_abs_ge_0_75": [],
    }
    blocked = build_allocation_model_preview(candidates, review)
    assert blocked["status"] == "BLOCKED_CASH_ONLY"
    assert blocked["cash_pct"] == 100.0
    assert blocked["weights_pct"] == {}
    assert blocked["capital_authorized"] is False
    assert blocked["orders_created"] == 0


def test_allocation_preview_is_capped_and_remains_non_executable():
    from research_v1.backtesting.portfolio_scoreboard import build_allocation_model_preview

    candidates = [
        {"kind": "alpha", "verdict": "prometteuse", "evaluated": True,
         "sharpe": 2.0, "volatility_pct": 20.0},
        {"kind": "beta", "verdict": "prometteuse", "evaluated": True,
         "sharpe": 1.0, "volatility_pct": 20.0},
        {"kind": "gamma", "verdict": "prometteuse", "evaluated": True,
         "sharpe": 1.0, "volatility_pct": 20.0},
    ]
    review = {
        "asset_level_exposure_validated": True,
        "market_regime_analysis_validated": True,
        "sector_concentration_validated": True,
        "liquidity_validated": True,
        "highly_correlated_pairs_abs_ge_0_75": [],
    }
    preview = build_allocation_model_preview(candidates, review)
    assert preview["status"] == "MODEL_PREVIEW_ONLY"
    assert preview["weights_pct"]["alpha"] == 25.0
    assert sum(preview["weights_pct"].values()) <= 80.0
    assert preview["cash_pct"] >= 20.0
    assert preview["capital_authorized"] is False
    assert preview["strategies_activated"] == 0
    assert preview["orders_created"] == 0


def test_allocation_preview_blocks_highly_correlated_candidates():
    from research_v1.backtesting.portfolio_scoreboard import build_allocation_model_preview

    candidate = [{"kind": "alpha", "verdict": "prometteuse", "evaluated": True,
                  "sharpe": 1.5, "volatility_pct": 15.0}]
    review = {
        "asset_level_exposure_validated": True,
        "market_regime_analysis_validated": True,
        "sector_concentration_validated": True,
        "liquidity_validated": True,
        "highly_correlated_pairs_abs_ge_0_75": [{"left": "alpha", "right": "beta", "correlation": 0.9}],
    }
    preview = build_allocation_model_preview(candidate, review)
    assert preview["status"] == "BLOCKED_CASH_ONLY"
    assert preview["cash_pct"] == 100.0


def test_curve_metrics_add_downside_risk_and_drawdown_duration():
    from research_v1.backtesting.portfolio_scoreboard import _curve_metrics

    metrics = _curve_metrics([100.0, 110.0, 105.0, 100.0, 112.0])
    assert metrics["sortino"] > 0
    assert metrics["calmar"] > 0
    assert metrics["max_drawdown_pct"] < 0
    assert metrics["max_drawdown_duration_bars"] == 2


def test_curve_metrics_reject_non_finite_or_non_positive_equity():
    from research_v1.backtesting.portfolio_scoreboard import _curve_metrics

    import pytest
    with pytest.raises(ValueError, match="positives et finies"):
        _curve_metrics([100.0, float("nan"), 102.0])
    with pytest.raises(ValueError, match="positives et finies"):
        _curve_metrics([100.0, 0.0, 102.0])


def test_walk_forward_fold_rows_include_downside_and_drawdown_duration_metrics():
    from research_v1.backtesting.portfolio_scoreboard import _fold_rows

    strategy = [100.0]
    for index in range(1, 51):
        strategy.append(strategy[-1] * (1.012 if index % 4 else 0.985))
    benchmark = [100.0 + index * 0.2 for index in range(len(strategy))]
    rows = _fold_rows(strategy, benchmark, test_start=0, test_window=20)

    assert len(rows) == 2
    for row in rows:
        assert "sortino" in row
        assert "calmar" in row
        assert "max_drawdown_duration_bars" in row
        assert row["max_drawdown_duration_bars"] >= 0


def test_verdict_requires_positive_median_fold_excess():
    metrics = {
        "oos_bars": 900, "fold_count": 8, "oos_return_pct": 25.0,
        "max_drawdown_pct": -10.0, "stress_return_pct": 20.0,
        "sharpe": 2.0, "equal_weight_sharpe": 1.0,
        "excess_equal_weight_pct": 12.0, "hac_t_stat": 4.0,
        "positive_fold_ratio": 0.875, "median_fold_excess_pct": -0.2,
        "stress_excess_equal_weight_pct": 8.0, "strategies_tested": 50,
        "max_single_asset_weight_pct": 35.0, "average_invested_asset_hhi": 0.35,
    }
    verdict, reason = _verdict(metrics, min_oos_bars=756, min_folds=6,
                               min_positive_fold_ratio=0.6, z_threshold=3.29)
    assert verdict == "à surveiller"
    assert "médiane" in reason
    metrics["median_fold_excess_pct"] = 0.1
    verdict, _ = _verdict(metrics, min_oos_bars=756, min_folds=6,
                          min_positive_fold_ratio=0.6, z_threshold=3.29)
    assert verdict == "prometteuse"
