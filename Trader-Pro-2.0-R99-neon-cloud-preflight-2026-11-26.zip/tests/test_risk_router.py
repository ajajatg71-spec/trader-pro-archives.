import unittest
from unittest.mock import Mock
from routers.risk import create_risk_router


class RiskRouterTests(unittest.TestCase):
    def test_risk_route_delegates_to_injected_reader(self):
        reader = Mock(return_value={"daily": -12.5, "drawdown": 2.1, "paused": False})
        router = create_risk_router(lambda: None, reader)
        endpoints = {route.path: route.endpoint for route in router.routes}
        self.assertEqual(endpoints["/api/risk"](), {"daily": -12.5, "drawdown": 2.1, "paused": False})
        reader.assert_called_once_with()


if __name__ == "__main__":
    unittest.main()
