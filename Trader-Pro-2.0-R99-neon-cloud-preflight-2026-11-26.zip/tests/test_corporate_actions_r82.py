import unittest
from datetime import date, datetime, timezone
from research_v1.quant.corporate_actions import CorporateActionError, CorporateActionEvent, dividend_total_return_index, split_adjusted_closes

class ExplicitRawPriceBasisTests(unittest.TestCase):
 def setUp(self):
  self.ts=[datetime(2025,1,d,21,tzinfo=timezone.utc) for d in (2,3,6)]
  self.asof=self.ts[-1]
  self.event=CorporateActionEvent("AAPL","dividend",date(2025,1,6),self.ts[0],"test",cash_amount="1",currency="USD")
 def test_total_return_rejects_unspecified_basis(self):
  with self.assertRaisesRegex(CorporateActionError,"raw"):
   dividend_total_return_index([100,100,99],self.ts,[self.event],currency="USD")
 def test_total_return_accepts_explicit_raw_basis(self):
  self.assertAlmostEqual(dividend_total_return_index([100,100,99],self.ts,[self.event],currency="USD",price_basis="raw")[-1],100)
 def test_total_return_rejects_adjusted_basis(self):
  with self.assertRaisesRegex(CorporateActionError,"raw"):
   dividend_total_return_index([100,100,99],self.ts,[self.event],currency="USD",price_basis="all")
 def test_split_adjustment_rejects_unspecified_basis(self):
  split=CorporateActionEvent("AAPL","split",date(2025,1,6),self.ts[0],"test",split_ratio=2)
  with self.assertRaisesRegex(CorporateActionError,"raw"):
   split_adjusted_closes([100,100,50],self.ts,[split],as_of=self.asof)
 def test_split_adjustment_accepts_explicit_raw_basis(self):
  split=CorporateActionEvent("AAPL","split",date(2025,1,6),self.ts[0],"test",split_ratio=2)
  self.assertEqual(split_adjusted_closes([100,100,50],self.ts,[split],as_of=self.asof,price_basis="raw"),(50,50,50))

if __name__=="__main__": unittest.main()
