from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FRONT = ROOT / "frontend"


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def test_frontend_calls_only_existing_read_routes_for_dashboard():
    source = read("frontend/src/main.tsx")
    for route in ("/api/state", "/api/risk", "/api/orders", "/api/health", "/api/logout"):
        assert route in source
    backend = read("routers/dashboard.py") + read("routers/risk.py") + read("routers/orders.py") + read("routers/analytics.py") + read("routers/authentication.py")
    for route in ("/api/state", "/api/risk", "/api/orders", "/api/health", "/api/logout"):
        assert route in backend


def test_frontend_exposes_no_order_mutation_controls():
    source = read("frontend/src/main.tsx")
    for forbidden in ("/api/approve/", "/api/reject/", "/api/cancel/", "/api/plan", "/api/rebalance", "/api/pause"):
        assert forbidden not in source


def test_api_client_uses_same_origin_session_and_no_store():
    source = read("frontend/src/api.ts")
    assert "credentials: 'same-origin'" in source
    assert "cache: 'no-store'" in source
    assert "X-Trader" in source
    assert "window.location.assign('/login')" in source


def test_service_worker_never_caches_api_or_cross_origin_responses():
    source = read("frontend/public/sw.js")
    assert "url.origin !== self.location.origin" in source
    assert "url.pathname.startsWith('/api/')" in source
    assert "request.method !== 'GET'" in source
    assert "offline.html" in source


def test_pwa_shell_assets_exist_and_are_declared_for_install():
    source = read("frontend/public/sw.js")
    for name in ("offline.html", "manifest.webmanifest", "icon-192.png", "icon-512.png"):
        assert (FRONT / "public" / name).is_file()
        assert name in source


def test_backend_keeps_legacy_dashboard_until_react_build_exists():
    source = read("app.py")
    assert "FRONTEND_INDEX" in source
    assert "os.path.isfile(FRONTEND_INDEX)" in source
    assert "page.html" in source


def test_backend_security_requires_https_and_csrf_header_for_writes():
    source = read("app.py")
    assert "if not security.is_https(request)" in source
    assert 'request.headers.get("x-trader") != "1"' in source


def test_frontend_risk_and_daily_indicators_fail_closed_when_data_are_unknown():
    source = read("frontend/src/main.tsx")
    assert "function riskPresentation" in source
    assert "label:'INDISPONIBLE',tone:'negative'" in source
    assert "label:'À VÉRIFIER',tone:'warning'" in source
    assert "function dailyTone" in source
    assert "if(n===0)return 'neutral'" in source
    assert "if(n===null)return 'warning'" in source
    assert "tone={riskState.tone}" in source


def test_frontend_does_not_present_a_limited_recent_order_sample_as_all_open_orders():
    source = read("frontend/src/main.tsx")
    assert "Ordres récents" in source
    assert "20 derniers ordres" in source
    assert "Ordres à surveiller" not in source
    assert "openOrders" not in source


def test_frontend_clears_stale_financial_data_after_a_failed_refresh_and_prevents_overlap():
    source = read("frontend/src/main.tsx")
    assert "const inFlight=useRef(false)" in source
    assert "if(inFlight.current)return" in source
    assert "setState(null);setRisk(null);setOrders([]);setHealth(null);setUpdated(null)" in source


def test_frontend_financial_formatting_does_not_turn_missing_values_into_zero():
    source = read("frontend/src/main.tsx")
    assert "const numericValue=(v:unknown)" in source
    assert "v===null||v===undefined||v===''" in source
    assert "minimumFractionDigits:2,maximumFractionDigits:2" in source
    assert "numericValue(p.pl)===null?'neutral'" in source


def test_service_worker_caches_only_static_assets_and_never_authenticated_html():
    source = read("frontend/public/sw.js")
    assert "url.pathname.startsWith('/api/')" in source
    assert "request.mode === 'navigate'" in source
    assert "url.pathname.startsWith('/assets/')" in source
    assert "request.method !== 'GET'" in source
    assert "CACHE_PREFIX" in source
    assert "response.type === 'basic'" in source


def test_pwa_manifest_declares_standalone_scope_and_french_locale():
    import json
    manifest = json.loads((FRONT / "public" / "manifest.webmanifest").read_text(encoding="utf-8"))
    assert manifest["display"] == "standalone"
    assert manifest["scope"] == "/"
    assert manifest["lang"] == "fr-FR"


def test_react_shell_has_install_prompt_offline_state_and_accessible_navigation():
    source = read("frontend/src/main.tsx")
    assert "beforeinstallprompt" in source
    assert "setOnline(false);setState(null);setRisk(null);setOrders([]);setHealth(null);setUpdated(null)" in source
    assert 'aria-label="Navigation principale"' in source
    assert 'className="skip-link"' in source
    assert 'id="research"' in source


def test_mobile_install_help_covers_ios_and_browser_menu_fallback():
    source = read("frontend/src/main.tsx")
    assert "iphone|ipad|ipod" in source
    assert "Sur l’écran d’accueil" in source
    assert "Installer l’application" in source
    assert 'role="dialog"' in source

def test_connection_indicator_never_labels_offline_session_as_secure():
    source = read("frontend/src/main.tsx")
    assert "online?'Connecté':'Hors ligne'" in source
    assert "Hors ligne — données masquées" in source
    assert "Session sécurisée" not in source

def test_research_preregistration_is_disabled_offline():
    source = read("frontend/src/ResearchRegistry.tsx")
    assert "if (!navigator.onLine)" in source
    assert "disabled={busy||!online}" in source


def test_dashboard_rechecks_connectivity_after_async_requests_before_exposing_financial_data():
    source = read("frontend/src/main.tsx")
    refresh = source.split("const refresh=useCallback(async()=>", 1)[1].split("},[]);", 1)[0]
    assert "if(!navigator.onLine)" in refresh
    assert refresh.count("if(!navigator.onLine)throw new Error(") >= 2
    assert refresh.index("if(!navigator.onLine)throw new Error(") < refresh.index("setState(s);setRisk(r);setOrders(o)")
    assert "Connexion interrompue — données financières masquées." in refresh


def test_dashboard_does_not_start_financial_fetches_when_browser_is_already_offline():
    source = read("frontend/src/main.tsx")
    refresh = source.split("const refresh=useCallback(async()=>", 1)[1].split("},[]);", 1)[0]
    assert refresh.index("if(!navigator.onLine){") < refresh.index("api<AccountState>('/api/state')")
    assert "setState(null);setRisk(null);setOrders([]);setHealth(null);setUpdated(null)" in refresh
