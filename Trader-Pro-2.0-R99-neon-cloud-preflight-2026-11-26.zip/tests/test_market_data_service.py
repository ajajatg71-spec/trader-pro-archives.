import unittest
from datetime import datetime, timezone, timedelta
from services.market_data import (validated_daily_closes, MarketDataError, MarketDataService, ProviderChain,
                                  DailyBars, MarketDataComparison, compare_daily_bars, require_fresh_daily_bars,
                                  inspect_daily_bar_coverage, require_consistent_daily_bars)


class MarketDataServiceTests(unittest.TestCase):
    def test_validates_normalizes_and_caches_bars(self):
        calls = []
        def reader(symbol, limit):
            calls.append((symbol, limit)); return [10, 11, 12], [100, 120, 90]
        service = MarketDataService(reader, ttl_seconds=30)
        a = service.daily_bars(" aapl ", 3)
        b = service.daily_bars("AAPL", 3)
        self.assertEqual(a.closes, (10.0, 11.0, 12.0))
        self.assertIs(a, b)
        self.assertEqual(calls, [("AAPL", 3)])

    def test_rejects_invalid_symbol_and_bad_values(self):
        service = MarketDataService(lambda s, n: ([1, float("nan")], [1, 2]))
        with self.assertRaises(MarketDataError): service.daily_bars("AAPL;DROP", 2)
        with self.assertRaises(MarketDataError): service.daily_bars("AAPL", 2)

    def test_rejects_misaligned_and_short_history(self):
        service = MarketDataService(lambda s, n: ([1, 2, 3], [1]))
        with self.assertRaises(MarketDataError): service.daily_bars("MSFT", 3)

    def test_news_is_cached_and_sanitized(self):
        calls = []
        service = MarketDataService(lambda s, n: ([1, 2], [10, 20]),
                                    lambda s, n: calls.append(s) or [" headline ", "", "second"])
        one = service.news("msft", 3)
        two = service.news("MSFT", 3)
        self.assertEqual(one.headlines, ("headline", "second"))
        self.assertIs(one, two)
        self.assertEqual(calls, ["MSFT"])

    def test_invalidate_forces_refresh(self):
        calls = []
        service = MarketDataService(lambda s, n: calls.append(s) or ([1, 2], [3, 4]))
        service.daily_bars("NVDA", 2)
        service.invalidate("NVDA")
        service.daily_bars("NVDA", 2)
        self.assertEqual(len(calls), 2)


    def test_provider_chain_fails_over_and_records_source(self):
        calls = []
        def primary(symbol, limit):
            calls.append("primary")
            raise TimeoutError("provider down")
        def secondary(symbol, limit):
            calls.append("secondary")
            return ([10, 11], [100, 110])
        service = MarketDataService(ProviderChain([("primary", primary), ("secondary", secondary)]))
        result = service.daily_bars("AAPL", 2)
        self.assertEqual(result.source, "secondary")
        self.assertEqual(calls, ["primary", "secondary"])

    def test_provider_chain_preserves_declared_adjustment_mode(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        stamps = (base, base + timedelta(days=1))
        def split_reader(symbol, limit):
            return (stamps, [10, 11], [100, 110])
        split_reader.adjustment_mode = "split"
        bars = MarketDataService(ProviderChain([("alpaca", split_reader)])).daily_bars("AAPL", 2)
        self.assertEqual(bars.adjustment_mode, "split")
        self.assertEqual(bars.source, "alpaca")

    def test_provider_chain_keeps_legacy_provider_mode_unknown(self):
        bars = MarketDataService(ProviderChain([("legacy", lambda s, n: ([10, 11], [100, 110]))])).daily_bars("AAPL", 2)
        self.assertEqual(bars.adjustment_mode, "unknown")

    def test_provider_chain_health_tracks_failover_without_exposing_error_text(self):
        def primary(symbol, limit):
            raise RuntimeError("https://provider.example/data?token=SECRET")
        chain = ProviderChain([
            ("primary", primary),
            ("backup", lambda s, n: ([10, 11], [100, 110])),
        ])
        result = MarketDataService(chain).daily_bars("AAPL", 2)
        self.assertEqual(result.source, "backup")
        snapshot = chain.health_snapshot()
        self.assertEqual(snapshot["providers"]["primary"]["attempts"], 1)
        self.assertEqual(snapshot["providers"]["primary"]["failures"], 1)
        self.assertEqual(snapshot["providers"]["primary"]["consecutive_failures"], 1)
        self.assertEqual(snapshot["providers"]["primary"]["last_error_type"], "RuntimeError")
        self.assertEqual(snapshot["providers"]["backup"]["successes"], 1)
        self.assertEqual(snapshot["providers"]["backup"]["consecutive_failures"], 0)
        self.assertEqual(snapshot["last_selected_source"], "backup")
        self.assertNotIn("SECRET", repr(snapshot))
        self.assertNotIn("provider.example", repr(snapshot))

    def test_provider_chain_opens_circuit_skips_provider_and_recovers(self):
        monotonic = [100.0]
        primary_calls = []
        primary_available = [False]
        def primary(symbol, limit):
            primary_calls.append(symbol)
            if not primary_available[0]:
                raise TimeoutError("private endpoint token=SECRET")
            return ([20, 21], [200, 210])
        backup = lambda s, n: ([10, 11], [100, 110])
        chain = ProviderChain(
            [("primary", primary), ("backup", backup)],
            monotonic_clock=lambda: monotonic[0],
            failure_threshold=2, cooldown_seconds=10,
        )
        chain("AAPL", 2)
        chain("AAPL", 2)
        self.assertEqual(len(primary_calls), 2)
        snapshot = chain.health_snapshot()["providers"]["primary"]
        self.assertEqual(snapshot["circuit_state"], "open")
        chain("AAPL", 2)
        self.assertEqual(len(primary_calls), 2, "le fournisseur ouvert doit être ignoré")
        snapshot = chain.health_snapshot()["providers"]["primary"]
        self.assertEqual(snapshot["circuit_skips"], 1)
        self.assertEqual(snapshot["attempts"], 2)
        monotonic[0] += 10
        primary_available[0] = True
        recovered = chain("AAPL", 2)
        self.assertEqual(recovered[-1], "primary")
        snapshot = chain.health_snapshot()["providers"]["primary"]
        self.assertEqual(snapshot["circuit_state"], "closed")
        self.assertEqual(snapshot["consecutive_failures"], 0)
        self.assertNotIn("SECRET", repr(chain.health_snapshot()))

    def test_provider_chain_rejects_invalid_circuit_configuration(self):
        with self.assertRaises(ValueError):
            ProviderChain([("one", lambda s, n: ([1, 2], [1, 2]))], failure_threshold=0)
        with self.assertRaises(ValueError):
            ProviderChain([("one", lambda s, n: ([1, 2], [1, 2]))], cooldown_seconds=0)

    def test_provider_chain_health_counts_total_failures(self):
        chain = ProviderChain([
            ("one", lambda s, n: (_ for _ in ()).throw(TimeoutError("secret-url"))),
            ("two", lambda s, n: ([], [])),
        ])
        with self.assertRaises(MarketDataError):
            chain("AAPL", 2)
        snapshot = chain.health_snapshot()
        self.assertEqual(snapshot["providers"]["one"]["failures"], 1)
        self.assertEqual(snapshot["providers"]["two"]["failures"], 1)
        self.assertIsNone(snapshot["last_selected_source"])
        self.assertNotIn("secret-url", repr(snapshot))

    def test_provider_chain_skips_malformed_primary_payload(self):
        chain = ProviderChain([
            ("primary", lambda s, n: ([10, 11], [100])),
            ("backup", lambda s, n: ([12, 13], [120, 130])),
        ])
        result = MarketDataService(chain).daily_bars("MSFT", 2)
        self.assertEqual(result.closes, (12.0, 13.0))
        self.assertEqual(result.source, "backup")


    def test_provider_chain_fails_over_on_invalid_numeric_data(self):
        chain = ProviderChain([
            ("primary", lambda s, n: ([10, float("nan")], [1, 2])),
            ("backup", lambda s, n: ([20, 21], [2, 3])),
        ])
        result = MarketDataService(chain).daily_bars("AAPL", 2)
        self.assertEqual(result.source, "backup")
        self.assertEqual(result.closes, (20.0, 21.0))

    def test_provider_chain_fails_over_on_invalid_timestamps(self):
        chain = ProviderChain([
            ("primary", lambda s, n: (["2026-01-02T00:00:00Z", "2026-01-01T00:00:00Z"], [10, 11], [1, 2])),
            ("backup", lambda s, n: (["2026-01-01T00:00:00Z", "2026-01-02T00:00:00Z"], [12, 13], [2, 3])),
        ])
        result = MarketDataService(chain).daily_bars("AAPL", 2)
        self.assertEqual(result.source, "backup")
        self.assertEqual(len(result.timestamps), 2)

    def test_provider_chain_reports_all_provider_failures(self):
        chain = ProviderChain([
            ("one", lambda s, n: (_ for _ in ()).throw(TimeoutError())),
            ("two", lambda s, n: ([], [])),
        ])
        with self.assertRaisesRegex(MarketDataError, "one.*two"):
            MarketDataService(chain).daily_bars("NVDA", 2)

    def test_compares_providers_on_matching_timestamps(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        stamps = (base, base + timedelta(days=1), base + timedelta(days=2))
        primary = DailyBars("AAPL", (100.0, 101.0, 102.0), (10, 10, 10), base,
                            source="primary", timestamps=stamps)
        secondary = DailyBars("AAPL", (100.1, 101.1, 103.0), (9, 9, 9), base,
                              source="secondary", timestamps=stamps)
        result = compare_daily_bars(primary, secondary, tolerance_pct=0.5)
        self.assertEqual(result.matched_bars, 3)
        self.assertEqual(result.primary_only_bars, 0)
        self.assertFalse(result.within_tolerance)
        self.assertGreater(result.max_close_deviation_pct, 0.5)

    def test_comparison_reports_volume_deviation_and_overlap(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        stamps = (base, base + timedelta(days=1), base + timedelta(days=2))
        primary = DailyBars("AAPL", (100, 101, 102), (100, 0, 50), base,
                            source="primary", timestamps=stamps)
        secondary = DailyBars("AAPL", (100, 101, 102), (90, 0, 25), base,
                              source="secondary", timestamps=stamps)
        result = compare_daily_bars(primary, secondary, volume_tolerance_pct=50)
        self.assertAlmostEqual(result.max_volume_deviation_pct, 50.0)
        self.assertAlmostEqual(result.mean_volume_deviation_pct, (10 + 0 + 50) / 3)
        self.assertTrue(result.within_volume_tolerance)
        self.assertEqual(result.overlap_pct, 100.0)

    def test_quality_gate_accepts_consistent_high_overlap_histories(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        stamps = (base, base + timedelta(days=1), base + timedelta(days=2))
        a = DailyBars("AAPL", (10, 11, 12), (100, 110, 120), base, source="p", timestamps=stamps, adjustment_mode="split")
        b = DailyBars("AAPL", (10.01, 11.01, 12.01), (101, 109, 121), base, source="q", timestamps=stamps, adjustment_mode="split")
        comparison = compare_daily_bars(a, b)
        self.assertIs(require_consistent_daily_bars(comparison), comparison)


    def test_quality_gate_rejects_unknown_adjustment_provenance(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        stamps = (base, base + timedelta(days=1))
        a = DailyBars("AAPL", (10, 11), (1, 1), base, source="p", timestamps=stamps, adjustment_mode="split")
        b = DailyBars("AAPL", (10, 11), (1, 1), base, source="q", timestamps=stamps)
        report = compare_daily_bars(a, b)
        self.assertFalse(report.adjustment_verified)
        with self.assertRaisesRegex(MarketDataError, "ajustement"):
            require_consistent_daily_bars(report)

    def test_quality_gate_rejects_different_adjustment_modes(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        stamps = (base, base + timedelta(days=1))
        a = DailyBars("AAPL", (10, 11), (1, 1), base, source="p", timestamps=stamps, adjustment_mode="split")
        b = DailyBars("AAPL", (10, 11), (1, 1), base, source="q", timestamps=stamps, adjustment_mode="raw")
        report = compare_daily_bars(a, b)
        with self.assertRaisesRegex(MarketDataError, "ajustement"):
            require_consistent_daily_bars(report)

    def test_matching_declared_adjustment_modes_are_verified(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        stamps = (base, base + timedelta(days=1))
        a = DailyBars("AAPL", (10, 11), (1, 1), base, source="p", timestamps=stamps, adjustment_mode="split")
        b = DailyBars("AAPL", (10, 11), (1, 1), base, source="q", timestamps=stamps, adjustment_mode="split")
        report = compare_daily_bars(a, b)
        self.assertTrue(report.adjustment_verified)
        self.assertIs(require_consistent_daily_bars(report), report)

    def test_quality_gate_rejects_low_overlap(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        a = DailyBars("AAPL", (10, 11, 12), (1, 1, 1), base, source="p",
                      timestamps=(base, base + timedelta(days=1), base + timedelta(days=2)))
        b = DailyBars("AAPL", (11, 12, 13), (1, 1, 1), base, source="q",
                      timestamps=(base + timedelta(days=1), base + timedelta(days=2), base + timedelta(days=3)))
        comparison = compare_daily_bars(a, b)
        with self.assertRaisesRegex(MarketDataError, "Recouvrement"):
            require_consistent_daily_bars(comparison, min_overlap_pct=90)

    def test_quality_gate_rejects_close_price_deviation(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        stamps = (base, base + timedelta(days=1))
        a = DailyBars("AAPL", (10, 11), (1, 1), base, source="p", timestamps=stamps)
        b = DailyBars("AAPL", (10, 12), (1, 1), base, source="q", timestamps=stamps)
        with self.assertRaisesRegex(MarketDataError, "clôture"):
            require_consistent_daily_bars(compare_daily_bars(a, b))

    def test_quality_gate_handles_close_deviation_above_one_hundred_percent(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        stamps = (base, base + timedelta(days=1))
        a = DailyBars("AAPL", (10, 10), (1, 1), base, source="p", timestamps=stamps)
        b = DailyBars("AAPL", (30, 30), (1, 1), base, source="q", timestamps=stamps)
        comparison = compare_daily_bars(a, b)
        self.assertEqual(comparison.max_close_deviation_pct, 200.0)
        with self.assertRaisesRegex(MarketDataError, "clôture"):
            require_consistent_daily_bars(comparison)

    def test_quality_gate_can_ignore_volume_but_not_close_prices(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        stamps = (base, base + timedelta(days=1))
        a = DailyBars("AAPL", (10, 11), (100, 100), base, source="p", timestamps=stamps, adjustment_mode="split")
        b = DailyBars("AAPL", (10, 11), (1000, 1000), base, source="q", timestamps=stamps, adjustment_mode="split")
        comparison = compare_daily_bars(a, b)
        with self.assertRaisesRegex(MarketDataError, "volume"):
            require_consistent_daily_bars(comparison)
        self.assertIs(require_consistent_daily_bars(comparison, require_volume=False), comparison)

    def test_quality_gate_rejects_forged_or_malformed_comparison_reports(self):
        valid = MarketDataComparison(
            primary_source="alpaca_iex", secondary_source="twelvedata",
            matched_bars=2, primary_only_bars=0, secondary_only_bars=0,
            max_close_deviation_pct=0.1, mean_close_deviation_pct=0.1,
            within_tolerance=True, max_volume_deviation_pct=0.0,
            mean_volume_deviation_pct=0.0, within_volume_tolerance=True,
            overlap_pct=100.0, primary_adjustment_mode="split",
            secondary_adjustment_mode="split", adjustment_verified=True,
        )
        self.assertIs(require_consistent_daily_bars(valid), valid)
        invalid_reports = (
            __import__("dataclasses").replace(valid, overlap_pct=float("nan")),
            __import__("dataclasses").replace(valid, matched_bars=True),
            __import__("dataclasses").replace(valid, primary_source="twelvedata"),
            __import__("dataclasses").replace(valid, within_tolerance=1),
            __import__("dataclasses").replace(valid, max_close_deviation_pct=float("inf")),
            __import__("dataclasses").replace(valid, mean_close_deviation_pct=0.2),
            __import__("dataclasses").replace(valid, max_volume_deviation_pct=None),
            # A caller cannot forge a passing verdict while supplying a large
            # deviation, or alter the reported overlap independently of counts.
            __import__("dataclasses").replace(valid, max_close_deviation_pct=25.0,
                                               mean_close_deviation_pct=25.0),
            __import__("dataclasses").replace(valid, overlap_pct=50.0),
            __import__("dataclasses").replace(valid, primary_only_bars=2),
            __import__("dataclasses").replace(valid, close_tolerance_pct=float("nan")),
            __import__("dataclasses").replace(valid, max_volume_deviation_pct=50.0,
                                               mean_volume_deviation_pct=50.0),
        )
        for report in invalid_reports:
            with self.subTest(report=report), self.assertRaises(MarketDataError):
                require_consistent_daily_bars(report)

    def test_comparison_records_explicit_tolerance_thresholds(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        stamps = (base, base + timedelta(days=1))
        a = DailyBars("AAPL", (100, 101), (100, 100), base, source="p", timestamps=stamps)
        b = DailyBars("AAPL", (100.2, 101.2), (105, 105), base, source="q", timestamps=stamps)
        report = compare_daily_bars(a, b, tolerance_pct=0.25, volume_tolerance_pct=4.0)
        self.assertEqual(report.close_tolerance_pct, 0.25)
        self.assertEqual(report.volume_tolerance_pct, 4.0)
        self.assertTrue(report.within_tolerance)
        self.assertFalse(report.within_volume_tolerance)
        with self.assertRaisesRegex(MarketDataError, "volume"):
            require_consistent_daily_bars(report)

    def test_comparison_matches_equivalent_timezone_instants(self):
        from zoneinfo import ZoneInfo
        from datetime import timedelta
        eastern = ZoneInfo("America/New_York")
        stamps_a = (datetime(2026, 1, 5, 0, 0, tzinfo=eastern),
                    datetime(2026, 1, 6, 0, 0, tzinfo=eastern))
        stamps_b = tuple(stamp.astimezone(timezone.utc) for stamp in stamps_a)
        a = DailyBars("AAPL", (100, 101), (1000, 1100), stamps_a[-1],
                      source="alpaca_iex", timestamps=stamps_a)
        b = DailyBars("AAPL", (100, 101), (1000, 1100), stamps_b[-1],
                      source="twelvedata", timestamps=stamps_b)
        result = compare_daily_bars(a, b)
        self.assertEqual(result.matched_bars, 2)
        self.assertEqual(result.overlap_pct, 100.0)

    def test_quality_gate_validates_overlap_parameter(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        stamps = (base, base + timedelta(days=1))
        a = DailyBars("AAPL", (10, 11), (1, 1), base, source="p", timestamps=stamps)
        b = DailyBars("AAPL", (10, 11), (1, 1), base, source="q", timestamps=stamps)
        comparison = compare_daily_bars(a, b)
        for value in (-1, 101, float("nan"), "bad"):
            with self.subTest(value=value), self.assertRaises(MarketDataError):
                require_consistent_daily_bars(comparison, min_overlap_pct=value)

    def test_comparison_rejects_misaligned_or_invalid_volumes(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        stamps = (base, base + timedelta(days=1))
        valid = DailyBars("AAPL", (10, 11), (1, 2), base, source="p", timestamps=stamps)
        short_volumes = DailyBars("AAPL", (10, 11), (1,), base, source="q", timestamps=stamps)
        with self.assertRaisesRegex(MarketDataError, "désalignés"):
            compare_daily_bars(valid, short_volumes)
        invalid_volumes = DailyBars("AAPL", (10, 11), (1, float("nan")), base,
                                    source="q", timestamps=stamps)
        with self.assertRaisesRegex(MarketDataError, "Volume invalide"):
            compare_daily_bars(valid, invalid_volumes)

    def test_comparison_rejects_invalid_volume_tolerance(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        stamps = (base, base + timedelta(days=1))
        a = DailyBars("AAPL", (10, 11), (1, 2), base, source="p", timestamps=stamps)
        b = DailyBars("AAPL", (10, 11), (1, 2), base, source="q", timestamps=stamps)
        for tolerance in (float("nan"), float("inf"), -1, "invalid"):
            with self.subTest(tolerance=tolerance), self.assertRaises(MarketDataError):
                compare_daily_bars(a, b, volume_tolerance_pct=tolerance)

    def test_comparison_reports_different_history_coverage(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        p = DailyBars("AAPL", (10, 11), (1, 1), base, source="p",
                      timestamps=(base, base + timedelta(days=1)))
        q = DailyBars("AAPL", (11, 12), (1, 1), base, source="q",
                      timestamps=(base + timedelta(days=1), base + timedelta(days=2)))
        result = compare_daily_bars(p, q)
        self.assertEqual(result.matched_bars, 1)
        self.assertEqual(result.primary_only_bars, 1)
        self.assertEqual(result.secondary_only_bars, 1)

    def test_comparison_rejects_missing_timestamps_and_no_overlap(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        untimed = DailyBars("AAPL", (10, 11), (1, 1), base)
        timed = DailyBars("AAPL", (10, 11), (1, 1), base, timestamps=(base, base + timedelta(days=1)))
        with self.assertRaises(MarketDataError):
            compare_daily_bars(untimed, timed)
        other = DailyBars("AAPL", (10, 11), (1, 1), base, timestamps=(base + timedelta(days=3), base + timedelta(days=4)))
        with self.assertRaises(MarketDataError):
            compare_daily_bars(timed, other)

    def test_comparison_rejects_duplicate_timestamps(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        duplicate = DailyBars("AAPL", (10, 11), (1, 1), base, source="p",
                              timestamps=(base, base))
        valid = DailyBars("AAPL", (10, 11), (1, 1), base, source="q",
                          timestamps=(base, base + timedelta(days=1)))
        with self.assertRaisesRegex(MarketDataError, "dupliqué"):
            compare_daily_bars(duplicate, valid)

    def test_comparison_rejects_different_symbols_or_same_source(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        stamps = (base, base + timedelta(days=1))
        a = DailyBars("AAPL", (10, 11), (1, 1), base, source="p", timestamps=stamps)
        different_symbol = DailyBars("MSFT", (10, 11), (1, 1), base, source="q", timestamps=stamps)
        same_source = DailyBars("AAPL", (10, 11), (1, 1), base, source="p", timestamps=stamps)
        with self.assertRaisesRegex(MarketDataError, "symboles différents"):
            compare_daily_bars(a, different_symbol)
        with self.assertRaisesRegex(MarketDataError, "fournisseurs distincts"):
            compare_daily_bars(a, same_source)

    def test_comparison_rejects_non_finite_or_invalid_tolerance(self):
        base = datetime(2026, 1, 1, tzinfo=timezone.utc)
        stamps = (base, base + timedelta(days=1))
        a = DailyBars("AAPL", (10, 11), (1, 1), base, source="p", timestamps=stamps)
        b = DailyBars("AAPL", (10, 11), (1, 1), base, source="q", timestamps=stamps)
        for tolerance in (float("nan"), float("inf"), -0.1, "invalid"):
            with self.subTest(tolerance=tolerance), self.assertRaises(MarketDataError):
                compare_daily_bars(a, b, tolerance_pct=tolerance)


    def test_freshness_accepts_last_completed_xnys_session(self):
        now = datetime(2026, 11, 10, 22, 0, tzinfo=timezone.utc)
        stamp = datetime(2026, 11, 10, 14, 30, tzinfo=timezone.utc)
        bars = DailyBars("AAPL", (10.0, 11.0), (1, 2), now,
                         timestamps=(stamp - timedelta(days=1), stamp))
        self.assertEqual(require_fresh_daily_bars(bars, now=now), now - stamp)

    def test_freshness_rejects_previous_session_after_new_session_closed(self):
        now = datetime(2026, 11, 10, 22, 0, tzinfo=timezone.utc)
        old = datetime(2026, 11, 9, 14, 30, tzinfo=timezone.utc)
        bars = DailyBars("AAPL", (10.0, 11.0), (1, 2), now,
                         timestamps=(old - timedelta(days=3), old))
        with self.assertRaisesRegex(MarketDataError, "Données périmées"):
            require_fresh_daily_bars(bars, now=now)

    def test_freshness_handles_weekend_without_calendar_day_false_alarm(self):
        now = datetime(2026, 11, 14, 20, 0, tzinfo=timezone.utc)  # Saturday
        friday = datetime(2026, 11, 13, 14, 30, tzinfo=timezone.utc)
        bars = DailyBars("AAPL", (10.0, 11.0), (1, 2), now,
                         timestamps=(friday - timedelta(days=1), friday))
        self.assertEqual(require_fresh_daily_bars(bars, now=now), now - friday)

    def test_freshness_rejects_weekend_bar_timestamp(self):
        now = datetime(2026, 11, 14, 20, 0, tzinfo=timezone.utc)
        saturday = datetime(2026, 11, 14, 14, 30, tzinfo=timezone.utc)
        bars = DailyBars("AAPL", (10.0, 11.0), (1, 2), now,
                         timestamps=(saturday - timedelta(days=1), saturday))
        with self.assertRaisesRegex(MarketDataError, "calendrier boursier"):
            require_fresh_daily_bars(bars, now=now)

    def test_freshness_does_not_expect_current_session_before_close(self):
        now = datetime(2026, 11, 10, 19, 0, tzinfo=timezone.utc)  # 14:00 ET, before close
        monday = datetime(2026, 11, 9, 14, 30, tzinfo=timezone.utc)
        bars = DailyBars("AAPL", (10.0, 11.0), (1, 2), now,
                         timestamps=(monday - timedelta(days=1), monday))
        self.assertEqual(require_fresh_daily_bars(bars, now=now), now - monday)

    def test_freshness_handles_thanksgiving_holiday(self):
        now = datetime(2026, 11, 26, 20, 0, tzinfo=timezone.utc)  # Thanksgiving
        wednesday = datetime(2026, 11, 25, 14, 30, tzinfo=timezone.utc)
        bars = DailyBars("AAPL", (10.0, 11.0), (1, 2), now,
                         timestamps=(wednesday - timedelta(days=1), wednesday))
        self.assertEqual(require_fresh_daily_bars(bars, now=now), now - wednesday)

    def test_freshness_handles_early_close(self):
        friday = datetime(2026, 11, 27, 18, 20, tzinfo=timezone.utc)  # 15 min after 13:00 ET close + delay
        stamp = datetime(2026, 11, 27, 14, 30, tzinfo=timezone.utc)
        bars = DailyBars("AAPL", (10.0, 11.0), (1, 2), friday,
                         timestamps=(stamp - timedelta(days=1), stamp))
        self.assertEqual(require_fresh_daily_bars(bars, now=friday), friday - stamp)

    def test_freshness_rejects_missing_timestamps_by_default(self):
        now = datetime(2026, 11, 10, 22, 0, tzinfo=timezone.utc)
        bars = DailyBars("AAPL", (10.0, 11.0), (1, 2), now)
        with self.assertRaisesRegex(MarketDataError, "horodatages.*absents"):
            require_fresh_daily_bars(bars, now=now)

    def test_freshness_rejects_future_timestamp(self):
        now = datetime(2026, 11, 10, 22, 0, tzinfo=timezone.utc)
        future = now + timedelta(minutes=1)
        bars = DailyBars("AAPL", (10.0, 11.0), (1, 2), now,
                         timestamps=(future - timedelta(days=1), future))
        with self.assertRaisesRegex(MarketDataError, "futur"):
            require_fresh_daily_bars(bars, now=now)

    def test_freshness_rejects_naive_now_and_invalid_publication_delay(self):
        now = datetime(2026, 11, 10, 22, 0, tzinfo=timezone.utc)
        stamp = datetime(2026, 11, 10, 14, 30, tzinfo=timezone.utc)
        bars = DailyBars("AAPL", (10.0, 11.0), (1, 2), now,
                         timestamps=(stamp - timedelta(days=1), stamp))
        with self.assertRaises(ValueError):
            require_fresh_daily_bars(bars, now=datetime(2026, 11, 10, 22))
        with self.assertRaises(ValueError):
            require_fresh_daily_bars(bars, now=now, publication_delay=-timedelta(minutes=1))

    def test_coverage_ignores_weekends_and_exchange_holidays(self):
        # Friday 20 Nov, Monday 23 Nov and Tuesday 24 Nov 2026.
        stamps = tuple(datetime(2026, 11, day, 15, 0, tzinfo=timezone.utc)
                       for day in (20, 23, 24))
        bars = DailyBars("AAPL", (10, 11, 12), (1, 1, 1), stamps[-1], timestamps=stamps)
        report = inspect_daily_bar_coverage(bars)
        self.assertEqual(report.expected_sessions, 3)
        self.assertTrue(report.complete)

    def test_coverage_reports_missing_trading_session(self):
        stamps = tuple(datetime(2026, 11, day, 15, 0, tzinfo=timezone.utc)
                       for day in (20, 24))  # Monday 23 November is missing
        bars = DailyBars("AAPL", (10, 12), (1, 1), stamps[-1], timestamps=stamps)
        report = inspect_daily_bar_coverage(bars)
        self.assertEqual(report.missing_sessions, ("2026-11-23",))
        self.assertFalse(report.complete)
        with self.assertRaisesRegex(MarketDataError, "2026-11-23"):
            inspect_daily_bar_coverage(bars, max_missing_sessions=0)

    def test_coverage_rejects_non_session_and_duplicate_timestamps(self):
        saturday = datetime(2026, 11, 21, 15, 0, tzinfo=timezone.utc)
        bars = DailyBars("AAPL", (10, 11), (1, 1), saturday,
                         timestamps=(saturday - timedelta(days=1), saturday))
        with self.assertRaisesRegex(MarketDataError, "jour non ouvré"):
            inspect_daily_bar_coverage(bars)
        friday = datetime(2026, 11, 20, 15, 0, tzinfo=timezone.utc)
        duplicate = DailyBars("AAPL", (10, 11), (1, 1), friday,
                              timestamps=(friday, friday))
        with self.assertRaisesRegex(MarketDataError, "dupliqués"):
            inspect_daily_bar_coverage(duplicate)

    def test_provider_chain_rejects_duplicate_names(self):
        with self.assertRaises(ValueError):
            ProviderChain([("same", lambda s, n: ([], [])), ("same", lambda s, n: ([], []))])

    def test_preserves_provider_timestamps_as_utc(self):
        service = MarketDataService(lambda s, n: (
            ["2026-01-01T00:00:00Z", "2026-01-02T00:00:00Z"], [10, 11], [1, 2]
        ))
        result = service.daily_bars("AAPL", 2)
        self.assertEqual(result.timestamps[0].isoformat(), "2026-01-01T00:00:00+00:00")
        self.assertEqual(len(result.timestamps), result.count)

    def test_rejects_non_monotonic_or_naive_provider_timestamps(self):
        bad_orders = [
            ["2026-01-02T00:00:00Z", "2026-01-01T00:00:00Z"],
            ["2026-01-01T00:00:00", "2026-01-02T00:00:00Z"],
        ]
        for stamps in bad_orders:
            service = MarketDataService(lambda s, n, stamps=stamps: ([10, 11], [1, 2], stamps))
            with self.assertRaises(MarketDataError):
                service.daily_bars("AAPL", 2)


    def test_risk_consumer_uses_same_freshness_gate_as_signals(self):
        now = datetime(2026, 1, 5, 22, 0, tzinfo=timezone.utc)
        stamp = datetime(2026, 1, 5, 21, 0, tzinfo=timezone.utc)
        service = MarketDataService(lambda symbol, limit: ([stamp, stamp], [10, 11], [1, 1]))
        # Duplicate timestamps are rejected at the provider boundary, before
        # any risk model can consume a misleading close series.
        with self.assertRaises(MarketDataError):
            validated_daily_closes(service, "AAPL", now=now)

    def test_risk_consumer_rejects_stale_market_data(self):
        now = datetime(2026, 1, 6, 22, 0, tzinfo=timezone.utc)
        stale = datetime(2026, 1, 5, 21, 0, tzinfo=timezone.utc)
        service = MarketDataService(lambda symbol, limit: (
            [stale, stale + timedelta(minutes=1)], [10, 11], [1, 1]
        ))
        with self.assertRaisesRegex(MarketDataError, "périmées"):
            validated_daily_closes(service, "AAPL", now=now)

if __name__ == "__main__": unittest.main()
