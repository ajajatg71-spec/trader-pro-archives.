from pathlib import Path


def test_neon_readonly_workflow_is_manual_only_and_uses_secret():
    workflow = (
        Path(__file__).resolve().parents[1]
        / ".github"
        / "workflows"
        / "neon-readonly-preflight.yml"
    ).read_text(encoding="utf-8")
    assert "workflow_dispatch:" in workflow
    assert "push:" not in workflow
    assert "pull_request:" not in workflow
    assert "secrets.TRADER_PRO_TEST_DATABASE_URL" in workflow
    assert "scripts/verify_neon_sqlalchemy_readonly.py" in workflow
    assert "scripts/run_alpaca_paper_orders.py" not in workflow
    assert "TRADER_PRO_TEST_DATABASE_DISPOSABLE" not in workflow
