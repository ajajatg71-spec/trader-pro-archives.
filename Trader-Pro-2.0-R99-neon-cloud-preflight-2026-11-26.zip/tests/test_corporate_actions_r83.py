import unittest
from datetime import date, datetime, timezone
from research_v1.quant.corporate_actions import CorporateActionBatch, CorporateActionError, CorporateActionEvent

class CorporateActionBatchEnvelopeTests(unittest.TestCase):
 def setUp(self):
  self.at=datetime(2025,1,1,tzinfo=timezone.utc)
  self.event=CorporateActionEvent("AAPL","dividend",date(2025,1,2),self.at,"alpaca",cash_amount="0.5",currency="USD",event_id="e1")
 def batch(self, **kw):
  values=dict(events=(self.event,),requested_symbols=("AAPL",),start_date=date(2025,1,1),end_date=date(2025,1,31),retrieved_at=self.at,pages_fetched=1,pagination_complete=True,source="alpaca")
  values.update(kw); return CorporateActionBatch(**values)
 def test_accepts_complete_scoped_batch(self): self.assertEqual(self.batch().events,(self.event,))
 def test_rejects_incomplete_pagination(self):
  with self.assertRaisesRegex(CorporateActionError,"pagination non terminée"): self.batch(pagination_complete=False)
 def test_rejects_event_outside_requested_universe(self):
  other=CorporateActionEvent("MSFT","dividend",date(2025,1,2),self.at,"alpaca",cash_amount="0.5",currency="USD")
  with self.assertRaisesRegex(CorporateActionError,"hors univers"): self.batch(events=(other,))
 def test_rejects_source_mismatch(self):
  other=CorporateActionEvent("AAPL","dividend",date(2025,1,2),self.at,"other",cash_amount="0.5",currency="USD")
  with self.assertRaisesRegex(CorporateActionError,"hors source"): self.batch(events=(other,))
 def test_rejects_duplicate_requested_symbols(self):
  with self.assertRaisesRegex(CorporateActionError,"dupliqués"): self.batch(requested_symbols=("AAPL","AAPL"))
 def test_rejects_naive_retrieval_timestamp(self):
  with self.assertRaisesRegex(CorporateActionError,"retrieved_at"): self.batch(retrieved_at=datetime(2025,1,1))

if __name__=="__main__": unittest.main()
