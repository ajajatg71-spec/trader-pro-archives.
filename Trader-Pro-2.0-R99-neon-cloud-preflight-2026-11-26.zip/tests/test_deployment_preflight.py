from scripts.deployment_preflight import PAPER_URL, validate_environment
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def valid_env():
    return {
        "BROKER": "alpaca",
        "ALPACA_BASE_URL": PAPER_URL,
        "APCA_API_KEY_ID": "paper-key-id",
        "APCA_API_SECRET_KEY": "paper-secret-key",
        "APP_PASSWORD": "a-strong-app-password",
        "TOTP_SECRET": "JBSWY3DPEHPK3PXP",
        "DATABASE_URL": "postgresql+psycopg://user:pass@db.example/trader",
        "TRADER_OPERATOR_PASSWORD": "a-different-operator-password-2026",
        "TRADER_OPERATOR_TOTP_SECRET": "KRUGS4ZANFZSAYJA",
        "TRUSTED_PROXY_IPS": "10.0.0.10/32",
        "SEC_USER_AGENT": "TraderPro contact ops@example.com",
    }


def test_valid_paper_production_environment_passes():
    assert validate_environment(valid_env()) == []


def test_simulator_or_unspecified_broker_fails_production_preflight():
    env = valid_env()
    env["BROKER"] = "sim"
    assert any("BROKER" in error for error in validate_environment(env))


def test_live_or_non_official_alpaca_endpoint_is_rejected():
    env = valid_env()
    env["ALPACA_BASE_URL"] = "https://api.alpaca.markets"
    assert any("ALPACA_BASE_URL" in error for error in validate_environment(env))


def test_database_and_operator_secrets_are_mandatory_and_distinct():
    env = valid_env()
    env["DATABASE_URL"] = "sqlite:///trader.db"
    env["TRADER_OPERATOR_PASSWORD"] = env["APP_PASSWORD"]
    errors = validate_environment(env)
    assert any("DATABASE_URL" in error for error in errors)
    assert any("distincts" in error for error in errors)


def test_wildcard_trusted_proxy_is_rejected():
    env = valid_env()
    env["TRUSTED_PROXY_IPS"] = "0.0.0.0/0"
    assert any("TRUSTED_PROXY_IPS" in error for error in validate_environment(env))


def test_dockerfile_builds_and_copies_the_compiled_react_frontend():
    dockerfile = (ROOT / "Dockerfile").read_text(encoding="utf-8")
    assert "FROM node:22-alpine AS frontend-build" in dockerfile
    assert "RUN npm run build" in dockerfile
    assert "COPY --from=frontend-build /web/dist ./frontend/dist" in dockerfile
    assert "HEALTHCHECK" in dockerfile


def test_missing_paper_endpoint_is_rejected_even_though_paper_is_default_elsewhere():
    env = valid_env()
    del env["ALPACA_BASE_URL"]
    assert any("ALPACA_BASE_URL" in error for error in validate_environment(env))


def test_missing_sec_user_agent_is_rejected():
    env = valid_env()
    del env["SEC_USER_AGENT"]
    assert any("SEC_USER_AGENT" in error for error in validate_environment(env))


def test_broad_or_malformed_proxy_network_is_rejected():
    for proxy in ("10.0.0.0/8", "2001:db8::/16", "not-an-ip"):
        env = valid_env()
        env["TRUSTED_PROXY_IPS"] = proxy
        assert any("TRUSTED_PROXY_IPS" in error for error in validate_environment(env))


def test_multiple_narrow_proxy_addresses_are_accepted():
    env = valid_env()
    env["TRUSTED_PROXY_IPS"] = "10.0.0.10/32,2001:db8::10/128"
    assert validate_environment(env) == []


def test_docker_build_requires_lockfile_and_uses_npm_ci():
    dockerfile = (ROOT / "Dockerfile").read_text(encoding="utf-8")
    assert "COPY frontend/package.json frontend/package-lock.json ./" in dockerfile
    assert "RUN npm ci --no-audit --no-fund" in dockerfile
    assert "RUN npm install" not in dockerfile


def test_dockerignore_excludes_secrets_and_runtime_financial_state():
    dockerignore = (ROOT / ".dockerignore").read_text(encoding="utf-8")
    for entry in (".env", ".env.*", "state.json", "history.jsonl", "backups/", "*.db"):
        assert entry in dockerignore
