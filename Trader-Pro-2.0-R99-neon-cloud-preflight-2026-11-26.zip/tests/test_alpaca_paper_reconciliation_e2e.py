"""Offline end-to-end contract test for the Paper event -> fill -> reconciliation path.

Uses a deterministic fake broker and SQLite only. It does not contact Alpaca,
create an order, or claim a real Paper execution.
"""
from __future__ import annotations

import tempfile
from pathlib import Path

from sqlalchemy import create_engine, func, select

from db.base import Base
from db.models import (
    AccountSnapshotRecord,
    BrokerEventRecord,
    FillRecord,
    OrderRecord,
    ReconciliationRunRecord,
)
from db.order_repository import OrderRepository
from db.session import build_session_factory
from services.alpaca_trade_updates import persist_trade_update
from services.broker_events import BrokerEventProcessor
from services.reconciliation import ReconciliationService


class _PaperSnapshot:
    def __init__(self):
        self.remote_orders = [{
            "id": "paper-order-e2e-1",
            "client_order_id": "tp-paper-e2e-1",
            "symbol": "F",
            "side": "buy",
            "status": "filled",
            "qty": "1",
            "filled_qty": "1",
            "filled_avg_price": "11.25",
        }]
        self.remote_fills = [{
            "id": "paper-fill-e2e-1",
            "order_id": "paper-order-e2e-1",
            "symbol": "F",
            "side": "buy",
            "qty": "1",
            "price": "11.25",
            "fee": "0",
            "time": "2026-11-26T15:00:00Z",
        }]

    def orders(self, status="all", limit=10000):
        return self.remote_orders[:limit]

    def fills(self, pages=10):
        return self.remote_fills

    def account(self):
        return {"equity": "10000", "cash": "9988.75", "buying_power": "19977.50"}

    def positions(self):
        return [{
            "symbol": "F",
            "qty": "1",
            "market_value": "11.25",
            "avg_entry_price": "11.25",
            "unrealized_pl": "0",
        }]


def test_trade_update_drives_durable_fill_and_complete_reconciliation():
    with tempfile.TemporaryDirectory() as temp_dir:
        engine = create_engine(f"sqlite:///{Path(temp_dir) / 'paper-e2e.db'}")
        Base.metadata.create_all(engine)
        sessions = build_session_factory(engine)
        try:
            repository = OrderRepository(sessions)
            assert repository.stage_order(
                client_order_id="tp-paper-e2e-1",
                symbol="F",
                side="buy",
                notional=11.25,
                source="paper_e2e_test",
            )
            broker = _PaperSnapshot()
            reconciliation = ReconciliationService(repository, broker)
            processor = BrokerEventProcessor(sessions, reconciliation)
            notification = {
                "stream": "trade_updates",
                "data": {
                    "event": "fill",
                    "execution_id": "paper-fill-e2e-1",
                    "timestamp": "2026-11-26T15:00:00Z",
                    "order": {
                        "id": "paper-order-e2e-1",
                        "client_order_id": "tp-paper-e2e-1",
                        "symbol": "F",
                        "side": "buy",
                        "status": "filled",
                        "qty": "1",
                        "filled_qty": "1",
                    },
                },
            }

            assert persist_trade_update(notification, processor) is True
            result = processor.process_pending()
            assert result["processed"] == 1
            assert result["failed"] == 0
            assert result["reconciliation"]["fills_recorded"] == 1
            assert result["reconciliation"]["reconciliation_evidence"]["status"] == "succeeded"
            assert result["reconciliation"]["reconciliation_evidence"]["snapshot_complete"] is True

            # Provider event replay is idempotent and does not trigger a second run.
            assert persist_trade_update(notification, processor) is False
            assert processor.process_pending()["claimed"] == 0

            with sessions() as session:
                order = session.scalar(select(OrderRecord).where(
                    OrderRecord.client_order_id == "tp-paper-e2e-1"))
                assert order is not None
                assert order.status == "filled"
                assert order.broker_order_id == "paper-order-e2e-1"
                assert session.scalar(select(func.count()).select_from(FillRecord)) == 1
                assert session.scalar(select(func.count()).select_from(AccountSnapshotRecord)) == 1
                assert session.scalar(select(func.count()).select_from(ReconciliationRunRecord)) == 1
                event = session.scalar(select(BrokerEventRecord))
                assert event is not None and event.status == "processed"
        finally:
            engine.dispose()
