# Decision R64 — Validation numérique de la réconciliation financière

## Constat
La comparaison du grand livre avec le compte broker utilisait `Decimal`, mais
ne rejetait pas explicitement toutes les valeurs non finies (`NaN`, `Infinity`).
Avec ces valeurs, certaines comparaisons peuvent ne pas déclencher de différence
et risquer de produire un résultat financier trompeur.

## Modification
La réconciliation financière classe désormais comme `inconclusive` :
- un capital initial, une tolérance, un cash ou une equity non finis ;
- un fill local avec quantité, prix ou frais non finis ;
- une position broker avec quantité ou valeur de marché non finie.

Les valeurs négatives non autorisées pour le capital, les tolérances, le cash et
l'equity sont également refusées. Aucune donnée n'est corrigée automatiquement.

## Validation ciblée
- `tests/test_reconciliation.py`
- `tests/test_order_repository.py`
- `tests/test_order_lifecycle.py`
- Résultat : 91 passed, 13 subtests passed.
- Compilation Python : à vérifier lors de la constitution de l'archive.

## Limites
Candidat local uniquement. Pas de validation réelle Neon/PostgreSQL ni Alpaca
Paper dans ce jalon. Aucun ordre réel n'a été envoyé ; Live reste verrouillé.
