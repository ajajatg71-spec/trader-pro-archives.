# Trader Pro — Phase 10 frontend

React + TypeScript + Vite responsive web/mobile PWA shell. The first increment is deliberately read-only: account state, positions, risk snapshot, open orders and recent activity. No approval, rejection, cancellation, pause, plan or strategy-write controls are exposed here.

## Build

```bash
cd frontend
npm install
npm run typecheck
npm run build
```

The build writes `frontend/dist`. FastAPI serves that build at `/` automatically when `dist/index.html` exists; otherwise it keeps serving the existing `page.html` dashboard. `/assets`, `/manifest.webmanifest` and `/sw.js` are served only when the compiled frontend is present.

## Security boundaries

- Uses the existing HttpOnly `sess` cookie and sends `X-Trader: 1` on requests.
- API calls use `cache: no-store`; service worker deliberately excludes `/api/*` from caching.
- No secrets or broker credentials are placed in frontend code.
- All order-related content is read-only in this increment.
- Production use still requires HTTPS, a successful frontend build, and real-browser integration tests against the secured FastAPI app.

## PWA hardening increment (R26)

- The service worker uses a versioned static-asset cache and only stores same-origin GET assets under `/assets/` plus the explicit public shell files.
- API responses, authenticated navigation documents, login pages, mutations and cross-origin responses are never cached.
- Offline navigation falls back to a neutral offline page; the React client clears financial state when the browser reports loss of connectivity.
- The UI exposes accessible in-page navigation, a skip link, online/offline status, and the browser install prompt when supported.
- Background refresh pauses while the document is hidden or the browser is offline.
- These changes do not add trading, order, portfolio, or strategy mutation controls.
