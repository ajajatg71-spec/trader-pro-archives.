import React, { useCallback, useEffect, useState } from 'react';
import { api } from './api';
import { ClipboardList, RefreshCw, ShieldCheck } from 'lucide-react';

type Family = {
  family_id: string; study: string; protocol_version: string;
  manifest: { universe?: string[]; hypotheses?: string[] };
  expected_ids: string[]; status: string;
  adjusted_results?: { adjusted_p_values?: Record<string, number>; family_size?: number } | null;
  created_at?: string | null; selection_authorized: false;
};

export function ResearchRegistry() {
  const [items, setItems] = useState<Family[]>([]);
  const [study, setStudy] = useState('candle-confluence');
  const [version, setVersion] = useState('v1');
  const [universe, setUniverse] = useState('AAPL, MSFT, SPY');
  const [hypotheses, setHypotheses] = useState('candle_only, candle_rsi, candle_macd');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [online, setOnline] = useState(navigator.onLine);
  useEffect(() => { const onOnline=()=>setOnline(true); const onOffline=()=>setOnline(false); window.addEventListener('online',onOnline); window.addEventListener('offline',onOffline); return ()=>{window.removeEventListener('online',onOnline);window.removeEventListener('offline',onOffline)}; }, []);

  const refresh = useCallback(async () => {
    if (!navigator.onLine) { setError('Registre indisponible hors connexion.'); return; }
    setError('');
    try {
      const result = await api<{items: Family[]}>('/api/research/registry/families?limit=100');
      setItems(result.items || []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Registre indisponible');
    }
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);

  const preregister = async (event: React.FormEvent) => {
    event.preventDefault(); if (!navigator.onLine) { setError('Connexion requise pour pré-enregistrer une étude.'); return; } setBusy(true); setError(''); setMessage('');
    try {
      const result = await api<Family>('/api/research/registry/families', {
        method: 'POST',
        body: JSON.stringify({
          study, protocol_version: version,
          universe: universe.split(',').map(x => x.trim().toUpperCase()).filter(Boolean),
          hypotheses: hypotheses.split(',').map(x => x.trim()).filter(Boolean),
          metadata: { source: 'trader-pro-web', preregistration: true }
        })
      });
      setMessage(`Famille ${result.family_id.slice(0, 12)}… pré-enregistrée.`);
      await refresh();
    } catch (e) { setError(e instanceof Error ? e.message : 'Pré-enregistrement impossible'); }
    finally { setBusy(false); }
  };

  return <section className="panel research-panel">
    <div className="panel-head">
      <div><h2><ClipboardList size={17}/> Registre de recherche quantitative</h2>
      <p className="muted">Déclaration préalable des études et de leurs hypothèses.</p></div>
      <button className="icon-btn" onClick={() => void refresh()} aria-label="Actualiser le registre"><RefreshCw size={16}/></button>
    </div>
    <div className="registry-notice"><ShieldCheck size={16}/> {online?'Lecture et pré-enregistrement uniquement.':'Hors ligne : registre en lecture indisponible, aucun envoi ne sera tenté.'} Les résultats seront enregistrés par le moteur de recherche, jamais saisis manuellement ici.</div>
    {error && <div className="error">{error}</div>}
    {message && <div className="registry-success">{message}</div>}
    <form className="registry-form" onSubmit={preregister}>
      <label>Étude<input value={study} onChange={e=>setStudy(e.target.value)} required maxLength={120}/></label>
      <label>Version du protocole<input value={version} onChange={e=>setVersion(e.target.value)} required maxLength={64}/></label>
      <label>Univers d’actifs<input value={universe} onChange={e=>setUniverse(e.target.value)} required/></label>
      <label>Hypothèses (identifiants séparés par des virgules)<input value={hypotheses} onChange={e=>setHypotheses(e.target.value)} required/></label>
      <button className="primary-btn" disabled={busy||!online} type="submit">{busy ? 'Traitement…' : 'Pré-enregistrer la famille'}</button>
    </form>
    <div className="registry-list">
      <div className="registry-subhead"><b>Familles enregistrées</b><span className="count">{items.length}</span></div>
      {items.length ? items.map(item => <article className="family-row" key={item.family_id}>
        <span><b>{item.study}</b><small>{(item.manifest?.universe||[]).join(', ')} · {item.protocol_version}</small>
        <small>{(item.manifest?.hypotheses||[]).join(' · ')}</small><small className="family-id">{item.family_id.slice(0,20)}…</small></span>
        <span className={`family-status ${item.status==='RESULTS_LOCKED'?'locked':''}`}>{item.status}</span>
      </article>) : <p className="empty block">Aucune famille persistée. Vérifier la disponibilité de PostgreSQL.</p>}
    </div>
    <p className="muted registry-footnote">Le verrouillage statistique sera déclenché exclusivement par un résultat de recherche traçable. Une famille pré-enregistrée ne constitue pas une validation ni une autorisation de stratégie.</p>
  </section>;
}
