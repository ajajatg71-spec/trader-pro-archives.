export type ApiError = { detail?: string };
export async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers); headers.set('X-Trader', '1');
  if (init.body && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  const response = await fetch(path, { ...init, headers, credentials: 'same-origin', cache: 'no-store' });
  if (response.status === 401) { window.location.assign('/login'); throw new Error('Session expirée'); }
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error((body as ApiError).detail || `Erreur HTTP ${response.status}`);
  return body as T;
}
export type AccountState = {mode?:string;clock?:boolean;acct?:{equity?:string|number;cash?:string|number};daily?:number;pos?:Array<{symbol:string;value:string|number;pl:string|number}>;log?:string[];paused?:boolean;targets?:Array<[string,number]>;blocked?:string[]};
export type RiskSnapshot = {alerts?:string[];daily?:number;drawdown?:number;cash_pct?:number;paused?:boolean;limits?:Record<string,number>;positions?:Array<{symbol:string;pct:number}>;institutional?:{status?:string;breaches?:string[];metrics?:Record<string,number>};adv?:{var95_pct?:number;var95_usd?:number;cvar95_pct?:number;vol_ann_pct?:number;avg_corr?:number;eff_n?:number;beta?:number;regime?:string;error?:string}};
