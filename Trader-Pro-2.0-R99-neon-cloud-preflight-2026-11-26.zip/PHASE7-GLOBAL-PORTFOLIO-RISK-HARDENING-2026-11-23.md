# Phase 7 — durcissement du risque global de portefeuille

Date : 23 novembre 2026

## Objectif

Renforcer le contrôle global du portefeuille avant toute décision d'approbation, sans modifier les limites des comptes existants ni activer de stratégie.

## Changements

- Le snapshot global contrôle la réserve minimale de liquidités (`min_cash`) exprimée en pourcentage de l'equity.
- Les expositions sectorielles et par émetteur sont résumées par HHI.
- Le taux de couverture des classifications est exposé pour éviter de confondre absence de données et diversification.
- Les limites facultatives `max_sector_hhi` et `max_issuer_hhi` sont validées dans l'intervalle [0, 1].
- En présence d'une limite HHI, les classifications manquantes entraînent un blocage fail-closed.
- Le contrôle pré-transaction calcule le HHI projeté après l'achat envisagé.
- Les violations VaR/CVaR/stress ne sont plus dupliquées dans le résultat du snapshot.

## Validation sur R3 exact

- Base R3 avant modification : 709 passed, 11 skipped, 202 subtests passed.
- Tests ciblés : 87 passed.
- Suite complète après modification : 715 passed, 11 skipped, 202 subtests passed.
- `python -m compileall -q .` : passed.
- `node --check frontend/public/sw.js` : passed.
- Deux avertissements FastAPI relatifs aux gestionnaires `on_event` historiques.

## Limites

Les classifications doivent être fournies par une source de référence fiable ; leur exactitude externe n'est pas certifiée. Les limites HHI sont optionnelles et ne sont pas activées par défaut. Les mesures VaR/CVaR, corrélation et liquidité dépendent de données fraîches et de bonne provenance. Les tests PostgreSQL intégrés restent ignorés faute de base jetable configurée ; Alpaca Paper authentifié n'a pas été testé. Aucun ordre n'a été soumis et Live reste verrouillé.
