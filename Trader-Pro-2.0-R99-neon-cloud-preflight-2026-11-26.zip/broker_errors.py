"""Shared broker exception type, independent of provider implementations."""

class BrokerError(Exception):
    def __init__(self, msg, status=0):
        super().__init__(msg)
        self.status = status
