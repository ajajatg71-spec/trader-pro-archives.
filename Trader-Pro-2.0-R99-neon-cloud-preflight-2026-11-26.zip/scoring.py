"""Notation des actions et moteur de décision explicable. Une donnée absente ne fausse pas le score."""
from indicators import rsi, macd, sma
W = {"tech": .35, "news": .20, "inst": .30, "congress": .05, "fund": .10}

def tech_signal(c):
    """-1..+1 : MACD (±.4), RSI extrême (±.3), prix vs moyenne mobile (±.3)."""
    if len(c) < 35: return None
    r, h = rsi(c), macd(c)[2]
    sc = (.4 if h > 0 else -.4) + (.3 if r < 30 else -.3 if r > 70 else 0) + (.3 if c[-1] > sma(c, min(50, len(c))) else -.3)
    return max(-1.0, min(1.0, sc))

def inst_signal(tk, counts):
    c = counts.get(tk)
    if not c: return None
    n = sum(c.values())
    return (c.get("new", 0) + .5 * c.get("up", 0) - .5 * c.get("down", 0) - c.get("sold", 0)) / n

def fund_signal(growth, margin, min_g=10, min_m=10):
    if growth is None or margin is None: return None
    return {2: 1.0, 1: 0.0, 0: -1.0}[(growth >= min_g) + (margin >= min_m)]

def valuation(pe, pe_ref):
    if not pe or not pe_ref: return None
    return "sous-évalué" if pe < .8 * pe_ref else "surévalué" if pe > 1.25 * pe_ref else "correct"

def combine(sig, w=W):
    """(score 0-100, couverture 0-1). None si aucune donnée."""
    use = {k: v for k, v in sig.items() if v is not None and k in w}
    if not use: return None
    tw = sum(w[k] for k in use)
    return round(50 + 50 * sum(w[k] * v for k, v in use.items()) / tw, 1), tw / sum(w.values())

def decide(score, rsi_val, held, coverage, buy=65, sell=35, min_cov=.5):
    """(action, raisons). Jamais d'achat sans données suffisantes ni si le titre est suracheté."""
    why = [f"score {score}/100", f"données disponibles {coverage:.0%}"]
    if coverage < min_cov: return "garder", why + ["données insuffisantes"]
    if score >= buy:
        if rsi_val and rsi_val > 70: return "garder", why + ["signal fort mais RSI > 70 (suracheté)"]
        return ("garder", why + ["déjà en portefeuille"]) if held else ("acheter", why + ["score au-dessus du seuil d’achat"])
    if score <= sell and held: return "vendre", why + ["score sous le seuil de vente"]
    return "garder", why + ["score neutre"]
