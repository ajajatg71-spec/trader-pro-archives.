# Trader Pro 2.0 — R24 : durcissement de l'intégrité des preuves de recherche

Date : 23 novembre 2026  
Base : R23 (`Trader-Pro-2.0-consolide-candidat-2026-11-23-r23.zip`)

## Objectif

Renforcer le verrouillage des résultats de recherche afin que le registre ne se contente pas de recevoir des empreintes : il recalcule celles qu'il peut vérifier et refuse les preuves mal formées.

## Changements

- Le registre recalcule l'empreinte SHA-256 du manifeste pré-enregistré et la compare à `protocol_hash`.
- Le registre recalcule l'empreinte SHA-256 des résultats normalisés et la compare à `results_hash`.
- Le registre vérifie que `code_hash` correspond exactement à `code_version`.
- Le registre contrôle le format des identifiants d'exécution, des empreintes hexadécimales et des horodatages avec fuseau, ainsi que leur ordre chronologique.
- Le calcul des empreintes refuse désormais les objets non JSON canoniques au lieu de les convertir implicitement en texte.
- L'exécuteur refuse les tables vides, les valeurs non numériques et les p-values non finies ou hors de [0,1].
- Ajout de tests de falsification d'empreinte, de p-values invalides et de snapshots non canoniques.
- Aucun endpoint public, accès broker, ordre, activation de stratégie ou autorisation d'allocation ajouté.

## Validation locale

- Suite complète avec `BROKER=sim` : **750 passed, 11 skipped, 202 subtests passed**.
- Tests ciblés provenance/registre/adaptateur : **14 passed**.
- `python -m compileall -q .` : réussi.
- Alembic : une seule tête, `ea21c7b4d903`.
- 11 tests ignorés : intégrations PostgreSQL externe non disponibles dans cet environnement.
- 2 avertissements de dépréciation FastAPI (`on_event`).

## Limites non certifiées

- Le hash de snapshot atteste l'identité des données sérialisées reçues par le service ; il ne prouve pas la qualité, la licence, l'origine fournisseur ou l'exactitude économique des données.
- Le service de recherche est backend-only ; aucune interface de lancement utilisateur n'est livrée dans cette version.
- Pas de validation sur Neon/PostgreSQL réel, pas de build React certifié, pas de test authentifié Alpaca Paper ni de soumission d'ordre.
- Les résultats demeurent descriptifs/recherche uniquement. Aucune sélection automatique, allocation de capital ou exécution Live n'est autorisée.

## Décision

R24 améliore l'intégrité locale des preuves avant verrouillage. Prochaine priorité : construire un chargeur OHLCV documenté avec contrôle de qualité et d'origine, puis une commande de recherche contrôlée et enfin valider les transactions et migrations sur PostgreSQL dédié.
