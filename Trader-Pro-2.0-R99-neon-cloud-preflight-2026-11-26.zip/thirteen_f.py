"""Portefeuilles institutionnels 13F : lecture, comparaison, récupération sur la SEC (EDGAR)."""
import json, os, re
import xml.etree.ElementTree as ET

def _t(e): return e.tag.split("}")[-1]

def parse_infotable(xml):
    """XML d'un tableau d'information 13F -> {cusip: {name, shares, value}} (doublons additionnés)."""
    out = {}
    for row in ET.fromstring(xml.encode() if isinstance(xml, str) else xml).iter():
        if _t(row) != "infoTable": continue
        d = {_t(c): c for c in row.iter()}
        key = (d["cusip"].text or "").strip()
        o = out.setdefault(key, {"name": d["nameOfIssuer"].text.strip(), "shares": 0.0, "value": 0.0})
        o["shares"] += float(d["sshPrnamt"].text); o["value"] += float(d["value"].text)
    return out

def diff(prev, cur):
    """Achats, ventes, renforcements et allègements entre deux trimestres (seuil 1 %)."""
    r = {"new": [], "sold": [], "increased": [], "decreased": []}
    for k, c in cur.items():
        p = prev.get(k)
        if not p: r["new"].append((k, c["name"])); continue
        ch = (c["shares"] - p["shares"]) / p["shares"] * 100 if p["shares"] else 0
        if ch >= 1: r["increased"].append((k, c["name"], round(ch, 1)))
        elif ch <= -1: r["decreased"].append((k, c["name"], round(ch, 1)))
    r["sold"] = [(k, p["name"]) for k, p in prev.items() if k not in cur]
    return r

def weights(h, top=10):
    tot = sum(x["value"] for x in h.values()) or 1.0
    return sorted(((x["name"], x["value"] / tot * 100) for x in h.values()), key=lambda a: -a[1])[:top]

NAMES = {"APPLE INC": "AAPL", "AMERICAN EXPRESS": "AXP", "ALPHABET INC": "GOOGL", "COCA COLA": "KO",
         "BANK AMERICA": "BAC", "CHEVRON": "CVX", "OCCIDENTAL PETE": "OXY", "KRAFT HEINZ": "KHC", "MOODYS": "MCO"}
try: NAMES.update(json.load(open("tickers.json")))  # ajoute tes propres correspondances nom -> ticker
except Exception: pass

def to_ticker(name):
    n = re.sub(r"[^A-Z0-9 ]", "", name.upper().replace(".", "")).strip()
    return next((t for k, t in NAMES.items() if n.startswith(k)), None)

# --- Récupération EDGAR (non testée hors ligne : lance-la une fois sur ton serveur) ---
def _get(url):
    import requests
    ua = os.getenv("SEC_USER_AGENT", "")
    if not ua: raise RuntimeError("Définis SEC_USER_AGENT (ex. « Prénom Nom email@exemple.com »), exigé par la SEC")
    r = requests.get(url, headers={"User-Agent": ua}, timeout=20); r.raise_for_status(); return r

def latest_two(cik):
    """[dernier, précédent] dépôts 13F-HR d'un gestionnaire (CIK numérique)."""
    c10, c = str(int(cik)).zfill(10), str(int(cik))
    s = _get(f"https://data.sec.gov/submissions/CIK{c10}.json").json()["filings"]["recent"]
    accs = [a for a, f in zip(s["accessionNumber"], s["form"]) if f == "13F-HR"][:2]
    out = []
    for a in accs:
        base = f"https://www.sec.gov/Archives/edgar/data/{c}/{a.replace('-', '')}"
        items = _get(base + "/index.json").json()["directory"]["item"]
        name = next(i["name"] for i in items if i["name"].lower().endswith(".xml") and "primary_doc" not in i["name"].lower())
        out.append(parse_infotable(_get(f"{base}/{name}").content))
    if len(out) < 2: raise RuntimeError("Moins de deux dépôts 13F trouvés")
    return out

def compare(inst):
    """Titres détenus par plusieurs investisseurs suivis : [(ticker, nb investisseurs, poids moyen %)]."""
    agg = {}
    for v in inst.values():
        for t, w in v["weights"]: agg.setdefault(t, []).append(w)
    return sorted(((t, len(ws), round(sum(ws) / len(ws), 2)) for t, ws in agg.items()), key=lambda x: (-x[1], -x[2]))
