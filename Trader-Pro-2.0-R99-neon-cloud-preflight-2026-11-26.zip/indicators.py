"""Indicateurs techniques (fonctions pures, listes de clôtures du plus ancien au plus récent)."""

def sma(v, n):
    return sum(v[-n:]) / n if len(v) >= n else None

def ema_series(v, n):
    k, e, out = 2 / (n + 1), None, []
    for x in v:
        e = x if e is None else x * k + e * (1 - k)
        out.append(e)
    return out

def rsi(v, n=14):
    """RSI de Wilder. None si pas assez de données."""
    if len(v) <= n: return None
    g = l = 0.0
    for i in range(1, n + 1):
        d = v[i] - v[i - 1]; g += max(d, 0); l += max(-d, 0)
    g, l = g / n, l / n
    for i in range(n + 1, len(v)):
        d = v[i] - v[i - 1]
        g, l = (g * (n - 1) + max(d, 0)) / n, (l * (n - 1) + max(-d, 0)) / n
    if g == 0 and l == 0: return 50.0
    return 100.0 if l == 0 else 100 - 100 / (1 + g / l)

def macd(v, fast=12, slow=26, sig=9):
    """(macd, signal, histogramme) au dernier point, ou None."""
    if len(v) < slow + sig: return None
    m = [a - b for a, b in zip(ema_series(v, fast), ema_series(v, slow))]
    s = ema_series(m, sig)
    return m[-1], s[-1], m[-1] - s[-1]
