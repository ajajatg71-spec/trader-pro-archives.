# Trader Pro 2.0 — R80 : benchmark total return du scoreboard multi-stratégies

Base : R79.

## Modifications
- Ajout optionnel d'un benchmark de marché total return au scoreboard portefeuille.
- Les événements doivent être validés, correspondre au benchmark et être exprimés dans la devise déclarée.
- Le benchmark reprend le même instant d'entrée et les mêmes frais/glissements que le buy-and-hold prix existant ; après l'entrée, il incorpore les splits et dividendes via l'indice événementiel.
- Les métriques de rendement total et d'excès sont exposées séparément.
- Le benchmark total return n'influence pas le verdict, le classement, les paramètres ou les ordres des stratégies.
- Sans événements/devise fournis, le comportement précédent est conservé.

## Tests
5 tests ciblés ajoutés. Suite ciblée : 5 passed. Compilation Python (`compileall`) réussie. Suite complète : 934 passed, 11 skipped, 205 subtests passed in 24.28s.

## Limites
- Le fournisseur d'événements n'est pas connecté ; les données restent injectées par l'appelant.
- L'exhaustivité des actions, la devise, le calendrier et la base de prix bruts doivent être validés à la source.
- Pas de validation Neon/PostgreSQL ou Alpaca Paper réelle.
