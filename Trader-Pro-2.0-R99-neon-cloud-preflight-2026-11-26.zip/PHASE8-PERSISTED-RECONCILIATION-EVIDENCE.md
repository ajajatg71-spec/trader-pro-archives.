# Phase 8 — Persisted reconciliation evidence

## Delivered in this revision

- Added `reconciliation_runs` with a unique run ID, Paper source, result status, snapshot-completeness flag, unresolved count, observed order/fill/position counts, SHA-256 evidence hash, details, and timestamps.
- Each successful reconciliation execution now stores a durable evidence record. Truncated snapshots, unmatched orders/fills, invalid fills, quantity mismatches, or warnings result in an `inconclusive` record rather than a success proof.
- The reconciliation report returns the persisted evidence reference and hash.
- `system_safety_state.last_reconciliation_run_id` links the last accepted proof.
- A proof is consumed exactly once in the same locked transaction that authorizes `READY`; its `consumed_at` timestamp prevents replay after later safety-state cycles.
- Removed the boolean `reconciliation_passed` authorization. Transition to `READY` now requires an existing Paper reconciliation run with `succeeded` status, complete snapshots, zero unresolved items, a 64-character evidence hash, and age no greater than five minutes. The actor must be `operator`.
- The evidence reference and hash are included in the safety-transition audit event.

## Local verification

- `python -m pytest -q`: 509 passed, 7 skipped, 92 subtests passed before the single-use hardening; latest results are recorded in the delivery report.
- `python -m unittest discover -q`: 499 tests OK.
- `python -m compileall -q .`: passed.
- `alembic heads`: one head, `8d4f2a6c1e90`.
- A fresh SQLite database successfully migrated from base through head `8d4f2a6c1e90`; this does not establish PostgreSQL lock/concurrency behavior.

## Remaining gates

- The local runtime has no Docker, PostgreSQL server/client, or Alpaca credentials. No PostgreSQL concurrency test or authenticated Alpaca Paper request has been executed here.
- Operator API is present in `routers/operator.py`; it uses a separate operator password and TOTP. Fine-grained multi-role authorization is not implemented.
- Local tests now reject expired proofs and replayed proofs. A dedicated PostgreSQL concurrency test has been added but remains opt-in and unexecuted until a dedicated PostgreSQL test URL is configured.
- A Paper run with a known verified opening-cash baseline is still required before claiming full cash/position accounting reconciliation.
- Live remains disabled.
