# Phase 6 — Strategy Engine (socle fonctionnel livré, intégration système à valider)

## Livré
- Contrat abstrait `BaseStrategy` : validation de configuration, génération de signaux, métadonnées, initialisation et contrôle de santé.
- Modèles immuables de signal et configuration : direction BUY/SELL/NEUTRAL, force/confiance bornées, symbole contrôlé, timestamp timezone-aware, version et explication obligatoires.
- `StrategyRegistry` thread-safe : enregistrement unique, activation conditionnée au health check, désactivation et inventaire.
- Quatre stratégies déterministes : Momentum, Trend Following, Mean Reversion et Breakout. Les calculs quantitatifs V1 sont réutilisés sans modification.
- `StrategyManager` : cycle STOPPED / INITIALIZING / ACTIVE / ERROR, activation/désactivation, sélection des stratégies actives et isolation des erreurs d'une stratégie.
- `MarketRegimeDetector` : adaptateur de la règle V1 `risklib.regime`. Il retourne UNKNOWN si l'historique est insuffisant ; la règle V1 distingue seulement haussier/baissier et ne prétend pas détecter les marchés latéraux ou volatils.
- `StrategySelector` : allow-list explicite par régime, fermeture par défaut pour les régimes inconnus.
- `SignalAggregator` : agrégation par familles de preuve ; Momentum et Trend Following ne sont pas comptés comme deux confirmations indépendantes. Les groupes sont des garde-fous heuristiques, pas une estimation statistique de corrélation.
- `StrategyAllocator` : génération de propositions indicatives plafonnées, jamais d'ordres.
- `risk_gate` : approbation explicite obligatoire par un contrôle de risque externe ; échec ou exception = rejet. Une approbation ne soumet aucun ordre et n'autorise qu'une revue par le futur moteur Paper.
- `StrategyEvaluator` : délégation des métriques et comparaisons au moteur quantitatif de phase 5.
- `SignalLogger` : journal d'audit en mémoire borné et thread-safe ; persistance PostgreSQL non encore branchée.

## Tests et validation locale
- Tests dédiés Strategy Engine : 20 tests, plus 7 sous-cas.
- Suite globale, compilation, import FastAPI et nombre de routes consignés dans le rapport de livraison.

## Limites / hors périmètre
- L'intégration end-to-end entre `StrategyManager`, le service Risk Management réel et Paper Execution n'est pas encore activée : le `risk_gate` est un point d'injection strict, sans dépendance broker.
- Journal d'audit non persistant ; la persistance dépend de la clôture de la phase 3.
- Les régimes RANGING et VOLATILE nécessitent un détecteur validé dédié avant activation ; aucun régime n'est inventé à partir des données V1 actuelles.
- Pas de trading Live ; aucune stratégie ne peut envoyer directement un ordre.

## 2026-11-11 — raccordement sécurisé Risk -> Paper
- Ajout de `services/strategy_engine/pipeline.py` : Market Data validée, stratégies actives, sélection de régime, agrégation et allocation prudente.
- Les propositions BUY passent un premier contrôle de risque (`core.check`) et sont uniquement placées en attente avec `risk_status=PRECHECK_PASSED_RECHECK_REQUIRED`.
- Aucun accès au courtier depuis le pipeline. L'approbation manuelle passe par `OrderService.approve`, qui refait les contrôles avant soumission Paper.
- Ajout de `POST /api/strategy/run?symbols=AAPL,MSFT` derrière la même authentification/anti-CSRF que les autres routes.
- Ajout de contrôles d'arrêt partagés : compte bloqué, perte journalière, drawdown et perte hebdomadaire. Un dépassement active la pause.
- En SIM, l'absence d'horodatages est explicitement acceptée uniquement pour les données synthétiques simulées. En Paper Alpaca, les horodatages réels et la fraîcheur XNYS restent obligatoires.
- Les ventes/shorts ne sont pas générés par ce pipeline : les signaux SELL sont informatifs; seules les propositions BUY long-only peuvent être staged.
- Les propositions restent dans le stockage JSON historique; la persistance PostgreSQL reste à raccorder et à valider séparément.

## 2026-11-11 — fiabilité des configurations et des lots multi-symboles
- `StrategyConfig` refuse désormais les valeurs booléennes, non numériques, NaN et infinies, y compris dans les paramètres non consommés par une stratégie donnée.
- `SignalAggregator` refuse explicitement les signaux d'un autre symbole au lieu de les ignorer silencieusement.
- `SignalAggregator` et `StrategyAllocator` refusent les booléens utilisés comme seuils/allocation.
- Le pipeline renvoie désormais un résultat explicite `SYMBOL_REJECTED` ou `SYMBOL_ERROR` pour une erreur propre à un symbole. Une erreur de données sur un titre ne masque plus les résultats des titres précédents déjà traités dans le lot.
- Ajout de tests couvrant ces cas et le scénario AAPL accepté / MSFT rejeté pour historique insuffisant.
