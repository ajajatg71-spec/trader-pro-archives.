# Trader Pro 2.0 — R44 : métriques de risque par fenêtre walk-forward

Date : 23 novembre 2026  
Base : candidat R43 (archive source vérifiée avant modification).

## Changement

Les lignes de chaque fenêtre OOS du scoreboard multi-actifs exposent désormais aussi le Sortino, le Calmar et la durée maximale du drawdown. Ces métriques étaient déjà calculées pour la période OOS agrégée ; elles sont maintenant visibles au niveau de chaque fenêtre, ce qui permet d'identifier les stratégies dont le risque se dégrade selon les périodes.

Aucune règle, aucun paramètre de stratégie, aucune allocation et aucune exécution broker n'ont été modifiés. Il s'agit d'une amélioration de diagnostic, pas d'une preuve de rentabilité.

## Validation exécutée

- `BROKER=sim pytest -q` : **792 passed, 11 skipped, 202 subtests passed**.
- `python -m unittest discover -q` : **711 tests OK**.
- `python -m compileall -q .` : OK.
- `node --check frontend/public/sw.js` : OK.
- JSON `frontend/public/manifest.webmanifest` : OK.
- Les 11 tests ignorés nécessitent un PostgreSQL externe configuré ; aucun PostgreSQL/Neon réel n'a été testé.
- Le build Vite/Docker et les workflows GitHub Actions n'ont pas été exécutés dans cet environnement.
- Aucun ordre Alpaca Paper ou Live envoyé ; mode Live verrouillé.

## Portée

Cette modification rend le diagnostic OOS par fenêtre plus complet. Elle ne change pas le processus de sélection/optimisation des paramètres et ne constitue pas une preuve de rentabilité future.
