# Trader Pro 2.0 — R69 : validation chronologique des figures

Date : 26 novembre 2026  
Base : archive candidate R68 (`Trader-Pro-2.0-R68-alignement-benchmark-2026-11-26.zip`).

## Constat

L'audit des chemins de données de recherche a identifié une lacune dans `research_v1/validation/candle_evaluator.py` : le contrat indiquait que les barres devaient être ordonnées de l'ancien vers le récent, mais le validateur ne contrôlait pas cet ordre. Si des timestamps étaient présents, des barres désordonnées ou dupliquées pouvaient modifier artificiellement les indices d'entrée/sortie et les horizons évalués.

## Correction R69

- Si les timestamps sont absents de toutes les barres, le comportement historique reste compatible.
- Si des timestamps sont fournis, ils doivent être présents sur toutes les barres.
- Les timestamps doivent être ISO/datetime valides et inclure un fuseau horaire.
- Ils sont normalisés en UTC pour vérifier un ordre strictement croissant.
- Les timestamps dupliqués ou non chronologiques sont rejetés.
- Aucun tri automatique, remplissage ou réordonnancement silencieux n'est effectué.

## Fichiers

Modifiés uniquement :
- `research_v1/validation/candle_evaluator.py`
- `tests/test_candle_evaluator.py`

Aucun fichier supprimé. L'archive R68 source est conservée séparément.

## Vérifications

- Tests ciblés `tests/test_candle_evaluator.py` : 7 passed.
- Suite complète : **890 passed, 11 skipped, 202 subtests passed**.
- `python -m compileall -q research_v1` : succès.
- Les effets secondaires de tests sur `history.jsonl` ont été restaurés à l'état exact de R68.

## Portée et limites

R69 est une archive candidate locale de recherche. Cette modification vérifie la chronologie lorsque les timestamps sont fournis ; elle ne valide pas la qualité économique des données, les ajustements de corporate actions, les calendriers de marché ni la rentabilité des figures. Aucun déploiement Replit, test réel Neon PostgreSQL, connexion Alpaca Paper ou ordre broker n'a été effectué dans cette étape. Le mode Live reste non autorisé.
