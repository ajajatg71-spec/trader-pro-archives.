# Phase 3 — Order, Fill & Risk Persistence

Date : 11 novembre 2026

## Implémenté
- Dépôt SQL transactionnel pour les intentions d’ordre, statuts, identifiants client/courtier et quantité.
- Identifiant client unique et réutilisation idempotente uniquement si les paramètres correspondent.
- Persistance idempotente des exécutions (fills), liée à l’ordre parent, sans doublon de `broker_fill_id`.
- Snapshots de compte et événements de risque persistés et audités.
- `OrderService` écrit l’intention avant l’effet externe. Une panne de persistance empêche la soumission.
- Timeout ou erreur réseau pendant la soumission = `submission_unknown`, jamais interprété comme un échec certain. Réconciliation obligatoire avant retry.

## Vérifications
- `python -m compileall -q .` : réussi.
- `python -m pytest -q` : 311 réussis, 72 sous-tests réussis.
- `python -m unittest discover -q` : 307 réussis.
- Alembic SQLite : upgrade head, downgrade base, upgrade head : réussi.

## Limites explicites
- Aucun serveur PostgreSQL externe n'a été démarré dans cet environnement.
- Aucun courtier Paper externe n'a été interrogé ; les fills sont enregistrés par la méthode du dépôt mais leur ingestion automatique depuis le courtier reste à raccorder.
- La réconciliation périodique des ordres `submission_unknown`, ordres ouverts et fills avec le courtier reste une tâche à réaliser.
- Les snapshots sont disponibles mais leur collecte planifiée n'est pas encore activée.
- Live reste désactivé.

## Follow-up — broker reconciliation
See `PHASE3-BROKER-RECONCILIATION-REPORT.md`. The authenticated reconciliation endpoint, fill-ID normalization, position snapshots, duplicate-submission guard, and simulated-broker integration test have now been added. PostgreSQL 16 and external Alpaca Paper validation remain outstanding.
