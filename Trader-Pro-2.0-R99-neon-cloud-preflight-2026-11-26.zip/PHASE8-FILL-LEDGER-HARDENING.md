# Phase 8 — Fill Ledger hardening

## Changes

- Reconciliation now passes broker quantity, price and fee values into the repository as `Decimal` values instead of converting them through binary `float`.
- The repository validates finite, positive quantities/prices, non-negative fees, identifiers and symbols; it normalizes values once to the database's declared precision before both insert and idempotent replay comparison.
- Fill audit details are stored as decimal strings, avoiding float serialization drift.
- A broker fill without its execution timestamp is rejected from the immutable ledger rather than being assigned the local ingestion time. Naive timestamps, if supplied, are explicitly interpreted as UTC.
- Existing protections remain: unique broker fill IDs, immutable replay conflict detection, order/symbol linkage, partial-fill aggregation, quantity comparison with broker cumulative `filled_qty`, and no automatic retry.

## Verification

- `python -m pytest -q`: 502 passed, 7 skipped, 92 subtests passed.
- `python -m unittest discover -q`: 498 tests OK.
- `python -m compileall -q .`: passed.
- `alembic heads`: one head, `7c2d9e4a1b60`.

The test suite uses local SQLite/simulated broker fixtures. It does **not** certify PostgreSQL row-lock behavior or authenticated Alpaca Paper connectivity. Those remain mandatory external integration gates. Live trading remains disabled.
