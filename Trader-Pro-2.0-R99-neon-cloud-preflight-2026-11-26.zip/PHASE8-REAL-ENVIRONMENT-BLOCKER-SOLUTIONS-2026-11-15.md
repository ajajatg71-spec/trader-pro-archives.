# Phase 8 — Solutions d'environnement et de validation réelle (2026-11-15)

## Situation constatée dans l'environnement d'exécution actuel

- SQLAlchemy et Alembic sont importables.
- Le pilote `psycopg` n'est pas installé dans l'environnement courant, bien qu'il soit déclaré dans `requirements.txt`.
- Aucun `TRADER_PRO_TEST_DATABASE_URL`, `APCA_API_KEY_ID` ou `APCA_API_SECRET_KEY` n'est configuré.
- `docker`, `podman`, `psql` et `pg_dump` ne sont pas disponibles dans le PATH courant.
- En conséquence, aucune migration, intégration PostgreSQL réelle, sauvegarde/restauration réelle, ni requête authentifiée Alpaca Paper n'est certifiée par cette session.

## Chemin recommandé — Windows 10/11

1. Installer Docker Desktop et activer le moteur Linux/WSL2.
2. Dans le dossier du projet, créer `.env` avec un mot de passe PostgreSQL local robuste. Ne jamais committer `.env`.
3. Démarrer PostgreSQL 16 avec `docker compose up -d postgres` (le port est lié à `127.0.0.1` uniquement).
4. Installer les dépendances avec `powershell -ExecutionPolicy Bypass -File scripts/setup_venv.ps1`.
5. Installer les outils client PostgreSQL 16 (`psql`, `pg_dump`, `pg_restore`) et les rendre disponibles dans PATH.
6. Créer deux bases jetables distinctes suffixées `_test` et `_restore`, puis définir les deux URL SQLAlchemy `postgresql+psycopg://...` dans les variables d'environnement `TRADER_PRO_TEST_DATABASE_URL` et `TRADER_PRO_RESTORE_DATABASE_URL`.
7. Lancer `powershell -ExecutionPolicy Bypass -File scripts/verify_postgres.ps1`. Le script refuse une base source sans suffixe `_test`, une cible sans suffixe `_restore`, ou une cible de restauration non vide. Il applique les migrations, lance les tests d'intégration, effectue un dump et restaure dans la base distincte.

Le script Bash `scripts/verify_postgres.sh` reste disponible pour Linux/macOS/WSL. Ne jamais pointer ces variables vers une base de production ou contenant des données à conserver.

## Alpaca Paper — contrôle sans ordre

Une fois les identifiants Paper créés dans le tableau de bord Alpaca, définir localement `BROKER=alpaca`, `APCA_API_KEY_ID` et `APCA_API_SECRET_KEY`, puis exécuter `python scripts/verify_alpaca_paper_readonly.py`. Ce script est strictement en lecture seule : compte, positions, horloge et quelques barres SPY. Il doit afficher `ALPACA_PAPER_READ_ONLY_OK`.

Le script `scripts/verify_alpaca_paper_orders.py` est un test d'écriture distinct. Il peut créer puis annuler un ordre Paper d'une action et nécessite le marqueur explicite `TRADER_PRO_ENABLE_PAPER_ORDER_TEST=YES_I_CONFIRM_PAPER_ONLY`. Il n'a pas été lancé. Aucune autorisation de l'utilisateur pour créer un ordre n'est déduite de la demande de poursuivre le développement.

## Alternatives si Docker Desktop est impossible

- PostgreSQL 16 installé nativement sur Windows, avec les outils clients PostgreSQL 16.
- Une machine Linux/WSL2 avec PostgreSQL 16 local.
- Un PostgreSQL managé temporaire, uniquement avec deux bases jetables dédiées, TLS activé et secrets stockés hors du dépôt.

## Statut

Ces scripts réduisent la dépendance à l'environnement de cette session et fournissent un chemin opératoire Windows. Ils ne prouvent pas que les tests réels ont été exécutés. Phase 8 reste ouverte jusqu'à obtention des sorties de validation réelles; phase 9 reste partielle. Live demeure interdit.
