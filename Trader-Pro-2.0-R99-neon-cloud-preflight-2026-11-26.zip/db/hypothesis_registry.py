"""Durable, immutable pre-registration of research hypothesis families."""
from datetime import datetime, timezone
import hashlib
import json
import uuid
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from db.models import HypothesisFamilyRecord
from research_v1.validation.hypothesis_registry import canonical_family_id, adjust_complete_family

class HypothesisRegistryError(ValueError):
    pass


def _evidence_hash(value):
    """Hash JSON evidence deterministically; reject non-JSON and NaN values."""
    try:
        encoded = json.dumps(value, sort_keys=True, separators=(",", ":"),
                             ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise HypothesisRegistryError("Preuve non canonique") from exc
    return hashlib.sha256(encoded).hexdigest()

class HypothesisRegistry:
    def __init__(self, session_factory):
        self.session_factory = session_factory

    def preregister(self, *, study, universe, hypotheses, protocol_version, metadata=None):
        family_id = canonical_family_id(study=study, universe=universe, hypotheses=hypotheses, protocol_version=protocol_version)
        manifest = {"study": study.strip(), "universe": sorted({x.strip().upper() for x in universe}),
                    "hypotheses": sorted({x.strip() for x in hypotheses}),
                    "protocol_version": protocol_version.strip(), "metadata": metadata or {}}
        with self.session_factory() as session:
            existing = session.get(HypothesisFamilyRecord, family_id)
            if existing:
                if existing.manifest != manifest:
                    raise HypothesisRegistryError("Manifeste différent pour cet identifiant")
                return self._serialize(existing)
            record = HypothesisFamilyRecord(family_id=family_id, study=study.strip(), protocol_version=protocol_version.strip(),
                manifest=manifest, expected_ids=manifest["hypotheses"], status="PRE_REGISTERED", selection_authorized=False)
            session.add(record)
            try:
                session.commit()
            except IntegrityError:
                session.rollback()
                existing = session.get(HypothesisFamilyRecord, family_id)
                if not existing or existing.manifest != manifest:
                    raise HypothesisRegistryError("Conflit de pré-enregistrement")
                record = existing
            return self._serialize(record)

    def _record_execution_results(self, family_id, p_values, provenance):
        with self.session_factory() as session:
            record = session.get(HypothesisFamilyRecord, family_id)
            if record is None:
                raise HypothesisRegistryError("Famille inconnue")
            normalized = {str(k): float(v) for k, v in p_values.items()}
            if record.status == "RESULTS_LOCKED":
                if record.p_values != normalized:
                    raise HypothesisRegistryError("Résultats déjà verrouillés et immuables")
                return self._serialize(record)
            if not isinstance(provenance, dict) or provenance.get("execution_origin") != "BACKEND_RESEARCH_EXECUTOR":
                raise HypothesisRegistryError("Provenance d’exécution backend obligatoire")
            required = ("run_id", "protocol_hash", "market_data_snapshot_hash", "code_hash", "results_hash",
                        "code_version", "started_at", "completed_at")
            if any(not isinstance(provenance.get(key), str) or not provenance[key] for key in required):
                raise HypothesisRegistryError("Provenance incomplète")
            try:
                uuid.UUID(hex=provenance["run_id"])
                for key in ("protocol_hash", "market_data_snapshot_hash", "code_hash", "results_hash"):
                    value = provenance[key]
                    if len(value) != 64 or any(ch not in "0123456789abcdef" for ch in value):
                        raise ValueError(key)
                started = datetime.fromisoformat(provenance["started_at"])
                completed = datetime.fromisoformat(provenance["completed_at"])
                if started.tzinfo is None or completed.tzinfo is None or completed < started:
                    raise ValueError("timestamps")
            except (ValueError, TypeError, AttributeError) as exc:
                raise HypothesisRegistryError("Format de provenance invalide") from exc
            if provenance["protocol_hash"] != _evidence_hash(record.manifest):
                raise HypothesisRegistryError("Empreinte du protocole incohérente")
            if provenance["code_hash"] != hashlib.sha256(provenance["code_version"].encode("utf-8")).hexdigest():
                raise HypothesisRegistryError("Empreinte du code incohérente")
            if provenance["results_hash"] != _evidence_hash(normalized):
                raise HypothesisRegistryError("Empreinte des résultats incohérente")
            try:
                adjusted = adjust_complete_family(record.expected_ids, normalized)
            except ValueError as exc:
                raise HypothesisRegistryError(str(exc)) from exc
            record.p_values = normalized
            record.execution_provenance = dict(provenance)
            record.adjusted_results = adjusted
            record.status = "RESULTS_LOCKED"
            record.results_locked_at = datetime.now(timezone.utc)
            record.selection_authorized = False
            session.commit()
            return self._serialize(record)

    def list_families(self, limit=50):
        with self.session_factory() as session:
            records = session.scalars(select(HypothesisFamilyRecord).order_by(HypothesisFamilyRecord.created_at.desc()).limit(limit)).all()
            return [self._serialize(item) for item in records]

    @staticmethod
    def _serialize(record):
        return {"family_id": record.family_id, "study": record.study, "protocol_version": record.protocol_version,
            "manifest": record.manifest, "expected_ids": record.expected_ids, "status": record.status,
            "p_values": record.p_values, "adjusted_results": record.adjusted_results,
            "created_at": record.created_at.isoformat() if record.created_at else None,
            "results_locked_at": record.results_locked_at.isoformat() if record.results_locked_at else None,
            "execution_provenance": record.execution_provenance,
            "selection_authorized": False}
