"""Initial relational schema. Financial amounts use fixed precision Numeric columns."""
from datetime import datetime
from decimal import Decimal
from sqlalchemy import CheckConstraint, DateTime, ForeignKey, Index, Integer, Numeric, String, Text, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.types import JSON
from .base import Base


class StrategyConfigRecord(Base):
    __tablename__ = "strategy_configs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(80), nullable=False, unique=True)
    enabled: Mapped[bool] = mapped_column(nullable=False, default=False)
    auto_execute: Mapped[bool] = mapped_column(nullable=False, default=False)
    parameters: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class OrderRecord(Base):
    __tablename__ = "orders"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    client_order_id: Mapped[str] = mapped_column(String(128), nullable=False, unique=True)
    broker_order_id: Mapped[str | None] = mapped_column(String(128), unique=True)
    symbol: Mapped[str] = mapped_column(String(16), nullable=False, index=True)
    side: Mapped[str] = mapped_column(String(8), nullable=False)
    quantity: Mapped[Decimal | None] = mapped_column(Numeric(24, 10))
    notional: Mapped[Decimal | None] = mapped_column(Numeric(24, 8))
    status: Mapped[str] = mapped_column(String(24), nullable=False, index=True)
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    fills: Mapped[list["FillRecord"]] = relationship(back_populates="order")
    __table_args__ = (CheckConstraint("side IN ('buy','sell')", name="ck_orders_side"),)


class FillRecord(Base):
    __tablename__ = "fills"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    broker_fill_id: Mapped[str] = mapped_column(String(128), nullable=False, unique=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id", ondelete="RESTRICT"), nullable=False, index=True)
    symbol: Mapped[str] = mapped_column(String(16), nullable=False)
    quantity: Mapped[Decimal] = mapped_column(Numeric(24, 10), nullable=False)
    price: Mapped[Decimal] = mapped_column(Numeric(24, 8), nullable=False)
    fee: Mapped[Decimal] = mapped_column(Numeric(24, 8), nullable=False, default=0)
    executed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    order: Mapped[OrderRecord] = relationship(back_populates="fills")


class AccountSnapshotRecord(Base):
    __tablename__ = "account_snapshots"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    captured_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    equity: Mapped[Decimal] = mapped_column(Numeric(24, 8), nullable=False)
    cash: Mapped[Decimal] = mapped_column(Numeric(24, 8), nullable=False)
    buying_power: Mapped[Decimal | None] = mapped_column(Numeric(24, 8))
    source: Mapped[str] = mapped_column(String(24), nullable=False, default="paper")


class AuditEventRecord(Base):
    __tablename__ = "audit_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now(), index=True)
    event_type: Mapped[str] = mapped_column(String(48), nullable=False, index=True)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    correlation_id: Mapped[str | None] = mapped_column(String(128), index=True)
    details: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)


class RiskEventRecord(Base):
    __tablename__ = "risk_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now(), index=True)
    severity: Mapped[str] = mapped_column(String(16), nullable=False)
    rule: Mapped[str] = mapped_column(String(64), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    metrics: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)



Index("ix_orders_symbol_status", OrderRecord.symbol, OrderRecord.status)
Index("ix_fills_symbol_executed_at", FillRecord.symbol, FillRecord.executed_at)


class StrategyProposalRecord(Base):
    """Durable record of a strategy proposal and its risk/execution lifecycle."""
    __tablename__ = "strategy_proposals"
    proposal_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    symbol: Mapped[str] = mapped_column(String(16), nullable=False, index=True)
    side: Mapped[str] = mapped_column(String(8), nullable=False)
    notional: Mapped[Decimal] = mapped_column(Numeric(24, 8), nullable=False)
    allocation_pct: Mapped[Decimal] = mapped_column(Numeric(12, 8), nullable=False)
    confidence: Mapped[Decimal] = mapped_column(Numeric(8, 6), nullable=False)
    regime: Mapped[str] = mapped_column(String(24), nullable=False)
    source_strategies: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    signals: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    pending_payload: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    risk_reason: Mapped[str | None] = mapped_column(Text)
    broker_order_id: Mapped[str | None] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    __table_args__ = (
        CheckConstraint("side IN ('buy','sell')", name="ck_strategy_proposals_side"),
        CheckConstraint("notional > 0", name="ck_strategy_proposals_notional_positive"),
        CheckConstraint("allocation_pct >= 0 AND allocation_pct <= 100", name="ck_strategy_proposals_allocation_range"),
        CheckConstraint("confidence >= 0 AND confidence <= 1", name="ck_strategy_proposals_confidence_range"),
    )


class PositionSnapshotRecord(Base):
    """Point-in-time broker position snapshot used for post-restart reconciliation."""
    __tablename__ = "position_snapshots"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    captured_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    symbol: Mapped[str] = mapped_column(String(16), nullable=False, index=True)
    quantity: Mapped[Decimal] = mapped_column(Numeric(24, 10), nullable=False)
    market_value: Mapped[Decimal] = mapped_column(Numeric(24, 8), nullable=False)
    average_entry_price: Mapped[Decimal | None] = mapped_column(Numeric(24, 8))
    unrealized_pl: Mapped[Decimal | None] = mapped_column(Numeric(24, 8))
    source: Mapped[str] = mapped_column(String(24), nullable=False, default="paper")
    __table_args__ = (Index("ix_position_snapshots_time_symbol", "captured_at", "symbol"),)


class RiskControlStateRecord(Base):
    """Singleton operational pause state; survives process restarts."""
    __tablename__ = "risk_control_state"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    paused: Mapped[bool] = mapped_column(nullable=False, default=True)
    reason: Mapped[str | None] = mapped_column(Text)
    actor: Mapped[str] = mapped_column(String(64), nullable=False, default="system")
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)


class BrokerEventRecord(Base):
    """Durable inbox for broker notifications; notifications trigger reconciliation only."""
    __tablename__ = "broker_event_inbox"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    event_id: Mapped[str] = mapped_column(String(160), nullable=False, unique=True)
    event_type: Mapped[str] = mapped_column(String(48), nullable=False, index=True)
    broker_order_id: Mapped[str | None] = mapped_column(String(128), index=True)
    client_order_id: Mapped[str | None] = mapped_column(String(128), index=True)
    payload: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="pending", index=True)
    attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    processing_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    processing_token: Mapped[str | None] = mapped_column(String(36), index=True)
    processed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    next_attempt_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    last_error: Mapped[str | None] = mapped_column(Text)
    __table_args__ = (
        CheckConstraint("status IN ('pending','processing','processed','failed','dead_letter')", name="ck_broker_event_status"),
        CheckConstraint("attempts >= 0", name="ck_broker_event_attempts_nonnegative"),
    )


class ReconciliationRunRecord(Base):
    """Immutable evidence record for one broker reconciliation attempt."""
    __tablename__ = "reconciliation_runs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    run_id: Mapped[str] = mapped_column(String(64), nullable=False, unique=True, index=True)
    source: Mapped[str] = mapped_column(String(24), nullable=False, default="paper")
    status: Mapped[str] = mapped_column(String(16), nullable=False)
    snapshot_complete: Mapped[bool] = mapped_column(nullable=False, default=False)
    unresolved_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    orders_seen: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    fills_seen: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    positions_seen: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    evidence_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    details: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())
    completed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())
    consumed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (
        CheckConstraint("status IN ('succeeded','inconclusive','failed')", name="ck_reconciliation_run_status"),
        CheckConstraint("unresolved_count >= 0", name="ck_reconciliation_unresolved_nonnegative"),
        CheckConstraint("orders_seen >= 0 AND fills_seen >= 0 AND positions_seen >= 0", name="ck_reconciliation_counts_nonnegative"),
    )


class SystemSafetyStateRecord(Base):
    """Durable global trading safety state; missing or non-READY means no orders."""
    __tablename__ = "system_safety_state"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="RECONCILING")
    reason: Mapped[str | None] = mapped_column(Text)
    actor: Mapped[str] = mapped_column(String(64), nullable=False, default="system")
    generation: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    last_reconciliation_run_id: Mapped[str | None] = mapped_column(ForeignKey("reconciliation_runs.run_id", ondelete="RESTRICT"))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    __table_args__ = (
        CheckConstraint("status IN ('READY','DEGRADED','RECONCILING','HALTED')", name="ck_system_safety_status"),
        CheckConstraint("generation >= 1", name="ck_system_safety_generation"),
    )


class OperatorAuthAttemptRecord(Base):
    """Persistent per-client operator authentication throttle."""
    __tablename__ = "operator_auth_attempts"
    client_key: Mapped[str] = mapped_column(String(64), primary_key=True)
    window_started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    __table_args__ = (CheckConstraint("attempts >= 0", name="ck_operator_auth_attempts_nonnegative"),)


class OperatorTotpStateRecord(Base):
    """Singleton high-water mark preventing reuse of an accepted TOTP counter."""
    __tablename__ = "operator_totp_state"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    last_accepted_counter: Mapped[int] = mapped_column(Integer, nullable=False, default=-1)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    __table_args__ = (CheckConstraint("id = 1", name="ck_operator_totp_state_singleton"), CheckConstraint("last_accepted_counter >= -1", name="ck_operator_totp_counter_nonnegative"),)


class HypothesisFamilyRecord(Base):
    """Immutable preregistered research family and its one-time locked results."""
    __tablename__ = "research_hypothesis_families"
    family_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    study: Mapped[str] = mapped_column(String(120), nullable=False)
    protocol_version: Mapped[str] = mapped_column(String(64), nullable=False)
    manifest: Mapped[dict] = mapped_column(JSON, nullable=False)
    expected_ids: Mapped[list] = mapped_column(JSON, nullable=False)
    status: Mapped[str] = mapped_column(String(24), nullable=False, default="PRE_REGISTERED", index=True)
    p_values: Mapped[dict | None] = mapped_column(JSON)
    adjusted_results: Mapped[dict | None] = mapped_column(JSON)
    selection_authorized: Mapped[bool] = mapped_column(nullable=False, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    results_locked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    execution_provenance: Mapped[dict | None] = mapped_column(JSON)
    __table_args__ = (
        CheckConstraint("status IN ('PRE_REGISTERED','RESULTS_LOCKED')", name="ck_research_hypothesis_status"),
        CheckConstraint("selection_authorized = false", name="ck_research_hypothesis_no_auto_selection"),
    )


class CorporateActionRevisionRecord(Base):
    """Append-only point-in-time corporate-action event revision ledger."""
    __tablename__ = "corporate_action_revisions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source: Mapped[str] = mapped_column(String(48), nullable=False)
    event_id: Mapped[str] = mapped_column(String(160), nullable=False)
    revision: Mapped[int] = mapped_column(Integer, nullable=False)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(16), nullable=False)
    event_payload: Mapped[dict | None] = mapped_column(JSON(none_as_null=True))
    __table_args__ = (
        UniqueConstraint("source", "event_id", "revision", name="uq_corporate_action_revision_identity"),
        CheckConstraint("revision >= 1", name="ck_corporate_action_revision_positive"),
        CheckConstraint("status IN ('active','cancelled')", name="ck_corporate_action_revision_status"),
        CheckConstraint(
            "(status = 'active' AND event_payload IS NOT NULL) OR "
            "(status = 'cancelled' AND event_payload IS NULL)",
            name="ck_corporate_action_revision_payload_status",
        ),
    )
