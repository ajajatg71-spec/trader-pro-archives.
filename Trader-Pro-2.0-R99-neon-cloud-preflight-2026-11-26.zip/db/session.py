"""SQLAlchemy engine/session factory; engine creation is explicit and lazy."""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker


def normalize_database_url(database_url: str) -> str:
    """Normalize hosted PostgreSQL URLs to the installed psycopg 3 driver."""
    if database_url.startswith("postgres://"):
        return database_url.replace("postgres://", "postgresql+psycopg://", 1)
    if database_url.startswith("postgresql://"):
        return database_url.replace("postgresql://", "postgresql+psycopg://", 1)
    return database_url


def build_engine(database_url: str | None = None):
    url = database_url if database_url is not None else os.getenv("DATABASE_URL")
    if not url:
        raise RuntimeError("DATABASE_URL n'est pas configurée")
    url = normalize_database_url(url)
    kwargs = {"pool_pre_ping": True}
    if url.startswith("sqlite"):
        kwargs["connect_args"] = {"check_same_thread": False}
    return create_engine(url, **kwargs)


def build_session_factory(engine):
    return sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
