"""Durable Paper order/fill repository with idempotent client and fill IDs."""
from __future__ import annotations
from datetime import datetime, timezone, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from services.order_lifecycle import evaluate_transition
from db.models import (OrderRecord, FillRecord, AccountSnapshotRecord, AuditEventRecord,
                       RiskEventRecord, PositionSnapshotRecord, RiskControlStateRecord, SystemSafetyStateRecord, ReconciliationRunRecord, OperatorAuthAttemptRecord, OperatorTotpStateRecord)


class OrderRepositoryError(RuntimeError):
    pass


class OrderRepository:
    def __init__(self, session_factory):
        self.session_factory = session_factory

    @staticmethod
    def _validated_notional(value: Any) -> Decimal:
        if isinstance(value, bool):
            raise OrderRepositoryError("Montant d'ordre invalide")
        try:
            amount = Decimal(str(value))
        except (InvalidOperation, TypeError, ValueError) as exc:
            raise OrderRepositoryError("Montant d'ordre invalide") from exc
        if not amount.is_finite() or amount <= 0:
            raise OrderRepositoryError("Montant d'ordre invalide")
        return amount

    def stage_order(self, *, client_order_id: str, symbol: str, side: str,
                    notional: float, source: str = "paper") -> bool:
        amount = self._validated_notional(notional)
        if (not isinstance(client_order_id, str) or not client_order_id.strip()
                or not isinstance(symbol, str) or not symbol.strip()
                or side not in {"buy", "sell"}):
            raise OrderRepositoryError("Intention d'ordre invalide")
        try:
            with self.session_factory.begin() as session:
                current = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == client_order_id))
                if current:
                    if (current.symbol, current.side, current.notional) == (symbol, side, Decimal(str(notional))):
                        return False
                    raise OrderRepositoryError("Identifiant client déjà utilisé pour un autre ordre")
                session.add(OrderRecord(client_order_id=client_order_id, symbol=symbol,
                                        side=side, notional=amount, status="submitting"))
                session.add(AuditEventRecord(event_type="order_intent", message=f"Intention Paper {side} {symbol}",
                    correlation_id=client_order_id, details={"source": source, "notional": notional}))
            return True
        except OrderRepositoryError:
            raise
        except IntegrityError as exc:
            raise OrderRepositoryError("Conflit d'identifiant client") from exc
        except Exception as exc:
            raise OrderRepositoryError(f"Persistance de l'ordre impossible ({type(exc).__name__})") from exc

    def stage_order_if_trading_enabled(self, *, client_order_id: str, symbol: str, side: str,
                                       notional: float, source: str = "paper",
                                       max_total_buy_reservations: float | None = None,
                                       max_symbol_buy_reservation: float | None = None,
                                       external_open_buy_orders: list[dict[str, Any]] | None = None) -> bool:
        """Atomically check the durable kill switch and create a submission intent.

        The singleton risk row is locked in the same transaction as the intent.
        This serializes new submission claims against pause/resume transitions on
        PostgreSQL. An intent claimed before a pause is an in-flight operation and
        must be reconciled; a pause committed first prevents the claim.
        """
        candidate_amount = self._validated_notional(notional)
        if (not isinstance(client_order_id, str) or not client_order_id.strip()
                or not isinstance(symbol, str) or not symbol.strip()
                or side not in {"buy", "sell"}):
            raise OrderRepositoryError("Intention d'ordre invalide")
        if side == "buy" and max_total_buy_reservations is not None:
            try:
                ceiling = Decimal(str(max_total_buy_reservations))
                if not ceiling.is_finite() or ceiling < 0:
                    raise ValueError("plafond non fini ou négatif")
                external_open_buy_orders = external_open_buy_orders or []
                if not isinstance(external_open_buy_orders, list):
                    raise ValueError("snapshot externe invalide")
                symbol_ceiling = Decimal(str(max_symbol_buy_reservation))
                if not symbol_ceiling.is_finite() or symbol_ceiling < 0:
                    raise ValueError("plafond par symbole invalide")
                normalized_external: dict[str, tuple[str, Decimal]] = {}
                for item in external_open_buy_orders:
                    if not isinstance(item, dict):
                        raise ValueError("réservation externe invalide")
                    broker_id = item.get("broker_order_id")
                    symbol = item.get("symbol")
                    amount = Decimal(str(item.get("notional")))
                    if (not isinstance(broker_id, str) or not broker_id.strip()
                            or not isinstance(symbol, str) or not symbol.strip()
                            or not amount.is_finite() or amount <= 0):
                        raise ValueError("réservation externe invalide")
                    if broker_id in normalized_external:
                        raise ValueError("identifiant courtier dupliqué")
                    normalized_external[broker_id] = (symbol.upper(), amount)
            except Exception as exc:
                raise OrderRepositoryError("Paramètres de réservation agrégée invalides") from exc
        else:
            ceiling = None
            normalized_external = {}
            symbol_ceiling = None
        try:
            with self.session_factory.begin() as session:
                pause = session.scalar(
                    select(RiskControlStateRecord)
                    .where(RiskControlStateRecord.id == 1)
                    .with_for_update()
                )
                if pause is None:
                    raise OrderRepositoryError("État durable du coupe-circuit absent")
                safety = session.scalar(
                    select(SystemSafetyStateRecord)
                    .where(SystemSafetyStateRecord.id == 1)
                    .with_for_update()
                )
                if safety is None or safety.status != "READY":
                    safety_status = safety.status if safety is not None else "MISSING"
                    safety_reason = (safety.reason if safety is not None else None) or "État global de sécurité absent ou non prêt"
                    session.add(AuditEventRecord(event_type="order_submission_blocked",
                        message="Nouvelle intention refusée : état global non prêt",
                        correlation_id=client_order_id,
                        details={"gate": "SYSTEM_SAFETY_STATE", "status": safety_status, "reason": safety_reason}))
                    denied_reason = f"Trading bloqué : état global {safety_status} ({safety_reason})"
                elif pause.paused:
                    session.add(AuditEventRecord(event_type="order_submission_blocked",
                        message="Nouvelle intention refusée : coupe-circuit actif",
                        correlation_id=client_order_id,
                        details={"gate": "DURABLE_PAUSE_ATOMIC_CLAIM", "reason": pause.reason}))
                    # Commit the blocked audit, then report the denial outside the
                    # transaction so the audit is not rolled back.
                    denied_reason = pause.reason or "Trading en pause"
                else:
                    denied_reason = None
                    current = session.scalar(select(OrderRecord).where(
                        OrderRecord.client_order_id == client_order_id))
                    if current:
                        if (current.symbol, current.side, current.notional) == (
                            symbol, side, candidate_amount
                        ):
                            return False
                        raise OrderRepositoryError("Identifiant client déjà utilisé pour un autre ordre")
                    if side == "buy" and ceiling is not None:
                        terminal = {"filled", "canceled", "cancelled", "expired", "rejected", "done_for_day", "replaced"}
                        local_rows = session.scalars(select(OrderRecord).where(
                            OrderRecord.side == "buy", OrderRecord.status.not_in(terminal)
                        ).with_for_update()).all()
                        # Merge the broker snapshot with local durable intents. A
                        # broker order already represented locally is counted once;
                        # a not-yet-acknowledged local intent is still reserved.
                        amounts = [value[1] for value in normalized_external.values()]
                        symbol_amounts = [value[1] for value in normalized_external.values()
                                          if value[0] == symbol.upper()]
                        for local in local_rows:
                            if local.broker_order_id and local.broker_order_id in normalized_external:
                                external_symbol, external_amount = normalized_external[local.broker_order_id]
                                local_amount = Decimal(str(local.notional)) if local.notional is not None else None
                                if (external_symbol != local.symbol.upper() or local_amount is None
                                        or not local_amount.is_finite() or local_amount != external_amount):
                                    raise PermissionError("Réservation locale et courtier divergentes : approbation bloquée")
                                continue
                            local_amount = Decimal(str(local.notional)) if local.notional is not None else None
                            if local_amount is None or not local_amount.is_finite() or local_amount <= 0:
                                raise PermissionError("Réservation locale inconnue : nouvelle approbation bloquée")
                            amounts.append(local_amount)
                            if local.symbol.upper() == symbol.upper():
                                symbol_amounts.append(local_amount)
                        amounts.append(candidate_amount)
                        symbol_amounts.append(candidate_amount)
                        total_reserved = sum(amounts, Decimal("0"))
                        symbol_reserved = sum(symbol_amounts, Decimal("0"))
                        if (not total_reserved.is_finite() or total_reserved > ceiling
                                or symbol_ceiling is None or not symbol_reserved.is_finite()
                                or symbol_reserved > symbol_ceiling):
                            session.add(AuditEventRecord(event_type="order_submission_blocked",
                                message="Nouvelle intention refusée : plafond agrégé de réservations dépassé",
                                correlation_id=client_order_id,
                                details={"gate": "ATOMIC_AGGREGATE_BUY_RESERVATION",
                                         "reserved_total": str(total_reserved),
                                         "reservation_ceiling": str(ceiling),
                                         "symbol": symbol.upper(),
                                         "symbol_reserved_total": str(symbol_reserved),
                                         "symbol_reservation_ceiling": str(symbol_ceiling)}))
                            denied_reason = "Plafond agrégé de liquidités, d'exposition ou de concentration dépassé : ordre bloqué"
                        else:
                            denied_reason = None
                    else:
                        denied_reason = None
                    if denied_reason is None:
                        session.add(OrderRecord(client_order_id=client_order_id, symbol=symbol,
                            side=side, notional=candidate_amount, status="submitting"))
                        session.add(AuditEventRecord(event_type="order_intent",
                            message=f"Intention Paper {side} {symbol}", correlation_id=client_order_id,
                            details={"source": source, "notional": notional,
                                     "pause_gate": "locked_and_clear",
                                     "aggregate_reservation_gate": "checked" if ceiling is not None else "not_applicable"}))
            if denied_reason is not None:
                raise PermissionError(denied_reason)
            return True
        except (OrderRepositoryError, PermissionError):
            raise
        except IntegrityError as exc:
            raise OrderRepositoryError("Conflit d'identifiant client") from exc
        except Exception as exc:
            raise OrderRepositoryError(f"Réservation d'ordre impossible ({type(exc).__name__})") from exc

    def update_order(self, client_order_id: str, *, status: str, broker_order_id: str | None = None,
                     quantity: float | None = None, reason: str | None = None) -> None:
        allowed = {"accepted", "accepted_for_bidding", "new", "pending_new", "partially_filled", "filled", "done_for_day",
                   "canceled", "cancelled", "expired", "replaced", "pending_cancel", "pending_replace",
                   "stopped", "suspended", "calculated", "held", "rejected", "submission_unknown", "submission_failed"}
        status = str(status or "").strip().lower()
        if status not in allowed:
            raise OrderRepositoryError("Statut d'ordre non autorisé")
        try:
            with self.session_factory.begin() as session:
                row = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == client_order_id).with_for_update())
                if row is None:
                    raise OrderRepositoryError("Intention d'ordre introuvable")
                decision = evaluate_transition(row.status, status)
                if not decision.allowed:
                    # A stale/out-of-order broker snapshot must never regress a
                    # terminal or otherwise incompatible local lifecycle state.
                    session.add(AuditEventRecord(
                        event_type="order_status_ignored",
                        message=f"{client_order_id}: transition ignorée {row.status} -> {status}",
                        correlation_id=client_order_id,
                        details={"current_status": row.status, "incoming_status": status,
                                 "reason": decision.reason, "broker_order_id": broker_order_id},
                    ))
                    return
                row.status = status
                if broker_order_id:
                    row.broker_order_id = broker_order_id
                if quantity is not None:
                    row.quantity = Decimal(str(quantity))
                if status in {"accepted", "new", "partially_filled", "filled"} and row.submitted_at is None:
                    row.submitted_at = datetime.now(timezone.utc)
                session.add(AuditEventRecord(event_type="order_status", message=f"{client_order_id}: {status}",
                    correlation_id=client_order_id, details={"status": status, "reason": reason, "broker_order_id": broker_order_id}))
        except OrderRepositoryError:
            raise
        except Exception as exc:
            raise OrderRepositoryError(f"Mise à jour de l'ordre impossible ({type(exc).__name__})") from exc


    def record_order_cancel_event(self, *, client_order_id: str | None, broker_order_id: str,
                                 outcome: str, reason: str | None = None) -> None:
        """Durably record a broker cancellation request/result without guessing final status."""
        if not broker_order_id or outcome not in {"requested", "request_failed"}:
            raise OrderRepositoryError("Événement d'annulation invalide")
        try:
            with self.session_factory.begin() as session:
                if client_order_id:
                    row = session.scalar(select(OrderRecord).where(
                        OrderRecord.client_order_id == client_order_id).with_for_update())
                    if row is not None and outcome == "requested":
                        # A cancel request is only an intent, never authority to
                        # move an already-terminal order backwards. The order may
                        # have filled while the broker cancellation was in flight.
                        terminal_statuses = {"filled", "canceled", "cancelled", "expired", "rejected", "replaced"}
                        if row.status not in terminal_statuses:
                            row.status = "pending_cancel"
                        if not row.broker_order_id:
                            row.broker_order_id = broker_order_id
                else:
                    row = None
                preserved_terminal_status = bool(row is not None and row.status in
                    {"filled", "canceled", "cancelled", "expired", "rejected", "replaced"})
                session.add(AuditEventRecord(
                    event_type="broker_cancel_requested" if outcome == "requested" else "broker_cancel_request_failed",
                    message=f"Annulation broker {outcome}: {broker_order_id}",
                    correlation_id=client_order_id,
                    details={"broker_order_id": broker_order_id, "outcome": outcome,
                             "reason": (str(reason)[:1000] if reason else None),
                             "final_status_confirmed": False,
                             "terminal_status_preserved": preserved_terminal_status},
                ))
        except Exception as exc:
            raise OrderRepositoryError(f"Audit de demande d'annulation impossible ({type(exc).__name__})") from exc

    def recover_stale_submissions(self, *, stale_after_seconds: int = 120) -> list[str]:
        """Move abandoned `submitting` intents to `submission_unknown`.

        This is deliberately a classification only: it never resubmits an order.
        The stable client_order_id must be looked up at the broker before an
        operator can decide what to do. A crash can happen after broker acceptance
        but before the local status update.
        """
        if not isinstance(stale_after_seconds, int) or stale_after_seconds < 1 or stale_after_seconds > 86400:
            raise OrderRepositoryError("Délai de récupération invalide")
        cutoff = datetime.now(timezone.utc).timestamp() - stale_after_seconds
        try:
            with self.session_factory.begin() as session:
                rows = session.scalars(
                    select(OrderRecord)
                    .where(OrderRecord.status == "submitting")
                    .with_for_update()
                ).all()
                recovered: list[str] = []
                for row in rows:
                    stamp = row.updated_at
                    if stamp is None:
                        # A missing timestamp is not proof of a recent submission.
                        is_stale = True
                    else:
                        if stamp.tzinfo is None:
                            stamp = stamp.replace(tzinfo=timezone.utc)
                        is_stale = stamp.timestamp() <= cutoff
                    if not is_stale:
                        continue
                    row.status = "submission_unknown"
                    recovered.append(row.client_order_id)
                    session.add(AuditEventRecord(
                        event_type="order_recovery",
                        message=f"Soumission abandonnée classée inconnue : {row.client_order_id}",
                        correlation_id=row.client_order_id,
                        details={"from_status": "submitting", "to_status": "submission_unknown",
                                 "reason": "stale_submission_recovery",
                                 "stale_after_seconds": stale_after_seconds,
                                 "automatic_resubmission": False},
                    ))
                return recovered
        except OrderRepositoryError:
            raise
        except Exception as exc:
            raise OrderRepositoryError(f"Récupération des soumissions abandonnées impossible ({type(exc).__name__})") from exc

    def list_orders_for_reconciliation(self) -> list[dict[str, Any]]:
        """Return local orders that may still change or need broker confirmation."""
        statuses = {"submitting", "submission_unknown", "submission_failed", "accepted", "new",
                    "pending_new", "partially_filled", "pending_cancel", "pending_replace", "held",
                    "filled", "canceled", "cancelled", "expired", "rejected", "done_for_day", "replaced"}
        # Keep recently terminal orders in the reconciliation window: late fill
        # activities can arrive after a cancel/expiry status was first observed.
        terminal = {"filled", "canceled", "cancelled", "expired", "rejected", "done_for_day", "replaced"}
        cutoff = datetime.now(timezone.utc) - timedelta(days=7)
        try:
            with self.session_factory() as session:
                rows = session.scalars(select(OrderRecord).where(
                    (OrderRecord.status.not_in(terminal)) |
                    ((OrderRecord.status.in_(terminal)) & (OrderRecord.updated_at >= cutoff))
                ).order_by(OrderRecord.id)).all()
                return [{"client_order_id": r.client_order_id, "broker_order_id": r.broker_order_id,
                         "symbol": r.symbol, "side": r.side, "status": r.status,
                         "quantity": float(r.quantity) if r.quantity is not None else None}
                        for r in rows]
        except Exception as exc:
            raise OrderRepositoryError(f"Lecture des ordres à réconcilier impossible ({type(exc).__name__})") from exc

    def record_fill(self, *, broker_fill_id: str, client_order_id: str, symbol: str,
                    quantity: Decimal | str | float, price: Decimal | str | float,
                    fee: Decimal | str | float = Decimal("0"),
                    executed_at: datetime | None = None) -> bool:
        # Convert at the boundary and keep Decimal throughout: converting broker
        # decimal strings to float first can silently alter fractional-share fills.
        try:
            qty_value, price_value, fee_value = (Decimal(str(value)) for value in (quantity, price, fee))
        except (InvalidOperation, TypeError, ValueError) as exc:
            raise OrderRepositoryError("Exécution (fill) invalide") from exc
        if (not broker_fill_id or len(broker_fill_id) > 128 or not client_order_id
                or not symbol or len(symbol) > 16
                or not all(value.is_finite() for value in (qty_value, price_value, fee_value))
                or qty_value <= 0 or price_value <= 0 or fee_value < 0):
            raise OrderRepositoryError("Exécution (fill) invalide")
        qty_db = qty_value.quantize(Decimal("0.0000000001"))
        price_db = price_value.quantize(Decimal("0.00000001"))
        fee_db = fee_value.quantize(Decimal("0.00000001"))
        # The database scale is the ledger's canonical precision. Normalize once
        # before both insert and replay comparison; never pass through binary float.
        symbol = symbol.upper()
        try:
            with self.session_factory.begin() as session:
                order = session.scalar(select(OrderRecord).where(OrderRecord.client_order_id == client_order_id).with_for_update())
                if order is None:
                    raise OrderRepositoryError("Ordre associé au fill introuvable")
                existing = session.scalar(select(FillRecord).where(FillRecord.broker_fill_id == broker_fill_id))
                if existing:
                    # Compare at the database column scale. Providers often return
                    # binary floats; SQLite/PostgreSQL Numeric columns round these
                    # to their declared scale on persistence. Comparing the raw
                    # Decimal(str(float)) to the reloaded value would make an
                    # identical replay look like a conflicting fill.
                    same_fill = (
                        existing.order_id == order.id
                        and existing.symbol == symbol
                        and existing.quantity == qty_db
                        and existing.price == price_db
                        and existing.fee == fee_db
                    )
                    if same_fill:
                        return False
                    raise OrderRepositoryError("Identifiant de fill déjà utilisé avec des données différentes")
                if order.symbol != symbol:
                    raise OrderRepositoryError("Le symbole du fill ne correspond pas à l'ordre")
                if order.symbol.upper() != symbol:
                    raise OrderRepositoryError("Le symbole du fill ne correspond pas à l'ordre")
                stamp = executed_at or datetime.now(timezone.utc)
                if stamp.tzinfo is None:
                    stamp = stamp.replace(tzinfo=timezone.utc)
                session.add(FillRecord(broker_fill_id=broker_fill_id, order_id=order.id, symbol=symbol,
                    quantity=qty_db, price=price_db, fee=fee_db, executed_at=stamp))
                session.add(AuditEventRecord(event_type="fill_recorded", message=f"Fill {broker_fill_id} {symbol}",
                    correlation_id=client_order_id, details={"quantity": str(qty_db), "price": str(price_db), "fee": str(fee_db)}))
                return True
        except OrderRepositoryError:
            raise
        except IntegrityError as exc:
            raise OrderRepositoryError("Conflit d'identifiant de fill") from exc
        except Exception as exc:
            raise OrderRepositoryError(f"Enregistrement du fill impossible ({type(exc).__name__})") from exc

    def list_fills_for_ledger(self) -> list[dict[str, Any]]:
        """Return the durable fill ledger with the side of each parent order."""
        try:
            with self.session_factory() as session:
                rows = session.execute(
                    select(FillRecord, OrderRecord.side, OrderRecord.client_order_id)
                    .join(OrderRecord, FillRecord.order_id == OrderRecord.id)
                    .order_by(FillRecord.executed_at, FillRecord.id)
                ).all()
                return [{
                    "fill_id": fill.broker_fill_id,
                    "client_order_id": client_id,
                    "symbol": fill.symbol,
                    "side": side,
                    "quantity": Decimal(fill.quantity),
                    "price": Decimal(fill.price),
                    "fee": Decimal(fill.fee),
                    "executed_at": fill.executed_at,
                } for fill, side, client_id in rows]
        except Exception as exc:
            raise OrderRepositoryError(f"Lecture du grand livre des exécutions impossible ({type(exc).__name__})") from exc

    def record_account_snapshot(self, *, equity: float, cash: float, buying_power: float | None = None,
                                source: str = "paper", captured_at: datetime | None = None) -> None:
        if equity < 0 or cash < 0 or (buying_power is not None and buying_power < 0):
            raise OrderRepositoryError("Snapshot de compte invalide")
        try:
            with self.session_factory.begin() as session:
                stamp = captured_at or datetime.now(timezone.utc)
                session.add(AccountSnapshotRecord(captured_at=stamp,
                    equity=Decimal(str(equity)), cash=Decimal(str(cash)),
                    buying_power=Decimal(str(buying_power)) if buying_power is not None else None, source=source))
                session.add(AuditEventRecord(event_type="account_snapshot", message="Snapshot de compte enregistré",
                    details={"equity": equity, "cash": cash, "buying_power": buying_power, "source": source}))
        except Exception as exc:
            raise OrderRepositoryError(f"Snapshot non persisté ({type(exc).__name__})") from exc

    def record_reconciliation_snapshot(self, *, account: dict[str, Any],
                                       positions: list[dict[str, Any]],
                                       source: str = "paper",
                                       captured_at: datetime | None = None) -> None:
        """Persist account and all positions atomically as one broker snapshot."""
        try:
            stamp = captured_at or datetime.now(timezone.utc)
            equity = Decimal(str(account["equity"]))
            cash = Decimal(str(account["cash"]))
            buying_power_raw = account.get("buying_power")
            buying_power = Decimal(str(buying_power_raw)) if buying_power_raw is not None else None
            if (not equity.is_finite() or not cash.is_finite() or equity < 0 or cash < 0
                    or (buying_power is not None and (not buying_power.is_finite() or buying_power < 0))):
                raise OrderRepositoryError("Snapshot de compte invalide")
            normalized_positions = []
            for item in positions:
                symbol = str(item.get("symbol", "")).strip().upper()
                qty = Decimal(str(item.get("qty", "0")))
                market_value = Decimal(str(item.get("market_value", "0")))
                avg = item.get("avg_entry_price")
                upl = item.get("unrealized_pl")
                avg_value = Decimal(str(avg)) if avg not in (None, "") else None
                upl_value = Decimal(str(upl)) if upl not in (None, "") else None
                if (not symbol or not qty.is_finite() or qty == 0 or not market_value.is_finite()
                        or (avg_value is not None and (not avg_value.is_finite() or avg_value <= 0))
                        or (upl_value is not None and not upl_value.is_finite())):
                    raise OrderRepositoryError("Position du courtier invalide")
                # Negative quantity and market value are legitimate for short positions.
                normalized_positions.append((symbol, qty, market_value, avg_value, upl_value))
            with self.session_factory.begin() as session:
                session.add(AccountSnapshotRecord(captured_at=stamp, equity=equity,
                    cash=cash, buying_power=buying_power, source=source))
                for symbol, qty, market_value, avg_value, upl_value in normalized_positions:
                    session.add(PositionSnapshotRecord(captured_at=stamp, symbol=symbol, quantity=qty,
                        market_value=market_value, average_entry_price=avg_value,
                        unrealized_pl=upl_value, source=source))
                session.add(AuditEventRecord(event_type="broker_reconciliation_snapshot",
                    message="Snapshot courtier Paper enregistré",
                    details={"source": source, "positions": len(positions), "equity": str(equity), "cash": str(cash)}))
        except OrderRepositoryError:
            raise
        except Exception as exc:
            raise OrderRepositoryError(f"Snapshot de réconciliation non persisté ({type(exc).__name__})") from exc

    def record_risk_decision(self, *, client_order_id: str, symbol: str, side: str,
                             notional: float, decision: str, gate: str,
                             reason: str | None = None, metrics: dict[str, Any] | None = None) -> None:
        """Persist an immutable pre-trade decision before any broker side effect."""
        if decision not in {"approved", "blocked"} or side not in {"buy", "sell"}:
            raise OrderRepositoryError("Décision de risque invalide")
        if not client_order_id or not symbol or notional <= 0:
            raise OrderRepositoryError("Contexte de décision de risque invalide")
        details = {"decision": decision, "gate": gate, "symbol": symbol.upper(),
                   "side": side, "notional": notional, "reason": reason,
                   "metrics": metrics or {}}
        message = (f"Pré-trade {decision}: {side} {symbol.upper()} {notional:.2f} "
                   f"({gate})" + (f" — {reason}" if reason else ""))
        try:
            with self.session_factory.begin() as session:
                session.add(AuditEventRecord(event_type="risk_decision", message=message,
                    correlation_id=client_order_id, details=details))
                if decision == "blocked":
                    session.add(RiskEventRecord(severity="warning", rule=gate,
                        message=reason or message, metrics=metrics or {}))
        except Exception as exc:
            raise OrderRepositoryError(f"Décision de risque non persistée ({type(exc).__name__})") from exc

    def record_risk_event(self, *, severity: str, rule: str, message: str,
                          metrics: dict[str, Any] | None = None, correlation_id: str | None = None) -> None:
        try:
            with self.session_factory.begin() as session:
                session.add(RiskEventRecord(severity=severity, rule=rule, message=message, metrics=metrics or {}))
                session.add(AuditEventRecord(event_type="risk_event", message=message,
                    correlation_id=correlation_id, details={"severity": severity, "rule": rule, "metrics": metrics or {}}))
        except Exception as exc:
            raise OrderRepositoryError(f"Événement de risque non persisté ({type(exc).__name__})") from exc


    _SAFETY_TRANSITIONS = {
        "READY": {"DEGRADED", "RECONCILING", "HALTED"},
        "DEGRADED": {"RECONCILING", "HALTED"},
        "RECONCILING": {"READY", "DEGRADED", "HALTED"},
        "HALTED": {"RECONCILING"},
    }

    def get_system_safety_state(self) -> dict[str, Any]:
        try:
            with self.session_factory() as session:
                row = session.get(SystemSafetyStateRecord, 1)
                if row is None:
                    raise OrderRepositoryError("État global de sécurité absent")
                return {"status": row.status, "reason": row.reason, "actor": row.actor,
                        "generation": row.generation, "updated_at": row.updated_at}
        except OrderRepositoryError:
            raise
        except Exception as exc:
            raise OrderRepositoryError(f"Lecture de l'état global impossible ({type(exc).__name__})") from exc

    def record_reconciliation_run(self, *, run_id: str, source: str, status: str,
                                  snapshot_complete: bool, unresolved_count: int,
                                  orders_seen: int, fills_seen: int, positions_seen: int,
                                  evidence_hash: str, details: dict[str, Any]) -> dict[str, Any]:
        """Persist immutable reconciliation evidence; a run_id can never be overwritten."""
        if (not run_id or len(run_id) > 64 or source != "paper"
                or status not in {"succeeded", "inconclusive", "failed"}
                or len(evidence_hash) != 64 or unresolved_count < 0
                or min(orders_seen, fills_seen, positions_seen) < 0):
            raise OrderRepositoryError("Preuve de réconciliation invalide")
        try:
            with self.session_factory.begin() as session:
                row = ReconciliationRunRecord(
                    run_id=run_id, source=source, status=status,
                    snapshot_complete=bool(snapshot_complete), unresolved_count=unresolved_count,
                    orders_seen=orders_seen, fills_seen=fills_seen, positions_seen=positions_seen,
                    evidence_hash=evidence_hash, details=details or {})
                session.add(row)
                session.flush()
                session.add(AuditEventRecord(event_type="reconciliation_run_recorded",
                    message=f"Réconciliation {status}", correlation_id=run_id,
                    details={"source": source, "status": status, "snapshot_complete": bool(snapshot_complete),
                             "unresolved_count": unresolved_count, "evidence_hash": evidence_hash}))
                return {"run_id": row.run_id, "status": row.status, "evidence_hash": row.evidence_hash,
                        "snapshot_complete": row.snapshot_complete, "unresolved_count": row.unresolved_count,
                        "completed_at": row.completed_at}
        except Exception as exc:
            if isinstance(exc, OrderRepositoryError):
                raise
            raise OrderRepositoryError(f"Preuve de réconciliation non persistée ({type(exc).__name__})") from exc

    def get_reconciliation_run(self, run_id: str) -> dict[str, Any]:
        try:
            with self.session_factory() as session:
                row = session.scalar(select(ReconciliationRunRecord).where(ReconciliationRunRecord.run_id == run_id))
                if row is None:
                    raise OrderRepositoryError("Référence de réconciliation inconnue")
                return {"run_id": row.run_id, "source": row.source, "status": row.status,
                        "snapshot_complete": row.snapshot_complete, "unresolved_count": row.unresolved_count,
                        "evidence_hash": row.evidence_hash, "completed_at": row.completed_at,
                        "consumed_at": row.consumed_at, "details": row.details}
        except OrderRepositoryError:
            raise
        except Exception as exc:
            raise OrderRepositoryError(f"Lecture de la preuve impossible ({type(exc).__name__})") from exc

    def transition_system_safety_state(self, *, status: str, reason: str | None, actor: str,
                                       reconciliation_run_id: str | None = None) -> dict[str, Any]:
        """Guard transitions; READY requires a fresh, persisted, complete Paper reconciliation proof."""
        if status not in self._SAFETY_TRANSITIONS or not actor or len(actor) > 64:
            raise OrderRepositoryError("Transition ou acteur invalide")
        try:
            with self.session_factory.begin() as session:
                row = session.scalar(select(SystemSafetyStateRecord).where(
                    SystemSafetyStateRecord.id == 1).with_for_update())
                if row is None:
                    raise OrderRepositoryError("État global de sécurité absent")
                previous_status = row.status
                if status not in self._SAFETY_TRANSITIONS[previous_status]:
                    raise OrderRepositoryError(f"Transition interdite : {previous_status} -> {status}")
                if previous_status == "HALTED" and (status != "RECONCILING" or actor in {"system", "worker", "risk_engine"}):
                    raise OrderRepositoryError("La sortie de HALTED exige une action explicite d'opérateur")
                proof = None
                if status == "READY":
                    if actor != "operator":
                        raise OrderRepositoryError("Seul un opérateur peut autoriser le retour à READY")
                    if not reconciliation_run_id:
                        raise OrderRepositoryError("READY exige une référence de réconciliation persistée")
                    proof = session.scalar(select(ReconciliationRunRecord).where(
                        ReconciliationRunRecord.run_id == reconciliation_run_id).with_for_update())
                    if (proof is None or proof.source != "paper" or proof.status != "succeeded"
                            or proof.consumed_at is not None
                            or not proof.snapshot_complete or proof.unresolved_count != 0
                            or len(proof.evidence_hash or "") != 64):
                        raise OrderRepositoryError("Preuve Paper absente, incomplète ou comportant des écarts")
                    completed = proof.completed_at
                    if completed is None:
                        raise OrderRepositoryError("Horodatage de preuve absent")
                    now = datetime.now(timezone.utc)
                    if completed.tzinfo is None:
                        completed = completed.replace(tzinfo=timezone.utc)
                    if (now - completed).total_seconds() > 300 or (completed - now).total_seconds() > 30:
                        raise OrderRepositoryError("Preuve de réconciliation trop ancienne")
                    # A reconciliation proof is a one-time authorization artifact.
                    # Consume it in the same locked transaction as the READY transition
                    # so it cannot be replayed after a later DEGRADED/RECONCILING cycle.
                    proof.consumed_at = now
                    row.last_reconciliation_run_id = proof.run_id
                elif reconciliation_run_id is not None:
                    raise OrderRepositoryError("Une preuve ne peut être attachée qu'au passage à READY")
                row.status, row.reason, row.actor = status, (str(reason)[:2000] if reason else None), actor
                row.generation += 1
                session.add(AuditEventRecord(event_type="system_safety_transition",
                    message=f"État global {status}", details={"from": previous_status, "to": status,
                    "actor": actor, "generation": row.generation, "reason": row.reason,
                    "reconciliation_run_id": proof.run_id if proof else None,
                    "reconciliation_evidence_hash": proof.evidence_hash if proof else None}))
                result = {"status": row.status, "reason": row.reason, "actor": row.actor,
                          "generation": row.generation, "last_reconciliation_run_id": row.last_reconciliation_run_id}
            return result
        except OrderRepositoryError:
            raise
        except Exception as exc:
            raise OrderRepositoryError(f"Transition de sécurité impossible ({type(exc).__name__})") from exc

    def get_operational_pause(self) -> dict[str, Any]:
        """Read the durable singleton pause flag; a missing row is fail-closed."""
        try:
            with self.session_factory() as session:
                row = session.get(RiskControlStateRecord, 1)
                if row is None:
                    return {"paused": True, "reason": "État durable du coupe-circuit absent", "actor": "system", "updated_at": None}
                return {"paused": bool(row.paused), "reason": row.reason, "actor": row.actor,
                        "updated_at": row.updated_at}
        except Exception as exc:
            raise OrderRepositoryError(f"État du coupe-circuit illisible ({type(exc).__name__})") from exc

    def set_operational_pause(self, *, paused: bool, reason: str | None = None,
                              actor: str = "operator") -> None:
        """Atomically persist pause state and append-only audit event."""
        if not isinstance(paused, bool) or not actor or len(actor) > 64:
            raise OrderRepositoryError("Commande du coupe-circuit invalide")
        if reason is not None:
            reason = str(reason)[:2000]
        try:
            with self.session_factory.begin() as session:
                # Serialize concurrent operator transitions on PostgreSQL. Without
                # SELECT FOR UPDATE, simultaneous pause/resume requests can race
                # and leave the durable state inconsistent with transition order.
                row = session.scalar(
                    select(RiskControlStateRecord)
                    .where(RiskControlStateRecord.id == 1)
                    .with_for_update()
                )
                if row is None:
                    # Migrations seed this singleton. A missing row is an
                    # integrity incident; fail closed instead of silently
                    # recreating an operational authorization state at runtime.
                    raise OrderRepositoryError("État durable du coupe-circuit absent")
                row.paused, row.reason, row.actor = paused, reason, actor
                session.add(AuditEventRecord(event_type="emergency_pause" if paused else "trading_resume",
                    message=("Coupe-circuit activé" if paused else "Reprise du trading autorisée"),
                    details={"paused": paused, "reason": reason, "actor": actor}))
        except OrderRepositoryError:
            raise
        except Exception as exc:
            raise OrderRepositoryError(f"État du coupe-circuit non persisté ({type(exc).__name__})") from exc
    def reserve_operator_auth_attempt(self, client_key: str, *, now: datetime, limit: int = 5, window_seconds: int = 600) -> bool:
        """Atomically reserve one attempt before credential verification (including concurrent requests)."""
        try:
            with self.session_factory.begin() as session:
                row = session.scalar(select(OperatorAuthAttemptRecord).where(
                    OperatorAuthAttemptRecord.client_key == client_key).with_for_update())
                if row is None:
                    session.add(OperatorAuthAttemptRecord(client_key=client_key,
                        window_started_at=now, attempts=1))
                    return True
                started = row.window_started_at
                if started.tzinfo is None and now.tzinfo is not None:
                    started = started.replace(tzinfo=now.tzinfo)
                if (now - started).total_seconds() >= window_seconds:
                    row.window_started_at, row.attempts = now, 1
                elif row.attempts >= limit:
                    return False
                else:
                    row.attempts += 1
                return row.attempts <= limit
        except IntegrityError:
            # Concurrent first request: the unique primary key chooses one winner;
            # retry against its committed row and reserve a distinct slot.
            with self.session_factory.begin() as session:
                row = session.scalar(select(OperatorAuthAttemptRecord).where(
                    OperatorAuthAttemptRecord.client_key == client_key).with_for_update())
                if row is None:
                    raise
                started = row.window_started_at
                if started.tzinfo is None and now.tzinfo is not None:
                    started = started.replace(tzinfo=now.tzinfo)
                if (now - started).total_seconds() >= window_seconds:
                    row.window_started_at, row.attempts = now, 1
                elif row.attempts >= limit:
                    return False
                else:
                    row.attempts += 1
                return row.attempts <= limit

    def operator_auth_is_rate_limited(self, client_key: str, *, now: datetime, limit: int = 5, window_seconds: int = 600) -> bool:
        """Check a durable fixed-window throttle; row lock serializes PostgreSQL workers."""
        with self.session_factory.begin() as session:
            row = session.scalar(select(OperatorAuthAttemptRecord).where(
                OperatorAuthAttemptRecord.client_key == client_key).with_for_update())
            if row is None:
                return False
            started = row.window_started_at
            if started.tzinfo is None and now.tzinfo is not None:
                started = started.replace(tzinfo=now.tzinfo)
            if (now - started).total_seconds() >= window_seconds:
                return False
            return row.attempts >= limit

    def record_operator_auth_failure(self, client_key: str, *, now: datetime, window_seconds: int = 600) -> None:
        """Atomically increment the persistent throttle counter."""
        from sqlalchemy.exc import IntegrityError
        try:
            with self.session_factory.begin() as session:
                row = session.scalar(select(OperatorAuthAttemptRecord).where(
                    OperatorAuthAttemptRecord.client_key == client_key).with_for_update())
                if row is None:
                    row = OperatorAuthAttemptRecord(client_key=client_key, window_started_at=now, attempts=1)
                    session.add(row)
                else:
                    started = row.window_started_at
                    if started.tzinfo is None and now.tzinfo is not None:
                        started = started.replace(tzinfo=now.tzinfo)
                    if (now - started).total_seconds() >= window_seconds:
                        row.window_started_at, row.attempts = now, 1
                    else:
                        row.attempts += 1
        except IntegrityError:
            # Concurrent first inserts: the losing request retries once against the winner's row.
            with self.session_factory.begin() as session:
                row = session.scalar(select(OperatorAuthAttemptRecord).where(
                    OperatorAuthAttemptRecord.client_key == client_key).with_for_update())
                if row is None:
                    raise
                row.attempts += 1

    def consume_operator_totp_counter(self, counter: int) -> bool:
        """Persist TOTP high-water mark; exactly one concurrent replay can succeed."""
        with self.session_factory.begin() as session:
            row = session.scalar(select(OperatorTotpStateRecord).where(
                OperatorTotpStateRecord.id == 1).with_for_update())
            if row is None:
                row = OperatorTotpStateRecord(id=1, last_accepted_counter=-1)
                session.add(row)
                session.flush()
            if counter <= row.last_accepted_counter:
                return False
            row.last_accepted_counter = counter
            return True

