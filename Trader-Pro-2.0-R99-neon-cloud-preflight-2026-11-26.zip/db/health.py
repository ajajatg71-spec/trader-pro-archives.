"""Database readiness probes; never silently falls back to JSON or SQLite."""
from sqlalchemy import text


def check_database(engine):
    try:
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
        return {"configured": True, "reachable": True, "error": None}
    except Exception as exc:
        return {"configured": True, "reachable": False, "error": type(exc).__name__}
