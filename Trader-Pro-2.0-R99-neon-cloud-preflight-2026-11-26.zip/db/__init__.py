"""Database layer for Trader Pro; kept separate from legacy JSON state until migration validation."""
