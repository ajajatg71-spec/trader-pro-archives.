"""Durable append-only persistence for point-in-time corporate-action revisions."""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Iterable

from sqlalchemy import inspect, select, text
from sqlalchemy.exc import IntegrityError

from db.models import CorporateActionRevisionRecord
from research_v1.quant.corporate_action_ledger import (
    CorporateActionRevision,
    corporate_action_snapshot,
)
from research_v1.quant.corporate_actions import CorporateActionError, CorporateActionEvent


class CorporateActionRepositoryError(RuntimeError):
    """Invalid or conflicting corporate-action persistence operation."""


def _event_to_payload(event: CorporateActionEvent) -> dict:
    return {
        "symbol": event.symbol,
        "action_type": event.action_type,
        "ex_date": event.ex_date.isoformat(),
        "available_at": event.available_at.isoformat(),
        "source": event.source,
        "split_ratio": str(event.split_ratio) if event.split_ratio is not None else None,
        "cash_amount": str(event.cash_amount) if event.cash_amount is not None else None,
        "currency": event.currency,
        "event_id": event.event_id,
    }


def _payload_to_event(payload: dict) -> CorporateActionEvent:
    if not isinstance(payload, dict):
        raise CorporateActionRepositoryError("Payload d'événement persistant invalide")
    try:
        return CorporateActionEvent(
            symbol=payload["symbol"],
            action_type=payload["action_type"],
            ex_date=date.fromisoformat(payload["ex_date"]),
            available_at=datetime.fromisoformat(payload["available_at"]),
            source=payload["source"],
            split_ratio=payload.get("split_ratio"),
            cash_amount=payload.get("cash_amount"),
            currency=payload.get("currency"),
            event_id=payload.get("event_id"),
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise CorporateActionRepositoryError("Événement persistant non reconstructible") from exc


def _row_to_revision(row: CorporateActionRevisionRecord) -> CorporateActionRevision:
    recorded_at = row.recorded_at
    # SQLite drops tzinfo for DateTime(timezone=True); PostgreSQL preserves it.
    # In SQLite tests, the repository writes UTC-normalized values only.
    if recorded_at.tzinfo is None or recorded_at.utcoffset() is None:
        from datetime import timezone
        recorded_at = recorded_at.replace(tzinfo=timezone.utc)
    event = _payload_to_event(row.event_payload) if row.status == "active" else None
    return CorporateActionRevision(
        source=row.source, event_id=row.event_id, revision=row.revision,
        recorded_at=recorded_at, status=row.status, event=event,
    )


class CorporateActionRepository:
    """Stores revisions without UPDATE/DELETE APIs; duplicate inserts are idempotent."""

    def __init__(self, session_factory):
        self.session_factory = session_factory

    def append_revision(self, revision: CorporateActionRevision) -> bool:
        if not isinstance(revision, CorporateActionRevision):
            raise CorporateActionRepositoryError("Révision non validée")
        payload = _event_to_payload(revision.event) if revision.event is not None else None
        try:
            with self.session_factory.begin() as session:
                bind = session.get_bind()
                if bind.dialect.name == "postgresql":
                    # Serialize all writers for this provider/event identity, including
                    # the first insert when no row exists yet.
                    lock_key = f"corporate-action:{revision.source}:{revision.event_id}"
                    session.execute(text("SELECT pg_advisory_xact_lock(hashtext(:lock_key))"),
                                    {"lock_key": lock_key})
                existing = session.scalar(select(CorporateActionRevisionRecord).where(
                    CorporateActionRevisionRecord.source == revision.source,
                    CorporateActionRevisionRecord.event_id == revision.event_id,
                    CorporateActionRevisionRecord.revision == revision.revision,
                ))
                if existing is not None:
                    existing_recorded = existing.recorded_at
                    candidate_recorded = revision.recorded_at
                    if existing_recorded.tzinfo is None or existing_recorded.utcoffset() is None:
                        from datetime import timezone
                        existing_recorded = existing_recorded.replace(tzinfo=timezone.utc)
                    same = (
                        existing_recorded == candidate_recorded
                        and existing.status == revision.status
                        and existing.event_payload == payload
                    )
                    if same:
                        return False
                    raise CorporateActionRepositoryError(
                        "Conflit : une révision immuable existe déjà avec un contenu différent"
                    )
                latest = session.scalar(select(CorporateActionRevisionRecord).where(
                    CorporateActionRevisionRecord.source == revision.source,
                    CorporateActionRevisionRecord.event_id == revision.event_id,
                ).order_by(CorporateActionRevisionRecord.revision.desc()).limit(1).with_for_update())
                expected_revision = (latest.revision + 1) if latest is not None else 1
                if revision.revision != expected_revision:
                    raise CorporateActionRepositoryError(
                        f"Séquence de révision invalide : attendu {expected_revision}"
                    )
                if latest is not None:
                    latest_recorded = latest.recorded_at
                    if latest_recorded.tzinfo is None or latest_recorded.utcoffset() is None:
                        from datetime import timezone
                        latest_recorded = latest_recorded.replace(tzinfo=timezone.utc)
                    if revision.recorded_at < latest_recorded:
                        raise CorporateActionRepositoryError(
                            "Horodatage de révision antérieur à la révision précédente"
                        )
                session.add(CorporateActionRevisionRecord(
                    source=revision.source, event_id=revision.event_id,
                    revision=revision.revision, recorded_at=revision.recorded_at,
                    status=revision.status, event_payload=payload,
                ))
            return True
        except CorporateActionRepositoryError:
            raise
        except IntegrityError as exc:
            # Concurrent append of the same identity: fail closed; caller may reload.
            raise CorporateActionRepositoryError("Conflit concurrent sur l'identité de révision") from exc
        except Exception as exc:
            raise CorporateActionRepositoryError(
                f"Persistance de la révision impossible ({type(exc).__name__})"
            ) from exc

    def snapshot(self, *, as_of: datetime) -> tuple[CorporateActionEvent, ...]:
        if not isinstance(as_of, datetime) or as_of.tzinfo is None or as_of.utcoffset() is None:
            raise CorporateActionRepositoryError("as_of doit être horodaté avec fuseau")
        try:
            with self.session_factory() as session:
                rows = session.scalars(select(CorporateActionRevisionRecord).where(
                    CorporateActionRevisionRecord.recorded_at <= as_of
                ).order_by(
                    CorporateActionRevisionRecord.source,
                    CorporateActionRevisionRecord.event_id,
                    CorporateActionRevisionRecord.revision,
                )).all()
                revisions = tuple(_row_to_revision(row) for row in rows)
            return corporate_action_snapshot(revisions, as_of=as_of)
        except (CorporateActionError, CorporateActionRepositoryError):
            raise
        except Exception as exc:
            raise CorporateActionRepositoryError(
                f"Lecture du registre impossible ({type(exc).__name__})"
            ) from exc

    def storage_readiness(self) -> dict:
        """Verify the durable schema and PostgreSQL append-only trigger fail-closed."""
        required_columns = {
            "id", "source", "event_id", "revision", "recorded_at", "status", "event_payload"
        }
        required_checks = {
            "ck_corporate_action_revision_positive",
            "ck_corporate_action_revision_status",
            "ck_corporate_action_revision_payload_status",
        }
        issues = []
        try:
            with self.session_factory() as session:
                bind = session.get_bind()
                inspector = inspect(bind)
                table = "corporate_action_revisions"
                if not inspector.has_table(table):
                    return {
                        "ready": False, "dialect": bind.dialect.name,
                        "append_only_enforced": False,
                        "issues": ["table corporate_action_revisions absente"],
                    }
                columns = {column["name"] for column in inspector.get_columns(table)}
                if not required_columns.issubset(columns):
                    issues.append("colonnes du registre incomplètes")
                unique_sets = {
                    tuple(item.get("column_names") or ())
                    for item in inspector.get_unique_constraints(table)
                }
                if ("source", "event_id", "revision") not in unique_sets:
                    issues.append("contrainte unique source/event_id/revision absente")
                checks = {
                    item.get("name") for item in inspector.get_check_constraints(table)
                }
                if not required_checks.issubset(checks):
                    issues.append("contraintes CHECK du registre incomplètes")
                append_only_enforced = False
                if bind.dialect.name == "postgresql":
                    trigger = session.scalar(text("""
                        SELECT EXISTS (
                            SELECT 1
                            FROM pg_trigger t
                            JOIN pg_class c ON c.oid = t.tgrelid
                            JOIN pg_namespace n ON n.oid = c.relnamespace
                            WHERE c.relname = :table_name
                              AND n.nspname = current_schema()
                              AND t.tgname = 'trg_corporate_action_revisions_append_only'
                              AND NOT t.tgisinternal
                              AND t.tgenabled <> 'D'
                        )
                    """), {"table_name": table})
                    append_only_enforced = bool(trigger)
                    if not append_only_enforced:
                        issues.append("trigger PostgreSQL append-only absent ou désactivé")
                else:
                    issues.append("dialecte non PostgreSQL : immutabilité DB non vérifiée")
                return {
                    "ready": not issues,
                    "dialect": bind.dialect.name,
                    "append_only_enforced": append_only_enforced,
                    "issues": issues,
                }
        except Exception as exc:
            return {
                "ready": False, "dialect": None,
                "append_only_enforced": False,
                "issues": [f"inspection du registre impossible ({type(exc).__name__})"],
            }

    def latest_revision(self, *, source: str, event_id: str) -> CorporateActionRevision | None:
        """Return the latest durable revision for one provider event identity."""
        if not isinstance(source, str) or not source.strip() or not isinstance(event_id, str) or not event_id.strip():
            raise CorporateActionRepositoryError("Identité source/event_id invalide")
        try:
            with self.session_factory() as session:
                row = session.scalar(select(CorporateActionRevisionRecord).where(
                    CorporateActionRevisionRecord.source == source,
                    CorporateActionRevisionRecord.event_id == event_id,
                ).order_by(CorporateActionRevisionRecord.revision.desc()).limit(1))
                return _row_to_revision(row) if row is not None else None
        except Exception as exc:
            raise CorporateActionRepositoryError(
                f"Lecture de la dernière révision impossible ({type(exc).__name__})"
            ) from exc

    def count_revisions(self) -> int:
        from sqlalchemy import func
        try:
            with self.session_factory() as session:
                return int(session.scalar(select(func.count()).select_from(CorporateActionRevisionRecord)) or 0)
        except Exception as exc:
            raise CorporateActionRepositoryError(
                f"Comptage du registre impossible ({type(exc).__name__})"
            ) from exc
