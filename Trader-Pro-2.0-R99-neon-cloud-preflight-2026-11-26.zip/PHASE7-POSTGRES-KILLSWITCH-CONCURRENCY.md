# Phase 7 — PostgreSQL kill-switch concurrency hardening

Date: 11 November 2026

## Change

`OrderRepository.set_operational_pause()` now locks the durable singleton row with `SELECT ... FOR UPDATE` before updating it and writing its append-only audit event. PostgreSQL serializes competing transitions on this row. A missing singleton is no longer silently recreated by runtime control code: the migration must seed it, reads fail closed, and attempted writes raise `OrderRepositoryError`.

The PostgreSQL integration suite now includes a six-writer concurrent transition check. It verifies that every completed transition leaves a corresponding audit record. The schema/precision test was also corrected so its uniqueness assertion only passes when the duplicate broker-fill insert itself raises `IntegrityError`.

## Local verification

- `python -m pytest -q`: **410 passed, 5 skipped, 88 subtests passed**.
- `python -m unittest discover -q`: **406 tests passed**.
- `python -m compileall -q .`: passed.
- `bash -n scripts/verify_postgres.sh`: passed.

## External verification still required

The five skipped checks require `TRADER_PRO_TEST_DATABASE_URL` and a disposable PostgreSQL test database. No PostgreSQL server/client, Docker/Podman runtime, or psycopg driver is installed in this environment. Therefore `SELECT FOR UPDATE`, real concurrent transactions, PostgreSQL migration behavior, and backup/restore have not been executed here. Run `scripts/verify_postgres.sh` against separate disposable `_test` and `_restore` databases before closing this gate.

Paper trading and live broker execution were not invoked. Live remains disabled.
